package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ReportedException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.ServerException;
import com.santanderuk.corinthian.services.retentions.api.model.riskvaluation.RiskValuationCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.riskvaluation.RiskValuationCoreResponseWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class RiskValuationClient {

    private final RestTemplate restTemplate;

    @Value("${service.core.riskvaluation}")
    private String riskValuationCoreUrl;
    @Value("${apimanager.client-id-header-key}")
    private String clientIdHeaderKey;
    @Value("${apimanager.client-id-value}")
    private String clientIdValue;

    public RiskValuationClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public RiskValuationCoreResponse fetchRiskValuation(int accountNumber) throws ReportedException, ConnectionException {
        try {
            log.info("RiskValuationClient - > request received");

            HttpHeaders headers = new HttpHeaders();
            headers.add(clientIdHeaderKey, clientIdValue);
            headers.add(ACCEPT, APPLICATION_JSON_VALUE);
            headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);

            HttpEntity<HttpHeaders> requestEntity = new HttpEntity<>(headers);

            String url = String.format("%s/%s", riskValuationCoreUrl, accountNumber);

            log.info("Calling risk valuation url : {}", url);

            ResponseEntity<RiskValuationCoreResponseWrapper> response = restTemplate.exchange(url, GET, requestEntity, RiskValuationCoreResponseWrapper.class);
            log.debug("response body {}", response.getBody());

            if (response.getStatusCodeValue() == 204 || (response.getStatusCodeValue() == 200 && Objects.requireNonNull(response.getBody()).getStatus().equals("ACCOUNT_NOT_FOUND"))) {
                log.warn("Account_Not_Found in Risk Valuation table");
                throw new ServerException("ACCOUNT_NOT_FOUND", "Account Not Found in Risk Valuation table");
            }
            RiskValuationCoreResponse riskValuationCoreResponse = response.getBody().getData();
            if (riskValuationCoreResponse.getCalculatedValuation() == null || riskValuationCoreResponse.getCalculatedValuation() == 0) {
                log.warn("Zero_Valuation {}", response.getBody().getMessage());
                throw new ReportedException("RISK_CORE_NOT_FOUND", "Risk valuation core returned empty or zero valuation");
            }
            return riskValuationCoreResponse;
        } catch (HttpServerErrorException e) {
            log.error("Error while calling Risk Valuation Core Service", e);
            throw new ConnectionException(ConnectionException.Type.RISK_CORE_CONNECTION, e);
        }

    }
}

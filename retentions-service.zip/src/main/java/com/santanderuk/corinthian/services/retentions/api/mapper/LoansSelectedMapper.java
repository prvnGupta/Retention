package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.retentions.api.exceptions.NoDealsFoundException;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;

public class LoansSelectedMapper {

    private final List<Loan> matchedLoans;
    private final List<Loan> unmatchedLoans;

    public LoansSelectedMapper(DealsRequest selectedLoans, EligibilityResponse eligibilityResponse) throws NoDealsFoundException {
        this.matchedLoans = new ArrayList<>();
        this.unmatchedLoans = new ArrayList<>();

        buildLists(selectedLoans, eligibilityResponse);
    }

    final void buildLists(DealsRequest selectedLoans, EligibilityResponse eligibilityResponse) throws NoDealsFoundException {

        List<Loan> eligibleLoanDeals = eligibilityResponse.getLoans();

        eligibleLoanDeals.forEach(eligibleLoan -> {
            eligibleLoan.setPaymentDate(eligibilityResponse.getNextPaymentDate());
            if (hasFoundEligibleMatch(eligibleLoan, selectedLoans)) {
                eligibleLoan.setSelected(true);
                matchedLoans.add(eligibleLoan);
            } else {
                unmatchedLoans.add(eligibleLoan);
            }
        });
        if (CollectionUtils.isEmpty(this.matchedLoans)) {
            throw new NoDealsFoundException("No deals available for selected loan(s)");
        }
    }

    private boolean hasFoundEligibleMatch(Loan eligibleLoanMatch, DealsRequest selectedLoans) {
        long loansIdSelected = selectedLoans.getLoansSelected().stream()
                .filter(selectedLoan -> selectedLoan.getLoanScheme().equals(eligibleLoanMatch.getScheme()) &&
                        selectedLoan.getSequenceNumber() == eligibleLoanMatch.getSequenceNumber())
                .count();
        return loansIdSelected > 0;
    }

    public BigDecimal totalMonthlyPaymentOfNotSelectedLoans() {
        return unmatchedLoans.stream().map(Loan::getMonthlyPayment).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public int getShortestTermOfMatchedLoans() {
        OptionalInt shortestLoanTerm = matchedLoans.stream().mapToInt(Loan::getRemainingTerm).min();

        return shortestLoanTerm.isPresent() ? shortestLoanTerm.getAsInt() : 0;
    }

    public List<Loan> getSelectedLoans() {
        return new ArrayList<>(this.matchedLoans);
    }

    public List<Loan> getNotSelectedLoans() {
        return new ArrayList<>(this.unmatchedLoans);
    }
}

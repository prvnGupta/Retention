package com.santanderuk.corinthian.services.retentions.api.rules.loan;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;

@Component
public class LoanOutsideDealWindow implements LoanRule {

    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse) {
        eligibilityResponse.getLoans().forEach(loan -> {
            odmEligibilityResponse.getAccountResponse().getLoanResponse().forEach(odmLoanResponse -> {
                if (loansMatch(loan, odmLoanResponse)) {
                    isBlocked(odmLoanResponse, loan);
                }
            });
        });
    }

    @Override
    public void isBlocked(ODMLoanResponse odmLoanResponse, Loan loan) {
        if (odmLoanResponse.getTermEligibility().equalsIgnoreCase("N")) {
            loan.getBlockers().setOutsideDealWindow(true);
            loan.setEligibleToTransfer(false);
        }
    }
}

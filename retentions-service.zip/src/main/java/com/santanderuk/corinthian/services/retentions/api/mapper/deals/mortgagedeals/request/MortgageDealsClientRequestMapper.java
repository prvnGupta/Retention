package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import org.springframework.stereotype.Component;

@Component
public class MortgageDealsClientRequestMapper {

    private final MortgageDealsClientLoanRequestMapper loanRequestMapper;

    public MortgageDealsClientRequestMapper(MortgageDealsClientLoanRequestMapper loanRequestMapper) {

        this.loanRequestMapper = loanRequestMapper;
    }

    public MortgageDealsClientRequest create(MapperSourceData mapperSourceData) {
        var request = new MortgageDealsClientRequest();

        request.setAccountNumber(String.valueOf(mapperSourceData.getAccount()));
        request.setSalesChannel("Digital");
        request.setBuyToLet(isBuyToLet(mapperSourceData));
        request.setConsentToLet(isConsentToLet(mapperSourceData));
        request.setFlexi(isFlexi(mapperSourceData));
        request.setLoans(loanRequestMapper.create(mapperSourceData));

        return request;
    }

    private boolean isBuyToLet(MapperSourceData data) {
        var oSpecialPurchase = data.getAnmfPropertyResponse()
                .getPropertyEnquiryResponse()
                .getOutputStructure()
                .getOSpecialPurchase();

        return "L".equalsIgnoreCase(oSpecialPurchase);
    }

    private boolean isConsentToLet(MapperSourceData data) {
        var oConsentToLet = data.getAnmfPropertyResponse().getPropertyEnquiryResponse()
                .getOutputStructure()
                .getOConsentToLet();

        return "Y".equalsIgnoreCase(oConsentToLet);
    }

    private boolean isFlexi(MapperSourceData data) {
        var oFlexiInd = data.getAccountServiceResponse().getAccountServiceResponse()
                .getResponse()
                .getOStruc()
                .getOFlexiInd();

        return "Y".equalsIgnoreCase(oFlexiInd);
    }
}

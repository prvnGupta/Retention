package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.Loan;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import org.springframework.stereotype.Component;

import java.util.NoSuchElementException;

@Component
public class LongestTermFinder {

    public int get(MortgageDealsClientRequest mortgageDealsClientRequest) {

        return mortgageDealsClientRequest.getLoans().stream()
                .map(Loan::getRemainingInstalments)
                .mapToInt(x -> x)
                .max()
                .orElseThrow(NoSuchElementException::new);
    }
}

package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.model.esis.RetrieveEsisResponse;
import com.santanderuk.corinthian.services.retentions.config.Config;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static com.santanderuk.corinthian.services.commons.exceptions.ConnectionException.Type.ESIS_CONNECTION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class EsisClient {

    private final RestTemplate restTemplate;
    private final Config config;
    private final ApiManagerConfig apiManagerConfig;

    public EsisClient(RestTemplate restTemplate, Config config, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.config = config;
        this.apiManagerConfig = apiManagerConfig;
    }

    public RetrieveEsisResponse retrieveOffer(String esisRefId) throws ConnectionException {

        String parameterisedUrl = config.getRetrieveOfferUrl().replace("{esisRefId}", esisRefId);
        HttpEntity<Void> entity = new HttpEntity<>(generateRequestHeaders());

        try {
            ResponseEntity<RetrieveEsisResponse> response = restTemplate.exchange(parameterisedUrl, HttpMethod.GET, entity, RetrieveEsisResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            throw new ConnectionException(ESIS_CONNECTION, e);
        }
    }

    protected MultiValueMap<String, String> generateRequestHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-CLIENT-ID", apiManagerConfig.getClientIdValue());
        headers.add("X-IBM-CLIENT-SECRET", apiManagerConfig.getClientSecretValue());
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }
}

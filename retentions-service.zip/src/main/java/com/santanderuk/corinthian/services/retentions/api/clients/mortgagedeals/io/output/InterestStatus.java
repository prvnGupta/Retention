package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

public enum InterestStatus {
    Higher,
    Same,
    Lower
}

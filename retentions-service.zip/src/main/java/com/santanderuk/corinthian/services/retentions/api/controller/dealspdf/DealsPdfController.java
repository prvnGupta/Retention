package com.santanderuk.corinthian.services.retentions.api.controller.dealspdf;

import com.lowagie.text.DocumentException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.retentions.api.controller.BaseController;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.service.dealspdf.PDFService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@Slf4j
public class DealsPdfController extends BaseController {

    private final PDFService pdfService;

    @Autowired
    public DealsPdfController(PDFService pdfService) {
        this.pdfService = pdfService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to return a pdf document with available mortgage retentions deals for one mortgage account",
            nickname = "generateDealsPdf",
            notes = "This endpoint is used by Corinthian frontend application to get a pdf document with available mortgage retentions deals for one mortgage account. It uses mortgage deals core api"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PostMapping(
            value = "/{accountNumber}/deals-pdf",
            produces = MediaType.APPLICATION_PDF_VALUE,
            consumes = APPLICATION_JSON_VALUE
    )
    public ResponseEntity<InputStreamResource> generateDealsPdf(
            @RequestBody DealsRequest selectedLoans,
            @PathVariable int accountNumber,
            @RequestHeader(name = "Authorization") String jwtToken) throws GeneralException, DocumentException, IOException {
        log.info("/{accountNumber}/deals-pdf request received");
        log.debug("/{accountNumber}/deals-pdf received. Account: {}", accountNumber);
        log.debug("Jwt: {}", sanitizeString(jwtToken));

        var pdf = pdfService.createDealsPdf(jwtToken, accountNumber, selectedLoans);

        return new ResponseEntity<>(pdf, buildHeaders(), HttpStatus.CREATED);
    }

    private HttpHeaders buildHeaders() {

        var currentDate = LocalDate.now();
        var formatter = DateTimeFormatter.ofPattern("dd-MMMM-yyyy");
        var formattedString = currentDate.format(formatter);

        var headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.builder("attachment").filename(String.format("YourDealsAsOf-%s.pdf", formattedString)).build());
        return headers;
    }

}

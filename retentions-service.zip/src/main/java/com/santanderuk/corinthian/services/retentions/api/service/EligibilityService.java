package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.productdirectory.ProductDirectoryResponse;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.clients.ODMClient;
import com.santanderuk.corinthian.services.retentions.api.clients.RiskValuationClient;
import com.santanderuk.corinthian.services.retentions.api.mapper.EligibilityMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.ODMMapper;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.OdmRequestWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.riskvaluation.RiskValuationCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.AccountEligibilityRule;
import com.santanderuk.corinthian.services.retentions.api.rules.account.ODMEligibilityRule;
import com.santanderuk.corinthian.services.retentions.api.rules.bespoke.BespokeRule;
import com.santanderuk.corinthian.services.retentions.api.rules.loan.LoanRule;
import com.santanderuk.corinthian.services.retentions.api.validation.EligibilityFormatValidation;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static java.util.Collections.unmodifiableList;

@Service
@Slf4j
public class EligibilityService {

    private final ODMClient odmClient;
    private final AnmfCoreClient anmfClient;
    private final RiskValuationClient riskValuationClient;
    private final ODMMapper odmMapper;
    private final EligibilityMapper eligibilityMapper;
    private final List<ODMEligibilityRule> allEligiblityODMEligibilityRules;
    private final List<AccountEligibilityRule> allAccountEligibilityRules;
    private final List<LoanRule> allLoanRules;
    private final List<BespokeRule> bespokeRules;
    private final CacheableOperations cacheableOperations;
    private final OperativeSecurityService operativeSecurityService;
    private final AnmfCoreResponseBuilder anmfCoreResponseBuilder;
    private final EligibilityFormatValidation formatValidation;
    private final AnmfConfiguration anmfConfiguration;

    private final ProductDirectoryService productDirectoryService;

    @Autowired
    public EligibilityService(ODMClient odmClient, AnmfCoreClient anmfClient, RiskValuationClient riskValuationClient,
                              ODMMapper odmMapper, EligibilityMapper eligibilityMapper,
                              List<ODMEligibilityRule> allEligiblityODMEligibilityRules, List<AccountEligibilityRule> allAccountEligibilityRules,
                              List<LoanRule> allLoanRules, List<BespokeRule> bespokeRules, CacheableOperations cacheableOperations,
                              OperativeSecurityService operativeSecurityService, AnmfCoreResponseBuilder anmfCoreResponseBuilder,
                              EligibilityFormatValidation formatValidation,
                              AnmfConfiguration anmfConfiguration, ProductDirectoryService productDirectoryService) {
        this.odmClient = odmClient;
        this.anmfClient = anmfClient;
        this.riskValuationClient = riskValuationClient;
        this.odmMapper = odmMapper;
        this.eligibilityMapper = eligibilityMapper;
        this.allEligiblityODMEligibilityRules = unmodifiableList(allEligiblityODMEligibilityRules);
        this.allAccountEligibilityRules = unmodifiableList(allAccountEligibilityRules);
        this.allLoanRules = unmodifiableList(allLoanRules);
        this.bespokeRules = unmodifiableList(bespokeRules);
        this.cacheableOperations = cacheableOperations;
        this.operativeSecurityService = operativeSecurityService;
        this.anmfCoreResponseBuilder = anmfCoreResponseBuilder;
        this.formatValidation = formatValidation;
        this.anmfConfiguration = anmfConfiguration;
        this.productDirectoryService = productDirectoryService;

    }

    public EligibilityResponse fetchEligibilityByLoan(int accountNumber, String jwtToken) throws MaintenanceException, ConnectionException, ReportedException, OperativeSecurityException, ValidationsException {

        formatValidation.validate(accountNumber);

        AnmfRegion region = cacheableOperations.getAnmfActiveRegion();

        operativeSecurityService.checkAnmfAccountBelongToCustomerInJwt(accountNumber, jwtToken, region);

        AnmfCoreResponse anmfCoreResponse = getAnmfResponses(accountNumber, region);

        return useOdmAndRulesForBuildingEligibilityResponse(accountNumber, anmfCoreResponse);
    }

    private EligibilityResponse useOdmAndRulesForBuildingEligibilityResponse(int accountNumber, AnmfCoreResponse anmfCoreResponse) throws ReportedException, ConnectionException, ValidationsException {
        ProductDirectoryResponse productDirectoryResponse = productDirectoryService.getCompletionAndNearestDate(accountNumber);
        OdmEligibilityResponse odmEligibilityResponse = getOdmEligibilityResponse(accountNumber, anmfCoreResponse, productDirectoryResponse);
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(anmfCoreResponse, odmEligibilityResponse, productDirectoryResponse);
        runRules(anmfCoreResponse, odmEligibilityResponse, eligibilityResponse);
        return eligibilityResponse;
    }

    private void runRules(AnmfCoreResponse anmfCoreResponse, OdmEligibilityResponse odmEligibilityResponse, EligibilityResponse eligibilityResponse) {
        allLoanRules.forEach(loanRule -> loanRule.isEligible(eligibilityResponse, odmEligibilityResponse));
        allEligiblityODMEligibilityRules.forEach(eligibilityAccountRule -> eligibilityAccountRule.isEligible(eligibilityResponse, odmEligibilityResponse));
        allAccountEligibilityRules.forEach(eligibilityAccountRule -> eligibilityAccountRule.isEligible(eligibilityResponse, anmfCoreResponse, odmEligibilityResponse));
        bespokeRules.forEach(bespokeRule -> bespokeRule.isEligible(eligibilityResponse, anmfCoreResponse));
    }

    private OdmEligibilityResponse getOdmEligibilityResponse(int accountNumber, AnmfCoreResponse anmfCoreResponse, ProductDirectoryResponse productDirectoryResponse) throws ReportedException, ConnectionException {
        RiskValuationCoreResponse riskValuationCoreResponse = riskValuationClient.fetchRiskValuation(accountNumber);

        OdmRequestWrapper odmRequest = odmMapper.toOdm(accountNumber, anmfCoreResponse, riskValuationCoreResponse, productDirectoryResponse);

        return odmClient.fetchMortgageEligibilityCoreResponse(odmRequest);
    }

    private AnmfCoreResponse getAnmfResponses(int accountNumber, AnmfRegion region) throws ConnectionException, ReportedException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = anmfClient.fetchMortgageAccountDetailsV5(accountNumber, anmfConfiguration.getAnmfAccountDetailsUrl(), region);
        verifyAccountInfoResponse(anmfAccountServiceResponse);

        ANMFPropertyResponse anmfAddressResponse = anmfClient.fetchAddress(accountNumber, anmfConfiguration.getAnmfPropertyUrl(), region);

        return anmfCoreResponseBuilder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);
    }

    private EligibilityResponse buildEligibilityResponse(AnmfCoreResponse anmfCoreResponse, OdmEligibilityResponse odmEligibilityResponse, ProductDirectoryResponse productCompletionDate) {
        EligibilityResponse eligibilityResponse = eligibilityMapper.toEligibilityResponse(odmEligibilityResponse);
        eligibilityResponse.setLoans(anmfCoreResponse.getLoans());
        eligibilityResponse.setBandId(odmEligibilityResponse.getAccountResponse().getAccountBand());
        eligibilityResponse.setNextPaymentDate(anmfCoreResponse.getNextPaymentDate());
        eligibilityResponse.setProductCompletionDate(DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDate.parse(productCompletionDate.getFarthestCompletionDate())));

        return eligibilityResponse;
    }

    private void verifyAccountInfoResponse(AnmfAccountServiceResponse accountsDetailsV4) throws ReportedException {
        String anmfErrorCode = accountsDetailsV4.getAccountServiceResponse().getResponse().getOStruc().getEStruc().getECode();
        if (anmfErrorCode.length() != 0) {
            log.error("AnmfClient - > Error received from ANMF with error code: \"{}\" Complete message received from ANMF: {}", anmfErrorCode, accountsDetailsV4);
            throw new ReportedException(anmfErrorCode, accountsDetailsV4.getAccountServiceResponse().getResponse().getOStruc().getEStruc().getEMessage());
        }
    }
}

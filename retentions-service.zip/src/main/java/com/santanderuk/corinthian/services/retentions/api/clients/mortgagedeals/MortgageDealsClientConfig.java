package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Configuration
public class MortgageDealsClientConfig {

    @Value("${apimanager.client-id-value}")
    private String xIbmConfigId;

    @Value("${apimanager.client-secret-value}")
    private String xIbmConfigSecret;

    @Value("${mortgage-deals.products.url}")
    private String url;

}

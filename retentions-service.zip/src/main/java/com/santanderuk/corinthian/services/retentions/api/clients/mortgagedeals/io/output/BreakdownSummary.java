package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BreakdownSummary extends ModelBase {

    private static final long serialVersionUID = 1634559913260856500L;

    private int feeAddedId;
    private BreakdownSummaryFee withFee;
    private BreakdownSummaryFee withoutFee;
}

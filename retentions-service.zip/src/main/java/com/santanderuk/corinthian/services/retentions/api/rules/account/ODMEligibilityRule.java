package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;

public interface ODMEligibilityRule {

    void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse);
}

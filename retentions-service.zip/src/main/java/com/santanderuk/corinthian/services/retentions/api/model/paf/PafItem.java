package com.santanderuk.corinthian.services.retentions.api.model.paf;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PafItem {

    private String id, type, text, highlight, description;
}

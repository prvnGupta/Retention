package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.Borrower;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.BorrowerCorrespondenceAddress;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.service.PafService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class CoreRetentionMapperAccountBorrowers {

    private final PafService pafService;

    public CoreRetentionMapperAccountBorrowers(PafService pafService) {
        this.pafService = pafService;
    }

    public void map(CoreRetentionRequest coreRetentionRequest, CoreRetentionsData input) {

        List<Borrower> borrowers = input.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc()
                .getOCustomerList().stream()
                .map(customerList -> convertToCoreRetentionBorrower(customerList, input))
                .collect(Collectors.toList());

        coreRetentionRequest.getAccount().setBorrowers(borrowers);
    }

    private Borrower convertToCoreRetentionBorrower(OCustomer customerToConvert, CoreRetentionsData input) {
        Borrower borrower = new Borrower();

        boolean leadCustomerIndicator = isLeadCustomerIndicator(customerToConvert, input);

        borrower.setLeadCustomerInd(leadCustomerIndicator);
        borrower.setTitle(customerToConvert.getOCustomerTitle());
        borrower.setInitials(customerToConvert.getOInitials().replaceAll(" ", ""));
        borrower.setForename(
                customerToConvert.getOForename1() + " " +
                        customerToConvert.getOForename2() + " " +
                        customerToConvert.getOForename3()
        );

        borrower.setSurname(customerToConvert.getOSurname());
        borrower.setStaffInd("Y".equalsIgnoreCase(customerToConvert.getOStaffMortgage()));
        borrower.setDateOfBirth(formatDate(customerToConvert.getODateOfBirth()));
        borrower.setBdpCustomerType(customerToConvert.getOBdpType());
        borrower.setBdpCustomerNumber(String.valueOf(customerToConvert.getOCustomerId()));
        borrower.setHomeTelNumber(customerToConvert.getOHomePhone());
        borrower.setBorrowerCorrespondenceAddress(generateCorrespondenceAddress(customerToConvert));

        if (leadCustomerIndicator) {
            String inputEmail = input.getCaseRequest().getEmailAddress();
            borrower.setEmailAddress(MapCorrectEmailAddress(customerToConvert, inputEmail));
            String inputMobileNumber = input.getCaseRequest().getMobileNumber();
            borrower.setMobileTelNumber(null == inputMobileNumber ? "" : inputMobileNumber);
        } else {
            borrower.setEmailAddress(customerToConvert.getOEMailAddress());
            borrower.setMobileTelNumber(customerToConvert.getOMobilePhone());
        }
        return borrower;
    }

    private String MapCorrectEmailAddress(OCustomer customerToConvert, String inputEmail) {

        if (null == inputEmail || inputEmail.trim().equalsIgnoreCase("")) {
            return customerToConvert.getOEMailAddress();
        } else {
            return inputEmail.trim().toLowerCase();
        }
    }

    private BorrowerCorrespondenceAddress generateCorrespondenceAddress(OCustomer customerToConvert) {

        String country;
        if (StringUtils.isEmpty(customerToConvert.getOCorrespPostcode())) {

            country = customerToConvert.getOCorrespCountry();
        } else {

            country = pafService.fetchCountry(customerToConvert.getOCorrespPostcode());
        }

        BorrowerCorrespondenceAddress borrowerCorrespondenceAddress = new BorrowerCorrespondenceAddress();
        borrowerCorrespondenceAddress.setAddressLine1(customerToConvert.getOCorrespAddr1());
        borrowerCorrespondenceAddress.setAddressLine2("");
        borrowerCorrespondenceAddress.setAddressLine3("");
        borrowerCorrespondenceAddress.setAddressLine4(customerToConvert.getOCorrespAddr2());
        borrowerCorrespondenceAddress.setAddressLine5("");
        borrowerCorrespondenceAddress.setAddressLine6(customerToConvert.getOCorrespAddr3());
        borrowerCorrespondenceAddress.setAddressLine7("");
        borrowerCorrespondenceAddress.setAddressLine8(country);
        borrowerCorrespondenceAddress.setAddressLine9(customerToConvert.getOCorrespPostcode());
        borrowerCorrespondenceAddress.setPostcode(customerToConvert.getOCorrespPostcode());
        borrowerCorrespondenceAddress.setCorrespondenceAddressChangedInd(false);

        return borrowerCorrespondenceAddress;
    }

    private String formatDate(String oDateOfBirth) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate productEndDateLocalDate = LocalDate.parse(oDateOfBirth, formatter);
        return productEndDateLocalDate.toString();
    }

    private boolean isLeadCustomerIndicator(OCustomer customerToConvert, CoreRetentionsData input) {
        boolean sameBdpType = customerToConvert.getOBdpType().equalsIgnoreCase(input.getBdpType());
        boolean samebdpNumber = customerToConvert.getOCustomerId() == input.getBdpNumber();
        return samebdpNumber && sameBdpType;
    }
}

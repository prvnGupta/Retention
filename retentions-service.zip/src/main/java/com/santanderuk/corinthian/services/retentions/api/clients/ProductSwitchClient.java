package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.exceptions.UpdateFeeException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.gass.OfferInfoResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.generate.AcceptInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.UpdateOfferInfoRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.UpdateOfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.ProductTransferFeePayment;
import com.santanderuk.corinthian.services.retentions.config.Config;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class ProductSwitchClient {

    private final RestTemplate restTemplate;
    private final RestTemplate retrieveOfferInfoRestTemplate;
    private final Config config;
    private final ApiManagerConfig apiManagerConfig;
    private final InternalTransferConfig internalTransferConfig;

    public ProductSwitchClient(RestTemplate restTemplate, RestTemplate retrieveOfferInfoRestTemplate, Config config, ApiManagerConfig apiManagerConfig, InternalTransferConfig internalTransferConfig) {
        this.restTemplate = restTemplate;
        this.retrieveOfferInfoRestTemplate = retrieveOfferInfoRestTemplate;
        this.config = config;
        this.apiManagerConfig = apiManagerConfig;
        this.internalTransferConfig = internalTransferConfig;
    }

    public UpdateOfferInfoResponse sendUpdateRequest(int accountNumber, String esisRefId) throws ConnectionException {

        HttpEntity<UpdateOfferInfoRequest> request = buildRequest(accountNumber);
        String url = addEsisRefIdToUrl(config.getUpdateOfferInfoUrl(), esisRefId);

        try {
            ResponseEntity<UpdateOfferInfoResponse> responseEntity = restTemplate.exchange(url, PUT, request, UpdateOfferInfoResponse.class);
            return responseEntity.getBody();
        } catch (RestClientException e) {
            throw new ConnectionException(ConnectionException.Type.PRODUCT_SWITCH_CONNECTION, e);
        }
    }

    public OfferInfoResponse retrieveOfferInfo(String esisRefId) throws ConnectionException {

        HttpEntity<Void> entity = new HttpEntity<>(generateRequestHeaders());
        String url = addEsisRefIdToUrl(config.getRetrieveOfferInfoUrl(), esisRefId);

        try {
            ResponseEntity<OfferInfoResponse> responseEntity = retrieveOfferInfoRestTemplate.exchange(url, GET, entity, OfferInfoResponse.class);
            return responseEntity.getBody();
        } catch (RestClientException e) {
            throw new ConnectionException(ConnectionException.Type.PRODUCT_SWITCH_CONNECTION, e);
        }
    }

    public ServiceInfo acceptLater(String caseId) throws ConnectionException {

        HttpEntity<Void> entity = new HttpEntity<>(generateRequestHeaders());
        String url = addCaseIdToUrl(config.getAcceptLaterUrl(), caseId);

        try {
            ResponseEntity<ServiceInfo> responseEntity = restTemplate.exchange(url, PUT, entity, ServiceInfo.class);
            return responseEntity.getBody();
        } catch (RestClientException e) {
            throw new ConnectionException(ConnectionException.Type.PRODUCT_SWITCH_CONNECTION, e);
        }
    }

    public ServiceInfo acceptInSession(String caseId) throws ConnectionException {

        AcceptInSessionRequest body = new AcceptInSessionRequest();
        body.setSetWorkflowType(config.getWorkflowType());
        HttpEntity<AcceptInSessionRequest> entity = new HttpEntity<>(body, generateRequestHeaders());
        String url = addCaseIdToUrl(config.getAcceptInSessionUrl(), caseId);

        try {
            ResponseEntity<ServiceInfo> responseEntity = restTemplate.exchange(url, POST, entity, ServiceInfo.class);
            return responseEntity.getBody();
        } catch (RestClientException e) {
            throw new ConnectionException(ConnectionException.Type.PRODUCT_SWITCH_CONNECTION, e);
        }
    }

    public void callUpdateFee(String caseId, ProductTransferFeePayment feePaymentRequest) throws UpdateFeeException {

        HttpEntity<ProductTransferFeePayment> httpEntity = new HttpEntity<>(feePaymentRequest, generateRequestHeaders());
        try {
            log.info("About to call product-switch-service for update-fee");
            log.debug("UpdateFee Request: {}", feePaymentRequest.toString().replaceAll("[\r\n]", ""));

            String updateFeeUrl = internalTransferConfig.getFeePaymentEndpoint().replace("{caseId}", caseId);
            log.debug("Calling endpoint: {}", updateFeeUrl.replaceAll("[\r\n]", ""));

            restTemplate.postForEntity(updateFeeUrl, httpEntity, Void.class);
        } catch (Exception ex) {
            log.error("Exception while calling product-switch-service for update-fee", ex);
            throw new UpdateFeeException("Exception while calling product-switch-service for update-fee", ex);
        }
    }

    private HttpEntity<UpdateOfferInfoRequest> buildRequest(int accountNumber) {
        UpdateOfferInfoRequest request = new UpdateOfferInfoRequest();
        request.setAccountNumber(preffixAccountWithANMF(accountNumber));
        return new HttpEntity<>(request, generateRequestHeaders());
    }

    private String addEsisRefIdToUrl(String baseUrl, String esisRefId) {
        return baseUrl.replace("{esisRefId}", esisRefId);
    }

    private String addCaseIdToUrl(String baseUrl, String caseId) {
        return baseUrl.replace("{caseId}", caseId);
    }

    protected MultiValueMap<String, String> generateRequestHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }

    public void saveCoreRetentionsDataInDB(CoreRetentionsData coreRetentionsData, String esisRefId) throws ConnectionException {
        log.info("ProductSwitchClient - > saving Core Retentions Data to Table request received");
        String url = config.getSaveRetentionDataUrl().replace("{esisRefId}", esisRefId);
        HttpEntity<CoreRetentionsData> requestEntity = new HttpEntity<>(coreRetentionsData, generateRequestHeaders());
        try {
            log.debug("Calling saving Core Retentions Data service: {}", url);
            log.debug("Object to be sent to save retentions data is {}", coreRetentionsData);

            ResponseEntity<OfferInfoResponseWrapper> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, OfferInfoResponseWrapper.class);
            log.debug("Response body from saving Core Retentions Data: {}", response.getBody());
        } catch (RestClientException e) {
            throw new ConnectionException(ConnectionException.Type.PRODUCT_SWITCH_CONNECTION, e);
        }
    }

    private String preffixAccountWithANMF(int accountNumber) {
        return "ANMF" + accountNumber;
    }
}

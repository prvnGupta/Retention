package com.santanderuk.corinthian.services.retentions.api.model.acceptandpay;

import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotBlank;

@Data
@EqualsAndHashCode(callSuper = true)
public class AcceptAndPayInSessionRequest extends ModelBase {
    @NotBlank(message = "accountFrom: invalid format")
    private String accountFrom;
}

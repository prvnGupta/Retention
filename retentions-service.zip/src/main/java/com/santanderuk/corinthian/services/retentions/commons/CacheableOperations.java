package com.santanderuk.corinthian.services.retentions.commons;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CacheableOperations {

    @Autowired
    private HeartBeatClient heartBeatClient;

    @Cacheable(cacheManager = "cacheManagerHeartbeat", value = "heartbeatRegion")
    public AnmfRegion getAnmfActiveRegion() throws MaintenanceException, ConnectionException {
        log.info("Calling heartbeat to get region");
        return heartBeatClient.fetchCurrentRegion();
    }
}

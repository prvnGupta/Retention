package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.GeneralInfo;
import org.springframework.stereotype.Component;

@Component
public class CoreRetentionMapperGeneralInformation {

    public void map(CoreRetentionRequest coreRetentionRequest) {
        GeneralInfo generalInformation = new GeneralInfo();

        generalInformation.setChannel("INT");
        generalInformation.setCentre("2822");
        generalInformation.setCompany("0015");
        generalInformation.setCurrency("GBP");
        generalInformation.setBusinessProcess("0070");
        generalInformation.setProductType("103");
        generalInformation.setProductSubType("707");
        generalInformation.setProductReference("0000001");

        coreRetentionRequest.setGeneralInformation(generalInformation);
    }
}

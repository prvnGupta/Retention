package com.santanderuk.corinthian.services.retentions.api.exceptions;

public class UpdateFeeException extends Exception {

    public UpdateFeeException(String msg) {
        super(msg);
    }

    public UpdateFeeException(String msg, Exception e) {
        super(msg, e);
    }
}

package com.santanderuk.corinthian.services.retentions.api.utils;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.InterestRateChange;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Component
public class ProductUtils {

    private final DateUtils dateUtils;

    public ProductUtils(DateUtils dateUtils) {
        this.dateUtils = dateUtils;
    }

    public boolean isFixedTerm(Loan loan) {
        return loan.getProductDescription().toLowerCase().contains("year");
    }

    public boolean isTracker(Loan loan) {
        return loan.getProductDescription().toLowerCase().contains("tracker");
    }


    public boolean isFixedTermProduct(Product product) {
        return !product.getTerm().trim().equalsIgnoreCase("lifetime");
    }

    public boolean isFixedInterest(Product product) {
        return product.getType().trim().equalsIgnoreCase("fixed");
    }

    public String calculateLoanSwitchDate(String productCompletionDate, DealLoanView loan) {
        String switchDate = "";

        if (loan.getInterestRateChange() == InterestRateChange.HIGHER) {
            String productCompletionDateAnmfFormat = changeDateFormatToAnmfFormat(productCompletionDate);
            if (loan.isCurrentProductFixedTermFlag()) {
                if (loan.isCurrentProductTrackerFlag() && dateUtils.date1SoonerThanDate2(productCompletionDateAnmfFormat, loan.getProductEndDate())) {
                    switchDate = dateUtils.subtractOneDay(productCompletionDateAnmfFormat);
                } else {
                    switchDate = dateUtils.addOneDay(loan.getProductEndDate());
                }
            } else {
                switchDate = dateUtils.subtractOneDay(productCompletionDateAnmfFormat);
            }
        }
        return switchDate;
    }

    private String changeDateFormatToAnmfFormat(String date) {
        try {
            LocalDate parsed = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH);
            return formatter.format(parsed);
        } catch (Exception e) {
            return date;
        }
    }

    public String calculateLoanSwitchingProductEndDate(DealLoanView loan, Product product) {
        if (!isFixedTermProduct(product)) {
            return loan.getProductEndDate();
        } else {
            if (isFixedInterest(product)) {
                return product.getChargeEndDate();
            } else {
                return calculateProductEndDateForTrackerProduct(product.getTerm());
            }
        }
    }


    private int extractMonthsFromTerm(String term) {
        String years = term.split(" ")[0];
        return Integer.parseInt(years) * 12;
    }

    private String calculateProductEndDateForTrackerProduct(String term) {
        int numberOfMonths = extractMonthsFromTerm(term);
        return numberOfMonths + " months";
    }
}

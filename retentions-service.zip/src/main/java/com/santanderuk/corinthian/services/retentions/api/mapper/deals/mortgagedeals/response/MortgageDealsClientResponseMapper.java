package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.MortgageDealsClientResponse;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.Product;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MapperSourceData;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class MortgageDealsClientResponseMapper {

    private final CalculationsMapper calculationsMapper;
    private final MortgageDealsProductToAggregationResponseProductMapper mortgageDealsProductToAggregationResponseProductMapper;
    private final LoansToDealsMapper loansToDealsMapper;

    @Autowired
    public MortgageDealsClientResponseMapper(CalculationsMapper calculationsMapper, MortgageDealsProductToAggregationResponseProductMapper mortgageDealsProductToAggregationResponseProductMapper, LoansToDealsMapper loansToDealsMapper) {
        this.calculationsMapper = calculationsMapper;
        this.mortgageDealsProductToAggregationResponseProductMapper = mortgageDealsProductToAggregationResponseProductMapper;
        this.loansToDealsMapper = loansToDealsMapper;
    }

    public DealsResponse map(MortgageDealsClientResponse mortgageDealsClientResponse, MortgageDealsClientRequest mortgageDealsClientRequest, MapperSourceData sourceData) {

        var deals = mortgageDealsClientResponse.getProducts().stream()
                .filter(Product::isEligible)
                .map(product -> convertProductToDeal(product, sourceData, mortgageDealsClientRequest))
                .collect(Collectors.toList());


        var dealsResponse = new DealsResponse();
        dealsResponse.setDeals(deals);
        dealsResponse.setStepErcActive(anyStepErcProduct(deals));

        return dealsResponse;
    }

    private boolean anyStepErcProduct(List<Deal> deals) {
        for (Deal deal : deals) {
            if (deal.getProduct().isStepErc()) {
                return true;
            }
        }
        return false;
    }

    private Deal convertProductToDeal(Product product, MapperSourceData sourceData, MortgageDealsClientRequest mortgageDealsClientRequest) {
        var deal = new Deal();
        deal.setCalculations(calculationsMapper.map(product));
        deal.setProduct(mortgageDealsProductToAggregationResponseProductMapper.map(product, mortgageDealsClientRequest));
        deal.setDealLoans(loansToDealsMapper.map(product, sourceData));
        deal.setLoanToApplyTheFeeTo(product.getBreakdownSummary().getFeeAddedId());
        return deal;
    }
}

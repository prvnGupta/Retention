package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class CoreRetentionRequest {

    private ClientChannel channel;

    @Valid
    private Product product;

    @Valid
    private Account account;

    @Valid
    private Flags flags;

    @Valid
    private AdvisorInformation advisorInformation;

    @Valid
    private BookingInformation bookingInformation;

    @Valid
    private ApplicationInformation applicationInformation;

    @NotNull(message = "Governance type cannot be null")
    private String governanceType;

    private GeneralInfo generalInformation;
    private OfferConversionDetails offerConversionDetails;

    @Valid
    private boolean anmfToAnmfSwitch;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }

}

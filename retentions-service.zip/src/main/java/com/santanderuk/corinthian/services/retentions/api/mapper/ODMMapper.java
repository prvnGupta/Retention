package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.commons.clients.productdirectory.ProductDirectoryResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ReportedException;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.ODMLoanRequest;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.OdmRequest;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.OdmRequestWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.riskvaluation.RiskValuationCoreResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import static java.math.RoundingMode.HALF_UP;

@Component
@Slf4j
public class ODMMapper {

    @Value("${odm.channelId}")
    private String channelId;

    @Value("${odm.accountNumberType}")
    private String accountNumberType;

    public OdmRequestWrapper toOdm(int accountNumber,
                                   AnmfCoreResponse anmfCoreResponse,
                                   RiskValuationCoreResponse riskValuationCoreResponse,
                                   ProductDirectoryResponse productDirectoryResponse) throws ReportedException {


        OdmRequest odmRequest = new OdmRequest();

        LoanTotals totals = calculateLoanTotals(anmfCoreResponse);

        odmRequest.setAccountNumber(Integer.toString(accountNumber));
        odmRequest.setAccountBalance(totals.getOverall());
        odmRequest.setAccountNumberType(accountNumberType);
        odmRequest.setChannelID(channelId);
        odmRequest.setChargeEndDate(productDirectoryResponse.getNearestChargeEndDate());
        odmRequest.setCompletionDate(productDirectoryResponse.getFarthestCompletionDate());
        odmRequest.setLtvgeneral(calculateLtvRatio(totals.getRepayment().add(totals.getInterestOnly()), riskValuationCoreResponse.getCalculatedValuation()));
        odmRequest.setLtvio(calculateLtvRatio(totals.getInterestOnly(), riskValuationCoreResponse.getCalculatedValuation()));
        odmRequest.setRiskLevel(riskValuationCoreResponse.getRiskLevel());

        odmRequest.setIsBuyToLet(anmfCoreResponse.isBuyToLet() ? "Y" : "N");
        odmRequest.setIsConsentToLet(anmfCoreResponse.isConsentToLet() ? "Y" : "N");
        odmRequest.setIsFlexi(anmfCoreResponse.getFlexiIndicator().equalsIgnoreCase("Y") ? "Y" : "N");
        odmRequest.setPostCode(anmfCoreResponse.getProperty().getPostcode());
        odmRequest.setLoanRequest(generateLoanRequestList(anmfCoreResponse.getLoans()));

        OdmRequestWrapper odmRequestWrapper = new OdmRequestWrapper();
        odmRequestWrapper.setOdmRequest(odmRequest);

        return odmRequestWrapper;
    }

    private LoanTotals calculateLoanTotals(AnmfCoreResponse controllerRequest) {

        BigDecimal overallRunningTotal = new BigDecimal(0).setScale(2, HALF_UP);
        BigDecimal ioRunningTotal = new BigDecimal(0).setScale(2, HALF_UP);
        BigDecimal repaymentRunningTotal = new BigDecimal(0).setScale(2, HALF_UP);

        for (Loan loan : controllerRequest.getLoans()) {
            overallRunningTotal = overallRunningTotal.add(loan.getLoanBalance());
            if (loan.getLoanType().equalsIgnoreCase("I")) {
                ioRunningTotal = ioRunningTotal.add(loan.getLoanBalance());
            } else if (loan.getLoanType().equalsIgnoreCase("R")) {
                repaymentRunningTotal = repaymentRunningTotal.add(loan.getLoanBalance());
            }
        }

        LoanTotals totals = new LoanTotals();

        totals.setOverall(overallRunningTotal);
        totals.setInterestOnly(ioRunningTotal);
        totals.setRepayment(repaymentRunningTotal);

        return totals;
    }

    public BigDecimal calculateLtvRatio(BigDecimal loanAmount, Integer calculatedValuation) {
        BigDecimal valuation = new BigDecimal(calculatedValuation);

        BigDecimal result = loanAmount.divide(valuation, 50, HALF_UP);
        BigDecimal percentage = result.multiply(new BigDecimal(100));
        return percentage.setScale(2, HALF_UP);
    }

    private List<ODMLoanRequest> generateLoanRequestList(List<Loan> loans) throws ReportedException {

        List<ODMLoanRequest> odmLoanRequests = new ArrayList<>(loans.size());

        for (Loan loan : loans) {
            odmLoanRequests.add(mapToLoanRequest(loan));
        }
        return odmLoanRequests;
    }

    private ODMLoanRequest mapToLoanRequest(Loan loan) throws ReportedException {
        ODMLoanRequest odmLoanRequest = new ODMLoanRequest();
        String loanId = extractLoanId(loan);

        odmLoanRequest.setLoanID(loanId);
        odmLoanRequest.setRemainingTerm(loan.getRemainingTerm());

        decorateRollOfDate(loan, odmLoanRequest);

        odmLoanRequest.setIsOnReversionRate(loan.isOnReversionRate() ? "Y" : "N");
        odmLoanRequest.setLoanBalance(loan.getLoanBalance());

        return odmLoanRequest;
    }

    private void decorateRollOfDate(Loan loan, ODMLoanRequest odmLoanRequest) throws ReportedException {

        LocalDate loanStartDate = fromAnmfFormat(loan.getLoanStartDate());
        LocalDate productEndDate = fromAnmfFormat(loan.getProductEndDate());

        if (StringUtils.containsIgnoreCase(loan.getProductDescription(), "FLEXIBLE")) {
            odmLoanRequest.setRollOffDate(convertToODMDateFormat(loanStartDate));
        }

        if (!loan.getProductEndDate().equalsIgnoreCase("")) {
            odmLoanRequest.setRollOffDate(convertToODMDateFormat(productEndDate));
        }
    }

    private String extractLoanId(Loan loan) {
        if (loan.getLoanId() != null) {
            return loan.getLoanId().toString();
        }
        return "";
    }

    private String convertToODMDateFormat(LocalDate anmfDate) {
        DateTimeFormatter odmFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return odmFormat.format(anmfDate);

    }

    private LocalDate fromAnmfFormat(String anmfDate) throws ReportedException {

        if (StringUtils.isEmpty(anmfDate)) {
            return null;
        }
        try {
            DateTimeFormatter anmfFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return LocalDate.parse(anmfDate, anmfFormat);
        } catch (DateTimeParseException e) {
            log.error("Error parsing ANMF date format", e);
            throw new ReportedException("HUB_DATA_FORMAT_ERROR", "Exception while formatting ANMF date", e);
        }

    }

}

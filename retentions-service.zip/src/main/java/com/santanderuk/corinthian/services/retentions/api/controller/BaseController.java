package com.santanderuk.corinthian.services.retentions.api.controller;

import com.lowagie.text.DocumentException;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.UpdateOfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.validation.ConstraintViolationException;
import java.io.IOException;

import static org.springframework.http.HttpStatus.OK;

@ControllerAdvice
public class BaseController {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    protected ResponseEntity<CreateCaseWrapper> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus("ko");
        serviceInfo.setCode("BAD_REQUEST");
        serviceInfo.setMessage(ex.getBindingResult().getAllErrors().get(0).getDefaultMessage());

        CreateCaseWrapper responseWrapper = new CreateCaseWrapper();
        responseWrapper.setInfo(serviceInfo);
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<CreateCaseWrapper> handleUnrecognizedPropertyException() {
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus("ko");
        serviceInfo.setCode("BAD_REQUEST");
        serviceInfo.setMessage("Unrecognized property in the request");

        CreateCaseWrapper responseWrapper = new CreateCaseWrapper();
        responseWrapper.setInfo(serviceInfo);
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(FieldValidationException.class)
    private ResponseEntity<String> handleValidationException(FieldValidationException fieldValidationException) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");

        return new ResponseEntity<>(fieldValidationException.getMessage(), headers, HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(ConnectionException.class)
    private ResponseEntity<EligibilityResponseWrapper> handledConnectionFailed(ConnectionException connectionException) {
        EligibilityResponseWrapper wrapper = new EligibilityResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.exception(connectionException);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @ExceptionHandler(ServerException.class)
    private ResponseEntity<EligibilityResponseWrapper> handleServerException(ServerException serverException) {
        EligibilityResponseWrapper wrapper = new EligibilityResponseWrapper();
        ServiceInfo info = new ServiceInfo();
        info.setStatus("ko");
        info.setCode(serverException.getCode());
        info.setMessage(serverException.getMessage());
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ReportedException.class)
    public ResponseEntity<EligibilityResponseWrapper> handleReportedException(ReportedException reportedException) {
        EligibilityResponseWrapper responseWrapper = new EligibilityResponseWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(reportedException));
        return new ResponseEntity<>(responseWrapper, OK);
    }

    @ExceptionHandler(OperativeSecurityException.class)
    public ResponseEntity<EligibilityResponseWrapper> handleOperativeSecurityException(OperativeSecurityException operativeSecurityException) {
        EligibilityResponseWrapper wrapper = new EligibilityResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.exception(operativeSecurityException);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler({GeneralException.class, DocumentException.class})
    public ResponseEntity<EligibilityResponseWrapper> handleGeneralException(GeneralException generalException) {
        EligibilityResponseWrapper wrapper = new EligibilityResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.exception(generalException);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ValidationsException.class)
    public ResponseEntity<EligibilityResponseWrapper> handleValidationException(final ValidationsException validationExc) {
        final EligibilityResponseWrapper responseWrapper = new EligibilityResponseWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(validationExc));
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<CreateCaseWrapper> handleIOException(final IOException ioException) {
        final CreateCaseWrapper responseWrapper = new CreateCaseWrapper();
        GeneralException generalException = new GeneralException("", ioException.getMessage());
        responseWrapper.setInfo(ServiceInfoCreator.exception(generalException));
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NoDealsFoundException.class)
    public ResponseEntity<EligibilityResponseWrapper> handleNoDealsFound(final NoDealsFoundException noDealsException) {
        final EligibilityResponseWrapper responseWrapper = new EligibilityResponseWrapper();
        GeneralException generalException = new GeneralException("NO_DEAL_FOUND", noDealsException.getMessage());
        responseWrapper.setInfo(ServiceInfoCreator.exception(generalException));
        return new ResponseEntity<>(responseWrapper, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MaintenanceException.class)
    public ResponseEntity<EligibilityResponseWrapper> handleMaintenanceException(final MaintenanceException maintenanceException) {
        final EligibilityResponseWrapper responseWrapper = new EligibilityResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.exception(maintenanceException);
        responseWrapper.setInfo(info);
        return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<UpdateOfferInfoResponse> handleConstraintValidationException(final ConstraintViolationException constraintViolationException) {
        final UpdateOfferInfoResponse responseWrapper = new UpdateOfferInfoResponse();
        ServiceInfo info = ServiceInfoCreator.exception(constraintViolationException);
        info.setCode("ESIS_ID_BAD_FORMAT");
        info.setMessage("esis_ref_id format is not valid");
        responseWrapper.setInfo(info);
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<UpdateOfferInfoResponse> handleForbiddenException(final ForbiddenException forbiddenException) {
        final UpdateOfferInfoResponse response = new UpdateOfferInfoResponse();
        ServiceInfo info = new ServiceInfo("ko", forbiddenException.getCode(), forbiddenException.getMessage());
        response.setInfo(info);
        return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(PaymentsException.class)
    private ResponseEntity<AcceptAndPayInSessionResponseWrapper> handlePaymentsException(PaymentsException paymentsException) {
        AcceptAndPayInSessionResponseWrapper wrapper = new AcceptAndPayInSessionResponseWrapper();
        ServiceInfo info = new ServiceInfo();
        info.setStatus("ko");
        info.setCode(paymentsException.getCode());
        info.setMessage(paymentsException.getMessage());
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DealsFunctionalValidationException.class)
    private ResponseEntity<DealsResponseWrapper> handlePaymentsException(DealsFunctionalValidationException e) {
        var wrapper = new DealsResponseWrapper();
        var info = ServiceInfoCreator.exception(e);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.BAD_REQUEST);
    }

    public String sanitizeString(String sanitizeMe) {
        return sanitizeMe.replaceAll("[\r\n]", "");
    }

}

package com.santanderuk.corinthian.services.retentions.api.service.deals.anmfdatafetcher;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AnmfDataFetcherOutput {
    private ANMFPropertyResponse anmfPropertyResponse;
    private AnmfAccountServiceResponse accountServiceResponse;
}

package com.santanderuk.corinthian.services.retentions.api.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class ProductCalculations {

    private BigDecimal remainingBalance;
    private BigDecimal interest;
    private BigDecimal cost;
}

package com.santanderuk.corinthian.services.retentions.api.model.riskvaluation;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RiskValuationCoreResponse {

    private String riskLevel;
    private String idTipoValuation;

    private Integer valuation;
    private String valuationDate;

    private Integer valuationAvm;
    private String valuationDateAvm;
    private Integer condidenceLevelAvm;

    private Integer valuationHpi;
    private String valuationDateHpi;

    private Integer calculatedValuation;
    private String calculatedValuationDate;

    private String dateProcessed;
    private String band;
}

package com.santanderuk.corinthian.services.retentions.api.pdfGeneration;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

@Slf4j
@Component
public class PdfGenerator {

    public static final Template DEALS = Template.DEALS;

    private final TemplateEngine templateEngine;

    private final ContextBuilder contextBuilder;

    @Autowired
    public PdfGenerator(TemplateEngine templateEngine, ContextBuilder contextBuilder) {
        this.templateEngine = templateEngine;
        this.contextBuilder = contextBuilder;
    }

    public ByteArrayOutputStream createPdf(PdfGeneratorRequest pdfRequest) throws DocumentException, IOException {

        Context context = contextBuilder.buildContext(pdfRequest.getTemplateElements());

        String processedHtml = templateEngine.process(getTemplateName(pdfRequest), context);
        ByteArrayOutputStream generatedPDF = null;
        try {
            log.debug("about to create PDF");
            generatedPDF = generatePdfFromHtml(processedHtml);
            log.info("PDF created");
        } catch (DocumentException e) {
            log.warn("Exception while generating PDF", e);
            throw e;

        } finally {
            checkAndClosePDF(generatedPDF);
        }
        return generatedPDF;
    }

    private String getTemplateName(PdfGeneratorRequest pdfRequest) {
        if (pdfRequest.getTemplateName() == DEALS) {
            return "deals-pdf";
        }
        throw new TemplateNotFoundException();
    }

    private ByteArrayOutputStream generatePdfFromHtml(String processedHtml) throws DocumentException, IOException {
        ByteArrayOutputStream generatedPDF = new ByteArrayOutputStream();
        ITextRenderer renderer = new ITextRenderer(4.1666f, 3);

        File file = new File(getClass().getClassLoader().getResource("templates").getFile());
        String baseUrl = file.toURI().toString();
        renderer.setDocumentFromString(processedHtml, baseUrl);
        renderer.getFontResolver().addFont("templates/fonts/SantanderText-Regular.ttf", BaseFont.IDENTITY_H, true);
        renderer.getFontResolver().addFont("templates/fonts/Santander/SantanderHeadline-Regular.otf", BaseFont.IDENTITY_H, true);

        renderer.layout();
        renderer.createPDF(generatedPDF, false);
        renderer.finishPDF();
        return generatedPDF;
    }

    private void checkAndClosePDF(ByteArrayOutputStream generatedPDF) {
        if (generatedPDF != null) {
            try {
                generatedPDF.close();
            } catch (IOException e) {
                log.error("IOException when trying to close ByteArrayOutputStream");
            }
        }
    }
}

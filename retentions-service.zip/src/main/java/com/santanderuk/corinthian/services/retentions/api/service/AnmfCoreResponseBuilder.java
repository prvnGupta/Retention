package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.retentions.api.mapper.AnmfClientMapper;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Property;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class AnmfCoreResponseBuilder {

    private final AnmfClientMapper anmfClientMapper;

    @Autowired
    public AnmfCoreResponseBuilder(AnmfClientMapper anmfClientMapper) {
        this.anmfClientMapper = anmfClientMapper;
    }

    public AnmfCoreResponse buildAnmfCoreResponse(AnmfAccountServiceResponse accountsDetailsV4, ANMFPropertyResponse anmfAddressResponse) {

        AnmfCoreResponse anmfCoreResponse = new AnmfCoreResponse();
        String specialPurchase = anmfAddressResponse.getPropertyEnquiryResponse().getOutputStructure().getOSpecialPurchase();
        anmfCoreResponse.setBuyToLet(specialPurchase.equalsIgnoreCase("L"));

        String oConsentToLet = anmfAddressResponse.getPropertyEnquiryResponse().getOutputStructure().getOConsentToLet();
        anmfCoreResponse.setConsentToLet(oConsentToLet.equalsIgnoreCase("Y"));

        anmfCoreResponse.setCustomerOnArrears(isCustomerOnArrears(accountsDetailsV4));
        anmfCoreResponse.setFlexiIndicator(accountsDetailsV4.getAccountServiceResponse().getResponse().getOStruc().getOFlexiInd());
        anmfCoreResponse.setProperty(new Property(anmfAddressResponse.getPropertyEnquiryResponse().getOutputStructure().getOPropertyPostcode()));
        anmfCoreResponse.setLoans(anmfClientMapper.toLoans(accountsDetailsV4));
        anmfCoreResponse.setNextPaymentDate(accountsDetailsV4.getAccountServiceResponse().getResponse().getOStruc().getONextPaymentDt());
        return anmfCoreResponse;
    }

    private boolean isCustomerOnArrears(AnmfAccountServiceResponse accountsDetailsV4) {
        OStruc oStruc = accountsDetailsV4.getAccountServiceResponse().getResponse().getOStruc();

        BigDecimal arrearsTotal = oStruc.getOArrearsBalance()
                .add(oStruc.getORecBalance())
                .add(oStruc.getOSundriesArrears())
                .add(oStruc.getOSundriesRec());

        return arrearsTotal.compareTo(new BigDecimal("0.00")) > 0;
    }

}

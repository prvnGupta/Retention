package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.OutputStructure;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.*;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.service.PafService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class CoreRetentionMapperAccount {

    private final CoreRetentionMapperAccountLoan loanMapper;
    private final CoreRetentionMapperAccountBorrowers borrowersMapper;
    private final PafService pafService;

    @Autowired
    public CoreRetentionMapperAccount(CoreRetentionMapperAccountLoan loanMapper, CoreRetentionMapperAccountBorrowers borrowersMapper, PafService pafService) {
        this.loanMapper = loanMapper;
        this.borrowersMapper = borrowersMapper;
        this.pafService = pafService;
    }


    public void map(CoreRetentionRequest coreRetentionRequest, CoreRetentionsData input) {
        Account account = new Account();

        account.setType(1);
        account.setTitle("MR"); //ToDo hardcoded until we have the value form anmf account info
        account.setNumber(String.valueOf(input.getAccount()));
        account.setReference("ANMF" + input.getAccount());
        account.setPlatform("1");
        account.setBalance(getBalance(input));
        account.setSetupDate(null);

        account.setDrawdownAmount(new BigDecimal("0.00"));
        account.setBonusProductID(null);
        account.setTotalPortedLoans(calculateTotalPortedLoans(input));
        account.setTotalCapitalRepaymentAmount(new BigDecimal("0.00"));

        Mortgage mortgage = createMortgage(input);
        account.setMortgage(mortgage);

        Property property = createProperty(input);
        account.setProperty(property);

        coreRetentionRequest.setAccount(account);

        loanMapper.map(coreRetentionRequest, input);
        borrowersMapper.map(coreRetentionRequest, input);
    }

    private BigDecimal getBalance(CoreRetentionsData input) {
        return input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOCapitalBalance();
    }

    private BigDecimal calculateTotalPortedLoans(CoreRetentionsData input) {
        return input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().stream()
                .filter(oLoan -> isInSelectedLoans(oLoan, input.getCaseRequest().getLoansSelected()))
                .map(OActiveLoanDetail::getOCapitalBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private boolean isInSelectedLoans(OActiveLoanDetail oLoan, List<LoanIdentifier> selectedLoans) {
        long count = selectedLoans.stream()
                .filter(loanIdentifier -> isSameLoan(loanIdentifier, oLoan))
                .count();
        return count > 0;
    }

    private boolean isSameLoan(LoanIdentifier loanIdentifier, OActiveLoanDetail oLoan) {
        boolean sameLoanScheme = loanIdentifier.getLoanScheme().equalsIgnoreCase(oLoan.getOLoanScheme());
        boolean sameAppSeqNumber = loanIdentifier.getSequenceNumber() == oLoan.getOApplSeqNo();
        return sameLoanScheme && sameAppSeqNumber;
    }

    private Mortgage createMortgage(CoreRetentionsData input) {
        Mortgage mortgage = new Mortgage();
        mortgage.setCategory("B");
        mortgage.setMethodOfRepaymentType(calculateMethodRepayment(input)); //ToDo wainting confirmation what is this
        mortgage.setClassType("3");

        MortgageTerm term = createMortgageTerm(input);
        mortgage.setTerm(term);

        return mortgage;
    }

    private String calculateMethodRepayment(CoreRetentionsData input) {
        Set<String> repaymentMethodsSet = input.getAnmfAccountServiceResponse().getAccountServiceResponse()
                .getResponse().getOStruc().getOActiveLoanDetails().stream()
                .map(OActiveLoanDetail::getORepaymentType)
                .collect(Collectors.toSet());
        if (repaymentMethodsSet.size() == 1) {
            return repaymentMethodsSet.stream().findFirst().orElse("");
        } else {
            return "M";
        }
    }

    private MortgageTerm createMortgageTerm(CoreRetentionsData input) {
        MortgageTerm mortgageTerm = new MortgageTerm();
        int remainingInstallments = getRemainingInstallments(input);

        int years = remainingInstallments / 12;
        int months = remainingInstallments % 12;

        mortgageTerm.setYears(years);
        mortgageTerm.setMonths(months);
        mortgageTerm.setTotalMonths(remainingInstallments);

        mortgageTerm.setChanged(false);

        return mortgageTerm;
    }

    private int getRemainingInstallments(CoreRetentionsData input) {
        List<Integer> remainingInstallmentsList = input.getAnmfAccountServiceResponse().getAccountServiceResponse()
                .getResponse().getOStruc().getOActiveLoanDetails().stream()
                .map(OActiveLoanDetail::getORemainingInstlm)
                .collect(Collectors.toList());
        return Collections.max(remainingInstallmentsList);
    }

    private Property createProperty(CoreRetentionsData input) {
        Property property = new Property();

        property.setPrice(null);

        property.setAddress(createAddress(input));
        return property;
    }

    private PropertyAddress createAddress(CoreRetentionsData input) {
        PropertyAddress propertyAddress = new PropertyAddress();
        OutputStructure propertyData = input.getAddressResponse().getPropertyEnquiryResponse().getOutputStructure();
        /*
            Convertion rule for addresses
            Addressline 1 <- ANMF Addressline1
            Addressline 2 <- ANMF Addressline2
            Addressline 3 <- ""
            Addressline 4 <- ANMF Addressline3
            Addressline 5 <- ANMF Addressline4
            Addressline 6 <- ""
            Addressline 7 <- ""
            Addressline 8 <- Country
         */

        String country = pafService.fetchCountry(propertyData.getOPropertyPostcode());
        propertyAddress.setAddressLine1(propertyData.getOPropertyAddr1());
        propertyAddress.setAddressLine2(propertyData.getOPropertyAddr2());
        propertyAddress.setAddressLine3("");
        propertyAddress.setAddressLine4(propertyData.getOPropertyAddr3());
        propertyAddress.setAddressLine5(propertyData.getOPropertyAddr4());
        propertyAddress.setAddressLine6("");
        propertyAddress.setAddressLine7("");
        propertyAddress.setAddressLine8(country);
        propertyAddress.setPostcode(propertyData.getOPropertyPostcode());
        propertyAddress.setCorrespondenceChangeIndicator(false);

        return propertyAddress;
    }
}

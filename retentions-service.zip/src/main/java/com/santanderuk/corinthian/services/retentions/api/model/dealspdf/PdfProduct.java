package com.santanderuk.corinthian.services.retentions.api.model.dealspdf;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PdfProduct {

    private String productDescription;
    private String initialRate;
    private String productFee;
    private String monthlyPaymentWithFee;
    private String monthlyPaymentWithoutFee;
    private String overpaymentAllowance;
    private String erc;
    private String type;
    private String diffBankOfEnglandBaseRate;

}

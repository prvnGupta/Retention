package com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DealsPdfAnmfDataFetcher {

    private final AnmfCoreClient anmfCoreClient;
    private final AnmfConfiguration configuration;
    private final HeartBeatClient heartBeatClient;

    @Autowired
    public DealsPdfAnmfDataFetcher(AnmfCoreClient anmfCoreClient, AnmfConfiguration configuration, HeartBeatClient heartBeatClient) {
        this.anmfCoreClient = anmfCoreClient;
        this.configuration = configuration;
        this.heartBeatClient = heartBeatClient;
    }

    public DealsPdfAnmfDataFetcherOutput fetch(int account) throws ConnectionException, MaintenanceException {
        var region = heartBeatClient.fetchCurrentRegion();

        var accountDetails = accountDetails(account, region);

        return new DealsPdfAnmfDataFetcherOutput(accountDetails);
    }

    private AnmfAccountServiceResponse accountDetails(int account, AnmfRegion region) throws ConnectionException {
        return anmfCoreClient.fetchMortgageAccountDetailsV5(account, configuration.getAnmfAccountDetailsUrl(), region);
    }

}

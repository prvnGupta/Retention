package com.santanderuk.corinthian.services.retentions.api.model.createCase;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class CreateCaseWrapper {
    private ServiceInfo info;
    private CreateCase response;
}

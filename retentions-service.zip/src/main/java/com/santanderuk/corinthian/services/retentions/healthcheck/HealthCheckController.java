package com.santanderuk.corinthian.services.retentions.healthcheck;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckController {

    @GetMapping(value = "/health")
    public String getHealthCheck() {
        return "Up";
    }
}

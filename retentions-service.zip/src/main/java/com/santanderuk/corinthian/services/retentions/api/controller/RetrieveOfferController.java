package com.santanderuk.corinthian.services.retentions.api.controller;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve.RetrieveOfferResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve.RetrieveOfferResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.service.RetrieveOfferService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Pattern;

@Slf4j
@Validated
@RestController
public class RetrieveOfferController extends BaseController {

    private final RetrieveOfferService retrieveOfferService;

    public RetrieveOfferController(RetrieveOfferService retrieveOfferService) {
        this.retrieveOfferService = retrieveOfferService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to retrieve a previously generated mortgage retention offer pdf",
            nickname = "fetchOffer",
            notes = "This endpoint is used by Corinthian frontend application to retrieve a previously generated mortgage retention offer pdf. it will invoke mrs-esis-core api to retrieve de document."
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @GetMapping("/{accountNumber}/offer/retrieve/{esisRefId}")
    public ResponseEntity<RetrieveOfferResponseWrapper> fetchOffer(
            @PathVariable("accountNumber") int accountNumber,
            @PathVariable("esisRefId") @Pattern(regexp = "^[a-zA-Z0-9\\-]+$") String esisRefId,
            @RequestHeader(name = "Authorization", required = true) String jwtToken
    ) throws MaintenanceException, ConnectionException, OperativeSecurityException {
        RetrieveOfferResponse offerResponse = retrieveOfferService.retrieveOffer(accountNumber, jwtToken, esisRefId);
        RetrieveOfferResponseWrapper responseWrapper = buildRetrieveOfferResponseWrapper(offerResponse);
        return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
    }

    private RetrieveOfferResponseWrapper buildRetrieveOfferResponseWrapper(RetrieveOfferResponse offerResponse) {

        RetrieveOfferResponseWrapper responseWrapper = new RetrieveOfferResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.ok();
        responseWrapper.setInfo(info);
        responseWrapper.setData(offerResponse);
        return responseWrapper;
    }
}

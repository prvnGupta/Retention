package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.ApplicationInformation;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.springframework.stereotype.Component;

@Component
public class CoreRetentionMapperApplicationInformation {

    public void map(CoreRetentionRequest coreRetentionRequest) {
        ApplicationInformation applicationInformation = new ApplicationInformation();

        applicationInformation.setOmrtReference("");
        applicationInformation.setBrokerReferenceCode("");
        applicationInformation.setBrokerEmail("");
        applicationInformation.setSwitchEarlyReference("");
        applicationInformation.setRetentionUserId("CORINTHIAN");
        applicationInformation.setRetentionUserName("CORINTHIAN");
        applicationInformation.setSaleTypeID("2");
        applicationInformation.setCommunicationOptOut(false);
        applicationInformation.setOfferCreationSource("1");

        coreRetentionRequest.setApplicationInformation(applicationInformation);
    }
}

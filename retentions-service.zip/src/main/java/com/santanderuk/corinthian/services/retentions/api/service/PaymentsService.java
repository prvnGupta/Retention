package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.retentions.api.clients.InternalTransferClient;
import com.santanderuk.corinthian.services.retentions.api.exceptions.PaymentsException;
import com.santanderuk.corinthian.services.retentions.api.mapper.InternalTransferMapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.PaymentsInternalTransferRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentsService {
    private final InternalTransferClient internalTransferClient;
    private final InternalTransferMapper internalTransferMapper;

    @Autowired
    public PaymentsService(InternalTransferClient internalTransferClient, InternalTransferMapper internalTransferMapper) {
        this.internalTransferClient = internalTransferClient;
        this.internalTransferMapper = internalTransferMapper;
    }

    public String makeInternalTransfer(int mortgageAccount, String jwtToken, AcceptAndPayInSessionRequest acceptAndPayInSessionRequest, OnlineOfferEntity onlineOfferEntity) throws PaymentsException {
        PaymentsInternalTransferRequest paymentsInternalTransferRequest = internalTransferMapper.mapData(acceptAndPayInSessionRequest, jwtToken, onlineOfferEntity, mortgageAccount);
        AcceptAndPayInSessionResponseWrapper response = internalTransferClient.makeInternalTransfer(paymentsInternalTransferRequest);
        return response.getResponse().getPaymentId();
    }
}

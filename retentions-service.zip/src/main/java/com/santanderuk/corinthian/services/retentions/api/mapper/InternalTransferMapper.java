package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.retentions.api.exceptions.PaymentsException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.BdpCustomer;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.PaymentsInternalTransferRequest;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class InternalTransferMapper {

    public static final String FEE_PAYMENT_REF = "FeePayment ANMF";
    private final ObjectMapper objectMapper;

    private final InternalTransferConfig internalTransferConfig;

    @Autowired
    public InternalTransferMapper(ObjectMapper objectMapper, InternalTransferConfig internalTransferConfig) {
        this.objectMapper = objectMapper;
        this.internalTransferConfig = internalTransferConfig;
    }


    public PaymentsInternalTransferRequest mapData(AcceptAndPayInSessionRequest acceptAndPayInSessionRequest, String jwtToken, OnlineOfferEntity onlineOfferEntity, int mortgageAccount) throws PaymentsException {

        PaymentsInternalTransferRequest paymentsInternalTransferRequest = new PaymentsInternalTransferRequest();
        CoreRetentionsData coreRetentionsData = getCoreRetentionsData(onlineOfferEntity);
        OCustomer loggedInCustomerDetails = extractLoggedInCustomerDetails(coreRetentionsData, buildBdpCustomer(jwtToken));
        paymentsInternalTransferRequest.setCustomerFirstName(buildFirstName(loggedInCustomerDetails).trim());
        paymentsInternalTransferRequest.setCustomerLastName(buildLastName(loggedInCustomerDetails).trim());
        paymentsInternalTransferRequest.setOriginAccount(mapOriginAccount(acceptAndPayInSessionRequest));
        paymentsInternalTransferRequest.setBdpCustomer(buildBdpCustomer(jwtToken));
        paymentsInternalTransferRequest.setPaymentAmount(getAmount(coreRetentionsData));
        paymentsInternalTransferRequest.setPaymentReference(FEE_PAYMENT_REF + StringUtils.leftPad(String.valueOf(mortgageAccount), 9, "0"));
        paymentsInternalTransferRequest.setDestinationAccount(buildDestinationAccount());

        return paymentsInternalTransferRequest;
    }

    private OCustomer extractLoggedInCustomerDetails(CoreRetentionsData coreRetentionsData, BdpCustomer bdpCustomer) {
        int customerNumberFromJwt = bdpCustomer.getCustomerNumber();

        List<OCustomer> loggedInCustomerList = coreRetentionsData.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().stream().filter(customerList -> customerList.getOCustomerId() == customerNumberFromJwt).collect(Collectors.toList());
        return loggedInCustomerList.get(0);
    }

    private String buildFirstName(OCustomer customerDetails) {
        return customerDetails.getOForename1() + " " +
                customerDetails.getOForename2() + " " +
                customerDetails.getOForename3();
    }

    private String buildLastName(OCustomer customerDetails) {
        return customerDetails.getOSurname();
    }

    private CoreRetentionsData getCoreRetentionsData(OnlineOfferEntity onlineOfferEntity) throws PaymentsException {
        try {
            return objectMapper.readValue(onlineOfferEntity.getCoreRetentionsData().trim(), CoreRetentionsData.class);
        } catch (Exception e) {
            log.error("Error extracting CoreRetentionsData from onlineOfferEntity");
            throw new PaymentsException("KO_INTERNAL_TRANSFER_MAPPER", "Error in internalTransferMapper", e);
        }
    }

    private LocalAccountNumber buildDestinationAccount() {
        LocalAccountNumber localAccountNumber = new LocalAccountNumber();
        localAccountNumber.setSortcode(internalTransferConfig.getPaymentsDestinationAccNo().trim().substring(0, 6).trim());
        localAccountNumber.setAccountNumber(internalTransferConfig.getPaymentsDestinationAccNo().trim().substring(6).trim());
        return localAccountNumber;
    }

    private BigDecimal getAmount(CoreRetentionsData coreRetentionsData) {
        return coreRetentionsData.getSelectedDeal().getProduct().getProductFee();
    }

    private BdpCustomer buildBdpCustomer(String jwtToken) {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setCustomerNumber(JwtUtilities.getBdpCustomerFromJWT(jwtToken).getCustomerNumber());
        bdpCustomer.setCustomerType(JwtUtilities.getBdpCustomerFromJWT(jwtToken).getCustomerType());
        return bdpCustomer;
    }

    private LocalAccountNumber mapOriginAccount(AcceptAndPayInSessionRequest acceptAndPayInSessionRequest) {
        LocalAccountNumber localAccountNumber = new LocalAccountNumber();
        localAccountNumber.setAccountNumber(acceptAndPayInSessionRequest.getAccountFrom().trim().substring(6));
        localAccountNumber.setSortcode(acceptAndPayInSessionRequest.getAccountFrom().trim().substring(0, 6));
        return localAccountNumber;
    }
}

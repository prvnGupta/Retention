package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.retentions.api.exceptions.PaymentsException;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.PaymentsInternalTransferRequest;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class InternalTransferClient {

    private final RestTemplate restTemplate;
    private final InternalTransferConfig internalTransferConfig;

    @Autowired
    public InternalTransferClient(RestTemplate restTemplate, InternalTransferConfig internalTransferConfig) {
        this.restTemplate = restTemplate;
        this.internalTransferConfig = internalTransferConfig;
    }

    public AcceptAndPayInSessionResponseWrapper makeInternalTransfer(PaymentsInternalTransferRequest paymentsInternalTransferRequest) throws PaymentsException{

        HttpHeaders headers = createHeaders();

        HttpEntity<PaymentsInternalTransferRequest> httpEntity = new HttpEntity<>(paymentsInternalTransferRequest,headers);
        try {
            log.info("call to internalTransfer endpoint in payments-service");

            String makePayment = internalTransferConfig.getPaymentServiceEndpoint();
            log.debug("Calling endpoint: {}", makePayment.replaceAll("[\r\n]", ""));

            ResponseEntity<AcceptAndPayInSessionResponseWrapper> responseEntity = restTemplate.postForEntity(makePayment, httpEntity, AcceptAndPayInSessionResponseWrapper.class);
            return responseEntity.getBody();
        } catch (Exception exception){
            log.error("RestClientException Exception while calling payment service endpoint:", exception);
            throw new PaymentsException("INTERNAL_SERVER_ERROR","Error While connecting to Payment Service");
        }
    }

    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }

}

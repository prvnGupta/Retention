package com.santanderuk.corinthian.services.retentions.api.model.gass;

import com.santanderuk.corinthian.gassaudit.model.FormattedData;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProductFeeFormattedData implements FormattedData {
    private String customerNumber;
    private String emailAddress;
    private String feeAmount;
    private boolean jointMortgage;
    private String mccContractNumber;
    private String mobileNumber;
    private String mortgageAccountNumber;
    private String mortgageSortCode;
    private String remitterAccount;
    private String remitterSortCode;
    private String timeStamp;
    private String uid;
}

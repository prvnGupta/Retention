package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.Loan;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.LoanType;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class MortgageDealsClientLoanRequestMapper {

    public List<Loan> create(MapperSourceData sourceData) {

        return getActiveLoansFromAccountResponse(sourceData).stream()
                .map(activeLoan -> convertActiveLoanToClientLoan(activeLoan, sourceData))
                .collect(Collectors.toList());

    }

    private List<OActiveLoanDetail> getActiveLoansFromAccountResponse(MapperSourceData sourceData) {
        return sourceData.getAccountServiceResponse().getAccountServiceResponse()
                .getResponse()
                .getOStruc()
                .getOActiveLoanDetails();
    }

    private Loan convertActiveLoanToClientLoan(OActiveLoanDetail activeLoan, MapperSourceData sourceData) {
        var loan = new Loan();
        loan.setLoanId(activeLoan.getOLoanId());
        loan.setBalance(activeLoan.getOOutstandingBalance());

        var inDealsRequest = isInDealsRequest(activeLoan, sourceData.getDealsRequest());
        loan.setSelected(inDealsRequest);

        loan.setRemainingInstalments(activeLoan.getORemainingInstlm());
        loan.setRedemptionDate(activeLoan.getORedemptionDate());

        var loanType = convertToLoanType(activeLoan.getORepaymentType());
        loan.setLoanType(loanType);

        loan.setMonthlyPay(activeLoan.getOMonthlyPay());
        loan.setErc(activeLoan.getOErcDetailsGrp().getORdmStmErc());
        loan.setInterestRate(activeLoan.getOInterestRate());
        loan.setProductEndDate(activeLoan.getOProductEndDate());
        loan.setProductType(activeLoan.getOProductType());
        loan.setProductDescription(activeLoan.getOProductDesc());
        return loan;
    }

    private LoanType convertToLoanType(String oRepaymentType) {

        if (null == oRepaymentType) return LoanType.UNDEFINED;

        switch (oRepaymentType) {
            case "R":
                return LoanType.R;
            case "I":
                return LoanType.I;
            default:
                return LoanType.UNDEFINED;
        }
    }

    private boolean isInDealsRequest(OActiveLoanDetail activeLoan, DealsRequest dealsRequest) {
        var size = dealsRequest.getLoansSelected().stream()
                .filter(loanInDealsRequest -> isSameLoan(loanInDealsRequest, activeLoan))
                .count();
        return size > 0;
    }

    private boolean isSameLoan(LoanIdentifier loanInDealsRequest, OActiveLoanDetail activeLoan) {
        var sameLoanScheme = loanInDealsRequest.getLoanScheme().equalsIgnoreCase(activeLoan.getOLoanScheme());
        var sameSeqNumber = loanInDealsRequest.getSequenceNumber() == activeLoan.getOApplSeqNo();
        return sameLoanScheme && sameSeqNumber;
    }
}

package com.santanderuk.corinthian.services.retentions.api.service.deals;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import com.santanderuk.corinthian.services.retentions.config.Config;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DealsOperativeSecurity {
    public static final String ERROR_SECURITY_KO_CODE = "SECURITY_KO";
    public static final String ERROR_SECURITY_KO_MESSAGE = "Mortgage does not belong to customer";
    public static final String LOGGING_ERROR_SECURITY_KO = "Security KO. Mortgage does not belong to customer";

    private final AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;
    private final AnmfConfiguration anmfConfiguration ;
    private final Config config;
    private final HeartBeatClient heartBeatClient;

    @Autowired
    public DealsOperativeSecurity(
            AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService,
            AnmfConfiguration anmfConfiguration,
            Config config,
            HeartBeatClient heartBeatClient) {

        this.anmfBelongToCustomerWithBorrowerListService = anmfBelongToCustomerWithBorrowerListService;
        this.anmfConfiguration = anmfConfiguration;
        this.config = config;
        this.heartBeatClient = heartBeatClient;
    }

    public void check(int account, String jwtToken) throws ConnectionException, ValidationsException, OperativeSecurityException, MaintenanceException {
        var anmfBelongsToCustomerWithBorrowerList = getAnmfBelongsToCustomerWithBorrowerList(account, jwtToken);

        var anmfBelongsToCustomer = anmfBelongsToCustomerWithBorrowerList.getAnmfBelongsToCustomer();

        logStatusData(jwtToken, anmfBelongsToCustomer);

        if (securityExceptionHasToBeThrown(anmfBelongsToCustomer)) {
            log.error(LOGGING_ERROR_SECURITY_KO);
            throw new OperativeSecurityException(ERROR_SECURITY_KO_CODE, ERROR_SECURITY_KO_MESSAGE);
        }
    }

    private AnmfBelongsToCustomerWithBorrowerList getAnmfBelongsToCustomerWithBorrowerList(int account, String jwtToken) throws ValidationsException, ConnectionException, MaintenanceException {
        return anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(
                        account, 
                        jwtToken, 
                        anmfConfiguration.getAnmfCustomerServiceUrl(), 
                        heartBeatClient.fetchCurrentRegion());
    }

    private void logStatusData(String jwtToken, Boolean anmfBelongsToCustomer) {
        log.info("Acc Number: {}, called ANMF borrower list, ANMF account belongs to customer: {}", 0, anmfBelongsToCustomer);
        log.debug("JWT Token is : {}", jwtToken.replaceAll("[\r\n]", ""));
    }

    private boolean securityExceptionHasToBeThrown(boolean anmfBelongsToCustomer) {
        return config.isOperativeSecurity() && !anmfBelongsToCustomer;
    }
}

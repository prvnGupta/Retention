package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.gassaudit.model.FormattedData;
import com.santanderuk.corinthian.gassaudit.model.GassMessage;
import com.santanderuk.corinthian.gassaudit.writer.GassMQFactory;
import com.santanderuk.corinthian.gassaudit.writer.GassMessageGenerator;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.retentions.api.mapper.ProductSwitchGassFormattedDataMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.GassDataFetcherRetentionsService;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.gass.AcceptanceGassFormattedData;
import com.santanderuk.corinthian.services.retentions.api.model.gass.CreateCaseRequestFormattedData;
import com.santanderuk.corinthian.services.retentions.api.model.gass.ProductFeeFormattedData;
import io.micrometer.core.instrument.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

@Service
public class GassService {

    private final ProductSwitchGassFormattedDataMapper productSwitchGassFormattedDataMapper;
    private final GassDataFetcherRetentionsService gassDataFetcherRetentionsService;
    private final GassMessageGenerator gassMessageGenerator;
    private final GassMQFactory gassMQFactory;

    @Value("${gass.defaultvalues.trngrpid}")
    private String transactionGroup;

    @Value("${gass.defaultvalues.trntpnameswitch}")
    private String transactionNameProductSwitch;

    @Value("${gass.defaultvalues.trntpnameFeePayment}")
    private String transactionNameFeePayment;

    @Autowired
    public GassService(ProductSwitchGassFormattedDataMapper productSwitchGassFormattedDataMapper, GassDataFetcherRetentionsService gassDataFetcherRetentionsService, GassMessageGenerator gassMessageGenerator, GassMQFactory gassMQFactory) {
        this.productSwitchGassFormattedDataMapper = productSwitchGassFormattedDataMapper;
        this.gassDataFetcherRetentionsService = gassDataFetcherRetentionsService;
        this.gassMessageGenerator = gassMessageGenerator;
        this.gassMQFactory = gassMQFactory;
    }

    public void auditCreateRetentionCaseInGass(int account, String jwtToken, HttpServletRequest servletRequest, CoreRetentionsData coreRetentionsData, String offerId) throws GeneralException {
        String customerNumber = gassDataFetcherRetentionsService.fetchCustomerNumber(jwtToken);
        String ldapUid = JwtUtilities.getLdapUidFromJWT(jwtToken);
        String ipAddress = extractIpAddress(servletRequest);
        String status = extractGassSwitchStatus(offerId);

        CreateCaseRequestFormattedData formattedData = productSwitchGassFormattedDataMapper.createFormattedData(account, jwtToken, coreRetentionsData);
        GassMessage gassMessage = gassMessageGenerator.createGassMessage(account, customerNumber, ldapUid, status, ipAddress, transactionGroup, transactionNameProductSwitch, "0.00");
        gassMessage = gassMessageGenerator.addFormattedDataPayload(gassMessage, formattedData);
        gassMQFactory.publishToQueue(gassMessage);
    }

    public void auditProductSwitchAcceptLaterInGass(String coreRetentionsDataAsString, String jwtToken, int account, String offerDownloadedTime, HttpServletRequest servletRequest, String status) throws JsonProcessingException, GeneralException {
        CoreRetentionsData coreRetentionsData = convertStringToJson(coreRetentionsDataAsString);
        AcceptanceGassFormattedData gassData = productSwitchGassFormattedDataMapper.createProductSwitchAcceptLaterFormattedData(coreRetentionsData, jwtToken, account, offerDownloadedTime);
        performDefaultGassOperations(account, jwtToken, status, servletRequest, "0.00", gassData, transactionNameProductSwitch);
    }

    public void auditProductSwitchAcceptNowInGass(String coreRetentionsDataAsString, String jwtToken, int account, String offerDownloadedTime, HttpServletRequest servletRequest, String status) throws JsonProcessingException, GeneralException {
        CoreRetentionsData coreRetentionsData = convertStringToJson(coreRetentionsDataAsString);
        AcceptanceGassFormattedData gassData = productSwitchGassFormattedDataMapper.createProductSwitchAcceptNowFormattedData(coreRetentionsData, jwtToken, account, offerDownloadedTime);
        performDefaultGassOperations(account, jwtToken, status, servletRequest, "0.00", gassData, transactionNameProductSwitch);
    }

    public void auditProductSwitchFeeInGass(String coreRetentionsDataAsString, String jwtToken, int account, AcceptAndPayInSessionRequest request, HttpServletRequest servletRequest, String status) throws JsonProcessingException, GeneralException {

        CoreRetentionsData coreRetentionsData = convertStringToJson(coreRetentionsDataAsString);
        ProductFeeFormattedData gassData = productSwitchGassFormattedDataMapper.createProductSwitchFeeFormattedData(coreRetentionsData, jwtToken, account, request);
        String amount = coreRetentionsData.getSelectedDeal().getProduct().getProductFee().multiply(new BigDecimal("100")).toString();
        performDefaultGassOperations(account, jwtToken, status, servletRequest, amount, gassData, transactionNameFeePayment);
    }

    public CoreRetentionsData convertStringToJson(String coreRetentionsDataAsString) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(coreRetentionsDataAsString, CoreRetentionsData.class);
    }

    private void performDefaultGassOperations(int account, String jwtToken, String status, HttpServletRequest servletRequest, String amount, FormattedData gassData, String transactionName) throws GeneralException {
        String customerNumber = gassDataFetcherRetentionsService.fetchCustomerNumber(jwtToken);
        String ldapUid = JwtUtilities.getLdapUidFromJWT(jwtToken);
        String ipAddress = extractIpAddress(servletRequest);

        GassMessage gassMessage = gassMessageGenerator.createGassMessage(account, customerNumber, ldapUid, status, ipAddress, transactionGroup, transactionName, amount);
        gassMessage = gassMessageGenerator.addFormattedDataPayload(gassMessage, gassData);
        gassMQFactory.publishToQueue(gassMessage);
    }

    private String extractIpAddress(HttpServletRequest httpServletRequest) {
        String ipAddress = httpServletRequest.getHeader("X-FORWARDED-FOR");
        return StringUtils.isBlank(ipAddress) ? "" : ipAddress;
    }

    private String extractGassSwitchStatus(String offerId) {
        if (null != offerId && !offerId.trim().equalsIgnoreCase("")) {
            return "1";
        } else {
            return "2";
        }
    }
}

package com.santanderuk.corinthian.services.retentions.api.model.deals.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@EqualsAndHashCode
public class DealsResponse extends ModelBase {
    private boolean stepErcActive;
    private List<Deal> deals;
}

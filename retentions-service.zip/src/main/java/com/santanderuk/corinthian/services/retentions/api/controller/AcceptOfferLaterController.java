package com.santanderuk.corinthian.services.retentions.api.controller;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.model.ServiceInfoWrapper;
import com.santanderuk.corinthian.services.retentions.api.service.AcceptLaterService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Pattern;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@Validated
@RestController
public class AcceptOfferLaterController extends BaseController {

    private final AcceptLaterService acceptLaterService;

    public AcceptOfferLaterController(AcceptLaterService acceptLaterService) {
        this.acceptLaterService = acceptLaterService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to save a mortgage retention offer for 14 days",
            nickname = "acceptLater",
            notes = "This endpoint is used by Corinthian frontend application to save for 14 days a previously generated mortgage retention offer. it will invoke initiate-product-switch core api (product-switch-service)"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PutMapping(
            value = "/{accountNumber}/offer/{esisRefId}/accept-later",
            produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE
    )
    public ResponseEntity<ServiceInfoWrapper> acceptLater(
            @PathVariable("accountNumber") int accountNumber,
            @PathVariable("esisRefId") @Pattern(regexp = "^[a-zA-Z0-9\\-]+$") String esisRefId,
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            HttpServletRequest servletRequest) throws ConnectionException, MaintenanceException, OperativeSecurityException {

        acceptLaterService.acceptLater(accountNumber, jwtToken, esisRefId, servletRequest);

        ServiceInfoWrapper wrapper = buildResponseWrapper();
        return new ResponseEntity<>(wrapper, HttpStatus.OK);
    }

    private ServiceInfoWrapper buildResponseWrapper() {
        ServiceInfoWrapper wrapper = new ServiceInfoWrapper();
        wrapper.setInfo(ServiceInfoCreator.ok());
        return wrapper;
    }
}

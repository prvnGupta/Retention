package com.santanderuk.corinthian.services.retentions.api.model;

import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceInfoWrapper extends ModelBase {

    private ServiceInfo info;
}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.internalaccounts.InternalAccountsValidator;
import com.santanderuk.corinthian.services.commons.internalaccounts.RetrieveInternalAccounts;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.RetrieveInternalAccountsServiceUrls;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.exceptions.AcceptInSessionException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.PaymentsException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.UpdateFeeException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorFeePaidUpfront;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

import static com.santanderuk.corinthian.services.commons.utilities.JwtUtilities.getBdpCustomerFromJWT;
import static com.santanderuk.corinthian.services.commons.utilities.JwtUtilities.getLdapUidFromJWT;


@Service
@Slf4j
public class PayAndAcceptInSessionService {

    private final OperativeSecurityService operativeSecurityService;
    private final CacheableOperations cacheableOperations;
    private final RetrieveInternalAccounts retrieveInternalAccounts;
    private final InternalAccountsValidator internalAccountsValidator;
    private final ProductSwitchClient productSwitchClient;
    private final OfferInfoValidatorFeePaidUpfront offerInfoValidatorFeePaidUpfront;
    private final ObjectMapper objectMapper;
    private final InternalAccountFormatConverter internalAccountFormatConverter;
    private final GassService gassService;
    private final PaymentsService paymentsService;
    private final ProductSwitchService productSwitchService;


    @Value("${service.core.accountBalances}")
    private String accountBalancesUrl;

    @Value("${bksconnect.endpoints.contractsInMcc}")
    private String contractsInMccUrl;

    @Value("${bksconnect.endpoints.retrievemcc}")
    private String retrieveMccUrl;

    @Autowired
    public PayAndAcceptInSessionService(OperativeSecurityService operativeSecurityService, CacheableOperations cacheableOperations, RetrieveInternalAccounts retrieveInternalAccounts, InternalAccountsValidator internalAccountsValidator, ProductSwitchClient productSwitchClient, OfferInfoValidatorFeePaidUpfront offerInfoValidatorFeePaidUpfront, ObjectMapper objectMapper, InternalAccountFormatConverter internalAccountFormatConverter, GassService gassService, PaymentsService paymentsService, ProductSwitchService productSwitchService) {
        this.operativeSecurityService = operativeSecurityService;
        this.cacheableOperations = cacheableOperations;
        this.retrieveInternalAccounts = retrieveInternalAccounts;
        this.internalAccountsValidator = internalAccountsValidator;
        this.productSwitchClient = productSwitchClient;
        this.offerInfoValidatorFeePaidUpfront = offerInfoValidatorFeePaidUpfront;
        this.objectMapper = objectMapper;
        this.internalAccountFormatConverter = internalAccountFormatConverter;
        this.gassService = gassService;
        this.paymentsService = paymentsService;
        this.productSwitchService = productSwitchService;
    }

    public void payFeeAndAcceptOffer(AcceptAndPayInSessionRequest request, int account, String esisRefId, String jwtToken, HttpServletRequest servletRequest) throws JsonProcessingException, GeneralException {
        OfferInfoResponse offerInfoResponse = functionalValidations(request, account, esisRefId, jwtToken);
        feePaymentAndAcceptOfferInSession(account, request, jwtToken, servletRequest, offerInfoResponse.getData());
    }

    private OfferInfoResponse functionalValidations(AcceptAndPayInSessionRequest request, int account, String esisRefId, String jwtToken) throws GeneralException, JsonProcessingException {
        AnmfRegion anmfRegion = cacheableOperations.getAnmfActiveRegion();

        log.info("Validations: checkAnmfAccountBelongToCustomerInJwt for pay-and-accept-in-session. esisRefId: {}", esisRefId.replaceAll("[\r\n]", ""));
        operativeSecurityService.checkAnmfAccountBelongToCustomerInJwt(account, jwtToken, anmfRegion);

        OfferInfoResponse offerInfoResponse = productSwitchClient.retrieveOfferInfo(esisRefId);

        offerInfoValidatorFeePaidUpfront.validateOffer(offerInfoResponse, esisRefId, account);
        CoreRetentionsData coreRetentionsData = objectMapper.readValue(offerInfoResponse.getData().getCoreRetentionsData(), CoreRetentionsData.class);

        ContractsInMccControllerResponse accounts = retrieveInternalAccounts.getAccounts(getLdapUidFromJWT(jwtToken), getBdpCustomerFromJWT(jwtToken), generateRetrieveContractsUrls());
        log.info("Validations: validateInternal AccountBelongToCustomerAndHasBalance for pay-and-accept-in-session. esisRefId: {} caseId: {}", offerInfoResponse.getData().getEsisRefId(), offerInfoResponse.getData().getCaseId());
        internalAccountsValidator.validateAccountBelongToCustomerAndHasBalance(coreRetentionsData.getSelectedDeal().getProduct().getProductFee(), internalAccountFormatConverter.convertStringToLocalAccountNumber(request.getAccountFrom()), accountBalancesUrl, accounts.getDataResponse().getDataList().getContractElement());
        return offerInfoResponse;
    }

    private void feePaymentAndAcceptOfferInSession(int mortgageAccount, AcceptAndPayInSessionRequest acceptAndPayInSessionRequest, String jwtToken, HttpServletRequest httpServletRequest, OnlineOfferEntity onlineOfferEntity) throws JsonProcessingException, GeneralException, PaymentsException {
        boolean updateFeeCalled = false;
        boolean acceptInSessionCalled = false;

        try {
            log.info("paymentsService.makeInternalTransfer for pay-and-accept-in-session. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            String paymentId = paymentsService.makeInternalTransfer(mortgageAccount, jwtToken, acceptAndPayInSessionRequest, onlineOfferEntity);

            log.info("productSwitchService.callUpdateFee for pay-and-accept-in-session. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            productSwitchService.callUpdateFee(onlineOfferEntity.getCaseId(), acceptAndPayInSessionRequest, onlineOfferEntity, paymentId, jwtToken);
            updateFeeCalled = true;

            log.info("productSwitchService.callAcceptInSession for pay-and-accept-in-session. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            productSwitchService.callAcceptInSession(onlineOfferEntity.getCaseId());
            acceptInSessionCalled = true;

        } catch (PaymentsException e) {
            log.error("Error calling payments service from pay and accept in session. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            throw new PaymentsException("INTERNAL_SERVER_ERROR", "Error calling payments service from pay and accept in session", e);

        } catch (UpdateFeeException e) {
            log.error("TriggerEmailAlert -> feePaymentAndAcceptOfferInSession. Error calling product-switch-service update fee payment. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            productSwitchService.callAcceptInSession(onlineOfferEntity.getCaseId());

        } catch (AcceptInSessionException e) {
            log.error("TriggerEmailAlert -> feePaymentAndAcceptOfferInSession. Error calling product-switch-service accept-in-session. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());

        } finally {
            log.info("feePaymentAndAcceptOfferInSession -> Audit In GASS fee-payment. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            gassService.auditProductSwitchFeeInGass(onlineOfferEntity.getCoreRetentionsData(), jwtToken, mortgageAccount, acceptAndPayInSessionRequest, httpServletRequest, updateFeeCalled ? "1" : "2");
            log.info("feePaymentAndAcceptOfferInSession -> Audit In GASS accept-in-session. esisRefId: {} caseId: {}", onlineOfferEntity.getEsisRefId(), onlineOfferEntity.getCaseId());
            gassService.auditProductSwitchAcceptNowInGass(onlineOfferEntity.getCoreRetentionsData(), jwtToken, mortgageAccount, onlineOfferEntity.getOfferDownloadedDateTime(), httpServletRequest, acceptInSessionCalled ? "1" : "2");
        }
    }

    private RetrieveInternalAccountsServiceUrls generateRetrieveContractsUrls() {
        RetrieveInternalAccountsServiceUrls urls = new RetrieveInternalAccountsServiceUrls();
        urls.setContractsInMccUrl(contractsInMccUrl);
        urls.setRetrieveMccUrl(retrieveMccUrl);
        return urls;
    }
}

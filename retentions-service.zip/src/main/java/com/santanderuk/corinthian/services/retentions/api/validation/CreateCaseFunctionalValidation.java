package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class CreateCaseFunctionalValidation {
    public void validate(CreateCaseFunctionalValidationInput input) throws ValidationsException {
        validateProductCode(input);
    }

    private void validateProductCode(CreateCaseFunctionalValidationInput input) throws ValidationsException {
        List<String> availableProducts = availableProductCodes(input);
        String productCode = input.getCaseRequest().getProductCode();
        if (!availableProducts.contains(productCode)) {
            throw new ValidationsException(ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_PRODUCT_CODE_NOT_VALID);
        }

    }

    private List<String> availableProductCodes(CreateCaseFunctionalValidationInput input) {
        return input.getDealsResponse().getDeals().stream()
                .map(deal -> deal.getProduct().getProductCode())
                .collect(Collectors.toList());
    }
}

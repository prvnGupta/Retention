package com.santanderuk.corinthian.services.retentions.api.model.internalTransfer;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class PartenonContract extends ModelBase {

    @Valid
    private Centre centre;

    @NotBlank
    private String productTypeCode;

    @NotBlank
    private String contractNumber;
}

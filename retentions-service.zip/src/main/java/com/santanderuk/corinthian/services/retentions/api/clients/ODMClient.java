package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ReportedException;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.OdmRequestWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class ODMClient {

    @Value("${service.core.mortgageEligibility}")
    private String mortgageCoreUrl;

    @Value("${apimanager.client-id-header-key}")
    private String clientIdHeaderKey;

    @Value("${apimanager.client-id-value}")
    private String clientIdValue;

    @Autowired
    private RestTemplate restTemplate;

    public OdmEligibilityResponse fetchMortgageEligibilityCoreResponse(OdmRequestWrapper request) throws ConnectionException, ReportedException {

        try {
            log.info("MortgageEligibilityClient - > request received");
            MultiValueMap<String, String> headers = new LinkedMultiValueMap();
            headers.add(clientIdHeaderKey, clientIdValue);
            headers.add(ACCEPT, APPLICATION_JSON_VALUE);
            headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);

            HttpEntity requestEntity = new HttpEntity(request, headers);
            log.debug("request: {}", request);

            ResponseEntity<OdmEligibilityResponse> response = restTemplate.postForEntity(mortgageCoreUrl, requestEntity, OdmEligibilityResponse.class);
            log.debug("ODM response body {}", response.getBody().getAccountResponse());

            return processResponse(response);
        } catch (RestClientException e) {
            log.error("Error while calling Eligibility Core Service. Object being sent is {}", request.masked(), e);
            throw new ConnectionException(ConnectionException.Type.ELIGIBILITY_CORE_ERROR, e);
        }
    }

    private OdmEligibilityResponse processResponse(ResponseEntity<OdmEligibilityResponse> response) throws ReportedException {
        if (response.getBody().getAccountResponse() == null) {
            log.error("Error Received in Eligibility Core Service Response");
            throw new ReportedException("ELIGIBILITY_CORE_ERROR", "Error Received in Eligibility Core Service Response");
        } else {
            return response.getBody();
        }

    }
}

package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.ServerException;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionGenerateResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.config.Config;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class CoreRetentionsClient {

    private final RestTemplate coreRetentionsRestTemplate;
    private ApiManagerConfig apiManagerConfig;
    private Config config;


    @Autowired
    public CoreRetentionsClient(RestTemplate coreRetentionsRestTemplate, ApiManagerConfig apiManagerConfig, Config config) {
        this.coreRetentionsRestTemplate = coreRetentionsRestTemplate;
        this.apiManagerConfig = apiManagerConfig;
        this.config = config;

    }

    public CoreRetentionGenerateResponse generateOfferInSession(CoreRetentionRequest coreRetentionRequest) throws ConnectionException {

        log.info("CoreRetentionsClient - > generate offer request received");
        HttpEntity<CoreRetentionRequest> requestEntity = new HttpEntity<>(coreRetentionRequest, generateRequestHeaders());

        try {
            log.debug("Calling generate offer service: {}", config.getGenerateOfferUrl());
            log.debug("Object to be sent to core generate offer service is {}", coreRetentionRequest);

            ResponseEntity<CoreRetentionGenerateResponse> response = coreRetentionsRestTemplate.exchange(config.getGenerateOfferUrl(), HttpMethod.POST, requestEntity, CoreRetentionGenerateResponse.class);
            log.debug("Response body from generate offer: {}", response.getBody());
            return response.getBody();
        } catch (ServerException e) {
            log.error("Error while calling core-retention api", e);
            throw new ConnectionException(ConnectionException.Type.CORE_RETENTIONS_GENERATE_OFFER_CONNECTION, e);
        }
    }

    protected MultiValueMap<String, String> generateRequestHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-CLIENT-ID", apiManagerConfig.getClientIdValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }
}

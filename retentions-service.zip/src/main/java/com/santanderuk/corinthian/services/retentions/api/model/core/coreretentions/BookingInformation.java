package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

@Getter
@Setter
public class BookingInformation {


    @NotBlank
    private String businessCircumstanceCode;

    @NotBlank
    private String businessSource;

    @PositiveOrZero
    private BigDecimal totalBookingAmount;

    @NotBlank
    private String bookingStatus;

    @NotBlank
    private String applicationFormReceived;

    @PositiveOrZero
    private int branchID;

    @NotBlank
    private String businessGroup;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

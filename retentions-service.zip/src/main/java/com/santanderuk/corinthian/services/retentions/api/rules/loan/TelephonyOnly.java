package com.santanderuk.corinthian.services.retentions.api.rules.loan;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;

@Component
public class TelephonyOnly implements LoanRule {

    private static final int MINIMUM_LOAN_TERM_FOR_ONLINE = 66;//months

    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse) {
        eligibilityResponse.getLoans().forEach(loan -> {

            if (loan.getRemainingTerm() < MINIMUM_LOAN_TERM_FOR_ONLINE) {
                loan.setTelephonyOnly(true);
            }
        });
    }

    @Override
    public void isBlocked(ODMLoanResponse odmLoanResponse, Loan loan) {

    }
}

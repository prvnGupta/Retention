package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.exceptions.AcceptInSessionException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.UpdateFeeException;
import com.santanderuk.corinthian.services.retentions.api.mapper.UpdateFeePaymentMapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.ProductTransferFeePayment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ProductSwitchService {

    private final UpdateFeePaymentMapper updateFeePaymentMapper;
    private final ProductSwitchClient productSwitchClient;

    public ProductSwitchService(UpdateFeePaymentMapper updateFeePaymentMapper, ProductSwitchClient productSwitchClient) {
        this.updateFeePaymentMapper = updateFeePaymentMapper;
        this.productSwitchClient = productSwitchClient;
    }

    public void callUpdateFee(String caseId, AcceptAndPayInSessionRequest input, OnlineOfferEntity onlineOfferEntity, String paymentId, String jwtToken) throws JsonProcessingException, UpdateFeeException {
        ProductTransferFeePayment feePaymentRequest = updateFeePaymentMapper.generateRequest(input, onlineOfferEntity, paymentId, jwtToken);
        productSwitchClient.callUpdateFee(caseId, feePaymentRequest);
    }

    public void callAcceptInSession(String caseId) throws AcceptInSessionException {
        try {
            productSwitchClient.acceptInSession(caseId);
        } catch (ConnectionException ex) {
            throw new AcceptInSessionException("Error calling product-switch-service accept-in-session", ex);
        }
    }
}

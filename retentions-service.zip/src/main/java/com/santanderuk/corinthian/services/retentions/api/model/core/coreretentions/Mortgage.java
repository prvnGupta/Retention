package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;


import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class Mortgage {

    @NotBlank
    private String category;
    @NotBlank
    private String methodOfRepaymentType;
    @Valid
    private MortgageTerm term;
    private String classType;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

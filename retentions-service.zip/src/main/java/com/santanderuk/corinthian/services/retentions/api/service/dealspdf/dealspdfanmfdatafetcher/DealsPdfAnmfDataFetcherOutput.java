package com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class DealsPdfAnmfDataFetcherOutput {
    private AnmfAccountServiceResponse anmfAccountServiceResponse;
}

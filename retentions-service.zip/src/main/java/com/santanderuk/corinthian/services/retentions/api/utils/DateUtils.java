package com.santanderuk.corinthian.services.retentions.api.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class DateUtils {

    private final Clock clock;

    @Autowired
    public DateUtils(Clock clock) {
        this.clock = clock;
    }


    public String returnDateAsString(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public LocalDate todaysDate() {
        return LocalDate.now(clock);
    }

    public String addOneDay(String productCompletionDate) {
        DateTimeFormatter anmfFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate productCompletionDateLD = LocalDate.parse(productCompletionDate, anmfFormat);
        return productCompletionDateLD.plusDays(1).format(anmfFormat);
    }

    public String subtractOneDay(String productCompletionDate) {
        DateTimeFormatter anmfFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate productCompletionDateLD = LocalDate.parse(productCompletionDate, anmfFormat);
        return productCompletionDateLD.minusDays(1).format(anmfFormat);
    }

    public String toYearsAndMonths(Integer remainingInstallments) {

        int years = remainingInstallments / 12;
        int months = remainingInstallments % 12;

        String yearString = years > 1 ? "years" : "year";
        String monthString = months > 1 ? "months" : "month";

        if (years == 0) {
            return String.format("%d %s", months, monthString);
        } else if (months == 0) {
            return String.format("%d %s", years, yearString);
        } else {
            return String.format("%d %s %d %s", years, yearString, months, monthString);
        }
    }

    public boolean date1SoonerThanDate2(String date1, String date2) {
        DateTimeFormatter anmfFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate localDate1 = LocalDate.parse(date1, anmfFormat);
        LocalDate localDate2 = LocalDate.parse(date2, anmfFormat);
        return localDate1.isBefore(localDate2);
    }
}

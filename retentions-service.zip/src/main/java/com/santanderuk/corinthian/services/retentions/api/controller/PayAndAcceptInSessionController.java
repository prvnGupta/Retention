package com.santanderuk.corinthian.services.retentions.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.model.ServiceInfoWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.service.PayAndAcceptInSessionService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@Slf4j
public class PayAndAcceptInSessionController extends BaseController {

    private final PayAndAcceptInSessionService payAndAcceptInSessionService;

    @Autowired
    public PayAndAcceptInSessionController(PayAndAcceptInSessionService payAndAcceptInSessionService) {
        this.payAndAcceptInSessionService = payAndAcceptInSessionService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to pay transfer product fee and accept immediately a mortgage retention offer",
            nickname = "payAndAcceptInSession",
            notes = "This endpoint is used by Corinthian frontend application to pay mortgage transfer fee and then accept a previously generated mortgage retention offer. It will invoke payments-service for the fee payment and mortgage-retentions-fullfillment core api (product-switch-service)"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PutMapping(
            value = "/{accountNumber}/offer/{esisRefId}/pay-and-accept-in-session",
            produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE
    )
    public ResponseEntity<ServiceInfoWrapper> payAndAcceptInSession(
            @RequestBody @Valid AcceptAndPayInSessionRequest request,
            @PathVariable("accountNumber") int accountNumber,
            @PathVariable("esisRefId") String esisRefId,
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            HttpServletRequest servletRequest) throws GeneralException, JsonProcessingException {
        logInput(accountNumber, jwtToken, esisRefId);
        payAndAcceptInSessionService.payFeeAndAcceptOffer(request, accountNumber, esisRefId, jwtToken, servletRequest);
        log.info("retentions-service /{accountNumber}/offer/{esisRefId}/pay-and-accept-in-session OK response. esisRefId: {}", sanitizeString(esisRefId));
        return new ResponseEntity<>(buildResponseWrapper(), HttpStatus.OK);
    }

    private void logInput(int account, String jwtToken, String esisRefId) {
        log.info("retentions-service /{accountNumber}/offer/{esisRefId}/pay-and-accept-in-session request received. esisRefId: {}", sanitizeString(esisRefId));
        log.debug("account number: {}", account);
        log.debug("Jwt: {}", sanitizeString(jwtToken));
        log.debug("Esis Ref Id: {}", sanitizeString(esisRefId));
    }

    private ServiceInfoWrapper buildResponseWrapper() {
        ServiceInfoWrapper wrapper = new ServiceInfoWrapper();
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus("ok");
        serviceInfo.setMessage("Transfer complete and fee paid");
        serviceInfo.setCode("SUCCESS");
        wrapper.setInfo(serviceInfo);
        return wrapper;
    }

    @ExceptionHandler(JsonProcessingException.class)
    public ResponseEntity<ServiceInfoWrapper> handleJsonProcessingException() {
        ServiceInfoWrapper wrapper = new ServiceInfoWrapper();
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus("ko");
        serviceInfo.setCode("INTERNAL_SERVER_ERROR");
        serviceInfo.setMessage("Failed to read in database object");
        wrapper.setInfo(serviceInfo);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

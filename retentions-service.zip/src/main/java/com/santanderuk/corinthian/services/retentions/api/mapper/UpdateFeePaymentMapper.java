package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.ProductTransferFeePayment;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class UpdateFeePaymentMapper {

    private final InternalTransferConfig config;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    public UpdateFeePaymentMapper(InternalTransferConfig config, ObjectMapper objectMapper, Clock clock) {
        this.config = config;
        this.objectMapper = objectMapper;
        this.clock = clock;
    }

    public ProductTransferFeePayment generateRequest(AcceptAndPayInSessionRequest request, OnlineOfferEntity onlineOfferEntity, String paymentId, String jwtToken) throws JsonProcessingException {
        removeSpacesAccountFrom(request);
        CoreRetentionsData coreRetentionsData = deserializeCoreRetentionsData(onlineOfferEntity);

        ProductTransferFeePayment productTransferFeePayment = new ProductTransferFeePayment();
        productTransferFeePayment.setAgentId(config.getAgentId());
        productTransferFeePayment.setAnmfAccountNumber(config.getPaymentsDestinationAccNo());
        productTransferFeePayment.setOriginatingDetails(formatAccount(request.getAccountFrom()));
        productTransferFeePayment.setOriginatorName(buildOriginatorName(request.getAccountFrom(), coreRetentionsData, jwtToken).trim());
        productTransferFeePayment.setPaymentId(paymentId);
        productTransferFeePayment.setReference(onlineOfferEntity.getAnmfAccountNumber());
        productTransferFeePayment.setAmount(coreRetentionsData.getSelectedDeal().getProduct().getProductFee());
        productTransferFeePayment.setPaymentDateTime(getDateTimeInFormat());
        return productTransferFeePayment;
    }

    private CoreRetentionsData deserializeCoreRetentionsData(OnlineOfferEntity onlineOfferEntity) throws JsonProcessingException {
        return objectMapper.readValue(onlineOfferEntity.getCoreRetentionsData(), CoreRetentionsData.class);
    }

    private void removeSpacesAccountFrom(AcceptAndPayInSessionRequest request) {
        request.setAccountFrom(request.getAccountFrom().replaceAll("\\s+", ""));
    }

    private String formatAccount(String accountFrom) {
        if (isItSavingAccount(accountFrom)) {
            return accountFrom.substring(0, 6) + " - " + accountFrom.substring(6, 15);
        } else {
            return accountFrom.substring(0, 6) + " " + accountFrom.substring(6);
        }
    }

    private String buildOriginatorName(String accountFrom, CoreRetentionsData coreRetentionsData, String jwtToken) {
        String originatorName;
        if (isItSavingAccount(accountFrom)) {
            originatorName = accountFrom.substring(6, 15);
        } else {
            int customerNumberFromJwt = JwtUtilities.getBdpCustomerFromJWT(jwtToken).getCustomerNumber();
            OCustomer loggedInCustomerDetails = coreRetentionsData.getCustomerDetailsResponse()
                    .getCustomerServiceResponse().getOStruc().getOCustomerList().stream()
                    .filter(customerList -> customerList.getOCustomerId() == customerNumberFromJwt).findFirst().orElseGet(OCustomer::new);

            originatorName = loggedInCustomerDetails.getOCustomerTitle() + " " +
                    loggedInCustomerDetails.getOSurname() + " " +
                    loggedInCustomerDetails.getOForename1() + " " +
                    loggedInCustomerDetails.getOForename2() + " " +
                    loggedInCustomerDetails.getOForename3();
        }
        return originatorName;
    }

    private boolean isItSavingAccount(String accountFrom) {
        return accountFrom.length() > 15;
    }

    private String getDateTimeInFormat() {
        return LocalDateTime.now(clock).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
}

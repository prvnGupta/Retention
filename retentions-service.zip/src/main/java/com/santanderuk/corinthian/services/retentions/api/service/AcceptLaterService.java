package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorBasic;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
@Slf4j
public class AcceptLaterService {

    private final OperativeSecurityService operativeSecurityService;
    private final CacheableOperations cacheableOperations;
    private final ProductSwitchClient productSwitchClient;
    private final OfferInfoValidatorBasic offerInfoValidatorBasic;
    private final GassService gassService;

    @Autowired
    public AcceptLaterService(OperativeSecurityService operativeSecurityService, CacheableOperations cacheableOperations, ProductSwitchClient productSwitchClient, OfferInfoValidatorBasic offerInfoValidatorBasic, GassService gassService) {
        this.operativeSecurityService = operativeSecurityService;
        this.cacheableOperations = cacheableOperations;
        this.productSwitchClient = productSwitchClient;
        this.offerInfoValidatorBasic = offerInfoValidatorBasic;
        this.gassService = gassService;
    }

    public void acceptLater(int account, String jwtToken, String esisRefId, HttpServletRequest servletRequest) throws MaintenanceException, ConnectionException, OperativeSecurityException {

        AnmfRegion region = cacheableOperations.getAnmfActiveRegion();
        operativeSecurityService.checkAnmfAccountBelongToCustomerInJwt(account, jwtToken, region);

        OfferInfoResponse offerInfoResponse = productSwitchClient.retrieveOfferInfo(esisRefId);
        offerInfoValidatorBasic.validateOffer(offerInfoResponse, esisRefId, account);

        String caseId = offerInfoResponse.getData().getCaseId();
        String status = "1";

        try {
            productSwitchClient.acceptLater(caseId);
        } catch (ConnectionException e) {
            status = "2";
            throw e;
        } finally {
            try {
                gassService.auditProductSwitchAcceptLaterInGass(offerInfoResponse.getData().getCoreRetentionsData(), jwtToken, account, offerInfoResponse.getData().getOfferDownloadedDateTime(), servletRequest, status);
            } catch (JsonProcessingException | GeneralException ex) {
                log.error("JsonProcessException while converting from Sting to CoreRetentionsData", ex);
            }
        }

    }
}

package com.santanderuk.corinthian.services.retentions.api.model.esis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
@XmlAccessorType(XmlAccessType.FIELD)
@JacksonXmlRootElement(localName = "Response")
public class RetrieveEsisResponse {

    @JacksonXmlProperty(localName = "KFIData")
    protected KFIData kfiData;
    @JacksonXmlProperty(localName = "Output")
    protected Output output;

    @Getter
    @Setter
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class KFIData {

        @JacksonXmlText
        protected String value;
        @JacksonXmlProperty(isAttribute = true, localName = "KFIId")
        protected String kfiId;
        @JacksonXmlProperty(isAttribute = true, localName = "GZipCompressed")
        protected String gZipCompressed;
        @JacksonXmlProperty(isAttribute = true, localName = "Base64Encoded")
        protected String base64Encoded;

        @Override
        public String toString() {
            return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
        }
    }

    @Getter
    @Setter
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class Output {

        @JacksonXmlText
        protected String value;
        @JacksonXmlProperty(isAttribute = true, localName = "Type")
        protected String type;
        @JacksonXmlProperty(isAttribute = true, localName = "GZipCompressed")
        protected String gZipCompressed;
        @JacksonXmlProperty(isAttribute = true, localName = "Base64Encoded")
        protected String base64Encoded;

        @Override
        public String toString() {
            return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
        }

    }
}

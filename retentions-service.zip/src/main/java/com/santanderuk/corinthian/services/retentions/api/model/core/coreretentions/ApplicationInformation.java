package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;


import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
public class ApplicationInformation {

    private String omrtReference;

    private String brokerReferenceCode;

    private String brokerEmail;

    private String switchEarlyReference;

    private String retentionUserId;

    private String retentionUserName;

    private String saleTypeID;

    private boolean communicationOptOut;

    private String offerCreationSource;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

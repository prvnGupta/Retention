package com.santanderuk.corinthian.services.retentions.api.service.deals.anmfdatafetcher;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AnmfDataFetcher {

    private final AnmfCoreClient anmfCoreClient;
    private final AnmfConfiguration configuration;
    private final HeartBeatClient heartBeatClient;

    @Autowired
    public AnmfDataFetcher(AnmfCoreClient anmfCoreClient, AnmfConfiguration configuration, HeartBeatClient heartBeatClient) {
        this.anmfCoreClient = anmfCoreClient;
        this.configuration = configuration;
        this.heartBeatClient = heartBeatClient;
    }

    public AnmfDataFetcherOutput fetch(int account) throws ConnectionException, MaintenanceException {
        var region = heartBeatClient.fetchCurrentRegion();

        var property = property(account, region);
        var accountDetails = accountDetails(account, region);

        return new AnmfDataFetcherOutput(property, accountDetails);
    }

    private AnmfAccountServiceResponse accountDetails(int account, AnmfRegion region) throws ConnectionException {
        return anmfCoreClient.fetchMortgageAccountDetailsV5(account, configuration.getAnmfAccountDetailsUrl(), region);
    }

    private ANMFPropertyResponse property(int account, AnmfRegion region) throws ConnectionException {
        return anmfCoreClient.fetchAddress(account, configuration.getAnmfPropertyUrl(), region);
    }
}

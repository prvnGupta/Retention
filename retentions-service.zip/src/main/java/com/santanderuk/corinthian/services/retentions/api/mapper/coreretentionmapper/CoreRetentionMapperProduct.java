package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.FeePart;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.Fees;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.Product;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
public class CoreRetentionMapperProduct {

    public void map(CoreRetentionRequest coreRetentionRequest, CoreRetentionsData input) {
        String productCodeFromRequest = input.getCaseRequest().getProductCode();

        Product product = new Product();
        product.setCode(productCodeFromRequest);
        product.setDescription(getProductDescription(input));
        product.setFeeReceived(getFeeReceived(input));

        setUpFees(product, input);

        coreRetentionRequest.setProduct(product);
    }

    private String getProductDescription(CoreRetentionsData input) {
        return input.getSelectedDeal().getProduct().getDescription();
    }

    private String getFeeReceived(CoreRetentionsData input) {
        return input.getCaseRequest().isFeeAddedInMortgage()
                ? "Fee Rolled In"
                : "Fee Paid Upfront";
    }

    private void setUpFees(Product product, CoreRetentionsData input) {
        Fees fees = new Fees();
        fees.setIndicator(!productFeeIsZero(input));
        fees.setRequiredType("0");
        fees.setTotalFeesAddedAmount(input.getSelectedDeal().getProduct().getProductFee());
        fees.setAddedIndicator(productFeeIsZero(input) ? 4 : 1);

        List<FeePart> feeParts = new ArrayList<>();
        feeParts.add(createByDefaultFeePart());
        if (!productFeeIsZero(input)) {
            feeParts.add(createProductFeePart(input));
        }
        fees.setFeeParts(feeParts);

        product.setFees(fees);
    }

    private boolean productFeeIsZero(CoreRetentionsData input) {
        return input.getSelectedDeal().getProduct().getProductFee().compareTo(new BigDecimal("0.00")) == 0;
    }

    private FeePart createProductFeePart(CoreRetentionsData input) {
        BigDecimal productFee = input.getSelectedDeal().getProduct().getProductFee();
        String productCode = input.getSelectedDeal().getProduct().getProductCode();
        boolean feeAddedToMortgage = input.getCaseRequest().isFeeAddedInMortgage();

        FeePart feePart = new FeePart();

        feePart.setType(48);
        feePart.setAddedToLoanPartId(feeAddedToMortgage ? input.getSelectedDeal().getLoanToApplyTheFeeTo() : 0);
        feePart.setAmount(productFee);
        feePart.setAmountAddedToLoan(feeAddedToMortgage ? productFee : new BigDecimal("0.00"));
        feePart.setAmountCapitalised(feeAddedToMortgage ? productFee : new BigDecimal("0.00"));
        feePart.setAmountDueByCard(feeAddedToMortgage ? new BigDecimal("0.00") : productFee);
        feePart.setAmountDueByCheque(new BigDecimal("0.00"));
        feePart.setAmountPaidOnApplication(feeAddedToMortgage ? new BigDecimal("0.00") : productFee);
        feePart.setAmountPayable(productFee);
        feePart.setAmountWaived(new BigDecimal("0.00"));
        feePart.setBookingFeePercentage(new BigDecimal("0.00"));
        feePart.setBookingFeeProduct(productCode);
        feePart.setCanAddToLoan(feeAddedToMortgage);
        feePart.setCapitalisedLoanID(feeAddedToMortgage ? String.valueOf(input.getSelectedDeal().getLoanToApplyTheFeeTo()) : "0");
        feePart.setDescription("Booking Fee");

        return feePart;
    }

    private FeePart createByDefaultFeePart() {
        FeePart feePart = new FeePart();

        feePart.setType(11);
        feePart.setAddedToLoanPartId(0);
        feePart.setAmount(new BigDecimal("225.00"));
        feePart.setAmountAddedToLoan(new BigDecimal("0.00"));
        feePart.setAmountCapitalised(new BigDecimal("0.00"));
        feePart.setAmountDueByCard(new BigDecimal("0.00"));
        feePart.setAmountDueByCheque(new BigDecimal("0.00"));
        feePart.setAmountPaidOnApplication(new BigDecimal("0.00"));
        feePart.setAmountPayable(new BigDecimal("225.00"));
        feePart.setAmountWaived(new BigDecimal("0.00"));
        feePart.setBookingFeePercentage(new BigDecimal("0.00"));
        feePart.setBookingFeeProduct("");
        feePart.setCanAddToLoan(false);
        feePart.setCapitalisedLoanID("0");
        feePart.setDescription("Repayment Fee");

        return feePart;
    }

}

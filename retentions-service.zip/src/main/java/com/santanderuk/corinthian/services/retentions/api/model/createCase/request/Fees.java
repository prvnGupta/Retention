package com.santanderuk.corinthian.services.retentions.api.model.createCase.request;

import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class Fees {

    @NotNull
    private Boolean indicator;
    @Positive
    private Integer addedIndicator;
    private String requiredType;
    @PositiveOrZero
    private BigDecimal totalFeesAddedAmount;
    @Valid
    private List<FeePart> feeParts;

}

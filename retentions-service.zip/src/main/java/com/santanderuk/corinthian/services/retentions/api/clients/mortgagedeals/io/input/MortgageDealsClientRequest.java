package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MortgageDealsClientRequest extends ModelBase {

    private static final long serialVersionUID = 3144384700906244726L;

    private String accountNumber;
    @JsonProperty("isBuyToLet")
    private boolean isBuyToLet;
    @JsonProperty("isConsentToLet")
    private boolean isConsentToLet;
    @JsonProperty("isFlexi")
    private boolean isFlexi;

    private String salesChannel;

    private List<Loan> loans;
}

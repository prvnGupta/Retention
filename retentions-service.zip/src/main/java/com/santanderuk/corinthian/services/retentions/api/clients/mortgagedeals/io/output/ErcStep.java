package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ErcStep extends ModelBase {

    private static final long serialVersionUID = 1925439925954706892L;

    private String stepMaturityDate;
    private BigDecimal rate;

}

package com.santanderuk.corinthian.services.retentions.api.model.esis;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class RetrieveEsisResponseContent {


}

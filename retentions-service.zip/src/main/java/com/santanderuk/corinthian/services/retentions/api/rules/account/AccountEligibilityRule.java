package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;

public interface AccountEligibilityRule {

    void isEligible(EligibilityResponse eligibilityResponse, AnmfCoreResponse anmfCoreResponse, OdmEligibilityResponse odmEligibilityResponse);
}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.clients.productdirectory.ProductDirectoryClient;
import com.santanderuk.corinthian.services.commons.clients.productdirectory.ProductDirectoryResponse;
import com.santanderuk.corinthian.services.commons.clients.productdirectory.QueryParams;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ProductDirectoryService {


    ProductDirectoryClient productDirectoryClient;
    @Value("${product-directory.url}")
    private String productDirectoryUrl;
    @Value("${product-directory.query-parameters.result-filter}")
    private String queryResultFilter;
    @Value("${product-directory.query-parameters.application-type}")
    private String queryApplicationType;
    @Value("${product-directory.query-parameters.range-type}")
    private String queryRangeType;


    @Autowired
    public ProductDirectoryService(ProductDirectoryClient productDirectoryClient) {
        this.productDirectoryClient = productDirectoryClient;
    }

    public ProductDirectoryResponse getCompletionAndNearestDate(int account) throws ConnectionException, ValidationsException {
        log.info("Acc Number: {}. About to product catalogue completion-date endpoint", account);
        ProductDirectoryResponse productDirectoryData = productDirectoryClient.fetchProductDirectoryData(productDirectoryUrl, formQueryParams());
        log.info("Acc Number: {}. Product catalogue completion-date response received", account);
        return productDirectoryData;
    }

    private QueryParams formQueryParams() {
        QueryParams queryParams = new QueryParams();
        queryParams.setResultFilter(queryResultFilter);
        queryParams.setApplicationType(queryApplicationType);
        queryParams.setRangeType(queryRangeType);
        return queryParams;
    }

}

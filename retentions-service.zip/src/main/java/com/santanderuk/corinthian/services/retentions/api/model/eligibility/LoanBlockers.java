package com.santanderuk.corinthian.services.retentions.api.model.eligibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoanBlockers extends ModelBase {

    private static final long serialVersionUID = -5195303047159586916L;

    private boolean outsideDealWindow;

}

package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input;

public enum LoanType {
    R,
    I,
    UNDEFINED
}

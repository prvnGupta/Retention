package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class CoreRetentionsData {

    private int account;
    private CreateCaseRequest caseRequest;
    private Deal selectedDeal;
    private AnmfAccountServiceResponse anmfAccountServiceResponse;
    private ANMFPropertyResponse addressResponse;
    private CustomerDetailsResponse customerDetailsResponse;
    private String bdpType;
    private int bdpNumber;
}

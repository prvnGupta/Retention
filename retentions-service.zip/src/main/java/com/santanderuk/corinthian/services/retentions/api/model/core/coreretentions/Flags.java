package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
public class Flags {

    private int advised;
    private boolean introduced;
    private String btlClassification;
    private boolean initialAdvance;
    private int callingService;
    private String esisDoc;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

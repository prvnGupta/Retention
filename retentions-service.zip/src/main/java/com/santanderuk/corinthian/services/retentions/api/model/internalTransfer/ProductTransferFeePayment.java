package com.santanderuk.corinthian.services.retentions.api.model.internalTransfer;

import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class ProductTransferFeePayment extends ModelBase {
    private String agentId;
    private String anmfAccountNumber;
    private String originatingDetails;
    private String originatorName;
    private String paymentId;
    private String reference;
    private BigDecimal amount;
    private String paymentDateTime;
}

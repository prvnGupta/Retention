package com.santanderuk.corinthian.services.retentions.api.exceptions;

public class FieldValidationException extends RuntimeException {

    public FieldValidationException(String body) {
        super(body);
    }
}

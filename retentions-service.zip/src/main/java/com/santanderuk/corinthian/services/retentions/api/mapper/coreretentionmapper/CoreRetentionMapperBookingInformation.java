package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.BookingInformation;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class CoreRetentionMapperBookingInformation {

    public void map(CoreRetentionRequest coreRetentionRequest, CoreRetentionsData input) {
        BookingInformation bookingInformation = new BookingInformation();

        bookingInformation.setBusinessCircumstanceCode("Existing Borrower");
        bookingInformation.setBusinessSource("Introduced");
        bookingInformation.setTotalBookingAmount(getTotalBookingAmount(input));
        bookingInformation.setBookingStatus("Confirmed");
        bookingInformation.setApplicationFormReceived("Yes");
        bookingInformation.setBranchID(0);
        bookingInformation.setBusinessGroup("Contact Centre");

        coreRetentionRequest.setBookingInformation(bookingInformation);
    }

    private BigDecimal getTotalBookingAmount(CoreRetentionsData input) {
        return input.getAnmfAccountServiceResponse().getAccountServiceResponse()
                .getResponse().getOStruc().getOActiveLoanDetails().stream()
                .filter(oLoan -> isInSelectedLoans(oLoan, input.getCaseRequest().getLoansSelected()))
                .map(OActiveLoanDetail::getOCapitalBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private boolean isInSelectedLoans(OActiveLoanDetail oLoan, List<LoanIdentifier> selectedLoans) {
        long count = selectedLoans.stream()
                .filter(loanIdentifier -> isSameLoan(loanIdentifier, oLoan))
                .count();
        return count > 0;
    }

    private boolean isSameLoan(LoanIdentifier loanIdentifier, OActiveLoanDetail oLoan) {
        boolean sameLoanScheme = loanIdentifier.getLoanScheme().equalsIgnoreCase(oLoan.getOLoanScheme());
        boolean sameAppSeqNumber = loanIdentifier.getSequenceNumber() == oLoan.getOApplSeqNo();
        return sameLoanScheme && sameAppSeqNumber;
    }
}

package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.retentions.api.utils.CustomProductDateDeserializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Product extends ModelBase {

    private static final long serialVersionUID = 3226048168788762498L;

    @JsonDeserialize(using = CustomProductDateDeserializer.class)
    private String chargeEndDate;
    private BigDecimal maxLtv;
    private BigDecimal productFee;
    private String type;
    private String productCode;
    private BigDecimal rate;
    private String productDescription;
    private BigDecimal apr;
    private BigDecimal bankOfEnglandSvr;
    private boolean eligible;
    private List<LoanBreakdown> loanBreakdown;
    private BreakdownSummary breakdownSummary;
    private Erc erc;
    private Term term;
    private BigDecimal overpaymentAllowance;
    private boolean lifetime;
    private String launchDate;
    private String offSaleDate;
    private Term chargeEndAnniversary;
    private BigDecimal reversionBaseRate;
    private BigDecimal baseRateDifferential;
    @JsonDeserialize(using = CustomProductDateDeserializer.class)
    private String completionDeadline;
    private BigDecimal reversionRate;


}

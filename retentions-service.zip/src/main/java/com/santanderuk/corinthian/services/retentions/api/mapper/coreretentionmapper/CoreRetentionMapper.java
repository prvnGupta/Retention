package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.ClientChannel;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.GovernanceType;
import org.springframework.stereotype.Component;

@Component
public class CoreRetentionMapper {

    private CoreRetentionMapperAccount coreRetentionMapperAccount;
    private CoreRetentionMapperProduct coreRetentionMapperProduct;
    private CoreRetentionMapperFlags coreRetentionMapperFlags;
    private CoreRetentionMapperGeneralInformation coreRetentionMapperGeneralInformation;
    private CoreRetentionMapperAdvisorInformation coreRetentionMapperAdvisorInformation;
    private CoreRetentionMapperBookingInformation coreRetentionMapperBookingInformation;
    private CoreRetentionMapperApplicationInformation coreRetentionMapperApplicationInformation;
    private CoreRetentionMapperOfferConversionDetails coreRetentionMapperOfferConversionDetails;

    public CoreRetentionMapper(CoreRetentionMapperAccount coreRetentionMapperAccount, CoreRetentionMapperProduct coreRetentionMapperProduct, CoreRetentionMapperFlags coreRetentionMapperFlags, CoreRetentionMapperGeneralInformation coreRetentionMapperGeneralInformation, CoreRetentionMapperAdvisorInformation coreRetentionMapperAdvisorInformation, CoreRetentionMapperBookingInformation coreRetentionMapperBookingInformation, CoreRetentionMapperApplicationInformation coreRetentionMapperApplicationInformation, CoreRetentionMapperOfferConversionDetails coreRetentionMapperOfferConversionDetails) {
        this.coreRetentionMapperAccount = coreRetentionMapperAccount;
        this.coreRetentionMapperProduct = coreRetentionMapperProduct;
        this.coreRetentionMapperFlags = coreRetentionMapperFlags;
        this.coreRetentionMapperGeneralInformation = coreRetentionMapperGeneralInformation;
        this.coreRetentionMapperAdvisorInformation = coreRetentionMapperAdvisorInformation;
        this.coreRetentionMapperBookingInformation = coreRetentionMapperBookingInformation;
        this.coreRetentionMapperApplicationInformation = coreRetentionMapperApplicationInformation;
        this.coreRetentionMapperOfferConversionDetails = coreRetentionMapperOfferConversionDetails;
    }

    public CoreRetentionRequest buildCoreRetentionsRequest(CoreRetentionsData input) {
        CoreRetentionRequest coreRetentionRequest = new CoreRetentionRequest();

        coreRetentionRequest.setChannel(ClientChannel.CORINTHIAN);
        coreRetentionRequest.setGovernanceType(GovernanceType.valueOfLabel(fetchGovernanceType(input)).id);
        coreRetentionRequest.setAnmfToAnmfSwitch(true);
        coreRetentionMapperProduct.map(coreRetentionRequest, input);
        coreRetentionMapperAccount.map(coreRetentionRequest, input);
        coreRetentionMapperFlags.map(coreRetentionRequest, input);
        coreRetentionMapperGeneralInformation.map(coreRetentionRequest);
        coreRetentionMapperAdvisorInformation.map(coreRetentionRequest);
        coreRetentionMapperBookingInformation.map(coreRetentionRequest, input);
        coreRetentionMapperApplicationInformation.map(coreRetentionRequest);
        coreRetentionMapperOfferConversionDetails.map(coreRetentionRequest);

        return coreRetentionRequest;
    }

    private String fetchGovernanceType(CoreRetentionsData input) {
        return input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOGovernanceType();
    }
}

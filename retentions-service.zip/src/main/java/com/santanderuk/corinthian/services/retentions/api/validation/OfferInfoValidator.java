package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.retentions.api.exceptions.ForbiddenException;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;

public interface OfferInfoValidator {

    public void validateOffer(OfferInfoResponse offerInfoResponse, String esisRefId, int anmfAccount);

    default void validateEsisRefId(OfferInfoResponse offerInfoResponse, String esisRefId) {
        if (!offerInfoResponse.getData().getEsisRefId().equals(esisRefId)) {
            throw new ForbiddenException("ESIS_REF_ID_NOT_MATCHING", "esis ref id returned does not match request");
        }
    }

    default void validateOfferGeneratedForThisAnmfAccount(OfferInfoResponse offerInfoResponse, int anmfAccount) {
        int offerInfoAccount = Integer.parseInt(offerInfoResponse.getData().getAnmfAccountNumber().replace("ANMF", ""));

        if (offerInfoAccount != anmfAccount) {
            throw new ForbiddenException("ACCOUNT_NOT_MATCHING", "The account is not allowed to access this resource");
        }
    }

    default void validateFeeRolledIntoMortgage(OfferInfoResponse offerInfoResponse) {
        if (offerInfoResponse.getData().isFeePaidUpfront()) {
            throw new ForbiddenException("NOT_THE_RIGHT_API_TO_USE", "for fee paying upfront use the correct api");
        }
    }

    default void validateFeePaidUpfront(OfferInfoResponse offerInfoResponse) {
        if (!offerInfoResponse.getData().isFeePaidUpfront()) {
            throw new ForbiddenException("NOT_THE_RIGHT_API_TO_USE", "for fee paying in mortgage use the correct api");
        }
    }
}

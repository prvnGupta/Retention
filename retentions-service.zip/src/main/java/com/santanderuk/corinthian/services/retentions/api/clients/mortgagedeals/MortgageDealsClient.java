package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.MortgageDealsClientResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/*
    Client for this API: https://internal-developer-pre.santanderuk.pre.corp/sanuk/internal/node/21846
*/
@Component
@Slf4j
public class MortgageDealsClient {

    private final MortgageDealsClientConfig configuration;
    private final RestTemplate restTemplate;

    @Autowired
    public MortgageDealsClient(MortgageDealsClientConfig configuration, RestTemplate restTemplate) {
        this.configuration = configuration;
        this.restTemplate = restTemplate;
    }

    public MortgageDealsClientResponse fetch(MortgageDealsClientRequest request) throws MortgageDealsClientException {
        var req = createHttpEntity(request);

        ResponseEntity<MortgageDealsClientResponse> responseEntity;
        try {
            responseEntity = restTemplate.postForEntity(
                    configuration.getUrl(),
                    req,
                    MortgageDealsClientResponse.class);

        } catch (RestClientException e) {
            throw new MortgageDealsClientException();
        }

        return responseEntity.getBody();
    }

    private HttpEntity<MortgageDealsClientRequest> createHttpEntity(MortgageDealsClientRequest request) {
        var headers = createHttpHeaders();
        return new HttpEntity<>(request, headers);
    }

    private HttpHeaders createHttpHeaders() {
        var headers = new HttpHeaders();
        headers.add("X-IBM-Client-Id", configuration.getXIbmConfigId());
        headers.add("Accept", "application/json");
        headers.add("Content-Type", "application/json");
        return headers;
    }
}

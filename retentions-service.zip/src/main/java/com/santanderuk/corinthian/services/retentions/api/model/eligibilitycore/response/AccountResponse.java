package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class AccountResponse {
    private String accountNumber;
    private String accountEligibility;
    private String accountBalanceEligibility;
    private String accountBand;
    private String flexiEligibility;
    private String bandEligibility;
    private String minimumRemainingTermAccountEligibility;
    private BigDecimal minimumBalance;
    private List<ODMLoanResponse> loanResponse;
}

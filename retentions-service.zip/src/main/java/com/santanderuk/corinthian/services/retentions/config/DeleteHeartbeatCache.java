package com.santanderuk.corinthian.services.retentions.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
@Slf4j
public class DeleteHeartbeatCache {
    @Value("${caching.inMemoryCacheNames}")
    private String inMemoryCacheNames;

    @Autowired
    @Qualifier("cacheManagerHeartbeat")
    private CacheManager cacheManagerHeartbeat;

    @Scheduled(cron = "${caching.heartbeatExpiration}")
    private void clearAllCacheValues() {
        deleteInMemoryCache();
    }

    private void deleteInMemoryCache() {
        String[] cacheNames = inMemoryCacheNames.split(",");

        for (String cacheName : cacheNames) {
            cacheManagerHeartbeat.getCache(cacheName).clear();
        }
    }
}


package com.santanderuk.corinthian.services.retentions.api.exceptions;

public class AcceptInSessionException extends RuntimeException {

    public AcceptInSessionException(String message) {
        super(message);
    }

    public AcceptInSessionException(String msg, Exception e) {
        super(msg, e);
    }
}

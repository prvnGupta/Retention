package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.generate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GenerateOfferWrapper {

    private GenerateOffer response;
    private ServiceInfo info;
}

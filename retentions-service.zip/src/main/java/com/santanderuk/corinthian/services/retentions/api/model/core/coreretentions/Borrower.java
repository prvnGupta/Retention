package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;


import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class Borrower {

    private boolean leadCustomerInd;

    @NotBlank
    private String title;

    private String initials;

    @NotBlank
    private String forename;

    @NotBlank
    private String surname;

    @NotBlank
    private String bdpCustomerType;

    @NotBlank
    private String bdpCustomerNumber;

    private String homeTelNumber;

    @NotBlank
    private String mobileTelNumber;

    @Email
    private String emailAddress;

    @Valid
    private BorrowerCorrespondenceAddress borrowerCorrespondenceAddress;

    @NotNull
    private boolean staffInd;

    @NotBlank
    private String dateOfBirth;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

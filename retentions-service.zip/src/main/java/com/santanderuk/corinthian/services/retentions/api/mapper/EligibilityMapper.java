package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.retentions.api.model.eligibility.AccountBlockers;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static java.math.RoundingMode.HALF_UP;

@Component
@Slf4j
public class EligibilityMapper {

    public EligibilityResponse toEligibilityResponse(OdmEligibilityResponse odmCoreResponse) {

        if (odmCoreResponse != null && odmCoreResponse.getAccountResponse() != null) {

            return buildEligibilityResponse(odmCoreResponse);
        }
        return new EligibilityResponse();
    }

    private EligibilityResponse buildEligibilityResponse(OdmEligibilityResponse odmCoreResponse) {
        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        AccountBlockers blockers = new AccountBlockers();
        eligibilityResponse.setMinimumBalanceForSwitching(odmCoreResponse.getAccountResponse().getMinimumBalance().setScale(2, HALF_UP));
        eligibilityResponse.setBlockers(blockers);
        eligibilityResponse.setBandId(odmCoreResponse.getAccountResponse().getAccountBand());
        return eligibilityResponse;
    }
}

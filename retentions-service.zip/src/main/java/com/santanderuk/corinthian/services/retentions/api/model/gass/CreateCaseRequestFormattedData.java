package com.santanderuk.corinthian.services.retentions.api.model.gass;

import com.santanderuk.corinthian.gassaudit.model.FormattedData;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CreateCaseRequestFormattedData implements FormattedData {

    private String customerNumber;
    private String multiChannelContractId;
    private String uid;
    private String mortgageSortcode;
    private String mortgageAccount;
    private boolean jointMortgage;
    private List<SelectedLoanGassFormat> switchedLoanParts;
    private ProductDetails newProductDetails;
}

package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.Flags;
import org.springframework.stereotype.Component;

@Component
public class CoreRetentionMapperFlags {


    public void map(CoreRetentionRequest coreRetentionRequest, CoreRetentionsData input) {
        Flags flags = new Flags();

        flags.setAdvised(2);
        flags.setIntroduced(false);
        flags.setInitialAdvance(false);
        flags.setCallingService(3);
        flags.setBtlClassification(getBuyToLetFromAnmfAddressResponse(input));
        flags.setEsisDoc(null);

        coreRetentionRequest.setFlags(flags);
    }

    private String getBuyToLetFromAnmfAddressResponse(CoreRetentionsData input) {
        String oSpecialPurchase = input.getAddressResponse().getPropertyEnquiryResponse().getOutputStructure()
                .getOSpecialPurchase();
        return "L".equalsIgnoreCase(oSpecialPurchase)
                ? "B"
                : "N";
    }
}

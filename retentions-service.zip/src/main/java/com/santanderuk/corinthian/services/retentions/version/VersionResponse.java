package com.santanderuk.corinthian.services.retentions.version;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VersionResponse {

    private String buildTime;
    private String gitHash;
    private String buildVersion;
    private String serviceName;

}

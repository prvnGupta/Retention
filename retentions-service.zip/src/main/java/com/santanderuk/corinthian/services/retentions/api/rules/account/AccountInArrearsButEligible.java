package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;

@Component
public class AccountInArrearsButEligible implements AccountEligibilityRule {


    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, AnmfCoreResponse anmfCoreResponse, OdmEligibilityResponse odmEligibilityResponse) {
        eligibilityResponse.getBlockers().setEligibleInArrears(isInArrearsAndBandNotW(anmfCoreResponse.isCustomerOnArrears(), odmEligibilityResponse.getAccountResponse().getAccountBand()));
    }

    private boolean isInArrearsAndBandNotW(boolean customerOnArrears, String accountBand) {
        return customerOnArrears && !accountBand.equalsIgnoreCase("W");
    }

}

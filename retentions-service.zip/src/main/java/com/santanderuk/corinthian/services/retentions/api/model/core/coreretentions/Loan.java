package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

@Getter
@Setter
public class Loan {

    @Positive
    private int partId;
    @NotBlank
    private String loanScheme;
    @Positive
    private int sequenceNumber;
    @NotBlank
    private String productType;
    @NotBlank
    private String productCode;
    private boolean newProduct;
    @PositiveOrZero
    private BigDecimal balanceRequestAmount;
    @Positive
    private int repaymentType;
    @NotNull
    private boolean repaymentTypeChanged;
    private boolean capitalRepaymentMade;
    @PositiveOrZero
    private BigDecimal capitalRepaymentAmt;
    @Valid
    private LoanTerm term;
    @PositiveOrZero
    private BigDecimal interestRate;
    @NotNull
    private boolean portedLoan;
    @NotBlank
    private String originalProductCompletionDate;

    private boolean isTransferring;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

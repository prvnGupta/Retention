package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

public enum GovernanceType {

    FSA("FSA", "1"),
    CCA("CCA", "2"),
    UNREGULATED("UNR", "3"),
    PARTIALCCAREGULATED("Partial CCA Regulated", "5");

    public final String label;
    public final String id;

    private GovernanceType(String label, String id) {
        this.label = label;
        this.id = id;
    }

    public static GovernanceType valueOfLabel(String label) {
        for (GovernanceType e : values()) {
            if (e.label.equals(label)) {
                return e;
            }
        }
        return null;
    }
}

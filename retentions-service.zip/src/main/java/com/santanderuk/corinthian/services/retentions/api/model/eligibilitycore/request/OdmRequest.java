package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.utilities.LogMasker;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class OdmRequest {

    @JsonProperty("channelID")
    private String channelID;
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("accountNumberType")
    private String accountNumberType;
    @JsonProperty("accountBalance")
    private BigDecimal accountBalance;
    @JsonProperty("isBuyToLet")
    private String isBuyToLet;
    @JsonProperty("isConsentToLet")
    private String isConsentToLet;
    @JsonProperty("isFlexi")
    private String isFlexi;
    @JsonProperty("riskLevel")
    private String riskLevel;
    @JsonProperty("customerNumber")
    private String customerNumber;
    @JsonProperty("postCode")
    private String postCode;
    @JsonProperty("chargeEndDate")
    private String chargeEndDate;
    @JsonProperty("completionDate")
    private String completionDate;
    @JsonProperty("loanRequest")
    private List<ODMLoanRequest> loanRequest;
    @JsonProperty("ltvio")
    private BigDecimal ltvio;
    @JsonProperty("ltvgeneral")
    private BigDecimal ltvgeneral;


    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }

    public String toStringMasked() {
        return (new ToStringBuilder(this, ToStringStyle.JSON_STYLE))
                .append("channelID", this.channelID)
                .append("accountNumber", this.accountNumber)
                .append("accountNumberType", this.accountNumberType)
                .append("accountBalance", this.accountBalance)
                .append("isBuyToLet", this.isBuyToLet)
                .append("isConsentToLet", this.isConsentToLet)
                .append("isFlexi", this.isFlexi)
                .append("riskLevel", this.riskLevel)
                .append("customerNumber", this.customerNumber)
                .append("postCode", this.postCode)
                .append("chargeEndDate", this.chargeEndDate)
                .append("completionDate", this.completionDate)
                .append("loanRequest", this.loanRequest)
                .append("ltvio", this.ltvio)
                .append("ltvgeneral", this.ltvgeneral)
                .toString();
    }

    public OdmRequest masked() {

        OdmRequest deepCopy = null;

        try {

            ObjectMapper objectMapper = new ObjectMapper();
            deepCopy = objectMapper.readValue(objectMapper.writeValueAsString(this), OdmRequest.class);

            LogMasker logMasker = new LogMasker();
            deepCopy.setAccountNumber(logMasker.withContentStatus(deepCopy.getAccountNumber()));
            deepCopy.setCustomerNumber(logMasker.withContentStatus(deepCopy.getCustomerNumber()));
            deepCopy.setPostCode(logMasker.withContentStatus(deepCopy.getPostCode()));

        } catch (IOException e) {
            return null;
        }

        return deepCopy;
    }

}

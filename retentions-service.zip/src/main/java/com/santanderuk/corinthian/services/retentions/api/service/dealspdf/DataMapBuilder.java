package com.santanderuk.corinthian.services.retentions.api.service.dealspdf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import com.santanderuk.corinthian.services.retentions.api.model.dealspdf.PdfLoan;
import com.santanderuk.corinthian.services.retentions.api.model.dealspdf.PdfProduct;
import com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher.DealsPdfAnmfDataFetcherOutput;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.math.RoundingMode.HALF_UP;

@Component
public class DataMapBuilder {
    public Map<String, Object> build(DealsResponse dealsResponse, DealsPdfAnmfDataFetcherOutput anmfData, DealsRequest dealsRequest) {

        removeSvrProductFromProductsIfCurrentlyOnSvrAndSingleLoan(dealsResponse);
        return Map.of(
                "productsTable", generateProductList(dealsResponse),
                "currentDate", formatCurrentDateForPdf(),
                "bankOfEnglandRate", extractBankOfEnglandRate(dealsResponse),
                "currentLoans", generateCurrentLoansList(anmfData, dealsRequest),
                "diffSFORwithBoE", calculateDiffBetweenSFORAndBoElandRates(dealsResponse),
                "totalBalance", buildTotalBalance(anmfData),
                "totalMonthlyPayment", buildTotalMonthlyPayment(anmfData),
                "SVRReversionActive", checkIfAnyProductRevertingToSVR(dealsResponse),
                "stepErcActive", dealsResponse.isStepErcActive());
    }

    private void removeSvrProductFromProductsIfCurrentlyOnSvrAndSingleLoan(DealsResponse dealsResponse) {
        if (null != dealsResponse.getDeals() && !dealsResponse.getDeals().isEmpty()) {
            List<DealLoanView> dealLoans = dealsResponse.getDeals().get(0).getDealLoans();
            if (dealLoans.size() == 1 && dealLoans.get(0).getPreviousProduct().toLowerCase().contains("standard variable rate")) {
                dealsResponse.getDeals().removeIf(deal -> deal.getProduct().getType().equalsIgnoreCase("variable") && deal.getProduct().getTerm().equalsIgnoreCase("lifetime"));
            }
        }
    }

    private boolean checkIfAnyProductRevertingToSVR(DealsResponse dealsResponse) {
        return null != dealsResponse.getDeals() && null != dealsResponse.getDeals().stream().filter(this::productRevertingToSVR).findFirst().orElse(null);

    }

    private boolean productRevertingToSVR(Deal deal) {
        return deal.getProduct().getReversionProduct().equalsIgnoreCase("SVR");

    }

    private List<PdfProduct> generateProductList(DealsResponse dealsResponse) {
        return null == dealsResponse.getDeals() ? new ArrayList<>() : dealsResponse.getDeals().stream().map(this::convertToPdfProduct).collect(Collectors.toList());
    }

    private PdfProduct convertToPdfProduct(Deal deal) {
        Product product = deal.getProduct();

        PdfProduct pdfProduct = new PdfProduct();
        pdfProduct.setProductDescription(generateProductDesc(product));
        pdfProduct.setInitialRate(product.getRate().setScale(2, HALF_UP) + "%");
        pdfProduct.setProductFee("£" + product.getProductFee());
        pdfProduct.setMonthlyPaymentWithFee(pdfAmountText(deal.getCalculations().getMonthlyPaymentWithFee()));
        pdfProduct.setMonthlyPaymentWithoutFee(pdfAmountText(deal.getCalculations().getMonthlyPaymentWithoutFee()));
        pdfProduct.setErc(formatPdfErc(product.getErcPercentage()));

        pdfProduct.setOverpaymentAllowance(calculateOverpaymentAllowance(product));

        pdfProduct.setType(product.getType());
        pdfProduct.setDiffBankOfEnglandBaseRate(calculateDiffBankOfEnglandRate(product));

        return pdfProduct;
    }

    private String generateProductDesc(Product product) {
        if (product.getTerm().equalsIgnoreCase("lifetime") && product.getType().equalsIgnoreCase("variable")) {
            return "Standard Variable Rate";
        }
        return product.getTerm() + " " + product.getType();
    }

    private String calculateDiffBankOfEnglandRate(Product product) {
        return null == product.getBankOfEnglandRateDifference() ? "" : product.getBankOfEnglandRateDifference().setScale(2, HALF_UP) + "%";
    }

    private String pdfAmountText(BigDecimal amount) {
        DecimalFormat df = new DecimalFormat("#,###.00");
        return "£" + df.format(amount);
    }

    private String calculateOverpaymentAllowance(Product product) {
        BigDecimal ercPercentage = product.getErcPercentage();
        return ercPercentage.compareTo(BigDecimal.ZERO) == 0 ? "Unlimited" : product.getAnnualOverpaymentAllowancePercentage() + "%";
    }

    private String formatPdfErc(BigDecimal ercPercentage) {
        return ercPercentage.compareTo(BigDecimal.ZERO) == 0 ? "No charge" : ercPercentage + "%";
    }

    private String formatCurrentDateForPdf() {
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        return currentDate.format(formatter);

    }

    private String extractBankOfEnglandRate(DealsResponse dealsResponse) {
        try {
            return dealsResponse.getDeals().get(0).getProduct().getBankOfEnglandRate() + "%";//.setScale(2, RoundingMode.HALF_UP) + "%";
        } catch (Exception e) {
            // Is not that the scenario without deals is common, as they should have at least a SVR available
            // but just in case as good practice when having arrays
            return "";
        }
    }

    private List<PdfLoan> generateCurrentLoansList(DealsPdfAnmfDataFetcherOutput anmfData, DealsRequest selectedLoans) {

        return anmfData.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().stream().map(activeLoan -> convertActiveLoanToPdfLoan(activeLoan, selectedLoans)).collect(Collectors.toList());
    }

    private PdfLoan convertActiveLoanToPdfLoan(OActiveLoanDetail loan, DealsRequest selectedLoans) {

        PdfLoan pdfLoan = new PdfLoan();
        pdfLoan.setInterestRate(loan.getOInterestRate() + "%");
        pdfLoan.setLoanBalance(pdfAmountText(loan.getOOutstandingBalance()));
        pdfLoan.setMonthlyPayment(pdfAmountText(loan.getOMonthlyPay()));
        pdfLoan.setProductDescription(loan.getOProductDesc());
        pdfLoan.setSelected(pdfSelectedLoanText(loan, selectedLoans));

        return pdfLoan;
    }


    private String pdfSelectedLoanText(OActiveLoanDetail loan, DealsRequest selectedLoans) {
        return isLoanSelected(loan, selectedLoans) ? "Yes" : "No";
    }

    private boolean isLoanSelected(OActiveLoanDetail loan, DealsRequest selectedLoans) {
        long loansIdSelected = selectedLoans.getLoansSelected().stream().filter(selectedLoan -> selectedLoan.getLoanScheme().equals(loan.getOLoanScheme()) && selectedLoan.getSequenceNumber() == loan.getOApplSeqNo()).count();
        return loansIdSelected > 0;
    }


    private String calculateDiffBetweenSFORAndBoElandRates(DealsResponse dealsResponse) {
        try {
            BigDecimal bankOfEnglandRate = dealsResponse.getDeals().get(0).getProduct().getBankOfEnglandRate();
            BigDecimal santanderRevisionaryRate = dealsResponse.getDeals().get(0).getProduct().getSantanderRevisionaryRate();
            return santanderRevisionaryRate.subtract(bankOfEnglandRate) + "%";//.setScale(2, RoundingMode.HALF_UP) + "%";
        } catch (Exception e) {
            // Is not that the scenario without deals is common, as they should have at least a SVR available
            // but just in case as good practice when having arrays
            return "";
        }
    }

    private String buildTotalBalance(DealsPdfAnmfDataFetcherOutput dealsPdfAnmfDataFetcherOutput) {

        BigDecimal runningTotal = BigDecimal.valueOf(0.00);
        List<OActiveLoanDetail> loans = dealsPdfAnmfDataFetcherOutput.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        for (OActiveLoanDetail loan : loans) {
            runningTotal = runningTotal.add(loan.getOOutstandingBalance());
        }
        return pdfAmountText(runningTotal);
    }

    private String buildTotalMonthlyPayment(DealsPdfAnmfDataFetcherOutput dealsPdfAnmfDataFetcherOutput) {

        BigDecimal runningTotal = BigDecimal.valueOf(0.00);
        List<OActiveLoanDetail> loans = dealsPdfAnmfDataFetcherOutput.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        for (OActiveLoanDetail loan : loans) {
            runningTotal = runningTotal.add(loan.getOMonthlyPay());
        }
        return pdfAmountText(runningTotal);
    }
}

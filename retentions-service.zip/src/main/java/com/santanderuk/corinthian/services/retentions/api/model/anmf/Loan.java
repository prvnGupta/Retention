package com.santanderuk.corinthian.services.retentions.api.model.anmf;

import com.santanderuk.corinthian.services.commons.mappers.View;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.LoanBlockers;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
public class Loan extends ModelBase {

    private static final long serialVersionUID = 5361487282887890092L;

    private boolean selected;
    private Integer loanId;
    private Integer sequenceNumber;
    private String scheme;
    private BigDecimal loanBalance;
    private BigDecimal monthlyPayment;
    private String loanType;
    private Integer remainingTerm;
    private String productEndDate;
    private String loanEndDate;
    private String loanStartDate;
    private BigDecimal interestRate;
    private BigDecimal followOnRate;
    private boolean onReversionRate;
    private String productDescription;
    private boolean eligibleToTransfer = true;
    private LoanBlockers blockers;
    private View view;
    private boolean telephonyOnly;
    private BigDecimal annualOverpaymentAllowance;
    private BigDecimal earlyRepaymentChargeAsAmount;
    private String paymentDate;
    private BigDecimal baseRateDifference;
}


package com.santanderuk.corinthian.services.retentions.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.utilities.LoggingRequestInterceptor;
import com.santanderuk.corinthian.services.retentions.api.clients.RetentionsErrorHandler;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.time.Clock;
import java.util.ArrayList;
import java.util.List;

@Configuration
@Getter
@ComponentScan(basePackages = "com.santanderuk.corinthian")
public class Config {

    @Value("${caching.inMemoryCacheNames}")
    private String inMemoryCacheNames;

    @Value("${service.core.generateOffer}")
    private String generateOfferUrl;

    @Value("${service.core.retrieveOffer}")
    private String retrieveOfferUrl;

    @Value("${service.core.updateOfferInfo}")
    private String updateOfferInfoUrl;

    @Value("${service.core.workFlowtype}")
    private int workflowType;

    @Value("${service.core.retrieveOfferInfo}")
    private String retrieveOfferInfoUrl;

    @Value("${service.core.acceptLater}")
    private String acceptLaterUrl;

    @Value("${service.core.acceptInSession}")
    private String acceptInSessionUrl;

    @Value("${service.core.saveRetentionDataUrl}")
    private String saveRetentionDataUrl;

    @Value("${service.core.paf}")
    private String pafCoreUrl;

    @Value("${pafConstants.pafMaxAttempts}")
    private int pafMaxAttempts;

    @Value("${pafConstants.pafAttemptDelay}")
    private int pafAttemptDelay;

    @Value("${apimanager.client-id-header-key}")
    private String clientIdHeaderKey;

    @Value("${apimanager.client-id-value}")
    private String clientIdHeaderValue;

    @Value("${operativesecurity}")
    private boolean operativeSecurity;

    @Bean
    public Clock clock() {
        return Clock.systemDefaultZone();
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean("cacheManagerHeartbeat")
    public CacheManager cacheManagerHeartbeat() {
        SimpleCacheManager cacheManagerHeartbeat = new SimpleCacheManager();
        cacheManagerHeartbeat.setCaches(inMemoryCacheNames());
        return cacheManagerHeartbeat;
    }

    private List<ConcurrentMapCache> inMemoryCacheNames() {

        String[] cacheNames = inMemoryCacheNames.split(",");

        List<ConcurrentMapCache> cacheNamesList = new ArrayList<>(cacheNames.length);

        for (String cacheName : cacheNames) {
            ConcurrentMapCache concurrentMapCache = new ConcurrentMapCache(cacheName);
            cacheNamesList.add(concurrentMapCache);
        }

        return cacheNamesList;
    }

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new LoggingRequestInterceptor());
        restTemplate.setInterceptors(interceptors);
        return restTemplate;
    }

    @Bean
    public RestTemplate retrieveOfferInfoRestTemplate() {
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        restTemplate.setInterceptors(interceptors);
        return restTemplate;
    }

    @Bean
    public RestTemplate coreRetentionsRestTemplate() {
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new HttpComponentsClientHttpRequestFactory()));
        restTemplate.setErrorHandler(new RetentionsErrorHandler());
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new LoggingRequestInterceptor());
        restTemplate.setInterceptors(interceptors);

        return restTemplate;
    }

}

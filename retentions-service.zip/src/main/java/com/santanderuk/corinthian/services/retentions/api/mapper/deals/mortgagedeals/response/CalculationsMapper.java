package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.BreakdownSummaryFee;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.Product;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Calculations;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Optional;

@Component
class CalculationsMapper {

    public Calculations map(Product product) {

        var calculations = new Calculations();

        calculations.setRemainingBalanceWithFee(remainingBalanceWithFee(product));
        calculations.setRemainingBalanceWithoutFee(product.getBreakdownSummary().getWithoutFee().getTotalBalanceAfterDeal());

        calculations.setMonthlyPaymentWithFee(monthlyPaymentWithFee(product));
        calculations.setMonthlyPaymentWithoutFee(product.getBreakdownSummary().getWithoutFee().getTotalMonthlyPayment());

        calculations.setNewMortgageOutstandingBalanceWithFee(newMortgageBalanceWithFee(product));
        calculations.setNewMortgageOutstandingBalanceWithoutFee(product.getBreakdownSummary().getWithoutFee().getTotalNewOutstandingBalance());

        return calculations;
    }

    private BigDecimal newMortgageBalanceWithFee(Product product) {

        return Optional.ofNullable(product.getBreakdownSummary().getWithFee())
                .map(BreakdownSummaryFee::getTotalNewOutstandingBalance)
                .orElseGet(() -> product.getBreakdownSummary().getWithoutFee().getTotalNewOutstandingBalance());
    }

    private BigDecimal remainingBalanceWithFee(Product product) {

        return Optional.ofNullable(product.getBreakdownSummary().getWithFee())
                .map(BreakdownSummaryFee::getTotalBalanceAfterDeal)
                .orElseGet(() -> product.getBreakdownSummary().getWithoutFee().getTotalBalanceAfterDeal());
    }

    private BigDecimal monthlyPaymentWithFee(Product product) {

        return Optional.ofNullable(product.getBreakdownSummary().getWithFee())
                .map(BreakdownSummaryFee::getTotalMonthlyPayment)
                .orElseGet(() -> product.getBreakdownSummary().getWithoutFee().getTotalMonthlyPayment());
    }
}

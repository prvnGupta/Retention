package com.santanderuk.corinthian.services.retentions.api.service.deals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClient;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.MortgageDealsClientResponse;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MapperSourceData;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response.MortgageDealsClientResponseMapper;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.service.deals.anmfdatafetcher.AnmfDataFetcher;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidation;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DealsService {

    private final MortgageDealsClientResponseMapper mortgageDealsClientResponseMapper;
    private final MortgageDealsClient mortgageDealsClient;
    private final MortgageDealsClientRequestMapper mortgageDealsClientRequestMapper;
    private final AnmfDataFetcher anmfDataFetcher;
    private final DealsFunctionalValidation dealsFunctionalValidation;
    private final DealsOperativeSecurity operativeSecurity;

    public DealsService(
            MortgageDealsClientResponseMapper mortgageDealsClientResponseMapper,
            MortgageDealsClient mortgageDealsClient,
            MortgageDealsClientRequestMapper mortgageDealsClientRequestMapper,
            AnmfDataFetcher anmfDataFetcher,
            DealsFunctionalValidation dealsFunctionalValidation,
            DealsOperativeSecurity operativeSecurity) {

        this.mortgageDealsClientResponseMapper = mortgageDealsClientResponseMapper;
        this.mortgageDealsClient = mortgageDealsClient;
        this.mortgageDealsClientRequestMapper = mortgageDealsClientRequestMapper;
        this.anmfDataFetcher = anmfDataFetcher;
        this.dealsFunctionalValidation = dealsFunctionalValidation;
        this.operativeSecurity = operativeSecurity;
    }

    public DealsResponse get(int account, DealsRequest dealsRequest, String jwtToken) throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        MapperSourceData sourceData = setMapperSourceData(account, dealsRequest, jwtToken);
        return getDealsResponse(sourceData);
    }

    private MapperSourceData setMapperSourceData(int account, DealsRequest dealsRequest, String jwtToken) throws ConnectionException, ValidationsException, OperativeSecurityException, MaintenanceException, DealsFunctionalValidationException {
        operativeSecurity.check(account, jwtToken);

        var sourceData = new MapperSourceData();
        sourceData.setAccount(account);
        sourceData.setDealsRequest(dealsRequest);

        fetchAnmfData(account, sourceData);

        runFunctionalValidation(sourceData);
        return sourceData;
    }


    private void fetchAnmfData(int account, MapperSourceData sourceData) throws ConnectionException, MaintenanceException {
          var fetchedFromAnmf = anmfDataFetcher.fetch(account);

          sourceData.setAccountServiceResponse(fetchedFromAnmf.getAccountServiceResponse());
          sourceData.setAnmfPropertyResponse(fetchedFromAnmf.getAnmfPropertyResponse());
      }

    private void runFunctionalValidation(MapperSourceData sourceData) throws DealsFunctionalValidationException {
        dealsFunctionalValidation.run(sourceData.getDealsRequest(), sourceData.getAccountServiceResponse());
    }

    private DealsResponse getDealsResponse(MapperSourceData sourceData) throws MortgageDealsClientException {

        var clientRequest = mortgageDealsClientRequestMapper.create(sourceData);
        var clientResponse = mortgageDealsClient.fetch(clientRequest);

        var dealsResponseMapped = mortgageDealsClientResponseMapper.map(clientResponse, clientRequest, sourceData);

        logInteractionWithMortgageDeals(sourceData, clientRequest, clientResponse, dealsResponseMapped);

        return dealsResponseMapped;
    }

    private void logInteractionWithMortgageDeals(MapperSourceData sourceData, MortgageDealsClientRequest clientRequest, MortgageDealsClientResponse clientResponse, DealsResponse dealsResponseMapped) {
        log.debug(
                "Interaction with new mortgage deals for account {} " +
                "MapperSourceData: {} " +
                "MortgageDealsClientRequest: {} " +
                "MortgageDealsClientResponse: {} " +
                "DealsResponse: {}",
                sourceData.getAccount(), toJson(sourceData), toJson(clientRequest), toJson(clientRequest),toJson(dealsResponseMapped)
        );
    }

    private static String toJson(Object element) {
        try {
            ObjectMapper om = new ObjectMapper();
            return om.writeValueAsString(element);
        } catch (JsonProcessingException e) {
           return "";
        }
    }
}

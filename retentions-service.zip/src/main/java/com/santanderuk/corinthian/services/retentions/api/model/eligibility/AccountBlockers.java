package com.santanderuk.corinthian.services.retentions.api.model.eligibility;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountBlockers {

    private static final long serialVersionUID = 1l;

    private boolean notOnline;
    private boolean financialDifficulties;
    private boolean flexi;
    private boolean accountBalanceBelowThreshold;
    private boolean accountIneligible;
    private boolean allLoansIneligible;
    private boolean allLoansERC;
    private boolean outsideDealWindow;
    private boolean termRemaining;
    private boolean consentToLet;
    private boolean eligibleInArrears;
}


package com.santanderuk.corinthian.services.retentions.api.pdfGeneration;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;


@Getter
@Setter
public class PdfGeneratorRequest {

    private Template templateName;
    private Map<String, Object> templateElements;

}

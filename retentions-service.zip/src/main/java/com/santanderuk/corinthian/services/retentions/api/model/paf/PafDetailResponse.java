package com.santanderuk.corinthian.services.retentions.api.model.paf;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PafDetailResponse {

    private PafAddress address;
}

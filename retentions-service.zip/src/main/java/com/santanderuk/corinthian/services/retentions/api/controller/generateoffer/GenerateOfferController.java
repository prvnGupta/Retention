package com.santanderuk.corinthian.services.retentions.api.controller.generateoffer;

import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.controller.BaseController;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.generate.GenerateOffer;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.generate.GenerateOfferWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import com.santanderuk.corinthian.services.retentions.api.service.generateoffer.GenerateOfferService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@RestController
public class GenerateOfferController extends BaseController {

    private final GenerateOfferService generateOfferService;

    public GenerateOfferController( GenerateOfferService generateOfferService) {
        this.generateOfferService = generateOfferService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to accept immediately a mortgage retention offer",
            nickname = "generateOffer",
            notes = "This endpoint is used by Corinthian frontend application to accept a previously generated mortgage retention offer. it will invoke mortgage-retentions-fullfillment core api (product-switch-service)"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PostMapping(
            value = "/{accountNumber}/offer/generate",
            produces = APPLICATION_JSON_VALUE,
            consumes = APPLICATION_JSON_VALUE
    )
    public ResponseEntity<GenerateOfferWrapper> generateOffer(
            @Valid @RequestBody CreateCaseRequest offerRequest,
            @PathVariable("accountNumber") int accountNumber,
            @RequestHeader(name = "Authorization", required = true) String jwtToken) throws ConnectionException, ReportedException, ValidationsException, OperativeSecurityException, MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException {

        log.info("/{accountNumber}/create case request received");
        log.debug("Jwt: {}", sanitizeString(jwtToken));

        String offerId = generateOfferService.generateOfferInSession(accountNumber, offerRequest, jwtToken);
        GenerateOfferWrapper response = buildOfferResponse(offerId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private GenerateOfferWrapper buildOfferResponse(String offerId) {
        GenerateOffer offer = new GenerateOffer();
        offer.setOfferId(offerId);

        ServiceInfo info = ServiceInfoCreator.ok();
        info.setMessage("Offer generated");

        GenerateOfferWrapper response = new GenerateOfferWrapper();
        response.setResponse(offer);
        response.setInfo(info);

        return response;
    }
}

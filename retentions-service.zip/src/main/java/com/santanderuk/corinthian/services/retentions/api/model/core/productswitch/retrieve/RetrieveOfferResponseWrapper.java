package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetrieveOfferResponseWrapper extends ModelBase {

    private RetrieveOfferResponse data;
    private ServiceInfo info;
}

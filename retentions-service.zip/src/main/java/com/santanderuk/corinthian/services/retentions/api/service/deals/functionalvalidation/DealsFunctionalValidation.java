package com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class DealsFunctionalValidation {

    public static final DealsFunctionalValidationException.Type EXC_DEALS_NO_LOANS_IN_REQUEST = DealsFunctionalValidationException.Type.EXC_DEALS_NO_LOANS_IN_REQUEST;
    public static final DealsFunctionalValidationException.Type EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT = DealsFunctionalValidationException.Type.EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT;

    public void run(DealsRequest request, AnmfAccountServiceResponse accountResponse) throws DealsFunctionalValidationException {

        checkLoansInRequest(request);

        checkLoanInRequestExistsInAccount(request, accountResponse);
    }

    private void checkLoansInRequest(DealsRequest dealsRequest) throws DealsFunctionalValidationException {
        var numberOfLoans = 0;
        try {
            numberOfLoans = dealsRequest.getLoansSelected().size();
        } catch (Exception e) {
            // Just to be sure that we don't crash accessing data
        }

        if (numberOfLoans == 0) {
            throw new DealsFunctionalValidationException(EXC_DEALS_NO_LOANS_IN_REQUEST);
        }
    }

    private void checkLoanInRequestExistsInAccount(DealsRequest request, AnmfAccountServiceResponse accountResponse) throws DealsFunctionalValidationException {

        var requestLoansAsString = loansInRequest(request)
                .map(this::convertToString)
                .collect(Collectors.toList());

        var loansInAccount = loansInAccountResponse(accountResponse)
                .map(this::convertToString)
                .collect(Collectors.toList());

        if (!loansInAccount.containsAll(requestLoansAsString)) {
            throw new DealsFunctionalValidationException(EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT);
        }
    }

    private String convertToString(OActiveLoanDetail loanInAccount) {
        return loanInAccount.getOLoanScheme() + loanInAccount.getOApplSeqNo();
    }

    private String convertToString(LoanIdentifier request) {
        return request.getLoanScheme() + request.getSequenceNumber();
    }

    private Stream<OActiveLoanDetail> loansInAccountResponse(AnmfAccountServiceResponse accountResponse) {
        return accountResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().stream();
    }

    private Stream<LoanIdentifier> loansInRequest(DealsRequest request) {
        return request.getLoansSelected().stream();
    }


}

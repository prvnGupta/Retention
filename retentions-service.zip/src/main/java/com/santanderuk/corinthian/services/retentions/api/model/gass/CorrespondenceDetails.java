package com.santanderuk.corinthian.services.retentions.api.model.gass;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CorrespondenceDetails {

    private String emailAddress;
    private String mobileNumber;
}

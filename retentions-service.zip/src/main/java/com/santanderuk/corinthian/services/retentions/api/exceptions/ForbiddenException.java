package com.santanderuk.corinthian.services.retentions.api.exceptions;

import lombok.Getter;

@Getter
public class ForbiddenException extends RuntimeException {

    private String code;

    public ForbiddenException(String code, String msg){
        super(msg);
        this.code = code;
    }
}

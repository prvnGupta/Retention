package com.santanderuk.corinthian.services.retentions.api.model.deals.response;

public enum InterestRateChange {
    HIGHER, LOWER, SAME
}

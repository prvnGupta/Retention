package com.santanderuk.corinthian.services.retentions.api.exceptions;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.Getter;

@Getter
public class PaymentsException extends GeneralException {

    public PaymentsException(String code, String msg) {
        super(code, msg);
    }

    public PaymentsException(String code, String msg, Exception e) {
        super(code, msg, e);
    }
}

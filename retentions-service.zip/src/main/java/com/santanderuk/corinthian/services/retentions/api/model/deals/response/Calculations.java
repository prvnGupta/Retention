package com.santanderuk.corinthian.services.retentions.api.model.deals.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Calculations extends ModelBase {

    private BigDecimal remainingBalanceWithFee;
    private BigDecimal remainingBalanceWithoutFee;
    private BigDecimal monthlyPaymentWithFee;
    private BigDecimal monthlyPaymentWithoutFee;
    private BigDecimal newMortgageOutstandingBalanceWithFee;
    private BigDecimal newMortgageOutstandingBalanceWithoutFee;
}

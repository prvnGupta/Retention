package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class BorrowerCorrespondenceAddress {

    @NotEmpty
    private String addressLine1;
    private String addressLine2;

    @NotEmpty
    private String addressLine3;
    private String addressLine4;
    private String addressLine5;

    @NotEmpty
    private String addressLine6;
    private String addressLine7;

    @NotEmpty
    private String addressLine8;
    private String addressLine9;

    @Pattern(regexp = "([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\\s?[0-9][A-Za-z]{2})")
    private String postcode;

    private boolean correspondenceAddressChangedInd;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

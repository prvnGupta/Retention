package com.santanderuk.corinthian.services.retentions.api.model.eligibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EligibilityResponse {

    private List<Loan> loans;
    private BigDecimal minimumBalanceForSwitching;
    private AccountBlockers blockers;
    private String bandId;
    private String nextPaymentDate;
    private String productCompletionDate;

}

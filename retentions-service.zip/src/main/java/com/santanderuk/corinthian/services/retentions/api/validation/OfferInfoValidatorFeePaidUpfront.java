package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class OfferInfoValidatorFeePaidUpfront implements OfferInfoValidator {

    public void validateOffer(OfferInfoResponse offerInfoResponse, String esisRefId, int anmfAccount) {
        log.info("Validations: validateEsisRefId for pay-and-accept-in-session. esisRefId. esisRefId: {} caseId: {}", offerInfoResponse.getData().getEsisRefId(), offerInfoResponse.getData().getCaseId());
        validateEsisRefId(offerInfoResponse, esisRefId);
        log.info("Validations: validateOfferGeneratedForThisAnmfAccount for pay-and-accept-in-session. esisRefId: {} caseId: {}", offerInfoResponse.getData().getEsisRefId(), offerInfoResponse.getData().getCaseId());
        validateOfferGeneratedForThisAnmfAccount(offerInfoResponse, anmfAccount);
        log.info("Validations: validateFeePaidUpfront for pay-and-accept-in-session. esisRefId: {} caseId: {}", offerInfoResponse.getData().getEsisRefId(), offerInfoResponse.getData().getCaseId());
        validateFeePaidUpfront(offerInfoResponse);
    }
}

package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.validations.Validations;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EligibilityFormatValidation {

    private final Validations validations;

    @Autowired
    public EligibilityFormatValidation(Validations validations) {
        this.validations = validations;
    }

    public void validate(final int account) throws ValidationsException {
        if (!validations.isAccountNumber(account)) {
            throwValidationExceptionAccountFormat();
        }
    }

    public void validate(final int account, final List<LoanIdentifier> selectedLoan) throws ValidationsException {

        validate(account);

        for (LoanIdentifier loan : selectedLoan) {
            if (loanFormatIsNotValid(loan)) {
                throwValidationExceptionLoanFormat();
            }
        }
    }

    private void throwValidationExceptionAccountFormat() throws ValidationsException {
        throw new ValidationsException(
                ValidationsException.Type.EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT);
    }

    private void throwValidationExceptionLoanFormat() throws ValidationsException {
        throw new ValidationsException(
                ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN);
    }

    private boolean loanFormatIsNotValid(final LoanIdentifier loan) {
        return !validations.isLoanScheme(loan.getLoanScheme())
                || !validations.isApplicationSequenceNumber(loan.getSequenceNumber());
    }
}

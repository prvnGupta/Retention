package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.mappers.anmf.LoanPartToViewMapper;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.LoanBlockers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static java.math.RoundingMode.HALF_UP;

@Component
public class AnmfClientMapper {

    private final LoanPartToViewMapper loanPartToViewMapper;

    @Autowired
    public AnmfClientMapper(LoanPartToViewMapper loanPartToViewMapper) {
        this.loanPartToViewMapper = loanPartToViewMapper;
    }

    public List<Loan> toLoans(AnmfAccountServiceResponse accountsDetailsV4) {
        var oActiveLoanDetails = accountsDetailsV4.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        List<Loan> loans = new ArrayList<>(oActiveLoanDetails.size());

        for (var loan : oActiveLoanDetails) {
            var loanOut = toLoan(loan);
            loans.add(loanOut);
        }
        return loans;
    }

    private boolean checkIsOnReversionRate(OActiveLoanDetail loan) {
        var productDescription = loan.getOProductDesc().trim().toLowerCase();
        if (!isSVRorSFRorLTT(productDescription)) {
            return loan.getOErcDetailsGrp().getOErcApplFlag().equalsIgnoreCase("N");
        } else {
            return true;
        }
    }

    private boolean isSVRorSFRorLTT(String productDescription) {
        return (productDescription.contains("standard variable rate")) ||
                (productDescription.contains("santander's follow-on rate")) ||
                (productDescription.contains("lifetime tracker"));
    }

    private BigDecimal convertToBigDecimal(String oErcAllowPerc) {

        var percentageRemoved = oErcAllowPerc.replace("%", "");

        BigDecimal ercAllowance;
        try {
            ercAllowance = new BigDecimal(percentageRemoved);
        } catch (NumberFormatException nfe) {
            ercAllowance = new BigDecimal("0.00");
        }


        return ercAllowance.setScale(2, HALF_UP);
    }

    public Loan toLoan(OActiveLoanDetail activeLoan) {
        var loanOut = new Loan();
        loanOut.setLoanBalance(activeLoan.getOCapitalBalance());
        loanOut.setScheme(activeLoan.getOLoanScheme());
        loanOut.setSequenceNumber(activeLoan.getOApplSeqNo());
        loanOut.setMonthlyPayment(activeLoan.getOMonthlyPay());
        loanOut.setInterestRate(activeLoan.getOInterestRate());
        loanOut.setFollowOnRate(activeLoan.getORevisionaryDetails().getOReviInterestRate());
        loanOut.setLoanEndDate(activeLoan.getORedemptionDate());
        loanOut.setLoanStartDate(activeLoan.getOStartDate());
        loanOut.setBaseRateDifference(activeLoan.getOBaseRateDiff());


        loanOut.setLoanId(activeLoan.getOLoanId());

        loanOut.setLoanType(activeLoan.getORepaymentType());
        loanOut.setRemainingTerm(activeLoan.getORemainingInstlm());
        loanOut.setProductDescription(loanPartToViewMapper.toAbbreviatedProductDescription(activeLoan.getOProductDesc()));
        loanOut.setOnReversionRate(checkIsOnReversionRate(activeLoan));
        loanOut.setProductEndDate(activeLoan.getOProductEndDate());
        loanOut.setBlockers(new LoanBlockers());
        loanOut.setAnnualOverpaymentAllowance(convertToBigDecimal(activeLoan.getOErcDetailsGrp().getOErcAllowPerc()));
        loanOut.setEarlyRepaymentChargeAsAmount(activeLoan.getOErcDetailsGrp().getORdmStmErc());

        loanOut.setView(loanPartToViewMapper.toView(activeLoan));
        return loanOut;
    }
}

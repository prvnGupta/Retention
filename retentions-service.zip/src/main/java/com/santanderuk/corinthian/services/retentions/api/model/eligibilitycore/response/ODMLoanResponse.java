package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString()
public class ODMLoanResponse {
    private String loanID;
    private String loanEligibility;
    private String ercEligibility;
    private String loanBalanceEligibility;
    private String termEligibility;
    private String minimumRemainingTermLoanEligibility;
}

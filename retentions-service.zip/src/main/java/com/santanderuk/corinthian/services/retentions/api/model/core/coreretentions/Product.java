package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class Product {


    @NotEmpty(message = "Product code cannot be empty or null")
    @Pattern(regexp = "^[a-zA-Z0-9]{0,50}$")
    private String code;

    @NotEmpty(message = "Product productDescription cannot be empty or null")
    private String description;

    @NotEmpty(message = "Product fee received cannot be empty or null")
    private String feeReceived;

    @Valid
    private Fees fees;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

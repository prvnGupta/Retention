package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AllIneligibleLoans implements ODMEligibilityRule {

    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse) {

        List<ODMLoanResponse> loanListResponse = odmEligibilityResponse.getAccountResponse().getLoanResponse();
        long numberOfLoansNotEligible = loanListResponse.stream().filter(c -> "N".equalsIgnoreCase(c.getLoanEligibility())).count();

        if (loanListResponse.size() == numberOfLoansNotEligible) {
            eligibilityResponse.getBlockers().setAllLoansIneligible(true);
        }
    }
}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorFeeRolledIntoMortgage;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
@Slf4j
public class AcceptInSessionService {

    private final OperativeSecurityService operativeSecurityService;
    private final CacheableOperations cacheableOperations;
    private final ProductSwitchClient productSwitchClient;
    private final OfferInfoValidatorFeeRolledIntoMortgage offerInfoValidatorFeeRolledIntoMortgage;
    private final GassService gassService;

    @Autowired
    public AcceptInSessionService(OperativeSecurityService operativeSecurityService, CacheableOperations cacheableOperations,
                                  ProductSwitchClient productSwitchClient,
                                  OfferInfoValidatorFeeRolledIntoMortgage offerInfoValidatorFeeRolledIntoMortgage, GassService gassService) {
        this.operativeSecurityService = operativeSecurityService;
        this.cacheableOperations = cacheableOperations;
        this.productSwitchClient = productSwitchClient;
        this.offerInfoValidatorFeeRolledIntoMortgage = offerInfoValidatorFeeRolledIntoMortgage;
        this.gassService = gassService;
    }

    public ServiceInfo acceptInSession(int account, String jwtToken, String esisRefId, HttpServletRequest servletRequest) throws ConnectionException, MaintenanceException, OperativeSecurityException {

        ServiceInfo serviceInfo;
        operativeSecurityService.checkAnmfAccountBelongToCustomerInJwt(account, jwtToken, cacheableOperations.getAnmfActiveRegion());

        OfferInfoResponse offerInfoResponse = productSwitchClient.retrieveOfferInfo(esisRefId);
        offerInfoValidatorFeeRolledIntoMortgage.validateOffer(offerInfoResponse, esisRefId, account);
        String caseId = offerInfoResponse.getData().getCaseId();
        String status = "1";
        try {
            serviceInfo = productSwitchClient.acceptInSession(caseId);
        } catch (ConnectionException e) {
            status = "2";
            throw e;
        } finally {
            try {
                gassService.auditProductSwitchAcceptNowInGass(offerInfoResponse.getData().getCoreRetentionsData(), jwtToken, account, offerInfoResponse.getData().getOfferDownloadedDateTime(), servletRequest, status);
            } catch (JsonProcessingException | GeneralException ex) {
                log.error("JsonProcessException while converting from string to CoreRetentionsData", ex);
            }
        }
        return serviceInfo;
    }


}

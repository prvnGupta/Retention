package com.santanderuk.corinthian.services.retentions.api.model.deals.response;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class DealLoanView extends ModelBase {
    private int loanId;
    private String productTitle;
    private BigDecimal interestRate;
    private BigDecimal bankOfEnglandBaseRate;
    private boolean variable;
    private BigDecimal trackingRate;
    private boolean transferring;
    private BigDecimal monthlyPaymentWithFee;
    private BigDecimal monthlyPaymentWithoutFee;
    private BigDecimal loanBalance;
    private BigDecimal productFee;
    private boolean productWithFee;
    private BigDecimal newOutstandingBalance;
    private String previousProduct;
    private String productStartDate;
    private String productEndDate;
    private String remainingTerm;
    private String repaymentType;
    private BigDecimal annualOverpaymentAllowance;
    private BigDecimal earlyRepaymentChargeAsPercentage;
    private BigDecimal earlyRepaymentChargeAsAmount;
    private BigDecimal santanderFollowOnRate;
    private boolean applyFeeInThisLoan;
    private InterestRateChange interestRateChange;
    private boolean currentProductFixedTermFlag;
    private boolean lifetimeTermFlag;
    private boolean currentProductTrackerFlag;
    private boolean stepErc;
    private String reversionProduct;
}

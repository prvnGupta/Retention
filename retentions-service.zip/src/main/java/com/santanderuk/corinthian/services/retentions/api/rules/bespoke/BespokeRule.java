package com.santanderuk.corinthian.services.retentions.api.rules.bespoke;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;

public interface BespokeRule {

    void isEligible(EligibilityResponse eligibilityResponse, AnmfCoreResponse anmfCoreResponse);
}

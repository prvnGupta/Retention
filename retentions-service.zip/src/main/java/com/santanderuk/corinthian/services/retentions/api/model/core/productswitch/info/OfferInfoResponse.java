package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info;

import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OfferInfoResponse extends ModelBase {

    private OnlineOfferEntity data;
    private ServiceInfo info;
}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.clients.PafClient;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafDetailResponse;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafIdResponse;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafItem;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PafService {
    private PafClient pafClient;

    @Autowired
    public PafService(PafClient pafClient) {
        this.pafClient = pafClient;
    }

    public String fetchCountry(String postcode) {

        if (StringUtils.isEmpty(postcode)) {
            return "";
        }

        try {
            PafIdResponse pafIdResponse = pafClient.fetchPafIdResponse(postcode);
            String detailId = "";

            PafItem firstPafItem = pafIdResponse.getItems().get(0);
            if(!firstPafItem.getType().equalsIgnoreCase("Address")) {
                detailId = pafClient.fetchPafIdAndPostcodeResponse(postcode, firstPafItem.getId());
            }
            else {
                detailId = firstPafItem.getId();
            }

            PafDetailResponse pafDetails = pafClient.fetchPafDetailResponse(detailId);
            return pafDetails.getAddress().getHomeCountry();

        } catch (ConnectionException ce) {
            log.error("Failed to connect to PAF");
            return "";
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            return "";
        }

    }

    private boolean checkDetailIdIsValid(String detailId) {
        return !detailId.equals("");
    }
}

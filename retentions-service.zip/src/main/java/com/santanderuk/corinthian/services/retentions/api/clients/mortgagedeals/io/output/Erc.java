package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Erc extends ModelBase {

    private static final long serialVersionUID = 741438809689250162L;

    private boolean applicable;
    private List<ErcStep> steps;
}

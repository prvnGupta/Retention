package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.GassDataFetcherRetentionsService;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import com.santanderuk.corinthian.services.retentions.api.model.gass.*;
import com.santanderuk.corinthian.services.retentions.api.utils.DateUtils;
import com.santanderuk.corinthian.services.retentions.api.utils.ProductUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static java.math.RoundingMode.HALF_UP;

@Component
@Slf4j
public class ProductSwitchGassFormattedDataMapper {

    private final GassDataFetcherRetentionsService gassDataFetcherRetentionsService;
    private final DateUtils dateUtils;
    private final ProductUtils productUtils;
    private final Clock clock;
    private final GassConfig gassConfig;

    @Autowired
    public ProductSwitchGassFormattedDataMapper(GassDataFetcherRetentionsService gassDataFetcherRetentionsService,
                                                DateUtils dateUtils, ProductUtils productUtils, Clock clock, GassConfig gassConfig) {
        this.gassDataFetcherRetentionsService = gassDataFetcherRetentionsService;
        this.dateUtils = dateUtils;
        this.productUtils = productUtils;
        this.clock = clock;
        this.gassConfig = gassConfig;
    }


    public CreateCaseRequestFormattedData createFormattedData(int account, String jwtToken, CoreRetentionsData coreRetentionsData) {

        ProductDetails mortgageDetails = buildSelectedDeal(coreRetentionsData);

        CreateCaseRequestFormattedData formattedData = new CreateCaseRequestFormattedData();

        formattedData.setMultiChannelContractId(gassDataFetcherRetentionsService.fetchMccId(jwtToken));
        formattedData.setCustomerNumber(gassDataFetcherRetentionsService.fetchCustomerNumber(jwtToken));
        try {
            formattedData.setUid(JwtUtilities.getLdapUidFromJWT(jwtToken));
        } catch (GeneralException ge) {
            log.warn("could not extract Uid from Jwt");
            formattedData.setUid("");
        }
        formattedData.setMortgageSortcode(gassConfig.getAnmfSortcode());
        formattedData.setMortgageAccount(formatAccountNumber(account));
        formattedData.setSwitchedLoanParts(generateAcceptLaterGassSelectedLoanList(coreRetentionsData));
        formattedData.setNewProductDetails(mortgageDetails);
        formattedData.setJointMortgage(isJointMortgage(coreRetentionsData));

        return formattedData;
    }

    public AcceptanceGassFormattedData createProductSwitchAcceptLaterFormattedData(CoreRetentionsData coreRetentionsData, String jwtToken, int account, String offerDownloadedTime) {

        AcceptanceGassFormattedData acceptanceGassFormattedData = mapDefaultGassFields(coreRetentionsData, account, jwtToken, offerDownloadedTime);

        acceptanceGassFormattedData.setSwitchedLoanParts(generateAcceptLaterGassSelectedLoanList(coreRetentionsData));

        return acceptanceGassFormattedData;
    }

    public AcceptanceGassFormattedData createProductSwitchAcceptNowFormattedData(CoreRetentionsData coreRetentionsData, String jwtToken, int account, String offerDownloadedTime) {

        AcceptanceGassFormattedData acceptanceGassFormattedData = mapDefaultGassFields(coreRetentionsData, account, jwtToken, offerDownloadedTime);

        acceptanceGassFormattedData.setSwitchedLoanParts(generateAcceptNowGassSelectedLoanList(coreRetentionsData));
        acceptanceGassFormattedData.setOfferAccepted(true);

        return acceptanceGassFormattedData;
    }

    public ProductFeeFormattedData createProductSwitchFeeFormattedData(CoreRetentionsData coreRetentionsData, String jwtToken, int account, AcceptAndPayInSessionRequest request) {

        ProductFeeFormattedData productFeeFormattedData = new ProductFeeFormattedData();
        productFeeFormattedData.setCustomerNumber(gassDataFetcherRetentionsService.fetchCustomerNumber(jwtToken));
        productFeeFormattedData.setEmailAddress(coreRetentionsData.getCaseRequest().getEmailAddress());
        productFeeFormattedData.setFeeAmount(formatBigDecimalToCurrencyString(coreRetentionsData.getSelectedDeal().getProduct().getProductFee()));
        productFeeFormattedData.setJointMortgage(isJointMortgage(coreRetentionsData));
        productFeeFormattedData.setMccContractNumber(gassDataFetcherRetentionsService.fetchMccId(jwtToken));
        productFeeFormattedData.setMobileNumber(coreRetentionsData.getCaseRequest().getMobileNumber());
        productFeeFormattedData.setMortgageAccountNumber(formatAccountNumber(account));
        productFeeFormattedData.setMortgageSortCode(gassConfig.getAnmfSortcode());
        productFeeFormattedData.setRemitterAccount(extractRemitterAccount(request));
        productFeeFormattedData.setRemitterSortCode(extractRemitterSortCode(request));
        productFeeFormattedData.setTimeStamp(LocalDateTime.now(clock).toString());
        try {
            productFeeFormattedData.setUid(JwtUtilities.getLdapUidFromJWT(jwtToken));
        } catch (GeneralException ge) {
            log.warn("could not extract Uid from Jwt");
            productFeeFormattedData.setUid("");
        }
        return productFeeFormattedData;
    }

    private AcceptanceGassFormattedData mapDefaultGassFields(CoreRetentionsData coreRetentionsData, int account, String jwtToken, String offerDownloadedTime) {

        AcceptanceGassFormattedData acceptanceGassFormattedData = new AcceptanceGassFormattedData();
        acceptanceGassFormattedData.setNewProductDetails(mapProductDetails(coreRetentionsData));
        acceptanceGassFormattedData.setCorrespondenceDetails(mapCorrespondenceDetails(coreRetentionsData));
        acceptanceGassFormattedData.setMultiChannelContractId(gassDataFetcherRetentionsService.fetchMccId(jwtToken));
        acceptanceGassFormattedData.setCustomerNumber(gassDataFetcherRetentionsService.fetchCustomerNumber(jwtToken));
        acceptanceGassFormattedData.setMortgageSortcode(gassConfig.getAnmfSortcode());
        acceptanceGassFormattedData.setMortgageAccount(formatAccountNumber(account));
        acceptanceGassFormattedData.setJointMortgage(isJointMortgage(coreRetentionsData));

        try {
            acceptanceGassFormattedData.setUid(JwtUtilities.getLdapUidFromJWT(jwtToken));
        } catch (GeneralException ge) {
            log.warn("could not extract Uid from Jwt");
            acceptanceGassFormattedData.setUid("");
        }
        acceptanceGassFormattedData.setAcceptanceEmailSent(true);
        acceptanceGassFormattedData.setOfferDownloaded(isPopulated(offerDownloadedTime));

        return acceptanceGassFormattedData;
    }

    private String extractRemitterSortCode(AcceptAndPayInSessionRequest request) {
        return request.getAccountFrom().trim().substring(0, 6);
    }

    private String extractRemitterAccount(AcceptAndPayInSessionRequest request) {
        return request.getAccountFrom().trim().substring(6);
    }


    private CorrespondenceDetails mapCorrespondenceDetails(CoreRetentionsData coreRetentionsData) {
        CorrespondenceDetails correspondenceDetails = new CorrespondenceDetails();
        correspondenceDetails.setEmailAddress(coreRetentionsData.getCaseRequest().getEmailAddress());
        correspondenceDetails.setMobileNumber(coreRetentionsData.getCaseRequest().getMobileNumber());
        return correspondenceDetails;
    }

    private boolean isPopulated(String offerDownloadedTime) {
        return null != offerDownloadedTime;
    }

    private ProductDetails mapProductDetails(CoreRetentionsData coreRetentionsData) {

        ProductDetails productDetails = new ProductDetails();

        Deal deal = coreRetentionsData.getSelectedDeal();
        Product product = deal.getProduct();
        boolean feePaidUpfront = coreRetentionsData.getCaseRequest().isFeeAddedInMortgage();

        productDetails.setProductCode(product.getProductCode());
        productDetails.setProductDescription(product.getDescription());
        productDetails.setInterestRate(formatAsPercentage(product.getRate()));
        productDetails.setProductFee(formatBigDecimalToCurrencyString(product.getProductFee()));
        productDetails.setEarlyRepaymentCharge(formatERC(product.getErcPercentage()));
        productDetails.setOverpaymentAllowance(formatOverpaymentAllowance(product.getAnnualOverpaymentAllowancePercentage()));
        productDetails.setSantanderFollowOnRate(formatAsPercentage(product.getSantanderRevisionaryRate()));
        productDetails.setFeePaidUpfront(!feePaidUpfront);

        if (feePaidUpfront) {
            productDetails.setMonthlyPayment(formatBigDecimalToCurrencyString(deal.getCalculations().getMonthlyPaymentWithFee()));
            productDetails.setRemainingBalance(formatBigDecimalToCurrencyString(deal.getCalculations().getRemainingBalanceWithFee()));
        } else {
            productDetails.setMonthlyPayment(formatBigDecimalToCurrencyString(deal.getCalculations().getMonthlyPaymentWithoutFee()));
            productDetails.setRemainingBalance(formatBigDecimalToCurrencyString(deal.getCalculations().getRemainingBalanceWithoutFee()));
        }

        return productDetails;
    }

    private String formatAccountNumber(int number) {
        return String.format("%09d", number);
    }

    private boolean isJointMortgage(CoreRetentionsData coreRetentionsData) {
        return coreRetentionsData.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().size() > 1;
    }

    private List<SelectedLoanGassFormat> generateAcceptLaterGassSelectedLoanList(CoreRetentionsData coreRetentionsData) {

        List<LoanIdentifier> loansSelected = coreRetentionsData.getCaseRequest().getLoansSelected();
        List<SelectedLoanGassFormat> selectedLoanList = new ArrayList<>(loansSelected.size());

        for (DealLoanView dealLoanView : coreRetentionsData.getSelectedDeal().getDealLoans()) {
            if (dealLoanView.isTransferring()) {
                SelectedLoanGassFormat selectedLoanGassFormat = mapDefaultSelectedLoanValues(dealLoanView, coreRetentionsData);
                selectedLoanList.add(selectedLoanGassFormat);
            }
        }

        return selectedLoanList;
    }

    private List<SelectedLoanGassFormat> generateAcceptNowGassSelectedLoanList(CoreRetentionsData coreRetentionsData) {

        List<LoanIdentifier> loansSelected = coreRetentionsData.getCaseRequest().getLoansSelected();
        List<SelectedLoanGassFormat> selectedLoanList = new ArrayList<>(loansSelected.size());

        for (DealLoanView dealLoanView : coreRetentionsData.getSelectedDeal().getDealLoans()) {
            if (dealLoanView.isTransferring()) {
                SelectedLoanGassFormat selectedLoanGassFormat = mapDefaultSelectedLoanValues(dealLoanView, coreRetentionsData);
                selectedLoanList.add(selectedLoanGassFormat);
            }
        }
        return selectedLoanList;
    }

    private SelectedLoanGassFormat mapDefaultSelectedLoanValues(DealLoanView dealLoanView, CoreRetentionsData coreRetentionsData) {
        OActiveLoanDetail matchedLoanAnmf = getMatchedLoan(dealLoanView, coreRetentionsData);

        SelectedLoanGassFormat selectedLoanGassFormat = new SelectedLoanGassFormat();

        selectedLoanGassFormat.setPartId(matchedLoanAnmf.getOLoanId());
        selectedLoanGassFormat.setLoanScheme(matchedLoanAnmf.getOLoanScheme());
        selectedLoanGassFormat.setApplicationSequenceNumber(matchedLoanAnmf.getOApplSeqNo());
        selectedLoanGassFormat.setCurrentProductDescription(matchedLoanAnmf.getOProductDesc());
        selectedLoanGassFormat.setCurrentProductEndDate(getCurrentProductEndDate(matchedLoanAnmf));
        selectedLoanGassFormat.setCurrentInterestRate(getCurrentInterestRate(matchedLoanAnmf));
        selectedLoanGassFormat.setLoanEndDate(matchedLoanAnmf.getORedemptionDate());
        selectedLoanGassFormat.setLoanBalance(getLoanBalance(matchedLoanAnmf));
        selectedLoanGassFormat.setCurrentProductCode(matchedLoanAnmf.getOProductCode());
        selectedLoanGassFormat.setRemainingTerm(dateUtils.toYearsAndMonths(matchedLoanAnmf.getORemainingInstlm()));
        selectedLoanGassFormat.setRepaymentType(formatRepaymentType(matchedLoanAnmf.getORepaymentType()));
        selectedLoanGassFormat.setFeeAddedToThisLoan(dealLoanView.isApplyFeeInThisLoan());
        Product product = coreRetentionsData.getSelectedDeal().getProduct();
        selectedLoanGassFormat.setSwitchDate(formatSwitchDate(productUtils.calculateLoanSwitchDate(coreRetentionsData.getSelectedDeal().getProduct().getProductCompletionDate(), dealLoanView)));
        selectedLoanGassFormat.setNewProductEndDate(productUtils.calculateLoanSwitchingProductEndDate(dealLoanView, product));

        return selectedLoanGassFormat;
    }

    private String formatSwitchDate(String switchDate) {
        return StringUtils.isEmpty(switchDate) ? "Mortgage Offer acceptance date" : switchDate;
    }

    private String formatRepaymentType(String subAccountType) {
        return subAccountType.equalsIgnoreCase("R") ? "Repayment" : "Interest only";
    }

    private String getLoanBalance(OActiveLoanDetail matchedLoan) {
        return formatBigDecimalToCurrencyString(matchedLoan.getOCapitalBalance().setScale(2, HALF_UP));
    }

    private String getCurrentInterestRate(OActiveLoanDetail matchedLoan) {
        return matchedLoan.getOInterestRate().setScale(2, HALF_UP) + "%";
    }

    private String getCurrentProductEndDate(OActiveLoanDetail matchedLoan) {
        String productEndDate = matchedLoan.getOProductEndDate();
        if (StringUtils.isEmpty(productEndDate)) {
            return matchedLoan.getORedemptionDate();
        }
        return productEndDate;
    }

    private OActiveLoanDetail getMatchedLoan(DealLoanView dealLoanView, CoreRetentionsData coreRetentionsData) {
        return coreRetentionsData.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().stream().filter(
                oLoan -> oLoan.getOLoanId() == dealLoanView.getLoanId()
        ).findFirst().orElseGet(OActiveLoanDetail::new);
    }

    private ProductDetails buildSelectedDeal(CoreRetentionsData coreRetentionsData) {

        List<OActiveLoanDetail> anmfLoanParts = coreRetentionsData.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();

        List<LoanIdentifier> selectedLoans = coreRetentionsData.getCaseRequest().getLoansSelected();
        List<String> selectedLoanIdentifiers = buildSelectedLoanIdentifiers(selectedLoans);

        BigDecimal loanAmount = new BigDecimal("0.00");

        for (OActiveLoanDetail anmfLoan : anmfLoanParts) {
            String anmfLoanIdentifier = String.format("%s%d", anmfLoan.getOLoanScheme(), anmfLoan.getOApplSeqNo());
            if (selectedLoanIdentifiers.contains(anmfLoanIdentifier)) {
                loanAmount = loanAmount.add(anmfLoan.getOCapitalBalance()).setScale(2, HALF_UP);
            }
        }

        return mapProductDetails(coreRetentionsData);
    }

    private List<String> buildSelectedLoanIdentifiers(List<LoanIdentifier> selectedLoans) {

        List<String> selectedLoanIdentifiers = new ArrayList<>(selectedLoans.size());

        for (LoanIdentifier loanIdentifier : selectedLoans) {
            selectedLoanIdentifiers.add(String.format("%s%d", loanIdentifier.getLoanScheme(), loanIdentifier.getSequenceNumber()));
        }

        return selectedLoanIdentifiers;

    }

    private String formatOverpaymentAllowance(BigDecimal annualOverpaymentAllowancePercentage) {
        try {
            return annualOverpaymentAllowancePercentage.compareTo(BigDecimal.ZERO) != 0 ? annualOverpaymentAllowancePercentage.setScale(2, HALF_UP) + "%" : "Unlimited";
        } catch (Exception e) {
            return "";
        }
    }

    private String formatERC(BigDecimal ercPercentage) {
        return ercPercentage.compareTo(BigDecimal.ZERO) != 0 ? ercPercentage.setScale(2, HALF_UP) + "%" : "No charge";
    }

    private String formatAsPercentage(BigDecimal percentage) {
        return percentage.setScale(2, HALF_UP) + "%";
    }

    private String formatBigDecimalToCurrencyString(BigDecimal productFee) {
        return "£" + productFee;
    }
}

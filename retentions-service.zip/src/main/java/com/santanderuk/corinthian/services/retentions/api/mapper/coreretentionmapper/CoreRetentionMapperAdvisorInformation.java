package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.AdvisorInformation;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.springframework.stereotype.Component;

@Component
public class CoreRetentionMapperAdvisorInformation {

    public static final String ADVISOR_EMPLOYEE_NUMBER = "00000001";
    public static final String CORINTHIAN = "Corinthian";

    public void map(CoreRetentionRequest coreRetentionRequest) {
        AdvisorInformation advisorInformation = new AdvisorInformation();

        advisorInformation.setAdvisorEmployeeNumber(ADVISOR_EMPLOYEE_NUMBER);
        advisorInformation.setAdvisorSurname(CORINTHIAN);

        coreRetentionRequest.setAdvisorInformation(advisorInformation);
    }
}


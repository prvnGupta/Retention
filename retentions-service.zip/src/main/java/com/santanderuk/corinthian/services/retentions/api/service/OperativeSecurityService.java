package com.santanderuk.corinthian.services.retentions.api.service;


import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class OperativeSecurityService {

    private final AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;
    private final AnmfConfiguration anmfConfiguration;

    @Value("${operativesecurity}")
    private boolean operativeSecurity;

    public static final String LOGGING_ERROR_SECURITY_KO = "Security KO. Mortgage does not belong to customer";
    public static final String ERROR_SECURITY_KO_CODE = "SECURITY_KO";
    public static final String ERROR_SECURITY_KO_MESSAGE = "Mortgage does not belong to customer";

    public OperativeSecurityService(AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService, AnmfConfiguration anmfConfiguration) {
        this.anmfBelongToCustomerWithBorrowerListService = anmfBelongToCustomerWithBorrowerListService;
        this.anmfConfiguration = anmfConfiguration;
    }

    public void checkAnmfAccountBelongToCustomerInJwt(int accountNumber, String jwtToken, AnmfRegion region) throws OperativeSecurityException {
        try {
            checkOperativeSecurity(accountNumber, jwtToken, region);
        } catch (GeneralException ge) {
            log.error(LOGGING_ERROR_SECURITY_KO);
            throw new OperativeSecurityException(ERROR_SECURITY_KO_CODE, ERROR_SECURITY_KO_MESSAGE, ge);
        }
    }

    public CustomerDetailsResponse executeOperativeSecurityWithBorrowerList(int accountNumber, String jwtToken, AnmfRegion region) throws OperativeSecurityException {
        try {
            AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList = checkOperativeSecurity(accountNumber, jwtToken, region);
            return anmfBelongsToCustomerWithBorrowerList.getCustomerDetailsResponse();
        } catch (GeneralException ge) {
            log.error(LOGGING_ERROR_SECURITY_KO);
            throw new OperativeSecurityException(ERROR_SECURITY_KO_CODE, ERROR_SECURITY_KO_MESSAGE, ge);
        }
    }


    private AnmfBelongsToCustomerWithBorrowerList checkOperativeSecurity(int accountNumber, String jwtToken, AnmfRegion region) throws ValidationsException, OperativeSecurityException, ConnectionException {
        AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList = this.anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(accountNumber, jwtToken, anmfConfiguration.getAnmfCustomerServiceUrl(), region);

        log.info("Have called ANMF borrower list, ANMF account belongs to customer: {}", anmfBelongsToCustomerWithBorrowerList.getAnmfBelongsToCustomer());
        log.info("JWT Token is : {}", jwtToken.replaceAll("[\r\n]", ""));

        if (operativeSecurity && !anmfBelongsToCustomerWithBorrowerList.getAnmfBelongsToCustomer()) {
            log.error(LOGGING_ERROR_SECURITY_KO);
            throw new OperativeSecurityException(ERROR_SECURITY_KO_CODE, ERROR_SECURITY_KO_MESSAGE);
        }
        return anmfBelongsToCustomerWithBorrowerList;
    }
}

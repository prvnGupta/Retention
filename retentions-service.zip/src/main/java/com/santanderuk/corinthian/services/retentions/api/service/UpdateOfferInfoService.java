package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.UpdateOfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorBasic;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UpdateOfferInfoService {

    private final OperativeSecurityService operativeSecurityService;
    private final CacheableOperations cacheableOperations;
    private final ProductSwitchClient productSwitchClient;
    private final OfferInfoValidatorBasic offerInfoValidatorBasic;

    @Autowired
    public UpdateOfferInfoService(OperativeSecurityService operativeSecurityService, CacheableOperations cacheableOperations, ProductSwitchClient productSwitchClient, OfferInfoValidatorBasic offerInfoValidatorBasic) {
        this.operativeSecurityService = operativeSecurityService;
        this.cacheableOperations = cacheableOperations;
        this.productSwitchClient = productSwitchClient;
        this.offerInfoValidatorBasic = offerInfoValidatorBasic;
    }

    public UpdateOfferInfoResponse updateOfferInfo(int accountNumber, String esisRefId, String jwtToken) throws MaintenanceException, ConnectionException, OperativeSecurityException {

        AnmfRegion region = cacheableOperations.getAnmfActiveRegion();

        operativeSecurityService.checkAnmfAccountBelongToCustomerInJwt(accountNumber, jwtToken, region);

        OfferInfoResponse offerInfoResponse = productSwitchClient.retrieveOfferInfo(esisRefId);

        offerInfoValidatorBasic.validateOffer(offerInfoResponse, esisRefId, accountNumber);

        return productSwitchClient.sendUpdateRequest(accountNumber, esisRefId);
    }
}

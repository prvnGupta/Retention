package com.santanderuk.corinthian.services.retentions.api.model;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class GassDataFetcherRetentionsService {

    @Value("${bksconnect.endpoints.retrievemcc}")
    private String retrieveMccUrl;

    private final BksConnectClient bksConnectClient;

    public GassDataFetcherRetentionsService(BksConnectClient bksConnectClient) {
        this.bksConnectClient = bksConnectClient;
    }

    public String fetchCustomerNumber(String jwtToken) {
        return buildCustomerNumber(jwtToken);

    }

    private String buildCustomerNumber(String jwtToken) {
        BdpCustomer bdpCustomerFromJWT = JwtUtilities.getBdpCustomerFromJWT(jwtToken);
        String customerType = bdpCustomerFromJWT.getCustomerType();
        int customerNumber = bdpCustomerFromJWT.getCustomerNumber();
        return String.format("%s%d", customerType, customerNumber);
    }

    public String fetchMccId(String jwtToken) {
        try {
            String ldapUid = JwtUtilities.getLdapUidFromJWT(jwtToken);
            RetrieveMccResponse retrieveMccResponse = bksConnectClient.getMccFromLdapUid(retrieveMccUrl, ldapUid);
            return buildMccId(retrieveMccResponse);
        } catch (GeneralException e) {
            log.error("Failed to get MCC response due to :", e);
        }
        return "";
    }


    private String buildMccId(final RetrieveMccResponse retrieveMccResponse) {

        PartenonContract partenonContract = retrieveMccResponse.getDataResponse().getMccContract().getPartenonContract();

        String partenonContractGass = "";
        if (partenonContract != null) {
            if (partenonContract.getCentre().getCompany() != null) {
                partenonContractGass += partenonContract.getCentre().getCompany() + " ";
            }
            if (partenonContract.getCentre().getCentreCode() != null) {
                partenonContractGass += partenonContract.getCentre().getCentreCode() + " ";
            }
            if (partenonContract.getProductTypeCode() != null) {
                partenonContractGass += partenonContract.getProductTypeCode() + " ";
            }
            if (partenonContract.getContractNumber() != null) {
                partenonContractGass += partenonContract.getContractNumber();
            }
        }
        return partenonContractGass;
    }
}

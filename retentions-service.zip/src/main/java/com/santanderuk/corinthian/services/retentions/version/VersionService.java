package com.santanderuk.corinthian.services.retentions.version;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.Properties;

@Service
@Slf4j
public class VersionService {

    public VersionResponse getInfo() {

        return mapperFromPropertiesToResponse(
                loadProperties()
        );
    }

    private VersionResponse mapperFromPropertiesToResponse(Properties properties) {
        String buildTime = properties.getProperty("git.build.time");
        String gitHash = properties.getProperty("git.commit.id");
        String buildVersion = properties.getProperty("build.version");
        String serviceName = properties.getProperty("build.artifact");

        VersionResponse response = new VersionResponse();
        response.setBuildTime(buildTime);
        response.setGitHash(gitHash);
        response.setBuildVersion(buildVersion);
        response.setServiceName(serviceName);
        return response;
    }

    private Properties loadProperties() {
        Properties properties = new Properties();

        InputStream buildInfoFile = this.getClass().getClassLoader().getResourceAsStream("META-INF/build-info.properties");
        InputStream gitInfoFile = this.getClass().getClassLoader().getResourceAsStream("git.properties");

        try {
            properties.load(buildInfoFile);
        } catch (Exception e) {
            log.error("Failed to load build properties : {}", e.getMessage());
        }

        try {
            properties.load(gitInfoFile);
        } catch (Exception e) {
            log.error("Failed to load git info file : {}", e.getMessage());
        }
        return properties;
    }
}

package com.santanderuk.corinthian.services.retentions.api.model.createCase.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@ToString
public class Product {


    @NotEmpty(message = "Product code cannot be empty or null")
    @Pattern(regexp = "^[a-zA-Z0-9]{0,50}$")
    private String code;


}

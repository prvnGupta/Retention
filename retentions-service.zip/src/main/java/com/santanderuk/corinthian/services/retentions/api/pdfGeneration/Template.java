package com.santanderuk.corinthian.services.retentions.api.pdfGeneration;

public enum Template {
    DEALS
}

package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import org.springframework.stereotype.Component;

@Component
public class OfferInfoValidatorFeeRolledIntoMortgage implements OfferInfoValidator {

    public void validateOffer(OfferInfoResponse offerInfoResponse, String esisRefId, int anmfAccount) {
        validateEsisRefId(offerInfoResponse, esisRefId);
        validateOfferGeneratedForThisAnmfAccount(offerInfoResponse, anmfAccount);
        validateFeeRolledIntoMortgage(offerInfoResponse);
    }
}

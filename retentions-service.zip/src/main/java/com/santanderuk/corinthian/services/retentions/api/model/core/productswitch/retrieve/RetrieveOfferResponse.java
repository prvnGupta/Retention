package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetrieveOfferResponse extends ModelBase {

    private String pdfString;
    private boolean downloaded;
}

package com.santanderuk.corinthian.services.retentions.api.service.dealspdf;

import com.lowagie.text.DocumentException;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.pdfGeneration.PdfGenerator;
import com.santanderuk.corinthian.services.retentions.api.pdfGeneration.PdfGeneratorRequest;
import com.santanderuk.corinthian.services.retentions.api.pdfGeneration.Template;
import com.santanderuk.corinthian.services.retentions.api.service.deals.DealsService;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher.DealsPdfAnmfDataFetcher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

@Component
@Slf4j
public class PDFService {

    private final PdfGenerator pdfGenerator;
    private final DealsService dealsService;
    private final DealsPdfAnmfDataFetcher dealsPdfAnmfDataFetcher;
    private final DataMapBuilder dataMapBuilder;

    public PDFService(PdfGenerator pdfGenerator, DealsService dealsService, DealsPdfAnmfDataFetcher dealsPdfAnmfDataFetcher, DataMapBuilder dataMapBuilder) {
        this.pdfGenerator = pdfGenerator;
        this.dealsService = dealsService;
        this.dealsPdfAnmfDataFetcher = dealsPdfAnmfDataFetcher;
        this.dataMapBuilder = dataMapBuilder;
    }


    public InputStreamResource createDealsPdf(String jwtToken, int accountNumber, DealsRequest selectedLoans) throws DocumentException, GeneralException, IOException {

        var dataMap = createDataMap(jwtToken, accountNumber, selectedLoans);

        var pdfGeneratorRequest = createPdfGeneratorRequest(dataMap);

        var pdfAsByteArrayOutputStream = pdfGenerator.createPdf(pdfGeneratorRequest);
        return convertToInputStreamResource(pdfAsByteArrayOutputStream);
    }

    private PdfGeneratorRequest createPdfGeneratorRequest(Map<String, Object> dataMap) {
        var pdfGeneratorRequest = new PdfGeneratorRequest();
        pdfGeneratorRequest.setTemplateName(Template.DEALS);
        pdfGeneratorRequest.setTemplateElements(dataMap);
        return pdfGeneratorRequest;
    }

    private Map<String, Object> createDataMap(String jwtToken, int accountNumber, DealsRequest selectedLoans) throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        var dealsResponse = dealsService.get(accountNumber, selectedLoans, jwtToken);
        var anmfData = dealsPdfAnmfDataFetcher.fetch(accountNumber);

        return dataMapBuilder.build(dealsResponse, anmfData, selectedLoans);
    }

    private InputStreamResource convertToInputStreamResource(ByteArrayOutputStream pdfAsByteArrayOutputStream) {
        var byteArrayInputStream = new ByteArrayInputStream(pdfAsByteArrayOutputStream.toByteArray());
        return new InputStreamResource(byteArrayInputStream);
    }


}

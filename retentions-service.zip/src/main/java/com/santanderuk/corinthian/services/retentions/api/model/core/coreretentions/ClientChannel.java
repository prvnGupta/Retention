package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

public enum ClientChannel {
    CORINTHIAN, SHINAR, APOLLOS;
}

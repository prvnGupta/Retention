package com.santanderuk.corinthian.services.retentions.api.model.deals.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DealsRequest extends ModelBase {
    private List<LoanIdentifier> loansSelected;
}

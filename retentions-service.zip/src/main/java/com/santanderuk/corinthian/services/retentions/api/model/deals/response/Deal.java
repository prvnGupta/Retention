package com.santanderuk.corinthian.services.retentions.api.model.deals.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Deal extends ModelBase {
    private Calculations calculations;
    private Product product;
    private int loanToApplyTheFeeTo;
    private BigDecimal rate;
    private List<DealLoanView> dealLoans;
}

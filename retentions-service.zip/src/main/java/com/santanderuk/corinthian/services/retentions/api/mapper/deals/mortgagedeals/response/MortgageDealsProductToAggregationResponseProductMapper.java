package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.ErcStep;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.Product;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.Term;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.LongestTermFinder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Comparator;

import static java.math.RoundingMode.HALF_UP;

@Component
@Slf4j
@RequiredArgsConstructor
public class MortgageDealsProductToAggregationResponseProductMapper {

    private final LongestTermFinder longestTermFinder;

    // Convert from Product in Mortgage Deals API Response to Product in our API response
    public com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product map(Product sourceProduct, MortgageDealsClientRequest mortgageDealsClientRequest) {
        var product = new com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product();

        product.setStepErc(checkIfProductERCIsStepped(sourceProduct));
        product.setProductFee(sourceProduct.getProductFee());
        product.setDescription(sourceProduct.getProductDescription());
        product.setProductCode(sourceProduct.getProductCode());
        String chargeEndDate = sourceProduct.getChargeEndDate();
        product.setChargeEndDate(chargeEndDate == null ? "" : chargeEndDate);
        product.setType(sourceProduct.getType());
        product.setRate(sourceProduct.getRate());
        product.setTerm(calculateTerm(sourceProduct));
        int noOfMonths = calculateMonths(sourceProduct.getTerm());
        product.setTermInMonths(noOfMonths);
        product.setMortgageTermInMonthsAfterProduct(getLongestTermOfProduct(noOfMonths, mortgageDealsClientRequest));

        //This different mapping below for fixed products is to be used to show reversion tracking information for 2 years fixed product moving to follow on rate (as this BOER variable is used both for current and reversion product)
        product.setBankOfEnglandRate(sourceProduct.getType().equalsIgnoreCase("fixed") ? sourceProduct.getReversionBaseRate() : sourceProduct.getBankOfEnglandSvr());
        product.setBankOfEnglandRateDifference(sourceProduct.getBaseRateDifferential());
        product.setErcPercentage(calculateProductErc(sourceProduct));
        product.setAnnualOverpaymentAllowancePercentage(calculateAnnualOverpaymentAllowance(sourceProduct));
        product.setSantanderRevisionaryRate(sourceProduct.getReversionRate());
        product.setProductCompletionDate(sourceProduct.getCompletionDeadline());
        product.setReversionProduct(checkReversionProduct(sourceProduct));
        return product;
    }

    private String checkReversionProduct(Product sourceProduct) {
        if (!sourceProduct.isLifetime() && sourceProduct.getReversionBaseRate().compareTo(new BigDecimal("0.00")) == 0) {
            return "SVR";
        } else if (!sourceProduct.isLifetime() && !(sourceProduct.getReversionBaseRate().compareTo(new BigDecimal("0.00")) == 0)) {
            return "FoR";
        } else {
            return "N/A";
        }
    }

    private BigDecimal calculateAnnualOverpaymentAllowance(Product sourceProduct) {
        return (null != sourceProduct.getOverpaymentAllowance() && sourceProduct.getErc().isApplicable()) ?
                sourceProduct.getOverpaymentAllowance().setScale(2, HALF_UP) :
                BigDecimal.ZERO.setScale(2, HALF_UP);
    }

    private boolean checkIfProductERCIsStepped(Product sourceProduct) {
        try {
            return sourceProduct.getErc().isApplicable() && sourceProduct.getErc().getSteps().size() > 1;
        } catch (Exception e) {
            return false;
        }
    }

    private BigDecimal calculateProductErc(Product product) {
        try {
            return product.getErc().isApplicable() ? getHigherErcFromAllSteps(product) : new BigDecimal("0.00");
        } catch (Exception e) {
            return new BigDecimal("0.00");
        }
    }

    private BigDecimal getHigherErcFromAllSteps(Product product) {
        BigDecimal erc = product.getErc().getSteps().stream().map(ErcStep::getRate).max(Comparator.naturalOrder()).orElse(BigDecimal.ZERO);
        return erc.setScale(2, HALF_UP);
    }

    private String calculateTerm(Product sourceProduct) {
        return sourceProduct.isLifetime() ? "Lifetime" : formTermString(sourceProduct.getTerm());
    }

    private String formTermString(Term term) {
        return term.getYears() + " Year";
    }

    private int calculateMonths(Term term) {
        return term.getYears() * 12 + term.getMonths();
    }

    private int getLongestTermOfProduct(int termInMonths, MortgageDealsClientRequest mortgageDealsClientRequest) {
        var longestLoanTermInMonths = longestTermFinder.get(mortgageDealsClientRequest);
        return longestLoanTermInMonths - termInMonths;

    }

}

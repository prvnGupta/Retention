package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MortgageDealsClientResponse extends ModelBase {

    private static final long serialVersionUID = -8957750196276951718L;

    private String productBand;
    private List<Product> products;

    // In case of error these are the values to filled
    private String type;
    private String title;
    private int status;
    private String detail;
    private String instance;
}

package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;

@Getter
@Setter
public class FeePart {

    private int type;

    @NotBlank
    private String description;

    @PositiveOrZero
    private BigDecimal amount;

    @PositiveOrZero
    private BigDecimal amountWaived;

    @PositiveOrZero
    private BigDecimal amountPayable;

    @PositiveOrZero
    private BigDecimal amountCapitalised;

    private String capitalisedLoanID;

    private BigDecimal amountAddedToLoan;

    private BigDecimal amountPaidOnApplication;

    @PositiveOrZero
    private BigDecimal amountDueByCheque;

    @PositiveOrZero
    private BigDecimal amountDueByCard;

    @NotBlank
    private String bookingFeeProduct;
    private BigDecimal bookingFeePercentage;

    @NotNull
    private boolean canAddToLoan;

    @PositiveOrZero
    private int addedToLoanPartId;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LoanBreakdownWithoutFee extends ModelBase {

    private static final long serialVersionUID = -6807960728938482806L;

    private BigDecimal monthlyPayment;
    private BigDecimal dealCost;
    private BigDecimal newOutstandingBalance;
    private BigDecimal costDifferencePerMonth;
    private BigDecimal balanceAfterDeal;
}

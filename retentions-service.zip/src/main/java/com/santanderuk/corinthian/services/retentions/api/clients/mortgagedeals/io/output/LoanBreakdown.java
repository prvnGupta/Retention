package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.retentions.api.utils.CustomProductDateDeserializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LoanBreakdown extends ModelBase {

    private static final long serialVersionUID = -6176354394314321390L;

    private int loanId;
    @JsonDeserialize(using = CustomProductDateDeserializer.class)
    private String switchDate;
    @JsonDeserialize(using = CustomProductDateDeserializer.class)
    private String endDate;
    private InterestStatus interestStatus;
    private LoanBreakdownWithFee withFee;
    private LoanBreakdownWithoutFee withoutFee;
}

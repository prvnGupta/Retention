package com.santanderuk.corinthian.services.retentions.api.model.gass;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDetails {
    private String productCode;
    private String productDescription;
    private String interestRate;
    private String productFee;
    private boolean feePaidUpfront;
    private String earlyRepaymentCharge;
    private String santanderFollowOnRate;
    private String overpaymentAllowance;
    private String monthlyPayment;
    private String remainingBalance;
}

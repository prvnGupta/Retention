package com.santanderuk.corinthian.services.retentions.api.model.gass;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectedLoanGassFormat {
    private int partId;
    private String loanScheme;
    private int applicationSequenceNumber;
    private String switchDate;
    private String newProductEndDate;
    private String currentProductCode;
    private String currentProductDescription;
    private String currentProductEndDate;
    private String currentInterestRate;
    private String loanEndDate;
    private String loanBalance;
    private String remainingTerm;
    private String repaymentType;
    private boolean feeAddedToThisLoan;
}

package com.santanderuk.corinthian.services.retentions.api.model.anmf;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

@Getter
@Setter
public class AnmfCoreResponse {

    private boolean buyToLet;
    private boolean consentToLet;
    private String flexiIndicator;
    private Property property;
    private List<Loan> loans;
    private boolean customerOnArrears;
    private String nextPaymentDate;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

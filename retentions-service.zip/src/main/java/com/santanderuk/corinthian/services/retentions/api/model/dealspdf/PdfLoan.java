package com.santanderuk.corinthian.services.retentions.api.model.dealspdf;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PdfLoan {
    private String loanBalance;
    private String monthlyPayment;
    private String interestRate;
    private String productDescription;
    private String selected;
}

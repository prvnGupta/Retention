package com.santanderuk.corinthian.services.retentions.api.model.createCase;

import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import java.util.List;

@Getter
@Setter
public class CreateCaseRequest {

    @Pattern(regexp = "^[a-zA-Z0-9]{0,50}$", message = "productCode: incorrect format")
    private String productCode;

    private List<LoanIdentifier> loansSelected;

    private boolean feeAddedInMortgage;

    @Pattern(regexp = "^$|^(07\\d{9})$", message = "mobileNumber: incorrect format")
    private String mobileNumber;

    @Email(message = "emailAddress: incorrect format")
    private String emailAddress;

}

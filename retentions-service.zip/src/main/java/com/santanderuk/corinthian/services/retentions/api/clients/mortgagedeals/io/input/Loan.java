package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Loan extends ModelBase {

    private static final long serialVersionUID = -6915704172048437141L;

    private int loanId;
    private BigDecimal balance;
    private boolean selected;
    private int remainingInstalments;
    private String redemptionDate;
    private LoanType loanType;
    private BigDecimal monthlyPay;
    private BigDecimal erc;
    private BigDecimal interestRate;
    private String productEndDate;
    private String productType;
    private String productDescription;
}

package com.santanderuk.corinthian.services.retentions.api.controller;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.model.ServiceInfoWrapper;
import com.santanderuk.corinthian.services.retentions.api.service.AcceptInSessionService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Pattern;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@Validated
@RestController
public class AcceptInSessionController extends BaseController {

    private final AcceptInSessionService acceptInSessionService;

    @Autowired
    public AcceptInSessionController(AcceptInSessionService acceptInSessionService) {
        this.acceptInSessionService = acceptInSessionService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to accept immediately a mortgage retention offer",
            nickname = "acceptInSession",
            notes = "This endpoint is used by Corinthian frontend application to accept a previously generated mortgage retention offer. it will invoke mortgage-retentions-fullfillment core api (product-switch-service)"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PutMapping(
            value = "/{accountNumber}/offer/{esisRefId}/accept-in-session",
            produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE
    )
    public ResponseEntity<ServiceInfoWrapper> acceptInSession(
            @PathVariable("accountNumber") int accountNumber,
            @PathVariable("esisRefId") @Pattern(regexp = "^[a-zA-Z0-9\\-]+$") String esisRefId,
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            HttpServletRequest servletRequest
    ) throws GeneralException {
        logInput(accountNumber, jwtToken, esisRefId);
        acceptInSessionService.acceptInSession(accountNumber, jwtToken, esisRefId,servletRequest);
        return new ResponseEntity<>(buildResponseWrapper(), HttpStatus.OK);
    }

    private void logInput(int account, String jwtToken, String esisRefId) {
        log.info("retentions-service /{accountNumber}/offer/{esisRefId}/accept-in-session request received");
        log.debug("account number: {}", account);
        log.debug("Jwt: {}", sanitizeString(jwtToken));
        log.debug("Esis Ref Id: {}", sanitizeString(esisRefId));
    }

    private ServiceInfoWrapper buildResponseWrapper() {
        ServiceInfoWrapper wrapper = new ServiceInfoWrapper();
        log.info("retentions-service /{accountNumber}/offer/{esisRefId}/accept-in-session OK response");
        wrapper.setInfo(ServiceInfoCreator.ok());
        return wrapper;
    }
}

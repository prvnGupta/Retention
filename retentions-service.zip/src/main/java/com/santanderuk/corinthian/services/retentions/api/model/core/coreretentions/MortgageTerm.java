package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;


import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.PositiveOrZero;

@Getter
@Setter
public class MortgageTerm {

    @PositiveOrZero
    private int years;

    @PositiveOrZero
    private int months;

    @PositiveOrZero
    private int totalMonths;

    private boolean changed;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

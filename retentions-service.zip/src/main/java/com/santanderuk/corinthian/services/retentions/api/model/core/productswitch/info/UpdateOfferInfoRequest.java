package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateOfferInfoRequest {

    private String accountNumber;
}

package com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

public class DealsFunctionalValidationException extends GeneralException {

    public static final String CODE = "EXC_DEALS_FUNCTIONAL_VALIDATION";
    public static final String MESSAGE = "There was an issue validating the request. One loan or more does not belong to the account";

    public DealsFunctionalValidationException(Type type) {
        super(type.getCode(), type.getMessage());
    }

    public DealsFunctionalValidationException(Type type, Exception e) {
        super(type.getCode(), type.getMessage(), e);
    }

    public enum Type {
        EXC_DEALS_NO_LOANS_IN_REQUEST("EXC_DEALS_NO_LOANS_IN_REQUEST", "There are not loans in the request"),
        EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", "One or more of the loans does not belong to the account");

        private final String code;
        private final String message;

        Type(String code, String message) {
            this.code = code;
            this.message = message;
        }

        public String getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

    }


}

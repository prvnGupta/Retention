package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.OfferConversionDetails;
import org.springframework.stereotype.Component;

@Component
public class CoreRetentionMapperOfferConversionDetails {

    public void map(CoreRetentionRequest coreRetentionRequest) {
        OfferConversionDetails offerConversionDetails = new OfferConversionDetails();

        offerConversionDetails.setConversionFromCCAFlexiIndicator(false);
        offerConversionDetails.setConversionFromUnitaryFlexiIndicator(false);
        offerConversionDetails.setMultiConversionDateIndicator(false);
        offerConversionDetails.setSplitLoanIndicator(false);

        coreRetentionRequest.setOfferConversionDetails(offerConversionDetails);
    }
}

package com.santanderuk.corinthian.services.retentions.api.service.generateoffer;

import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.clients.CoreRetentionsClient;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionGenerateResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class GenerateOfferService {

    private final CoreRetentionsRequestBuilder requestBuilder;
    private final CoreRetentionMapper coreRetentionMapper;
    private final CoreRetentionsClient coreRetentionsClient;
    private final ProductSwitchClient productSwitchClient;


    @Autowired
    public GenerateOfferService(CoreRetentionsRequestBuilder requestBuilder,
                                CoreRetentionMapper coreRetentionMapper,
                                CoreRetentionsClient coreRetentionsClient,
                                ProductSwitchClient productSwitchClient) {
        this.requestBuilder = requestBuilder;
        this.coreRetentionMapper = coreRetentionMapper;
        this.coreRetentionsClient = coreRetentionsClient;
        this.productSwitchClient = productSwitchClient;
    }

    public String generateOfferInSession(int accountNumber, CreateCaseRequest offerRequest, String jwtToken) throws ConnectionException, ValidationsException, ReportedException, MaintenanceException, OperativeSecurityException, MortgageDealsClientException, DealsFunctionalValidationException {

        CoreRetentionsData coreRetentionsData = requestBuilder.buildCoreRetentionsRequest(accountNumber, offerRequest, jwtToken);

        CoreRetentionRequest coreRetentionRequest = coreRetentionMapper.buildCoreRetentionsRequest(coreRetentionsData);

        CoreRetentionGenerateResponse coreRetentionGenerateResponse = coreRetentionsClient.generateOfferInSession(coreRetentionRequest);
        productSwitchClient.saveCoreRetentionsDataInDB(coreRetentionsData, coreRetentionGenerateResponse.getKfiOfferId());

        return coreRetentionGenerateResponse.getKfiOfferId();
    }
}

package com.santanderuk.corinthian.services.retentions.api.rules.loan;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;

public interface LoanRule {

    void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse);

    void isBlocked(ODMLoanResponse odmLoanResponse, Loan loan);

    default boolean loansMatch(Loan loan, ODMLoanResponse odmLoanResponse) {
        return odmLoanResponse.getLoanID().equalsIgnoreCase(loan.getLoanId().toString());
    }
}

package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

public class MortgageDealsClientException  extends GeneralException {

    public MortgageDealsClientException() {
        super("MORTGAGE-DEALS-CLIENT-EXCEPTION", "Exception thrown in MortgageDealsClient");
    }

    public MortgageDealsClientException(Exception e) {
       super("MORTGAGE-DEALS-CLIENT-EXCEPTION", "Exception thrown in MortgageDealsClient", e);

    }
}

package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;


import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
public class GeneralInfo {

    private String channel;
    private String centre;
    private String company;
    private String currency;
    private String businessProcess;
    private String productType;
    private String productSubType;
    private String productReference;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}


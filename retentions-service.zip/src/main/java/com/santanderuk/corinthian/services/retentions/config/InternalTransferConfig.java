package com.santanderuk.corinthian.services.retentions.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class InternalTransferConfig {

    @Value("${product-transfer-fee-payment.endpoint}")
    private String feePaymentEndpoint;

    @Value("${product-transfer-fee-payment.agent-id}")
    private String agentId;

    @Value("${payments-service.endpoint}")
    private String paymentServiceEndpoint;

    @Value("${payments-service.destination-account-number}")
    private String paymentsDestinationAccNo;
}

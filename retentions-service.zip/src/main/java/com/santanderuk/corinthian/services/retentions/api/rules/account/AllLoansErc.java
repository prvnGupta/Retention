package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;

@Component
public class AllLoansErc implements ODMEligibilityRule {

    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse) {

        int loanERCNotEligibleCount = 0;
        int loansCount = odmEligibilityResponse.getAccountResponse().getLoanResponse().size();
        for (ODMLoanResponse loan : odmEligibilityResponse.getAccountResponse().getLoanResponse()) {
            if (loan.getErcEligibility().equalsIgnoreCase("N")) {
                loanERCNotEligibleCount++;
            }
        }

        boolean allLoansERC = loanERCNotEligibleCount == loansCount;
        eligibilityResponse.getBlockers().setAllLoansERC(allLoansERC);
    }
}

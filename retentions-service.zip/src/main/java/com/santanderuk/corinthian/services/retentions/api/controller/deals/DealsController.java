package com.santanderuk.corinthian.services.retentions.api.controller.deals;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.controller.BaseController;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.service.deals.DealsService;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@Slf4j
public class DealsController extends BaseController {

    private final DealsService dealsService;

    @Autowired
    public DealsController(DealsService dealsService) {
        this.dealsService = dealsService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to return available mortgage retentions deals for one mortgage account",
            nickname = "fetchDeals",
            notes = "This endpoint is used by Corinthian frontend application to get available mortgage retentions deals for one mortgage account. It will return as well an illustration on how the loans will look after applying the deal. It uses mortgage deals core api"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PostMapping(
            value = "/{accountNumber}/deals",
            produces = APPLICATION_JSON_VALUE,
            consumes = APPLICATION_JSON_VALUE
    )
    public ResponseEntity<DealsResponseWrapper> fetchDeals(
            @RequestBody DealsRequest selectedLoans,
            @PathVariable int accountNumber,
            @RequestHeader(name = "Authorization") String jwtToken) throws MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, OperativeSecurityException, ValidationsException {

        var deals = dealsService.get(accountNumber, selectedLoans, jwtToken);

        var responseWrapper = new DealsResponseWrapper();
        responseWrapper.setResponse(deals);
        responseWrapper.setInfo(ServiceInfoCreator.ok());

        return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
    }
}

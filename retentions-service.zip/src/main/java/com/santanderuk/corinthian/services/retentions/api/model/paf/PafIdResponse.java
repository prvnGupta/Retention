package com.santanderuk.corinthian.services.retentions.api.model.paf;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PafIdResponse {

    private List<PafItem> items;
}

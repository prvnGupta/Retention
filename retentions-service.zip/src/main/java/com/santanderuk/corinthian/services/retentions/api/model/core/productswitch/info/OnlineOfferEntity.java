package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info;

import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OnlineOfferEntity extends ModelBase {

    private String caseId;
    private String anmfAccountNumber;
    private String offerGeneratedBy;
    private String offerAcceptedBy;
    private String offerDownloadedDateTime;
    private String esisRefId;
    private String createdDateTime;
    private String updatedDateTime;
    private String offerAcceptedDateTime;
    private String coreRetentionsData;
    private boolean feePaidUpfront;
}
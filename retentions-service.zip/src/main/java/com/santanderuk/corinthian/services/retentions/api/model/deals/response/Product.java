package com.santanderuk.corinthian.services.retentions.api.model.deals.response;

import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class Product extends ModelBase {

    private boolean stepErc;
    private BigDecimal productFee;
    private String description;
    private String productCode;
    private String chargeEndDate;
    private String type;
    private BigDecimal rate;
    private String term;
    private int termInMonths;
    private int mortgageTermInMonthsAfterProduct;
    private BigDecimal bankOfEnglandRate;
    private BigDecimal bankOfEnglandRateDifference;
    private BigDecimal ercPercentage;
    private BigDecimal annualOverpaymentAllowancePercentage;
    private BigDecimal santanderRevisionaryRate;
    private String productCompletionDate;
    private String reversionProduct;
}

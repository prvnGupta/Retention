package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class Account {

    private int type;

    @NotEmpty
    private String title;

    @NotEmpty
    private String reference;

    @NotEmpty
    private String platform;

    @NotEmpty
    private String number;

    @PositiveOrZero
    private BigDecimal balance;

    @NotEmpty
    private String setupDate;

    @Valid
    private Mortgage mortgage;

    @Valid
    private Property property;

    private BigDecimal drawdownAmount;
    private BigDecimal bonusProductID;
    private BigDecimal totalPortedLoans;
    private BigDecimal totalCapitalRepaymentAmount;

    @Valid
    private List<Loan> loans;

    @Valid
    private List<Borrower> borrowers;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }

}

package com.santanderuk.corinthian.services.retentions.api.service.generateoffer;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.service.deals.DealsService;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import com.santanderuk.corinthian.services.retentions.api.validation.CreateCaseFunctionalValidation;
import com.santanderuk.corinthian.services.retentions.api.validation.CreateCaseFunctionalValidationInput;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class CoreRetentionsRequestBuilder {

    private final CreateCaseFunctionalValidation functionalValidation;
    private final CacheableOperations cacheableOperations;
    private final AnmfCoreClient anmfCoreClient;
    private final AnmfConfiguration anmfConfiguration;
    private final DealsService dealsService;

    public CoreRetentionsRequestBuilder(CreateCaseFunctionalValidation functionalValidation, CacheableOperations cacheableOperations, AnmfCoreClient anmfCoreClient, AnmfConfiguration anmfConfiguration, DealsService dealsService) {
        this.functionalValidation = functionalValidation;
        this.cacheableOperations = cacheableOperations;
        this.anmfCoreClient = anmfCoreClient;
        this.anmfConfiguration = anmfConfiguration;
        this.dealsService = dealsService;
    }

    public CoreRetentionsData buildCoreRetentionsRequest(int accountNumber, CreateCaseRequest createCaseRequest, String jwtToken) throws ConnectionException, ReportedException, ValidationsException, OperativeSecurityException, MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException {
        var coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setAccount(accountNumber);
        coreRetentionsData.setCaseRequest(createCaseRequest);

        var dealsRequest = convertToDealsRequest(createCaseRequest);
        var dealsResponse = dealsService.get(accountNumber, dealsRequest, jwtToken);

        functionalValidations(createCaseRequest, dealsResponse);

        coreRetentionsData.setSelectedDeal(getSelectedDeal(dealsResponse, createCaseRequest));
        if (isPayingFeeUpFront(createCaseRequest)) {
            setAllLoansFeeAddedToFalse(coreRetentionsData);
        }

        addAnmfDataToMapperInput(coreRetentionsData, accountNumber);

        addBdpCustomerToMapperInput(coreRetentionsData, jwtToken);

        return coreRetentionsData;
    }

    private void setAllLoansFeeAddedToFalse(CoreRetentionsData coreRetentionsData) {
        coreRetentionsData.getSelectedDeal().getDealLoans().forEach(dealLoanView -> dealLoanView.setApplyFeeInThisLoan(false));
    }

    private DealsRequest convertToDealsRequest(CreateCaseRequest createCaseRequest) {

        var loans = new ArrayList<LoanIdentifier>();
        createCaseRequest.getLoansSelected().forEach(loanSelected -> {
            var loanForDealsRequest = new LoanIdentifier();
            loanForDealsRequest.setLoanScheme(loanSelected.getLoanScheme());
            loanForDealsRequest.setSequenceNumber(loanSelected.getSequenceNumber());
            loans.add(loanForDealsRequest);
        });
        var dealsRequest = new DealsRequest();
        dealsRequest.setLoansSelected(loans);
        return dealsRequest;
    }

    private boolean isPayingFeeUpFront(CreateCaseRequest createCaseRequest) {
        return !createCaseRequest.isFeeAddedInMortgage();
    }

    private void functionalValidations(CreateCaseRequest createCaseRequest, DealsResponse dealsResponse) throws ValidationsException {
        var functionalValidationInput = new CreateCaseFunctionalValidationInput();
        functionalValidationInput.setCaseRequest(createCaseRequest);
        functionalValidationInput.setDealsResponse(dealsResponse);
        functionalValidation.validate(functionalValidationInput);
    }

    private Deal getSelectedDeal(DealsResponse dealsResponse, CreateCaseRequest caseRequest) {
        return dealsResponse.getDeals().stream()
                .filter(deal -> isSameDeal(deal, caseRequest))
                .findFirst()
                .orElseGet(Deal::new);
    }

    private boolean isSameDeal(Deal deal, CreateCaseRequest caseRequest) {
        return deal.getProduct().getProductCode().equalsIgnoreCase(caseRequest.getProductCode());
    }

    private void addAnmfDataToMapperInput(CoreRetentionsData mapperInput, int accountNumber) throws ConnectionException, MaintenanceException {
        var anmfRegion = cacheableOperations.getAnmfActiveRegion();

        var anmfAccountServiceResponse = anmfCoreClient.fetchMortgageAccountDetailsV5(accountNumber, anmfConfiguration.getAnmfAccountDetailsUrl(), anmfRegion);
        mapperInput.setAnmfAccountServiceResponse(anmfAccountServiceResponse);

        var customerDetailsResponse = anmfCoreClient.fetchMortgageCustomerDetailsV4(accountNumber, anmfConfiguration.getAnmfCustomerServiceUrl(), anmfRegion);
        mapperInput.setCustomerDetailsResponse(customerDetailsResponse);

        var anmfAddressResponse = anmfCoreClient.fetchAddress(accountNumber, anmfConfiguration.getAnmfPropertyUrl(), anmfRegion);
        mapperInput.setAddressResponse(anmfAddressResponse);
    }

    private void addBdpCustomerToMapperInput(CoreRetentionsData mapperInput, String jwtToken) {
        var bdpCustomerFromJWT = JwtUtilities.getBdpCustomerFromJWT(jwtToken);
        mapperInput.setBdpType(bdpCustomerFromJWT.getCustomerType());
        mapperInput.setBdpNumber(bdpCustomerFromJWT.getCustomerNumber());
    }
}

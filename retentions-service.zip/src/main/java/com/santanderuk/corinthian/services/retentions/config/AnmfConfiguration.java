package com.santanderuk.corinthian.services.retentions.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class AnmfConfiguration {

    @Value("${anmf.services.account-details}")
    private String anmfAccountDetailsUrl;

    @Value("${anmf.services.customerservice}")
    private String anmfCustomerServiceUrl;

    @Value("${anmf.services.property}")
    private String anmfPropertyUrl;
}

package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class MapperSourceData extends ModelBase {

    private int account;
    private ANMFPropertyResponse anmfPropertyResponse;
    private AnmfAccountServiceResponse accountServiceResponse;
    private DealsRequest dealsRequest;
}

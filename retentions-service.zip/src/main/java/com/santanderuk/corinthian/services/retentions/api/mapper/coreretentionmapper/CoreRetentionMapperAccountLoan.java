package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.LoanTerm;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class CoreRetentionMapperAccountLoan {

    public void map(CoreRetentionRequest coreRetentionRequest, CoreRetentionsData input) {
        List<Loan> loanList = input.getAnmfAccountServiceResponse().getAccountServiceResponse()
                .getResponse().getOStruc().getOActiveLoanDetails().stream()
                .map(oLoan -> convertToCaseRetentionLoan(oLoan, input))
                .collect(Collectors.toList());

        coreRetentionRequest.getAccount().setLoans(loanList);
    }

    private Loan convertToCaseRetentionLoan(OActiveLoanDetail loanFromANMF, CoreRetentionsData input) {
        Loan loan = new Loan();

        loan.setTransferring(isBeingTransferred(input.getCaseRequest(), loanFromANMF));
        loan.setPartId(getLoanId(loanFromANMF, input));
        loan.setProductType(mapProductType(loan.isTransferring(), loanFromANMF, input.getSelectedDeal().getProduct()));
        loan.setProductCode(getProductCode(loanFromANMF, input));
        loan.setBalanceRequestAmount(loanFromANMF.getOCapitalBalance());
        loan.setRepaymentType(getRepaymentType(loanFromANMF));
        loan.setCapitalRepaymentAmt(new BigDecimal("0.00"));
        loan.setCapitalRepaymentMade(false);
        loan.setRepaymentTypeChanged(false);
        loan.setNewProduct(getNewProduct(loanFromANMF, input));
        loan.setPortedLoan(false);
        loan.setInterestRate(getInterestRate(loanFromANMF, input));
        loan.setTerm(getTerm(loanFromANMF));
        loan.setOriginalProductCompletionDate(getOriginalProductCompletionDate(loanFromANMF));
        loan.setLoanScheme(mapSchema(loanFromANMF, input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoans()));
        loan.setSequenceNumber(mapSequenceNumber(loanFromANMF, input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoans()));

        return loan;
    }

    private String mapProductType(boolean isLoanTransferring, OActiveLoanDetail loanFromANMF, Product newProduct) {
        String productType = isLoanTransferring ? newProduct.getType() : loanFromANMF.getOProductType();
        return "FIXED".equalsIgnoreCase(productType) ? "F" : "A";
    }

    private OActiveLoan findMatchedLoan(OActiveLoanDetail loanFromANMF, List<OActiveLoan> oActiveLoans) {
        return oActiveLoans.stream().filter(
                activeLoan -> isSameLoan(activeLoan, loanFromANMF)
        ).findFirst().orElseGet(OActiveLoan::new);
    }

    private int mapSequenceNumber(OActiveLoanDetail loanFromANMF, List<OActiveLoan> oActiveLoans) {
        return findMatchedLoan(loanFromANMF, oActiveLoans).getOApplSeqNo();
    }

    private String mapSchema(OActiveLoanDetail loanFromANMF, List<OActiveLoan> oActiveLoans) {
        return findMatchedLoan(loanFromANMF, oActiveLoans).getOLoanSch();
    }

    private boolean isBeingTransferred(CreateCaseRequest caseRequest, OActiveLoanDetail loanFromANMF) {

        List<String> transferringLoanIds = caseRequest.getLoansSelected().stream().map(loanIdentifier ->
                String.format("%s%d", loanIdentifier.getLoanScheme(), loanIdentifier.getSequenceNumber())).collect(Collectors.toList());

        String loanToBeConvertedId = String.format("%s%d", loanFromANMF.getOLoanScheme(), loanFromANMF.getOApplSeqNo());

        return transferringLoanIds.contains(loanToBeConvertedId);
    }

    private String getOriginalProductCompletionDate(OActiveLoanDetail loanToBeConverted) {
        String dateToBeUsed;
        if (thereIsLoanProductEndDate(loanToBeConverted)) {
            dateToBeUsed = loanToBeConverted.getOProductEndDate();
        } else {
            dateToBeUsed = loanToBeConverted.getORedemptionDate();
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate productEndDateLocalDate = LocalDate.parse(dateToBeUsed, formatter);
        return productEndDateLocalDate.toString();
    }

    private boolean thereIsLoanProductEndDate(OActiveLoanDetail loanToBeConverted) {
        return null != loanToBeConverted.getOProductEndDate() && !"".equalsIgnoreCase(loanToBeConverted.getOProductEndDate());
    }

    private LoanTerm getTerm(OActiveLoanDetail loanToBeConverted) {
        LoanTerm loanTerm = new LoanTerm();

        int remainingInstallments = loanToBeConverted.getORemainingInstlm();

        int years = remainingInstallments / 12;
        int months = remainingInstallments % 12;

        loanTerm.setYears(years);
        loanTerm.setMonths(months);

        loanTerm.setTermRemaining(remainingInstallments);
        loanTerm.setTotalMonths(remainingInstallments);

        loanTerm.setChanged(false);

        return loanTerm;
    }

    private BigDecimal getInterestRate(OActiveLoanDetail loanToBeConverted, CoreRetentionsData input) {
        return isLoanSelected(loanToBeConverted, input)
                ? input.getSelectedDeal().getProduct().getRate()
                : loanToBeConverted.getOInterestRate();
    }

    private boolean getNewProduct(OActiveLoanDetail loanToBeConverted, CoreRetentionsData input) {
        return isLoanSelected(loanToBeConverted, input);
    }

    private int getRepaymentType(OActiveLoanDetail loanToBeConverted) {
        return "R".equalsIgnoreCase(loanToBeConverted.getORepaymentType())
                ? 1
                : 2;
    }

    private String getProductCode(OActiveLoanDetail loanToBeConverted, CoreRetentionsData input) {
        return isLoanSelected(loanToBeConverted, input)
                ? input.getCaseRequest().getProductCode()
                : loanToBeConverted.getOProductCode();
    }

    private boolean isLoanSelected(OActiveLoanDetail loanToBeConverted, CoreRetentionsData input) {
        long count = input.getCaseRequest().getLoansSelected().stream()
                .filter(loanIdentifier -> isSameLoan(loanToBeConverted, loanIdentifier)).count();

        return count > 0;
    }

    private int getLoanId(OActiveLoanDetail oLoan, CoreRetentionsData input) {
        Optional<OActiveLoan> first = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoans().stream()
                .filter(oActiveLoan -> isSameLoan(oActiveLoan, oLoan))
                .findFirst();

        return first.map(OActiveLoan::getOLoanId).orElse(0);
    }

    private boolean isSameLoan(OActiveLoan oActiveLoan, OActiveLoanDetail oLoan) {
        boolean sameLoanScheme = oActiveLoan.getOLoanSch().equalsIgnoreCase(oLoan.getOLoanScheme());
        boolean sameAppSeqNumber = oActiveLoan.getOApplSeqNo() == oLoan.getOApplSeqNo();
        return sameLoanScheme && sameAppSeqNumber;
    }

    private boolean isSameLoan(OActiveLoanDetail oLoan, LoanIdentifier loanSelected) {
        boolean sameLoanScheme = oLoan.getOLoanScheme().equalsIgnoreCase(loanSelected.getLoanScheme());
        boolean sameAppSeqNumber = oLoan.getOApplSeqNo() == loanSelected.getSequenceNumber();
        return sameLoanScheme && sameAppSeqNumber;
    }
}

package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;

@Component
public class OutsideDealWindow implements ODMEligibilityRule {

    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse) {

        int loansCount = eligibilityResponse.getLoans().size();
        int outsideTermWindowLoanCount = 0;

        for (Loan loan : eligibilityResponse.getLoans()) {
            if (loan.getBlockers().isOutsideDealWindow()) {
                outsideTermWindowLoanCount++;
            }
        }

        if (loansCount == outsideTermWindowLoanCount) {
            eligibilityResponse.getBlockers().setOutsideDealWindow(true);
        }

    }
}

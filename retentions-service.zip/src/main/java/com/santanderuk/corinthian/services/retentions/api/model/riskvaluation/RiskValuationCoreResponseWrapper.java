package com.santanderuk.corinthian.services.retentions.api.model.riskvaluation;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class RiskValuationCoreResponseWrapper {

    private String status;
    private String code;
    private String message;
    private RiskValuationCoreResponse data;
}

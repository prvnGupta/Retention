package com.santanderuk.corinthian.services.retentions.api.clients;


import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafDetailResponse;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafIdResponse;
import com.santanderuk.corinthian.services.retentions.config.Config;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class PafClient {

    private final Config config;
    private final RestTemplate restTemplate;

    @Autowired
    public PafClient(Config config, RestTemplate restTemplate) {
        this.config = config;
        this.restTemplate = restTemplate;
    }

    public PafIdResponse fetchPafIdResponse(String postcode) throws ConnectionException, InterruptedException {
        int count = 0;
        postcode = postcode.replaceAll(" ", "");
        while (true) {
            try {
                log.info("PAF ID - > request received");
                HttpEntity<?> requestEntity = createHttpEntity();

                String urlWithQuery = String.format("%s?query=%s", config.getPafCoreUrl(), postcode);

                log.info("URL for paf with postcode {},", urlWithQuery);

                ResponseEntity<PafIdResponse> response = restTemplate.exchange(urlWithQuery, GET, requestEntity, PafIdResponse.class);

                return response.getBody();
            } catch (RestClientException e) {
                log.warn("Exception while calling PAF Core Service. Query being sent is {}", postcode, e);
                TimeUnit.SECONDS.sleep(config.getPafAttemptDelay());
                if (++count == config.getPafMaxAttempts())
                    throw new ConnectionException(ConnectionException.Type.PAF_ID_UNAVAILABLE, e);
            }
        }
    }

    public String fetchPafIdAndPostcodeResponse(String postcode, String pafId) throws ConnectionException, InterruptedException {
        int count = 0;
        postcode = postcode.replaceAll(" ", "");
        while (true) {
            try {
                log.info("PAF ID - > request received");
                HttpEntity<?> requestEntity = createHttpEntity();

                String urlWithQuery = String.format("%s?container=%s&query=%s", config.getPafCoreUrl(), pafId, postcode);

                log.info("URL for paf with postcode {},", urlWithQuery);

                ResponseEntity<PafIdResponse> response = restTemplate.exchange(urlWithQuery, GET, requestEntity, PafIdResponse.class);

                return Objects.requireNonNull(response.getBody()).getItems().get(0).getId();
            } catch (Exception e) {
                log.warn("Exception while calling PAF Core Service. Query being sent is {}", postcode, e);
                TimeUnit.SECONDS.sleep(config.getPafAttemptDelay());
                if (++count == config.getPafMaxAttempts())
                    throw new ConnectionException(ConnectionException.Type.PAF_ID_UNAVAILABLE, e);
            }
        }
    }

    public PafDetailResponse fetchPafDetailResponse(String id) throws ConnectionException, InterruptedException {
        int count = 0;
        while (true) {
            try {
                log.info("PAF ID - > request received");
                HttpEntity<?> requestEntity = createHttpEntity();

                String urlWithQuery = String.format("%s/%s", config.getPafCoreUrl(), id);

                log.info("URL for paf with postcode {},", urlWithQuery);

                ResponseEntity<PafDetailResponse> response = restTemplate.exchange(urlWithQuery, GET, requestEntity, PafDetailResponse.class);
                log.debug("PAF response ID {}", response.getBody());

                return response.getBody();
            } catch (RestClientException | NullPointerException e) {
                log.warn("Exception while calling PAF Core Service. Query being sent is {}", id, e);
                TimeUnit.SECONDS.sleep(config.getPafAttemptDelay());
                if (++count == config.getPafMaxAttempts())
                    throw new ConnectionException(ConnectionException.Type.PAF_DETAILS_UNAVAILABLE, e);
            }
        }
    }

    public HttpEntity<?> createHttpEntity() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(config.getClientIdHeaderKey(), config.getClientIdHeaderValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);

        return new HttpEntity<>(headers);
    }

}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.retentions.api.clients.EsisClient;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.mapper.OfferResponseMapper;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve.RetrieveOfferResponse;
import com.santanderuk.corinthian.services.retentions.api.model.esis.RetrieveEsisResponse;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorBasic;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class RetrieveOfferService {

    private final OperativeSecurityService operativeSecurityService;
    private final CacheableOperations cacheableOperations;
    private final ProductSwitchClient productSwitchClient;
    private final EsisClient esisClient;
    private final OfferResponseMapper responseMapper;
    private final OfferInfoValidatorBasic offerInfoValidatorBasic;

    @Autowired
    public RetrieveOfferService(OperativeSecurityService operativeSecurityService, CacheableOperations cacheableOperations, ProductSwitchClient productSwitchClient, EsisClient esisClient, OfferResponseMapper responseMapper, OfferInfoValidatorBasic offerInfoValidatorBasic) {
        this.operativeSecurityService = operativeSecurityService;
        this.cacheableOperations = cacheableOperations;
        this.productSwitchClient = productSwitchClient;
        this.esisClient = esisClient;
        this.responseMapper = responseMapper;
        this.offerInfoValidatorBasic = offerInfoValidatorBasic;
    }

    public RetrieveOfferResponse retrieveOffer(int account, String jwtToken, String esisRefId) throws MaintenanceException, ConnectionException, OperativeSecurityException {

        AnmfRegion region = cacheableOperations.getAnmfActiveRegion();

        operativeSecurityService.checkAnmfAccountBelongToCustomerInJwt(account, jwtToken, region);

        OfferInfoResponse offerInfoResponse = productSwitchClient.retrieveOfferInfo(esisRefId);

        offerInfoValidatorBasic.validateOffer(offerInfoResponse, esisRefId, account);

        RetrieveEsisResponse esisResponse = esisClient.retrieveOffer(esisRefId);

        return responseMapper.mapToResponse(offerInfoResponse, esisResponse);
    }

}

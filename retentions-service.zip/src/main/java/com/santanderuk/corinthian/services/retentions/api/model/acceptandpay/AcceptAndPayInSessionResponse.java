package com.santanderuk.corinthian.services.retentions.api.model.acceptandpay;

import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Data
@EqualsAndHashCode(callSuper = true)
@Setter
@Getter
public class AcceptAndPayInSessionResponse extends ModelBase {
    private String paymentId;
}

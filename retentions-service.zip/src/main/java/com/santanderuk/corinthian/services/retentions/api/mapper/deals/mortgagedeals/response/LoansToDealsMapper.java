package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OErcStepDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.ORevisionaryDetails;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.ErcStep;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.LoanBreakdown;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.Product;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MapperSourceData;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.InterestRateChange;
import com.santanderuk.corinthian.services.retentions.api.utils.DateUtils;
import org.apache.commons.text.WordUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static java.math.RoundingMode.HALF_UP;

@Component
public class LoansToDealsMapper {

    private final DateUtils dateUtils;

    public LoansToDealsMapper(DateUtils dateUtils) {
        this.dateUtils = dateUtils;
    }

    public List<DealLoanView> map(Product product, MapperSourceData sourceData) {
        List<DealLoanView> loans = new ArrayList<>();

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails()
                .forEach(oActiveLoanDetail -> {
                    DealLoanView loan = new DealLoanView();

                    LoanBreakdown matchedDealsLoan = findMatchedLoanFromDealsResponse(product, oActiveLoanDetail);

                    loan.setTransferring(isLoanSelected(sourceData, oActiveLoanDetail));
                    loan.setLoanId(matchedDealsLoan.getLoanId());
                    loan.setNewOutstandingBalance(oActiveLoanDetail.getOOutstandingBalance());

                    boolean fixedProduct = oActiveLoanDetail.getOProductDesc().toLowerCase().contains("year");
                    boolean trackerProduct = oActiveLoanDetail.getOProductDesc().toLowerCase().contains("tracker");

                    loan.setCurrentProductFixedTermFlag(fixedProduct);
                    loan.setCurrentProductTrackerFlag(trackerProduct);
                    loan.setLoanBalance(oActiveLoanDetail.getOCapitalBalance());
                    loan.setRemainingTerm(dateUtils.toYearsAndMonths(oActiveLoanDetail.getORemainingInstlm()));
                    loan.setRepaymentType(oActiveLoanDetail.getORepaymentType().equalsIgnoreCase("R") ? "REPAYMENT" : "INTEREST_ONLY");

                    if (loan.isTransferring()) {
                        decorateWithProductDetails(loan, product, oActiveLoanDetail, matchedDealsLoan);
                    } else {
                        decorateWithLoanDetails(loan, oActiveLoanDetail);
                    }
                    loans.add(loan);
                });
        return loans;
    }

    private void decorateWithProductDetails(DealLoanView loan, Product product, OActiveLoanDetail oActiveLoanDetail, LoanBreakdown matchedDealsLoan) {
        loan.setProductTitle(mapProductDescription(product));
        loan.setProductFee(product.getProductFee());
        loan.setPreviousProduct(formatPreviousProduct(WordUtils.capitalizeFully(oActiveLoanDetail.getOProductDesc()), oActiveLoanDetail.getOInterestRate()));
        loan.setEarlyRepaymentChargeAsPercentage(calculateProductErc(product));
        loan.setInterestRateChange(mapInterestRateChange(matchedDealsLoan.getInterestStatus().toString()));
        loan.setInterestRate(product.getRate());
        loan.setProductStartDate(matchedDealsLoan.getSwitchDate());
        loan.setProductEndDate(calculateProductEndDate(matchedDealsLoan, product));
        boolean isFixedProduct = product.getType().toLowerCase().contains("fixed");
        loan.setVariable(!isFixedProduct);
        loan.setLifetimeTermFlag(product.isLifetime());
        loan.setSantanderFollowOnRate(product.getReversionRate());
        if (loan.isVariable()) {
            loan.setTrackingRate(product.getBaseRateDifferential());
        }
        loan.setMonthlyPaymentWithFee(matchedDealsLoan.getWithoutFee().getMonthlyPayment());
        loan.setMonthlyPaymentWithoutFee(matchedDealsLoan.getWithoutFee().getMonthlyPayment());
        loan.setNewOutstandingBalance(matchedDealsLoan.getWithoutFee().getNewOutstandingBalance());
        boolean productWithFee = product.getProductFee().compareTo(BigDecimal.ZERO) != 0;
        if (productWithFee) {
            loan.setProductWithFee(true);
            loan.setMonthlyPaymentWithFee(matchedDealsLoan.getWithFee().getMonthlyPayment());
            loan.setApplyFeeInThisLoan(matchedDealsLoan.getWithFee().isFeeRolledIn());
            loan.setNewOutstandingBalance(matchedDealsLoan.getWithFee().getNewOutstandingBalance());
            loan.setNewOutstandingBalance(matchedDealsLoan.getWithFee().getNewOutstandingBalance());
        }
        //changed based on rint 8650584698 pid response, please check 'pid-8650584698-58-products-resp.json' file.
        loan.setBankOfEnglandBaseRate(isFixedProduct ? product.getReversionBaseRate() : product.getBankOfEnglandSvr());
        loan.setStepErc(product.getErc().isApplicable() && product.getErc().getSteps().size() > 1);
        loan.setAnnualOverpaymentAllowance(calculateOverpaymentAllowancePercentage(product)
                .setScale(2, HALF_UP));
        loan.setReversionProduct(getReversionProduct(product));
    }

    private String getReversionProduct(Product product) {
        if (!product.isLifetime()) {
            if (product.getReversionBaseRate().compareTo(new BigDecimal("0.00")) == 0) {
                return "SVR";
            } else {
                return "FoR";
            }
        } else {
            return "N/A";
        }
    }

    private BigDecimal calculateOverpaymentAllowancePercentage(Product product) {
        return (null != product.getOverpaymentAllowance() && product.getErc().isApplicable()) ?
                product.getOverpaymentAllowance() : BigDecimal.ZERO;
    }

    private String calculateProductEndDate(LoanBreakdown matchedDealsLoan, Product product) {
        boolean isFixed = product.getType().toLowerCase().contains("fixed");
        return isFixed
                ? product.getChargeEndDate()
                : matchedDealsLoan.getEndDate();
    }

    private String mapProductDescription(Product sourceProduct) {
        if (sourceProduct.isLifetime()) {
            if (sourceProduct.getType().equalsIgnoreCase("variable")) {
                return "Standard Variable Rate";
            }
            return String.format("Lifetime %s", sourceProduct.getType());
        } else {
            int years = sourceProduct.getTerm().getYears();
            return String.format("%d Year %s", years, sourceProduct.getType());
        }
    }

    private BigDecimal calculateProductErc(Product product) {
        return product.getErc().isApplicable() ? getHigherErcFromAllSteps(product) : BigDecimal.ZERO;
    }

    private BigDecimal getHigherErcFromAllSteps(Product product) {
        return product.getErc().isApplicable() ? product.getErc().getSteps().stream().map(ErcStep::getRate).max(Comparator.naturalOrder()).orElse(BigDecimal.ZERO) : BigDecimal.ZERO;
    }

    private void decorateWithLoanDetails(DealLoanView loan, OActiveLoanDetail oActiveLoanDetail) {
        loan.setProductTitle(WordUtils.capitalizeFully(oActiveLoanDetail.getOProductDesc().toLowerCase().replace("(variable)", "")));
        loan.setEarlyRepaymentChargeAsAmount(oActiveLoanDetail.getOErcDetailsGrp().getORdmStmErc());
        loan.setEarlyRepaymentChargeAsPercentage(calculateLoanErc(oActiveLoanDetail).setScale(2, HALF_UP));
        loan.setInterestRate(oActiveLoanDetail.getOInterestRate());
        loan.setProductEndDate(oActiveLoanDetail.getOProductEndDate());
        loan.setMonthlyPaymentWithFee(oActiveLoanDetail.getOMonthlyPay());
        loan.setMonthlyPaymentWithoutFee(oActiveLoanDetail.getOMonthlyPay());
        loan.setVariable(!loan.getProductTitle().toLowerCase().contains("fixed"));
        loan.setLifetimeTermFlag(!oActiveLoanDetail.getOProductDesc().toLowerCase().contains("year"));
        loan.setAnnualOverpaymentAllowance(convertToBigDecimal(oActiveLoanDetail.getOErcDetailsGrp().getOErcAllowPerc()));
        if (loan.isVariable()) {
            loan.setTrackingRate(oActiveLoanDetail.getOBaseRateDiff());
        }
        loan.setBankOfEnglandBaseRate(oActiveLoanDetail.getOBaseRate());
        loan.setStepErc(oActiveLoanDetail.getOErcDetailsGrp().getOErcProdType().trim().equalsIgnoreCase("Stepped ERC"));
        loan.setReversionProduct(getReversionProductFromExistingLoan(oActiveLoanDetail));
        loan.setSantanderFollowOnRate(oActiveLoanDetail.getORevisionaryDetails().getOReviInterestRate());
    }

    private String getReversionProductFromExistingLoan(OActiveLoanDetail oActiveLoanDetail) {
        ORevisionaryDetails loanRevisionaryDetails = oActiveLoanDetail.getORevisionaryDetails();
        if (loanRevisionaryDetails.getOReviProdDesc().trim().equalsIgnoreCase("SANTANDER'S FOLLOW-ON RATE")) {
            return "FoR";
        } else {
            if (loanRevisionaryDetails.getOReviProdDesc().trim().equalsIgnoreCase("")) {
                return "N/A";
            } else {
                return "SVR";
            }
        }
    }

    private BigDecimal calculateLoanErc(OActiveLoanDetail oActiveLoanDetail) {
        var ercGroup = oActiveLoanDetail.getOErcDetailsGrp();
        return "y".equalsIgnoreCase(ercGroup.getOErcApplFlag()) ?
                getERCPercentage(oActiveLoanDetail) : BigDecimal.ZERO;
    }

    private BigDecimal getERCPercentage(OActiveLoanDetail oActiveLoanDetail) {

        var ercGroup = oActiveLoanDetail.getOErcDetailsGrp();
        return ercGroup.getOErcStepDetailsTab().getOErcStepDetails().
                stream().
                filter(resp -> resp.getOErcStepSeq() == ercGroup.getOErcCurrentStepSeq()).
                map(OErcStepDetail::getOErcRate).
                findFirst().
                orElseThrow();

    }

    private LoanBreakdown findMatchedLoanFromDealsResponse(Product product, OActiveLoanDetail oActiveLoanDetail) {
        return product.getLoanBreakdown().stream()
                .filter(loanBreakdown -> oActiveLoanDetail.getOLoanId() == loanBreakdown.getLoanId()).findFirst().orElseThrow();
    }

    private boolean isLoanSelected(MapperSourceData sourceData, OActiveLoanDetail oActiveLoanDetail) {
        return sourceData.getDealsRequest().getLoansSelected().stream()
                .anyMatch(loanIdentifier -> isLoanSelectedToTransfer(oActiveLoanDetail, loanIdentifier));
    }

    private InterestRateChange mapInterestRateChange(String interestRateChange) {
        InterestRateChange result = null;
        switch (interestRateChange.toUpperCase()) {
            case "SAME":
                result = InterestRateChange.SAME;
                break;
            case "LOWER":
                result = InterestRateChange.LOWER;
                break;
            case "HIGHER":
                result = InterestRateChange.HIGHER;
                break;
        }
        return result;
    }

    private String formatPreviousProduct(String productDescription, BigDecimal interestRate) {
        return productDescription + " at " + interestRate + "%";
    }

    private boolean isLoanSelectedToTransfer(OActiveLoanDetail oActiveLoanDetail, LoanIdentifier loanIdentifier) {
        return loanIdentifier.getLoanScheme().equalsIgnoreCase(oActiveLoanDetail.getOLoanScheme()) &&
                loanIdentifier.getSequenceNumber() == oActiveLoanDetail.getOApplSeqNo();
    }

    private BigDecimal convertToBigDecimal(String oErcAllowPercentage) {
        var percentageRemoved = oErcAllowPercentage.replace("%", "");
        BigDecimal ercAllowance;
        try {
            ercAllowance = new BigDecimal(percentageRemoved);
        } catch (NumberFormatException nfe) {
            ercAllowance = new BigDecimal("0.00");
        }
        return ercAllowance.setScale(2, HALF_UP);
    }
}

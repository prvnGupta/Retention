package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve.RetrieveOfferResponse;
import com.santanderuk.corinthian.services.retentions.api.model.esis.RetrieveEsisResponse;
import org.springframework.stereotype.Component;

@Component
public class OfferResponseMapper {

    public RetrieveOfferResponse mapToResponse(OfferInfoResponse offerInfoResponse, RetrieveEsisResponse esisResponse) {
        RetrieveOfferResponse offerResponse = new RetrieveOfferResponse();
        offerResponse.setPdfString(esisResponse.getOutput().getValue());
        if(null != offerInfoResponse.getData().getOfferDownloadedDateTime()) {
            offerResponse.setDownloaded(true);
        }
        return offerResponse;
    }
}

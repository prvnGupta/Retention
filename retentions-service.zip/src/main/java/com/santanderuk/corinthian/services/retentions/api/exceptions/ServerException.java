package com.santanderuk.corinthian.services.retentions.api.exceptions;

import lombok.Getter;

@Getter
public class ServerException extends RuntimeException {

    private String code;

    public ServerException(String code, String msg){
        super(msg);
        this.code = code;
    }
}

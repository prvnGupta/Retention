package com.santanderuk.corinthian.services.retentions.api.rules.account;

import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.springframework.stereotype.Component;


@Component
public class FinancialDifficulties implements ODMEligibilityRule {

    @Override
    public void isEligible(EligibilityResponse eligibilityResponse, OdmEligibilityResponse odmEligibilityResponse) {

        if (odmEligibilityResponse.getAccountResponse().getAccountBand().equalsIgnoreCase("W")) {
            eligibilityResponse.getBlockers().setFinancialDifficulties(true);
        }

    }
}

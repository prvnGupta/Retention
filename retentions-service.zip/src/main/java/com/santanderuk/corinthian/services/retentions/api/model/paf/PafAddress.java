package com.santanderuk.corinthian.services.retentions.api.model.paf;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PafAddress {

    private String homeCountry;
}

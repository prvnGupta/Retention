
package com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info;

import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateOfferInfoResponse extends ModelBase {

    private ServiceInfo info;
}

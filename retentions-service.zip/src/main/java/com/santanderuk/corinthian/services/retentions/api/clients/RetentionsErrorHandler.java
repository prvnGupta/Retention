package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.retentions.api.exceptions.FieldValidationException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.ServerException;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.stream.Collectors;

public class RetentionsErrorHandler implements ResponseErrorHandler {

    @Override
    public boolean hasError(ClientHttpResponse clientHttpResponse) throws IOException {
        HttpStatus statusCode = clientHttpResponse.getStatusCode();
        return statusCode.series() == HttpStatus.Series.SERVER_ERROR || statusCode.series() == HttpStatus.Series.CLIENT_ERROR;
    }

    @Override
    public void handleError(ClientHttpResponse clientHttpResponse) throws IOException {

        if (clientHttpResponse.getStatusCode().is5xxServerError()) {
            throw new ServerException("CORE_RETENTIONS_UNAVAILABLE", "Core retentions in unavailable");
        }

        if (clientHttpResponse.getStatusCode().is4xxClientError()) {
            String body = convert(clientHttpResponse.getBody(), Charset.defaultCharset());

            throw new FieldValidationException(body);
        }
    }

    private String convert(InputStream inputStream, Charset charset) throws IOException {

        try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, charset))) {
            return br.lines().collect(Collectors.joining(System.lineSeparator()));
        }
    }
}

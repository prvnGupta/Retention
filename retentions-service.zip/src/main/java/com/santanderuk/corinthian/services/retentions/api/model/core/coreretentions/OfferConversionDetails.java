package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
public class OfferConversionDetails {
    private boolean multiConversionDateIndicator;
    private boolean conversionFromCCAFlexiIndicator;
    private boolean conversionFromUnitaryFlexiIndicator;
    private boolean splitLoanIndicator;


    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}

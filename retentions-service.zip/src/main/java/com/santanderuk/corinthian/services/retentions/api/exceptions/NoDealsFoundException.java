package com.santanderuk.corinthian.services.retentions.api.exceptions;

public class NoDealsFoundException extends RuntimeException {

    public NoDealsFoundException(String message) {
        super(message);
    }
}

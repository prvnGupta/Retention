package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.math.BigDecimal;

@Getter
@Setter

public class ODMLoanRequest {
    @JsonProperty("loanID")
    private String loanID;
    @JsonProperty("loanBalance")
    private BigDecimal loanBalance;
    @JsonProperty("isOnReversionRate")
    private String isOnReversionRate;
    @JsonProperty("remainingTerm")
    private Integer remainingTerm;
    @JsonProperty("rollOffDate")
    private String rollOffDate;

    public String toString() {
        return (new ToStringBuilder(this, ToStringStyle.JSON_STYLE))
                .append("loanID", this.loanID)
                .append("loanBalance", this.loanBalance)
                .append("isOnReversionRate", this.isOnReversionRate)
                .append("remainingTerm", this.remainingTerm)
                .append("rollOffDate", this.rollOffDate)
                .toString();
    }
}

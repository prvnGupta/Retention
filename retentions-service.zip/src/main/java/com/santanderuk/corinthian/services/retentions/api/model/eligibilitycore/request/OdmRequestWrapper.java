package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OdmRequestWrapper {

    @JsonProperty("accountRequest")
    private OdmRequest odmRequest;

    public String toString() {
        return (new ToStringBuilder(this, ToStringStyle.JSON_STYLE))
                .append("accountRequest", this.odmRequest)
                .toString();
    }

    public String masked() {
        return (new ToStringBuilder(this, ToStringStyle.JSON_STYLE))
                .append("accountRequest", this.odmRequest.masked())
                .toString();
    }
}

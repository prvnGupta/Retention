package com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class DealsPdfAnmfDataFetcherTest {

    DealsPdfAnmfDataFetcher fetcher;

    @Mock
    AnmfCoreClient anmfCoreClient;

    @Mock
    AnmfConfiguration configuration;

    @Mock
    HeartBeatClient heartBeatClient;

    @BeforeEach
    void setUp() throws MaintenanceException, ConnectionException {
        mockRegion();
        mockConfiguration();
        mockFetchAddress();
        fetcher = new DealsPdfAnmfDataFetcher(anmfCoreClient, configuration, heartBeatClient);
    }

    @Test
    void callingAccountDetailsServiceFromCommons() throws MaintenanceException, ConnectionException {

        var accountServiceResponse = mockAccountService();

        var account = 12345678;
        var output = fetcher.fetch(account);

        verify(anmfCoreClient, times(1)).fetchMortgageAccountDetailsV5(anyInt(), anyString(), any());

        // Check we are sending to the fetchAddress the proper parameters
        var accountCaptor = ArgumentCaptor.forClass(Integer.class);
        var urlCaptor = ArgumentCaptor.forClass(String.class);
        var regionCaptor = ArgumentCaptor.forClass(AnmfRegion.class);

        verify(anmfCoreClient).fetchMortgageAccountDetailsV5(accountCaptor.capture(), urlCaptor.capture(), regionCaptor.capture());

        assertEquals(12345678, accountCaptor.getValue());
        assertEquals("http://account-service-url.corp", urlCaptor.getValue());
        assertEquals(AnmfRegion.A, regionCaptor.getValue());

        // Check the object returned from accountService is the same we added in the output
        assertEquals(accountServiceResponse, output.getAnmfAccountServiceResponse());

    }

    private AnmfAccountServiceResponse mockAccountService() throws ConnectionException {
        var response = new AnmfAccountServiceResponse();
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(response);
        return response;
    }

    private ANMFPropertyResponse mockFetchAddress() throws ConnectionException {
        var anmfAddresResponse = new ANMFPropertyResponse();
        when(anmfCoreClient.fetchAddress(anyInt(), anyString(), any())).thenReturn(anmfAddresResponse);
        return anmfAddresResponse;
    }

    private void mockConfiguration() {
        when(configuration.getAnmfPropertyUrl()).thenReturn("http://property-url.corp");
        when(configuration.getAnmfAccountDetailsUrl()).thenReturn("http://account-service-url.corp");
    }

    private void mockRegion() throws MaintenanceException, ConnectionException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
    }
}

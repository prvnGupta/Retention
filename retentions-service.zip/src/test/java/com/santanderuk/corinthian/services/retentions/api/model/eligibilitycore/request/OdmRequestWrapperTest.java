package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class OdmRequestWrapperTest extends OdmRequestTestBase {
    @Test
    public void testIsBeingMaskedWithPopulate() throws JsonProcessingException {

     //The test cases was failing due to strictly order check of json fields.
     //have added readTree method that compare irrespective of json fields order

        ObjectMapper mapper = new ObjectMapper();
        OdmRequestWrapper odmRequestWrapper = createOdmRequestWrapper();

        String expected = "{\n" +
                "    \"accountRequest\": {\n" +
                "        \"channelID\": \"channelID\",\n" +
                "        \"accountNumber\": \"POPULATED\",\n" +
                "        \"accountNumberType\": \"accountNumberType\",\n" +
                "        \"accountBalance\": 0.00,\n" +
                "        \"isBuyToLet\": \"isBuyToLet\",\n" +
                "        \"isConsentToLet\": \"isConsentToLet\",\n" +
                "        \"isFlexi\": \"isFlexi\",\n" +
                "        \"riskLevel\": \"riskLevel\",\n" +
                "        \"customerNumber\": \"POPULATED\",\n" +
                "        \"postCode\": \"POPULATED\",\n" +
                "        \"chargeEndDate\": \"chargeEndDate\",\n" +
                "        \"completionDate\": \"completionDate\",\n" +
                "        \"loanRequest\": [{\n" +
                "            \"loanID\": \"1\",\n" +
                "            \"loanBalance\": 0.00,\n" +
                "            \"isOnReversionRate\": \"N\",\n" +
                "            \"remainingTerm\": 1,\n" +
                "            \"rollOffDate\": \"20/08/2025\"\n" +
                "        }],\n" +
                "        \"ltvio\": 0.00,\n" +
                "        \"ltvgeneral\": 0.00\n" +
                "    }\n" +
                "}";
        expected = expected.replaceAll("[\r\n ]", "");
        assertEquals(mapper.readTree(expected), mapper.readTree(odmRequestWrapper.masked()));
    }

    @Test
    public void testIsBeingMaskedWithEMPTY() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        OdmRequestWrapper odmRequestWrapper = createOdmRequestWrapper();
        odmRequestWrapper.getOdmRequest().setAccountNumber("");
        odmRequestWrapper.getOdmRequest().setCustomerNumber("");
        odmRequestWrapper.getOdmRequest().setPostCode("");

        String expected = "{\n" +
                "    \"accountRequest\": {\n" +
                "        \"channelID\": \"channelID\",\n" +
                "        \"accountNumber\": \"EMPTY\",\n" +
                "        \"accountNumberType\": \"accountNumberType\",\n" +
                "        \"accountBalance\": 0.00,\n" +
                "        \"isBuyToLet\": \"isBuyToLet\",\n" +
                "        \"isConsentToLet\": \"isConsentToLet\",\n" +
                "        \"isFlexi\": \"isFlexi\",\n" +
                "        \"riskLevel\": \"riskLevel\",\n" +
                "        \"customerNumber\": \"EMPTY\",\n" +
                "        \"postCode\": \"EMPTY\",\n" +
                "        \"chargeEndDate\": \"chargeEndDate\",\n" +
                "        \"completionDate\": \"completionDate\",\n" +
                "        \"loanRequest\": [{\n" +
                "            \"loanID\": \"1\",\n" +
                "            \"loanBalance\": 0.00,\n" +
                "            \"isOnReversionRate\": \"N\",\n" +
                "            \"remainingTerm\": 1,\n" +
                "            \"rollOffDate\": \"20/08/2025\"\n" +
                "        }],\n" +
                "        \"ltvio\": 0.00,\n" +
                "        \"ltvgeneral\": 0.00\n" +
                "    }\n" +
                "}";
        expected = expected.replaceAll("[\r\n ]", "");
        assertEquals(mapper.readTree(expected), mapper.readTree(odmRequestWrapper.masked()));
    }

    @Test
    public void testIsBeingMaskedWithNull() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        OdmRequestWrapper odmRequestWrapper = createOdmRequestWrapper();
        odmRequestWrapper.getOdmRequest().setAccountNumber(null);
        odmRequestWrapper.getOdmRequest().setCustomerNumber(null);
        odmRequestWrapper.getOdmRequest().setPostCode(null);

        String expected = "{\n" +
                "    \"accountRequest\": {\n" +
                "        \"channelID\": \"channelID\",\n" +
                "        \"accountNumber\": \"NULL\",\n" +
                "        \"accountNumberType\": \"accountNumberType\",\n" +
                "        \"accountBalance\": 0.00,\n" +
                "        \"isBuyToLet\": \"isBuyToLet\",\n" +
                "        \"isConsentToLet\": \"isConsentToLet\",\n" +
                "        \"isFlexi\": \"isFlexi\",\n" +
                "        \"riskLevel\": \"riskLevel\",\n" +
                "        \"customerNumber\": \"NULL\",\n" +
                "        \"postCode\": \"NULL\",\n" +
                "        \"chargeEndDate\": \"chargeEndDate\",\n" +
                "        \"completionDate\": \"completionDate\",\n" +
                "        \"loanRequest\": [{\n" +
                "            \"loanID\": \"1\",\n" +
                "            \"loanBalance\": 0.00,\n" +
                "            \"isOnReversionRate\": \"N\",\n" +
                "            \"remainingTerm\": 1,\n" +
                "            \"rollOffDate\": \"20/08/2025\"\n" +
                "        }],\n" +
                "        \"ltvio\": 0.00,\n" +
                "        \"ltvgeneral\": 0.00\n" +
                "    }\n" +
                "}";
        expected = expected.replaceAll("[\r\n ]", "");
      assertEquals(mapper.readTree(expected), mapper.readTree(odmRequestWrapper.masked()));
    }

}

package com.santanderuk.corinthian.services.retentions;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.support.NoOpCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({"test", "operativeSec"})
public class CorinthianRedisCacheConfigurationForTestProfile extends CachingConfigurerSupport {

    @Bean
    @Primary
    public CacheManager cacheManagerShortLife() {
        return new NoOpCacheManager();
    }

    @Bean
    public CacheManager cacheManagerLongLife() {
        return new NoOpCacheManager();
    }

}

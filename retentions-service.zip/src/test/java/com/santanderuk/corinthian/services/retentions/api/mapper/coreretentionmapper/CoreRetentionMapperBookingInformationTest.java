package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


public class CoreRetentionMapperBookingInformationTest extends CoreRetentionMapperTestBase {


    @Test
    public void testOneLoan() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getBookingInformation());

        assertEquals("Existing Borrower", coreRetentionRequest.getBookingInformation().getBusinessCircumstanceCode());
        assertEquals("Introduced", coreRetentionRequest.getBookingInformation().getBusinessSource());
        assertEquals(new BigDecimal("1.00"), coreRetentionRequest.getBookingInformation().getTotalBookingAmount());
        assertEquals("Confirmed", coreRetentionRequest.getBookingInformation().getBookingStatus());
        assertEquals("Yes", coreRetentionRequest.getBookingInformation().getApplicationFormReceived());
        assertEquals(0, coreRetentionRequest.getBookingInformation().getBranchID());
        assertEquals("Contact Centre", coreRetentionRequest.getBookingInformation().getBusinessGroup());
    }

    @Test
    public void mapBookingInformationBookingAmountTwoLoan() {

        CoreRetentionsData input = generateDefaultMapperInput();
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        // Add second loan - first one is cap balance 1.11
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOLoanScheme("3T");
        oLoans.get(1).setOApplSeqNo(2);
        oLoans.get(1).setOCapitalBalance(new BigDecimal("10.00"));

        // Add second selected loan
        LoanIdentifier selectedLoan = new LoanIdentifier();
        selectedLoan.setLoanScheme("3T");
        selectedLoan.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(selectedLoan);


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("11.00"), coreRetentionRequest.getBookingInformation().getTotalBookingAmount());

    }

    @Test
    public void mapBookingInformationBookingAmountThreeLoan() {

        CoreRetentionsData input = generateDefaultMapperInput();
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        // Add second loan - first one is cap balance 1.11
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOLoanScheme("3T");
        oLoans.get(1).setOApplSeqNo(2);
        oLoans.get(1).setOCapitalBalance(new BigDecimal("10.00"));

        // Add third loan
        oLoans.add(generateDefaultLoan());
        oLoans.get(2).setOLoanScheme("3T");
        oLoans.get(2).setOApplSeqNo(3);
        oLoans.get(2).setOCapitalBalance(new BigDecimal("100.00"));

        // Add second selected loan
        LoanIdentifier selectedLoan2 = new LoanIdentifier();
        selectedLoan2.setLoanScheme("3T");
        selectedLoan2.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(selectedLoan2);

        // Add third selected loan
        LoanIdentifier selectedLoan3 = new LoanIdentifier();
        selectedLoan3.setLoanScheme("3T");
        selectedLoan3.setSequenceNumber(3);
        input.getCaseRequest().getLoansSelected().add(selectedLoan3);


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("111.00"), coreRetentionRequest.getBookingInformation().getTotalBookingAmount());

    }

    @Test
    public void mapBookingInformationBookingAmountThreeLoansInANMFButOnlyTwoSelected() {

        CoreRetentionsData input = generateDefaultMapperInput();
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        // Add second loan - first one is cap balance 1.11
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOLoanScheme("3T");
        oLoans.get(1).setOApplSeqNo(2);
        oLoans.get(1).setOCapitalBalance(new BigDecimal("10.00"));

        // Add third loan
        oLoans.add(generateDefaultLoan());
        oLoans.get(2).setOLoanScheme("3T");
        oLoans.get(2).setOApplSeqNo(3);
        oLoans.get(2).setOCapitalBalance(new BigDecimal("100.00"));

        // Add second selected loan
        LoanIdentifier selectedLoan2 = new LoanIdentifier();
        selectedLoan2.setLoanScheme("3T");
        selectedLoan2.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(selectedLoan2);


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("11.00"), coreRetentionRequest.getBookingInformation().getTotalBookingAmount());

    }
}

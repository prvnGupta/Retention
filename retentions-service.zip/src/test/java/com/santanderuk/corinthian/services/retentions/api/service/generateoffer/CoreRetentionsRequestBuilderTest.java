package com.santanderuk.corinthian.services.retentions.api.service.generateoffer;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionMapperTestBase;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.service.deals.DealsService;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import com.santanderuk.corinthian.services.retentions.api.validation.CreateCaseFunctionalValidation;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CoreRetentionsRequestBuilderTest extends CoreRetentionMapperTestBase {


    @Mock
    private CreateCaseFunctionalValidation functionalValidation;

    @Mock
    private CacheableOperations cacheableOperations;

    @Mock
    private AnmfCoreClient anmfCoreClient;

    @Mock
    private AnmfConfiguration anmfConfiguration;

    @Mock
    private DealsService dealsService;

    private CoreRetentionsRequestBuilder requestBuilder;
    private CreateCaseRequest offerRequest;

    private static final int ACCOUNT_NUMBER = 12345;
    private static final String TOKEN = "token";

    @BeforeEach
    public void setUp() throws Exception {

        requestBuilder = new CoreRetentionsRequestBuilder(functionalValidation, cacheableOperations, anmfCoreClient, anmfConfiguration, dealsService);

        offerRequest = genericOfferRequest();
        DealsResponse dealsResponse = generateDefaultDealsResponse();
        Mockito.when(dealsService.get(anyInt(), any(), anyString())).thenReturn(dealsResponse);
    }


    @Test
    void testWeCallNewDealsServicesCorrectly() throws DealsFunctionalValidationException, MaintenanceException, OperativeSecurityException, MortgageDealsClientException, ConnectionException, ReportedException, ValidationsException {

        requestBuilder.buildCoreRetentionsRequest(ACCOUNT_NUMBER, offerRequest, TOKEN);

        verify(dealsService, times(1)).get(anyInt(), any(), anyString());

        var accountCaptor = ArgumentCaptor.forClass(Integer.class);
        var dealsRequestArgumentCaptor = ArgumentCaptor.forClass(DealsRequest.class);
        var tokenCaptor = ArgumentCaptor.forClass(String.class);


        verify(dealsService).get(accountCaptor.capture(), dealsRequestArgumentCaptor.capture(), tokenCaptor.capture());

        assertEquals(ACCOUNT_NUMBER, accountCaptor.getValue());
        assertEquals("3T", dealsRequestArgumentCaptor.getValue().getLoansSelected().get(0).getLoanScheme());
        assertEquals(1, dealsRequestArgumentCaptor.getValue().getLoansSelected().get(0).getSequenceNumber());
        assertEquals(TOKEN, tokenCaptor.getValue());

    }

    @Test
    public void feeShouldNotBeAddedWhenPayingUpFront() throws GeneralException {

        offerRequest.setFeeAddedInMortgage(false);
        CoreRetentionsData coreRetentionsData = requestBuilder.buildCoreRetentionsRequest(ACCOUNT_NUMBER, offerRequest, TOKEN);


        assertFalse(coreRetentionsData.getSelectedDeal().getDealLoans().get(0).isApplyFeeInThisLoan());
        assertFalse(coreRetentionsData.getSelectedDeal().getDealLoans().get(1).isApplyFeeInThisLoan());
        assertEquals(2, coreRetentionsData.getSelectedDeal().getLoanToApplyTheFeeTo());
    }


    @Test
    public void testWeCallFunctionalValidations() throws GeneralException {

        requestBuilder.buildCoreRetentionsRequest(ACCOUNT_NUMBER, offerRequest, TOKEN);

        verify(functionalValidation, times(1)).validate(any());
    }

    @Test
    public void testWeCallCacheableOperations() throws GeneralException {

        requestBuilder.buildCoreRetentionsRequest(ACCOUNT_NUMBER, offerRequest, TOKEN);

        verify(cacheableOperations, times(1)).getAnmfActiveRegion();
    }

    @Test
    public void testWeCallANMFClientMethodsCorrectly() throws GeneralException {

        requestBuilder.buildCoreRetentionsRequest(ACCOUNT_NUMBER, offerRequest, TOKEN);

        verify(anmfCoreClient, times(1)).fetchMortgageAccountDetailsV5(ACCOUNT_NUMBER, anmfConfiguration.getAnmfAccountDetailsUrl(), null);
        verify(anmfCoreClient, times(1)).fetchMortgageCustomerDetailsV4(ACCOUNT_NUMBER, anmfConfiguration.getAnmfCustomerServiceUrl(), null);
        verify(anmfCoreClient, times(1)).fetchAddress(ACCOUNT_NUMBER, anmfConfiguration.getAnmfPropertyUrl(), null);
    }

    private DealsResponse generateDefaultDealsResponse() {
        DealsResponse dealsResponse = new DealsResponse();

        List<Deal> dealsList = new ArrayList<>();
        dealsList.add(generateDefaultDeal());
        dealsList.add(generateDefaultDeal());

        dealsResponse.setDeals(dealsList);
        return dealsResponse;
    }
}

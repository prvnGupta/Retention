package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.exceptions.PaymentsException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.ServerException;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.PaymentsInternalTransferRequest;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class InternalTransferClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private InternalTransferConfig mockInternalTransferConfig;

    InternalTransferClient internalTransferClient;

    @BeforeEach
    public void setUp() {
        when(mockInternalTransferConfig.getPaymentServiceEndpoint()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/intrenalTransfer");
        internalTransferClient = new InternalTransferClient(restTemplate, mockInternalTransferConfig);
    }


    @Test
    public void testWeReturnCorrectResponseForMakePayment() throws PaymentsException {
        ResponseEntity<AcceptAndPayInSessionResponseWrapper> mockResponse = generateDefaultAcceptResponse();

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AcceptAndPayInSessionResponseWrapper.class))).thenReturn(mockResponse);

        AcceptAndPayInSessionResponseWrapper response = internalTransferClient.makeInternalTransfer(new PaymentsInternalTransferRequest());

        assertThat(response.getInfo().getStatus(), equalTo("ok"));
        assertThat(response.getInfo().getMessage(), equalTo("Data found"));
    }

    @Test
    public void testToCheckPaymentsExceptionOnRestExceptionKO() throws PaymentsException {
        when(restTemplate.postForEntity(anyString(), any(), eq(AcceptAndPayInSessionResponseWrapper.class)))
                .thenThrow(RestClientException.class);
        assertThrows(PaymentsException.class, () -> internalTransferClient.makeInternalTransfer(new PaymentsInternalTransferRequest()));
    }

    @Test
    public void testToCheckPaymentsExceptionOnServerExceptionKO() throws PaymentsException {
        when(restTemplate.postForEntity(anyString(), any(), eq(AcceptAndPayInSessionResponseWrapper.class)))
                .thenThrow(ServerException.class);
        assertThrows(PaymentsException.class, () -> internalTransferClient.makeInternalTransfer(new PaymentsInternalTransferRequest()));
    }

    private ResponseEntity<AcceptAndPayInSessionResponseWrapper> generateDefaultAcceptResponse() {
        AcceptAndPayInSessionResponseWrapper response = new AcceptAndPayInSessionResponseWrapper();
        response.setInfo(ServiceInfoCreator.ok());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}

package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.retentions.FixtureReader;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.MortgageDealsClientResponse;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MapperSourceData;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Calculations;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class MortgageDealsClientResponseMapperTest {

    @Mock
    CalculationsMapper calculationsMapper;
    @Mock
    MortgageDealsProductToAggregationResponseProductMapper mortgageDealsProductToAggregationResponseProductMapper;
    @Mock
    LoansToDealsMapper mockLoansToDealsMapper;

    MortgageDealsClientResponseMapper mapper;

    public static MortgageDealsClientResponse loanMortgageDealsFixture(String filename) throws IOException {
        return FixtureReader.get(filename, MortgageDealsClientResponse.class);
    }

    @BeforeEach
    void setUp() {
        mockCalculationsMapper();
        mockProductMapper();
        mockLoansToDealsMapper();
        mapper = new MortgageDealsClientResponseMapper(calculationsMapper, mortgageDealsProductToAggregationResponseProductMapper, mockLoansToDealsMapper);
    }

    @Test
    void checkCalculationsMapperResponseIsBeingAddedToTheDeal() throws IOException {

        var mockedCalculations = mockCalculationsMapper();

        var clientOutput = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");
        var clientRequest = new MortgageDealsClientRequest();
        var mapped = mapper.map(clientOutput, clientRequest, new MapperSourceData());

        assertNotNull(mapped);
        assertNotNull(mapped.getDeals().get(0).getCalculations());

        assertEquals(mockedCalculations, mapped.getDeals().get(0).getCalculations());
        assertEquals(2, mapped.getDeals().get(0).getLoanToApplyTheFeeTo());
        assertFalse(mapped.isStepErcActive());
    }

    @Test
    void checkProductMapperResponseIsBeingAddedToTheDeal() throws IOException {

        var mockedProduct = mockProductMapper();

        var clientOutput = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");
        var clientRequest = new MortgageDealsClientRequest();
        var mapped = mapper.map(clientOutput, clientRequest, new MapperSourceData());

        assertNotNull(mapped);
        assertNotNull(mapped.getDeals().get(0).getProduct());

        assertEquals(mockedProduct, mapped.getDeals().get(0).getProduct());
        assertFalse(mapped.isStepErcActive());
    }

    @Test
    void checkLoansToDealsMapperResponseIsBeingAddedToTheDeal() throws IOException {

        var mockedLoansToDeals = mockLoansToDealsMapper();

        var clientOutput = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");
        var clientRequest = new MortgageDealsClientRequest();
        var mapped = mapper.map(clientOutput, clientRequest, new MapperSourceData());

        assertNotNull(mapped);
        assertNotNull(mapped.getDeals().get(0).getProduct());

        assertEquals(mockedLoansToDeals, mapped.getDeals().get(0).getDealLoans());
        assertFalse(mapped.isStepErcActive());
    }

    @Test
    void checkStepErcFlagActive() throws IOException {
        when(mortgageDealsProductToAggregationResponseProductMapper.map(any(), any())).thenReturn(createProductWithSteppedErc());

        var clientOutput = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");
        var clientRequest = new MortgageDealsClientRequest();
        var mapped = mapper.map(clientOutput, clientRequest, new MapperSourceData());

        assertTrue(mapped.isStepErcActive());
    }

    private Product createProductWithTermInMonths(int termInMonths) {
        var product = new Product();
        product.setTermInMonths(termInMonths);
        return product;
    }

    private Product createProductWithSteppedErc() {
        var product = new Product();
        product.setStepErc(true);
        return product;
    }

    private Calculations mockCalculationsMapper() {
        var calculations = new Calculations();
        when(calculationsMapper.map(any())).thenReturn(calculations);
        return calculations;
    }

    private Product mockProductMapper() {
        var product = new Product();
        when(mortgageDealsProductToAggregationResponseProductMapper.map(any(), any())).thenReturn(product);
        return product;
    }

    private List<DealLoanView> mockLoansToDealsMapper() {
        ArrayList<DealLoanView> loanArrayList = new ArrayList<>();
        when(mockLoansToDealsMapper.map(any(), any())).thenReturn(loanArrayList);
        return loanArrayList;
    }
}

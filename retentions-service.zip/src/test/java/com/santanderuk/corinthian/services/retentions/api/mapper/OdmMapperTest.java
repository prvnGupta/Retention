package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.commons.clients.productdirectory.ProductDirectoryResponse;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.ReportedException;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Property;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.OdmRequest;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request.OdmRequestWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.riskvaluation.RiskValuationCoreResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static java.math.RoundingMode.HALF_UP;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class OdmMapperTest {

    ODMMapper mapper;


    @BeforeEach
    public void setUp() {
        mapper = new ODMMapper();
    }

    @Test
    public void testWeBuildODMRequestCorrectly() throws GeneralException {

        Loan ioLoan = new Loan();
        ioLoan.setLoanId(1);
        ioLoan.setLoanType("I");
        ioLoan.setLoanBalance(new BigDecimal(100000).setScale(2, HALF_UP));
        ioLoan.setRemainingTerm(65);
        ioLoan.setProductEndDate("01/04/2023");
        ioLoan.setOnReversionRate(false);
        ioLoan.setProductDescription("Interest Only Product");

        Loan repaymentLoan = new Loan();
        repaymentLoan.setLoanId(2);
        repaymentLoan.setLoanType("R");
        repaymentLoan.setLoanBalance(new BigDecimal(400000).setScale(2, HALF_UP));
        repaymentLoan.setRemainingTerm(40);
        repaymentLoan.setProductEndDate("01/04/2023");
        repaymentLoan.setOnReversionRate(false);
        repaymentLoan.setProductDescription("Repayment");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(true)
                .withConsentToLet(true)
                .withLoan(ioLoan)
                .withLoan(repaymentLoan)
                .withProperty(new Property("MK5 7LA"))
                .withFlexiIndicator("Y").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(500000);
        riskValuationCoreResponse.setRiskLevel("5");

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        OdmRequestWrapper odmRequestWrapper = mapper.toOdm(1234567, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse);
        OdmRequest odmRequest = odmRequestWrapper.getOdmRequest();

        assertThat(odmRequest.getLtvio(), equalTo(new BigDecimal("20.00").setScale(2, HALF_UP)));
        assertThat(odmRequest.getLtvgeneral(), equalTo(new BigDecimal("100.00").setScale(2, HALF_UP)));
        assertThat(odmRequest.getRiskLevel(), equalTo("5"));
        assertThat(odmRequest.getIsBuyToLet(), equalTo("Y"));
        assertThat(odmRequest.getIsConsentToLet(), equalTo("Y"));
        assertThat(odmRequest.getIsFlexi(), equalTo("Y"));
        assertThat(odmRequest.getPostCode(), equalTo("MK5 7LA"));
        assertThat(odmRequest.getLoanRequest().get(0).getRemainingTerm(), equalTo(65));
        assertThat(odmRequest.getLoanRequest().get(0).getLoanID(), equalTo("1"));
        assertThat(odmRequest.getLoanRequest().get(0).getRollOffDate(), equalTo("2023-04-01"));
        assertThat(odmRequest.getLoanRequest().get(1).getRemainingTerm(), equalTo(40));
        assertThat(odmRequest.getLoanRequest().get(1).getLoanID(), equalTo("2"));
        assertThat(odmRequest.getLoanRequest().get(1).getRollOffDate(), equalTo("2023-04-01"));
        assertThat(odmRequest.getChargeEndDate(), equalTo("2021-01-01"));
        assertThat(odmRequest.getCompletionDate(), equalTo("2018-07-05"));
    }

    @Test
    public void testLTVGeneral() throws GeneralException {

        Loan repaymentLoan = new Loan();
        repaymentLoan.setLoanId(2);
        repaymentLoan.setLoanType("R");
        repaymentLoan.setLoanBalance(new BigDecimal("207619.00").setScale(2, HALF_UP));
        repaymentLoan.setRemainingTerm(40);
        repaymentLoan.setProductEndDate("01/04/2023");
        repaymentLoan.setOnReversionRate(false);
        repaymentLoan.setProductDescription("Repayment");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(true)
                .withConsentToLet(true)
                .withLoan(repaymentLoan)
                .withProperty(new Property("MK5 7LA"))
                .withFlexiIndicator("Y").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(342870);
        riskValuationCoreResponse.setRiskLevel("1");

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        OdmRequestWrapper odmRequestWrapper = mapper.toOdm(1234567, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse);
        OdmRequest odmRequest = odmRequestWrapper.getOdmRequest();

        assertThat(odmRequest.getLtvgeneral(), equalTo(new BigDecimal("60.55").setScale(2, HALF_UP)));

    }

    @Test
    public void testWeMapCorrectly() throws ReportedException {

        Loan ioLoan = new Loan();
        ioLoan.setLoanId(1);
        ioLoan.setLoanType("I");
        ioLoan.setLoanBalance(new BigDecimal("0.00").setScale(2, HALF_UP));
        ioLoan.setRemainingTerm(null);
        ioLoan.setProductEndDate("01/04/2023");
        ioLoan.setOnReversionRate(false);
        ioLoan.setProductDescription("Interest Only Product");

        Loan repaymentLoan = new Loan();
        repaymentLoan.setLoanId(2);
        repaymentLoan.setLoanType("R");
        repaymentLoan.setLoanBalance(new BigDecimal("639264.76").setScale(2, HALF_UP));
        repaymentLoan.setRemainingTerm(62);
        repaymentLoan.setProductEndDate("01/04/2023");
        repaymentLoan.setOnReversionRate(false);
        repaymentLoan.setProductDescription("Repayment");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(false)
                .withConsentToLet(false)
                .withLoan(ioLoan)
                .withLoan(repaymentLoan)
                .withProperty(new Property("MK5 7LA"))
                .withFlexiIndicator("").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(500000);

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        OdmRequestWrapper odmRequestWrapper = mapper.toOdm(123423, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse);

        OdmRequest odmRequest = odmRequestWrapper.getOdmRequest();
        assertThat(odmRequest.getLtvio(), equalTo(new BigDecimal("0.00").setScale(2, HALF_UP)));
        assertThat(odmRequest.getIsBuyToLet(), equalTo("N"));
        assertThat(odmRequest.getIsConsentToLet(), equalTo("N"));
        assertThat(odmRequest.getIsFlexi(), equalTo("N"));
        assertThat(odmRequest.getPostCode(), equalTo("MK5 7LA"));
        assertThat(odmRequest.getLoanRequest().get(0).getRemainingTerm(), equalTo(null));
        assertThat(odmRequest.getLoanRequest().get(0).getLoanID(), equalTo("1"));
        assertThat(odmRequest.getLoanRequest().get(1).getRemainingTerm(), equalTo(62));
        assertThat(odmRequest.getLoanRequest().get(1).getLoanID(), equalTo("2"));
        assertThat(odmRequest.getChargeEndDate(), equalTo("2021-01-01"));
        assertThat(odmRequest.getCompletionDate(), equalTo("2018-07-05"));
    }

    @Test
    public void testWeHandleInvalidDateFormat() {

        Loan ioLoan = new Loan();
        ioLoan.setLoanId(1);
        ioLoan.setLoanType("I");
        ioLoan.setLoanBalance(new BigDecimal("456789.45").setScale(2, HALF_UP));
        ioLoan.setRemainingTerm(40);
        ioLoan.setProductEndDate("hjefrkhdskj");
        ioLoan.setOnReversionRate(false);
        ioLoan.setProductDescription("Interest Only Product");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(true)
                .withConsentToLet(true)
                .withLoan(ioLoan)
                .withFlexiIndicator("Y").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(500000);

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        assertThrows(GeneralException.class, () -> mapper.toOdm(237489, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse));
    }

    @Test
    public void testWeSendTheCorrectChargeEndDateToOdm() throws GeneralException {

        Loan ioLoan = new Loan();
        ioLoan.setLoanId(1);
        ioLoan.setLoanType("I");
        ioLoan.setLoanBalance(new BigDecimal("456789.45").setScale(2, HALF_UP));
        ioLoan.setRemainingTerm(65);
        ioLoan.setProductEndDate("01/04/2023");
        ioLoan.setOnReversionRate(false);
        ioLoan.setProductDescription("Interest Only Product");

        Loan repaymentLoan = new Loan();
        repaymentLoan.setLoanId(2);
        repaymentLoan.setLoanType("R");
        repaymentLoan.setLoanBalance(new BigDecimal("639264.76").setScale(2, HALF_UP));
        repaymentLoan.setRemainingTerm(49);
        repaymentLoan.setProductEndDate("01/04/2023");
        repaymentLoan.setOnReversionRate(false);
        repaymentLoan.setProductDescription("Repayment");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(true)
                .withConsentToLet(true)
                .withLoan(ioLoan)
                .withLoan(repaymentLoan)
                .withFlexiIndicator("Y").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(500000);
        riskValuationCoreResponse.setRiskLevel("5");

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        OdmRequestWrapper odmRequestWrapper = mapper.toOdm(1234567, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse);
        OdmRequest odmRequest = odmRequestWrapper.getOdmRequest();


        assertThat(odmRequest.getChargeEndDate(), equalTo("2021-01-01"));
    }

    @Test
    public void testWeSetLTVGeneralToEqualIOWhenAllLoanPartsAreIO() throws GeneralException {

        Loan ioLoan = new Loan();
        ioLoan.setLoanId(1);
        ioLoan.setLoanType("I");
        ioLoan.setLoanBalance(new BigDecimal("250000").setScale(2, HALF_UP));
        ioLoan.setRemainingTerm(40);
        ioLoan.setProductEndDate("01/04/2023");
        ioLoan.setOnReversionRate(false);
        ioLoan.setProductDescription("Interest Only Product");

        Loan repaymentLoan = new Loan();
        repaymentLoan.setLoanId(2);
        repaymentLoan.setLoanType("I");
        repaymentLoan.setLoanBalance(new BigDecimal("250000").setScale(2, HALF_UP));
        repaymentLoan.setRemainingTerm(40);
        repaymentLoan.setProductEndDate("01/04/2023");
        repaymentLoan.setOnReversionRate(false);
        repaymentLoan.setProductDescription("Repayment");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(true)
                .withConsentToLet(true)
                .withLoan(ioLoan)
                .withLoan(repaymentLoan)
                .withFlexiIndicator("Y").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(500000);
        riskValuationCoreResponse.setRiskLevel("5");

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        OdmRequestWrapper odmRequestWrapper = mapper.toOdm(1234567, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse);
        OdmRequest odmRequest = odmRequestWrapper.getOdmRequest();

        assertThat(odmRequest.getLtvio(), equalTo(new BigDecimal("100.00").setScale(2, HALF_UP)));
        assertThat(odmRequest.getLtvgeneral(), equalTo(new BigDecimal(100).setScale(2, HALF_UP)));


    }

    @Test
    public void testWesetRollOfDateToLoanEndDateWhenNotOnReversionRate() throws ReportedException {

        Loan ioLoan = new Loan();
        ioLoan.setLoanId(1);
        ioLoan.setLoanType("I");
        ioLoan.setLoanBalance(new BigDecimal("250000").setScale(2, HALF_UP));
        ioLoan.setRemainingTerm(40);
        ioLoan.setProductEndDate("");
        ioLoan.setOnReversionRate(true);
        ioLoan.setProductDescription("FLEXIBLE(Something else)");
        ioLoan.setLoanStartDate("01/04/2050");

        Loan repaymentLoan = new Loan();
        repaymentLoan.setLoanId(2);
        repaymentLoan.setLoanType("I");
        repaymentLoan.setLoanBalance(new BigDecimal("250000").setScale(2, HALF_UP));
        repaymentLoan.setRemainingTerm(40);
        repaymentLoan.setOnReversionRate(false);
        repaymentLoan.setProductDescription("gadhsgjkadhskfjh");
        repaymentLoan.setProductEndDate("01/04/2023");

        AnmfCoreResponseBuilder builder = new AnmfCoreResponseBuilder();

        AnmfCoreResponse anmfCoreResponse2 = builder
                .withBuyToLet(true)
                .withConsentToLet(true)
                .withLoan(ioLoan)
                .withLoan(repaymentLoan)
                .withFlexiIndicator("Y").build();

        RiskValuationCoreResponse riskValuationCoreResponse = new RiskValuationCoreResponse();
        riskValuationCoreResponse.setCalculatedValuation(500000);
        riskValuationCoreResponse.setRiskLevel("5");

        ProductDirectoryResponse productDirectoryResponse = new ProductDirectoryResponse();
        productDirectoryResponse.setFarthestCompletionDate("2018-07-05");
        productDirectoryResponse.setNearestChargeEndDate("2021-01-01");

        OdmRequestWrapper odmRequestWrapper = mapper.toOdm(1234567, anmfCoreResponse2, riskValuationCoreResponse, productDirectoryResponse);
        OdmRequest odmRequest = odmRequestWrapper.getOdmRequest();

        assertThat(odmRequest.getLtvio(), equalTo(new BigDecimal("100.00").setScale(2, HALF_UP)));
        assertThat(odmRequest.getLtvgeneral(), equalTo(new BigDecimal(100).setScale(2, HALF_UP)));
        assertThat(odmRequest.getLoanRequest().get(0).getRollOffDate(), equalTo("2050-04-01"));

    }

    @Test
    public void testLTVRatio() {

        BigDecimal loanAmount = new BigDecimal("300434.94");
        Integer propertyValue = 398785;
        BigDecimal ltv = mapper.calculateLtvRatio(loanAmount, propertyValue);

        assertThat(ltv, equalTo(new BigDecimal("75.34")));
    }

    private static class AnmfCoreResponseBuilder {

        private boolean buyToLet;
        private boolean consentToLet;
        private String flexiIndicator = "";
        private Property property = new Property("MK1 1AB");
        List<Loan> loans = new ArrayList<>();

        private final AnmfCoreResponse anmfCoreResponse;

        AnmfCoreResponseBuilder() {
            anmfCoreResponse = new AnmfCoreResponse();
        }

        public AnmfCoreResponse build() {
            anmfCoreResponse.setLoans(loans);
            anmfCoreResponse.setBuyToLet(buyToLet);
            anmfCoreResponse.setConsentToLet(consentToLet);
            anmfCoreResponse.setFlexiIndicator(flexiIndicator);
            anmfCoreResponse.setProperty(property);

            return anmfCoreResponse;
        }

        public AnmfCoreResponseBuilder withLoan(Loan loan) {
            this.loans.add(loan);
            return this;
        }

        public AnmfCoreResponseBuilder withConsentToLet(boolean consentToLet) {
            this.consentToLet = consentToLet;
            return this;
        }

        public AnmfCoreResponseBuilder withBuyToLet(boolean buyToLet) {
            this.buyToLet = buyToLet;
            return this;
        }

        public AnmfCoreResponseBuilder withFlexiIndicator(String flexiIndicator) {
            this.flexiIndicator = flexiIndicator;
            return this;
        }

        public AnmfCoreResponseBuilder withProperty(Property property) {
            this.property = property;
            return this;
        }

    }
}

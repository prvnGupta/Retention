package com.santanderuk.corinthian.services.retentions.api.controller.deals;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.service.deals.DealsService;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class DealsControllerTest {

    @Mock
    DealsService dealsService;

    DealsController dealsController;

    @BeforeEach
    void setUp() throws MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, OperativeSecurityException, ValidationsException {
        mockDealsService();
        dealsController = new DealsController(dealsService);
    }

    @Test
    void checkWeAreReturningTheObjectCreatedByTheDealsService() throws MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, OperativeSecurityException, ValidationsException {
        var dealsResponseMocked = mockDealsService();
        var responseEntity = dealsController.fetchDeals(new DealsRequest(), 123455678,  "jwt-token");

        assertNotNull(responseEntity);
        assertNotNull(responseEntity.getBody());

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("ok", responseEntity.getBody().getInfo().getStatus());
        assertEquals("", responseEntity.getBody().getInfo().getCode());
        assertEquals("Data found", responseEntity.getBody().getInfo().getMessage());

        assertSame(dealsResponseMocked, responseEntity.getBody().getResponse());
    }

    @Test
    void checkWeSendToTheServiceTheProperData() throws MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, OperativeSecurityException, ValidationsException {
        var account = 12345678;
        var dealsRequest = new DealsRequest();
        var jwtToken = "jwt-token";
        dealsController.fetchDeals(dealsRequest, account, jwtToken);

        var integerArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        var dealsRequestArgumentCaptor = ArgumentCaptor.forClass(DealsRequest.class);
        var jwtTokenCaptor = ArgumentCaptor.forClass(String.class);
        verify(dealsService).get(integerArgumentCaptor.capture(), dealsRequestArgumentCaptor.capture(), jwtTokenCaptor.capture());

        assertEquals(account, integerArgumentCaptor.getValue());
        assertSame(dealsRequest, dealsRequestArgumentCaptor.getValue());
        assertEquals(jwtToken, jwtTokenCaptor.getValue());
    }

    private DealsResponse mockDealsService() throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        var dealsResponseMocked = new DealsResponse();
        when(dealsService.get(anyInt(), any(), any())).thenReturn(dealsResponseMocked);
        return dealsResponseMocked;
    }
}

package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CoreRetentionMapperGeneralInformationTest extends CoreRetentionMapperTestBase {

    @Test
    public void test() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getGeneralInformation());

        assertEquals("INT", coreRetentionRequest.getGeneralInformation().getChannel());
        assertEquals("2822", coreRetentionRequest.getGeneralInformation().getCentre());
        assertEquals("0015", coreRetentionRequest.getGeneralInformation().getCompany());
        assertEquals("GBP", coreRetentionRequest.getGeneralInformation().getCurrency());
        assertEquals("0070", coreRetentionRequest.getGeneralInformation().getBusinessProcess());
        assertEquals("103", coreRetentionRequest.getGeneralInformation().getProductType());
        assertEquals("707", coreRetentionRequest.getGeneralInformation().getProductSubType());
        assertEquals("0000001", coreRetentionRequest.getGeneralInformation().getProductReference());
    }

}

package com.santanderuk.corinthian.services.retentions.functional.generateoffer;

import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.retentions.functional.FunctionalTest;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

@Slf4j
@ActiveProfiles("test")
public class GenerateOfferFunctionalTest extends FunctionalTest {

    private Header authorizationHeader;
    private Header contentType;
    private Header accept;
    private String offerGenerateEndpoint;

    @BeforeEach
    public void setUp() throws InterruptedException {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
        offerGenerateEndpoint = String.format("http://localhost:%s/retentions-service/%s/offer/generate", serverPort, ACCOUNT_NUMBER);
    }

    @Test
    public void testWeReturn200WithCorrectBodyFeePayedUpfront() {

       stubHappyPath();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-valid.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(200).
                body("response.offerId", equalTo("1E1B708E51B2414F818BC845CACF71C7"),
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Offer generated"));
    }


    @Test
    @Disabled("This is disabled because is causing some weird behaviour where if the test is run with the whole application" +
            "this fails. But then you run the test by itself and it works. We will investigate later becasue the test" +
            "does not have a lot of importance")
    public void testWeReturn200WithCorrectBodyFeeAddedToMortgage() {

        stubHappyPath();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-valid-add-fee-to-mortgage.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(200).
                body("response.offerId", equalTo("1E1B708E51B2414F818BC845CACF71C7"),
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Offer generated"));
    }


    @Test
    public void testWeReturn400WhenRequestBodyInvalid() {

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"invalidJSON\":[" +
                        "{\"iAm\":\"an\"," +
                        "\"invalid\":\"JSON\"}" +
                        "]}").
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400);
    }


    @Test
    public void loanSchemeInRequestIsNotCorrect() {

        stubHappyPath();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-incorrect-loan-scheme.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT"),
                        "info.message", equalTo("One or more of the loans does not belong to the account")
                );
    }

    @Test
    public void sequenceNumberInRequestIsNotCorrect() {

        stubHappyPath();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-incorrect-sequence-number.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT"),
                        "info.message", equalTo("One or more of the loans does not belong to the account")
                );
    }

    @Test
    public void productSelectIsNotOfferedToThisAccount() {

        stubHappyPath();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-product-not-for-account.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_PRODUCT_CODE_NOT_VALID"),
                        "info.message", equalTo("The product code is not available for the customer")
                );
    }


    @Test
    public void testWeReturn400WhenInvalidEmailRequest() {

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("caseRequest/create-case-incorrect-email.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", Matchers.equalTo("ko"),
                        "info.message", Matchers.equalTo("emailAddress: incorrect format")
                );
    }

    @Test
    public void testWeReturn400WhenInvalidMobileRequest() {

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("caseRequest/create-case-incorrect-mobile.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", Matchers.equalTo("ko"),
                        "info.message", Matchers.equalTo("mobileNumber: incorrect format")
                );
    }


    @Test
    public void testWeReturn500WhenANMFInRegionX() {

        stubHeartbeatRegionX();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-valid.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.message", equalTo("Maintenance region X"),
                        "info.code", equalTo("MAINTENANCE_REGION_X")
                );
    }


    @Test
    public void testWeReturn500WhenANMFDown() {

        stubHappyPath();
        stubANMFAccountInfoDown(ACCOUNT_NUMBER);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-valid.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.message", equalTo("ANMF did not respond correctly"),
                        "info.code", equalTo("ANMF_UNAVAILABLE")
                );
    }

    @Test
    public void whenValidDataAndDownstreamServiceDownThenReturn500() throws InterruptedException {
        Thread.sleep(1000);
        stubHappyPath();
        stubCoreRetentionsDown();

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-valid.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(500);
        Thread.sleep(1000);
    }

    @Test
    public void testWeReturn400WhenCoreRetentionsError() throws InterruptedException {
        Thread.sleep(1000);
        stubHappyPath();
        Thread.sleep(1000);
        stubCoreRetentionsBadRequest();
        Thread.sleep(1000);
        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body(readFileContents("/new-deals/generate-offer-create-case-request/create-case-valid.json")).
                when().
                post(offerGenerateEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.message", equalTo("Error(s) list  : Field error in object 'caseRequest' on field 'account.borrowers[1].mobileTelNumber': rejected value []; codes [NotBlank.caseRequest.account.borrowers[1].mobileTelNumber,NotBlank.caseRequest.account.borrowers.mobileTelNumber,NotBlank.account.borrowers[1].mobileTelNumber,NotBlank.account.borrowers.mobileTelNumber,NotBlank.mobileTelNumber,NotBlank.java.lang.String,NotBlank]; arguments [org.springframework.context.support.DefaultMessageSourceResolvable: codes [caseRequest.account.borrowers[1].mobileTelNumber,account.borrowers[1].mobileTelNumber]; arguments []; default message [account.borrowers[1].mobileTelNumber]]; default message [must not be blank]" +
                                ""),
                        "info.code", equalTo("NotBlank")
                );
        Thread.sleep(1000);
    }

    private void stubHappyPath() {
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/new-deals/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(ACCOUNT_NUMBER, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(ACCOUNT_NUMBER, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/one-product.json");

        stubCoreRetentionsOk("core-retentions/core-retentions-with-offer-id.json");

        stubSaveCoreRetentionsDataToDBOk();

        stubPafId();

        stubPafDetails();

    }

}

package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OErcDetailsGrp;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.LoanType;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapperTestData.createEmptyMapperSourceData;
import static org.junit.jupiter.api.Assertions.*;

class MortgageDealsClientLoanRequestMapperTest {

    MortgageDealsClientLoanRequestMapper mortgageDealsClientLoanRequestMapper;

    @BeforeEach
    void setUp() {
        mortgageDealsClientLoanRequestMapper = new MortgageDealsClientLoanRequestMapper();
    }

    @Test
    void zeroLoansInClientRequestBecauseThereIsNotLoansInAccountsResponse() {
        var sourceData = createEmptyMapperSourceData();

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(0, request.size());
    }

    @Test
    void oneLoansInClientRequestBecauseThereIsNotLoansInAccountsResponse() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(50, request.get(0).getLoanId());
    }

    @Test
    void loanId() {

        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(50, request.get(0).getLoanId());
    }

    @Test
    void balance() {

        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setOOutstandingBalance(BigDecimal.valueOf(12345.67));

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(BigDecimal.valueOf(12345.67), request.get(0).getBalance());
    }

    @Test
    void selectedTrue() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        // This is the loan in the endpoint request
        addLoanInDealsRequest(sourceData, "3A", 1);

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertTrue(request.get(0).isSelected());
    }

    @Test
    void selectedFalse() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        // This is the loan in the endpoint request
        addLoanInDealsRequest(sourceData, "3A", 2);

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertFalse(request.get(0).isSelected());
    }

    @Test
    void remainingInstalments() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setORemainingInstlm(4);

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(4, request.get(0).getRemainingInstalments());
    }

    @Test
    void redemptionDate() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setORedemptionDate("01/02/2021");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals("01/02/2021", request.get(0).getRedemptionDate());
    }

    @Test
    void loanTypeR() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setORepaymentType("R");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(LoanType.R, request.get(0).getLoanType());
    }

    @Test
    void loanTypeI() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setORepaymentType("I");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(LoanType.I, request.get(0).getLoanType());
    }

    @Test
    void loanTypeUNDEFINED() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setORepaymentType("NOPE");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(LoanType.UNDEFINED, request.get(0).getLoanType());
    }

    @Test
    void monthlyPay() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setOMonthlyPay(BigDecimal.valueOf(122.33));

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(BigDecimal.valueOf(122.33), request.get(0).getMonthlyPay());
    }

    @Test
    void erc() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0).getOErcDetailsGrp()
                .setORdmStmErc(BigDecimal.valueOf(55.55));

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(BigDecimal.valueOf(55.55), request.get(0).getErc());
    }

    @Test
    void interestRate() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setOInterestRate(BigDecimal.valueOf(6.58));

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals(BigDecimal.valueOf(6.58), request.get(0).getInterestRate());
    }

    @Test
    void productEndDate() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setOProductEndDate("31/21/9999");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals("31/21/9999", request.get(0).getProductEndDate());
    }

    @Test
    void productType() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setOProductType("Fixed");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals("Fixed", request.get(0).getProductType());
    }

    @Test
    void productDescription() {
        var sourceData = createEmptyMapperSourceData();

        addActiveLoanInAccountResponse(sourceData, "3A", 1, 50);

        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc()
                .getOActiveLoanDetails()
                .get(0)
                .setOProductDesc("2 Year Fixed");

        var request = mortgageDealsClientLoanRequestMapper.create(sourceData);

        assertEquals(1, request.size());
        assertEquals("2 Year Fixed", request.get(0).getProductDescription());
    }

    private void addActiveLoanInAccountResponse(MapperSourceData sourceData, String loanScheme, int sequenceNumber, int loanId) {
        var activeLoanDetail = new OActiveLoanDetail();
        activeLoanDetail.setOLoanScheme(loanScheme);
        activeLoanDetail.setOApplSeqNo(sequenceNumber);
        activeLoanDetail.setOLoanId(loanId);
        OErcDetailsGrp errDetailsGroup = new OErcDetailsGrp();
        errDetailsGroup.setORdmStmErc(new BigDecimal("100.02"));
        activeLoanDetail.setOErcDetailsGrp(errDetailsGroup);
        sourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(activeLoanDetail);
    }

    private void addLoanInDealsRequest(MapperSourceData sourceData, String loanScheme, int sequenceNumber) {
        var loanSelected = new LoanIdentifier();
        loanSelected.setLoanScheme(loanScheme);
        loanSelected.setSequenceNumber(sequenceNumber);
        sourceData.getDealsRequest().getLoansSelected().add(loanSelected);
    }


}

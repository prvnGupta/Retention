package com.santanderuk.corinthian.services.retentions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Configuration
@Profile("local")
public class CorinthianRedisCacheConfigurationForLocalProfile extends CachingConfigurerSupport {

    @Value("${caching.inMemoryCacheNamesShortLife}")
    private String inMemoryCacheNamesShortLife;

    @Value("${caching.inMemoryCacheNamesLongLife}")
    private String inMemoryCacheNamesLongLife;

    @Bean
    @Profile("local")
    public CacheManager cacheManagerLongLife() {
        // configure and return an implementation of Spring's CacheManager SPI
        SimpleCacheManager cacheManagerLongLife = new SimpleCacheManager();
        cacheManagerLongLife.setCaches(inMemoryCacheNames(inMemoryCacheNamesLongLife));
        return cacheManagerLongLife;
    }

    @Bean
    @Primary
    @Profile("local")
    public CacheManager cacheManagerShortLife() {
        // configure and return an implementation of Spring's CacheManager SPI
        SimpleCacheManager cacheManagerShortLife = new SimpleCacheManager();
        cacheManagerShortLife.setCaches(inMemoryCacheNames(inMemoryCacheNamesShortLife));
        return cacheManagerShortLife;
    }

    private List<ConcurrentMapCache> inMemoryCacheNames(String names) {

        String[] cacheNames = names.split(",");

        List<ConcurrentMapCache> cacheNamesList = new ArrayList<>(cacheNames.length);

        for (String cacheName : cacheNames) {
            ConcurrentMapCache concurrentMapCache = new ConcurrentMapCache(cacheName);
            cacheNamesList.add(concurrentMapCache);
        }

        return cacheNamesList;
    }

}

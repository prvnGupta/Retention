package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.retentions.api.exceptions.ForbiddenException;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;

class OfferInfoValidatorBasicTest {

    private OfferInfoValidatorBasic offerInfoValidatorBasic;

    @BeforeEach
    void setUp() {
        offerInfoValidatorBasic = new OfferInfoValidatorBasic();
    }

    @Test
    void testWeThrowExceptionWhenEsisRefIdNotBelongToCustomer() {

        OfferInfoResponse offerInfoResponse = buildOfferInfoResponse();

        ForbiddenException forbiddenException = assertThrows(ForbiddenException.class, () -> offerInfoValidatorBasic.validateOffer(offerInfoResponse, "mismatch-esis-ref-id", 1));

        assertAll(() -> assertThat(forbiddenException.getCode(), equalTo("ESIS_REF_ID_NOT_MATCHING")),
                () -> assertThat(forbiddenException.getMessage(), equalTo("esis ref id returned does not match request")));
    }

    @Test
    void testWeThrowExceptionWhenAccountCannotAccessThisOffer() {

        OfferInfoResponse offerInfoResponse = buildOfferInfoResponse();

        ForbiddenException forbiddenException = assertThrows(ForbiddenException.class, () -> offerInfoValidatorBasic.validateOffer(offerInfoResponse, "esis-ref-id", 2));

        assertAll(() -> assertThat(forbiddenException.getCode(), equalTo("ACCOUNT_NOT_MATCHING")),
                () -> assertThat(forbiddenException.getMessage(), equalTo("The account is not allowed to access this resource")));
    }

    private OfferInfoResponse buildOfferInfoResponse() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setEsisRefId("esis-ref-id");
        data.setAnmfAccountNumber("ANMF1");
        offerInfoResponse.setData(data);
        return offerInfoResponse;
    }
}
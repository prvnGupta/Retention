package com.santanderuk.corinthian.services.retentions.functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.config.JsonPathConfig;
import com.santanderuk.corinthian.services.retentions.RetentionsServiceApplication;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.jayway.restassured.config.JsonConfig.jsonConfig;
import static com.jayway.restassured.config.RestAssuredConfig.newConfig;

@ContextConfiguration(initializers = FunctionalTest.RandomPortInitailizer.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = RetentionsServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class FunctionalTest {

    protected static final int ACCOUNT_NUMBER = 123456;

    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";
    protected String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    private WireMockServer coreMortgageEligibilityWireMock;
    private WireMockServer riskValuationWiremock;
    private WireMockServer productCatalogWiremock;
    private WireMockServer heartbeatWiremock;
    private WireMockServer anmfWiremock;
    private WireMockServer pafWiremock;
    private WireMockServer createCaseWiremock;
    private WireMockServer updateOfferInfoWiremock;
    private WireMockServer getOfferInfoWiremock;
    private WireMockServer acceptLaterWireMock;
    private WireMockServer updateFeeWireMock;
    private WireMockServer acceptInSessionWireMock;
    private WireMockServer esisWiremock;
    private WireMockServer saveCoreRetentionsDataWireMock;
    private WireMockServer retrieveMccWireMock;
    private WireMockServer contractsInMccWireMock;
    private WireMockServer accountBalancesWireMock;
    private WireMockServer paymentsServiceCallWireMock;

    @Value("${service.bksConnect.retrieveMcc.port}")
    protected int retrieveMccPort;

    @Value("${service.bksConnect.contractsInMcc.port}")
    protected int contractsInMccPort;

    @LocalServerPort
    protected String serverPort;

    @Value("${core.mortgage.api.port}")
    protected int coreMortgageEligibilityWireMockPort;

    @Value("${riskvaluation.port}")
    protected int riskValuationPort;

    @Value("${productCatalog.port}")
    protected int productCatalogPort;

    @Value("${heartbeat.port}")
    protected int heartbeatPort;

    @Value("${anmf.port}")
    protected int anmfPort;

    @Value("${paf.port}")
    protected int pafPort;

    @Value("${service.createCase.port}")
    protected int createCasePort;

    @Value("${service.getOfferInfo.port}")
    protected int getOfferInfoPort;

    @Value("${service.acceptLater.port}")
    protected int acceptLaterPort;

    @Value("${service.updateFee.port}")
    protected int updateFeePort;

    @Value("${service.acceptInSession.port}")
    protected int acceptInSessionPort;

    @Value("${service.updateOfferInfo.port}")
    protected int updateOfferInfoPort;

    @Value("${service.esis.port}")
    protected int esisPort;

    @Value("${service.saveRetentionDataUrl.port}")
    protected int saveCoreRetentionsDataPort;

    @Value("${service.core.account-balances.port}")
    protected int accountBalancesPort;

    @Value("${service.paymentsService.port}")
    protected int paymentsServicePort;

    @Value("${caching.inMemoryCacheNames}")
    private String inMemoryCacheNames;

    @Autowired
    @Qualifier("cacheManagerHeartbeat")
    private CacheManager cacheManagerHeartbeat;


    @BeforeEach
    public void baseSetUp() {

        RestAssured.config =
                newConfig().jsonConfig(jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));

        coreMortgageEligibilityWireMock = new WireMockServer(coreMortgageEligibilityWireMockPort);
        coreMortgageEligibilityWireMock.start();

        riskValuationWiremock = new WireMockServer(riskValuationPort);
        riskValuationWiremock.start();

        productCatalogWiremock = new WireMockServer(productCatalogPort);
        productCatalogWiremock.start();

        heartbeatWiremock = new WireMockServer(heartbeatPort);
        heartbeatWiremock.start();

        anmfWiremock = new WireMockServer(anmfPort);
        anmfWiremock.start();

        createCaseWiremock = new WireMockServer(createCasePort);
        createCaseWiremock.start();

        retrieveMccWireMock = new WireMockServer(retrieveMccPort);
        retrieveMccWireMock.start();

        contractsInMccWireMock = new WireMockServer(contractsInMccPort);
        contractsInMccWireMock.start();

        pafWiremock = new WireMockServer(pafPort);
        pafWiremock.start();

        getOfferInfoWiremock = new WireMockServer(getOfferInfoPort);
        getOfferInfoWiremock.start();

        acceptLaterWireMock = new WireMockServer(acceptLaterPort);
        acceptLaterWireMock.start();

        updateFeeWireMock = new WireMockServer(updateFeePort);
        updateFeeWireMock.start();

        acceptInSessionWireMock = new WireMockServer(acceptInSessionPort);
        acceptInSessionWireMock.start();

        updateOfferInfoWiremock = new WireMockServer(updateOfferInfoPort);
        updateOfferInfoWiremock.start();

        esisWiremock = new WireMockServer(esisPort);
        esisWiremock.start();

        saveCoreRetentionsDataWireMock = new WireMockServer(saveCoreRetentionsDataPort);
        saveCoreRetentionsDataWireMock.start();

        accountBalancesWireMock = new WireMockServer(accountBalancesPort);
        accountBalancesWireMock.start();

        paymentsServiceCallWireMock = new WireMockServer(paymentsServicePort);
        paymentsServiceCallWireMock.start();

    }

    @AfterEach
    public void baseTearDown() {
        deleteInMemoryCacheForTests();
        riskValuationWiremock.stop();
        coreMortgageEligibilityWireMock.stop();
        productCatalogWiremock.stop();
        heartbeatWiremock.stop();
        anmfWiremock.stop();
        createCaseWiremock.stop();
        retrieveMccWireMock.stop();
        contractsInMccWireMock.stop();
        pafWiremock.stop();
        getOfferInfoWiremock.stop();
        updateOfferInfoWiremock.stop();
        esisWiremock.stop();
        acceptLaterWireMock.stop();
        updateFeeWireMock.stop();
        acceptInSessionWireMock.stop();
        saveCoreRetentionsDataWireMock.stop();
        accountBalancesWireMock.stop();
        paymentsServiceCallWireMock.stop();
    }

    private void deleteInMemoryCacheForTests() {
        String[] cacheNames = inMemoryCacheNames.split(",");

        for (String cacheName : cacheNames) {
            cacheManagerHeartbeat.getCache(cacheName).clear();
        }
    }

    protected void stubPafId() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses"))
                .withQueryParam("query", notMatching("fhjkdhasfkjhsal"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-id-response.json"))));
    }

    protected void stubPafIdAndPostcode() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses"))
                .withQueryParam("container", equalTo("GB|RM|ENG|MILTON_KEYNES-MILTON_KEYNES_VILLAGE"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-id-response-2.json"))));
    }

    protected void stubPafDetails() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses/GB%7CRM%7CENG%7CMILTON_KEYNES-MILTON_KEYNES_VILLAGE"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-details-response.json"))));
    }

    protected void stubPafDetails1() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses/GB%7CRM%7CENG%7CMILTON_KEYNES-MILTON_KEYNES_VILLAGE"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-details-response.json"))));
    }

    protected void stubRetrieveMcc() {
        retrieveMccWireMock.stubFor(any(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect/bks-connect-retrieve-mcc-ok-response.json"))));
    }

    protected void stubContractsInMcc() {
        contractsInMccWireMock.stubFor(any(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/contract-mcc"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect/bks-connect-contracts-mcc-ok-response.json"))));
    }

    protected void stubProductCompletionDate(String testFixture) {
        productCatalogWiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/product-band/productCompletionDates"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    protected void stubProductDirectoryResponse(String testFixture) {
        productCatalogWiremock.stubFor(any(urlMatching("/sanuk/internal/mortgage-product-directory/products/conditions.*"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubCoreRetentionsOk(String testFixture) {
        createCaseWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/core-retentions/%s", "offer/generate")))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    public void stubSaveCoreRetentionsDataToDBOk() {
        saveCoreRetentionsDataWireMock.stubFor(put(urlPathEqualTo("/sanuk/internal/product-switch-service/offer-info/esis-ref-id/1E1B708E51B2414F818BC845CACF71C7/gass"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));
    }

    protected void stubCoreRetentionsDown() {
        createCaseWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/core-retentions/%s", "offer/generate")))
                .willReturn(aResponse()
                        .withStatus(503)));
    }

    protected void stubShortestChargeEndDate() {

        productCatalogWiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/product-band/nearest-fixed-charge-end-date"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("product/shortest-term-success-response.json"))));
    }


    protected void stubHeartBeat(String testFixture) {
        heartbeatWiremock.stubFor(get(urlPathEqualTo("/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubHeartBeatDown() {
        heartbeatWiremock.stubFor(get(urlPathEqualTo("/get-region"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")));
    }

    protected void stubHeartbeatRegionX() {

        heartbeatWiremock.stubFor(get(urlPathEqualTo("/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("heartbeat/heartbeat-response-x.json"))));
    }

    protected void stubRiskValuation(int accountNumber, String testFixture) {
        riskValuationWiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/risk-valuation/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubRiskValuationAccountNotFound(int accountNumber) {
        riskValuationWiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/risk-valuation/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(204)));
    }

    protected void stubRiskValuationAccountNotFoundWith200(int accountNumber) {
        riskValuationWiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/risk-valuation/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents("risk-valuation/response-account-not-found.json"))));
    }

    protected void stubRiskValuationConnectionDown(int accountNumber) {
        riskValuationWiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/risk-valuation/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)));
    }

    protected void stubANMFAccountInfo(int accountNumber, String testFixture) {
        anmfWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/mortgage-account-details/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubANMFAccountInfoDown(int accountNumber) {
        anmfWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/mortgage-account-details/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(503)));
    }

    protected void stubANMFPropertyInfoV2(int accountNumber, String testFixture) {
        anmfWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/collateral-asset-administration/accounts/%s/property", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubAnmfCustomerInfo(String testFixture) {
        anmfWiremock.stubFor(get(urlMatching("/sanuk/internal/mortgage-customer-details/accounts/.*/customers"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubODMCoreEligibility(String testFixture) {
        coreMortgageEligibilityWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-api/v1/api"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubODMCoreEligibilityDown() {
        coreMortgageEligibilityWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-api/v1/api"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(503)));
    }


    protected void stubProductSwitchUpdateDownloadDate(String esisRefId, String testFixture) {
        updateOfferInfoWiremock.stubFor(put(urlPathEqualTo(String.format("/sanuk/internal/product-switch-service/offer-info/esis-ref-id/%s/download", esisRefId)))
                .withRequestBody(containing("ANMF123456"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents(testFixture))));
    }


    protected void stubProductSwitchRetrieveOfferInfo(String esisRefId, String testFixture) {
        getOfferInfoWiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/product-switch-service/offer-info/esis-ref-id/%s", esisRefId)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents(testFixture))));
    }


    protected void stubProductSwitchRetrieveOfferInfoDown() {
        getOfferInfoWiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/product-switch-service/offer-info/esis-ref-id/esis-ref-id"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)));
    }


    protected void stubProductSwitchAcceptInSessionDown(String caseId) {
        acceptInSessionWireMock.stubFor(put(urlPathEqualTo(String.format("/sanuk/internal/product-switch-service/offer/%s/accept-in-session", caseId)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)));
    }

    protected void stubProductSwitchAcceptLater(String caseId, String testFixture) {
        acceptLaterWireMock.stubFor(put(urlPathEqualTo(String.format("/sanuk/internal/product-switch-service/offer/%s/bridge-transmission", caseId)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubProductSwitchAcceptInSession(String caseId, String testFixture) {
        acceptInSessionWireMock.stubFor(post(urlPathEqualTo(String.format("/sanuk/internal/product-switch-service/offer/%s/accept-in-session", caseId)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubProductSwitchAcceptLaterIsDown() {
        acceptLaterWireMock.stubFor(put(urlPathEqualTo("/sanuk/internal/product-switch-service/offer/case-id/bridge-transmission"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)));
    }

    protected void stubUpdateFee_Ok(String caseId) {
        updateFeeWireMock.stubFor(post(urlPathEqualTo(String.format("/sanuk/internal/product-switch-service/offer/%s/fees", caseId)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)));
    }

    protected void stubEsisResponse(String testFixture) {
        esisWiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/mrs-esis-core/v1/esis/esis-ref-id"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/xml")
                        .withStatus(200)
                        .withBody(readFileContents(testFixture))));
    }


    protected void stubEsisDown() {
        esisWiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/mrs-esis-core/v1/esis/esis-ref-id"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/xml")
                        .withStatus(500)));
    }


    protected void stubAccountBalancesOK() {
        accountBalancesWireMock.stubFor(get(urlMatching("/sanuk/internal/accounts-balances/v1/balances.*"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents("account-balances/account-balance-success-response.json"))));
    }

    protected void stubpaymentsService_OK() {
        paymentsServiceCallWireMock.stubFor(post(urlMatching("/payments-service/internalTransfer"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents("accept-and-pay/accept-and-pay-response.json"))));
    }

    protected void stubpaymentsServiceForPaymentsException_KO() {
        paymentsServiceCallWireMock.stubFor(post(urlMatching("/payments-service/internalTransfer"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)
                ));
    }

    protected void stubCoreRetentionsBadRequest() {
        createCaseWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/core-retentions/%s", "offer/generate")))
                .willReturn(aResponse()
                        .withBody(readFileContents("core-retentions/bad-request.json"))
                        .withStatus(400)));
    }

    protected void stubMortgageDealsProduct(String testFixture) {
        paymentsServiceCallWireMock.stubFor(post(urlMatching("/sanuk/internal/mortgage-deals/v2/products"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    public static class RandomPortInitailizer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {

            int randomEligibilityCoreMortgagePort = SocketUtils.findAvailableTcpPort();
            int randomRiskValuationPort = SocketUtils.findAvailableTcpPort();
            int randomProductCatalogPort = SocketUtils.findAvailableTcpPort();
            int randomCreateCasePort = SocketUtils.findAvailableTcpPort();
            int randomGenerateOfferPort = SocketUtils.findAvailableTcpPort();
            int randomRetrieveMccPort = SocketUtils.findAvailableTcpPort();
            int randomContractsInMccPort = SocketUtils.findAvailableTcpPort();
            int randomPafPort = SocketUtils.findAvailableTcpPort();
            int randomGetOfferInfoPort = SocketUtils.findAvailableTcpPort();
            int randomUpdateOfferInfoPort = SocketUtils.findAvailableTcpPort();
            int randomEsisPort = SocketUtils.findAvailableTcpPort();
            int randomAcceptLaterPort = SocketUtils.findAvailableTcpPort();
            int randomUpdateFeePort = SocketUtils.findAvailableTcpPort();
            int randomAcceptInSessionPort = SocketUtils.findAvailableTcpPort();
            int randomGetSaveRetnetionDataPort = SocketUtils.findAvailableTcpPort();
            int randomAccountBalancesPort = SocketUtils.findAvailableTcpPort();
            int randomPaymentsServicePort = SocketUtils.findAvailableTcpPort();

            String coreMortgageEligibilityUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-api/v1/api", randomEligibilityCoreMortgagePort);
            String riskValuationUrl = String.format("http://localhost:%d/sanuk/internal/risk-valuation/accounts", randomRiskValuationPort);
            String createCaseUrl = String.format("http://localhost:%d/sanuk/internal/core-retentions/case", randomCreateCasePort);
            String generateOfferUrl = String.format("http://localhost:%d/sanuk/internal/core-retentions/offer/generate", randomCreateCasePort);
            String retrieveMccUrl = String.format("http://localhost:%d/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user", randomRetrieveMccPort);
            String contractsInMccUrl = String.format("http://localhost:%d/sanuk/internal/core-bks-connect/ioc-core/contract-mcc", randomContractsInMccPort);
            String pafUrl = String.format("http://localhost:%d/sanuk/playground-internal/paf2/v2/addresses", randomPafPort);
            String updateOfferInfoUrl = String.format("http://localhost:%d/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download", randomUpdateOfferInfoPort);
            String retrieveOfferInfoUrl = String.format("http://localhost:%d/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}", randomGetOfferInfoPort);
            String retrieveOfferUrl = String.format("http://localhost:%d/sanuk/internal/mrs-esis-core/v1/esis/{esisRefId}", randomEsisPort);
            String acceptLaterUrl = String.format("http://localhost:%d/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission", randomAcceptLaterPort);
            String updateFeeUrl = String.format("http://localhost:%d/sanuk/internal/product-switch-service/offer/{caseId}/fees", randomUpdateFeePort);
            String acceptInSessionUrl = String.format("http://localhost:%d/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session", randomAcceptInSessionPort);
            String saveRetnetionDataurl = String.format("http://localhost:%d/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass", randomGetSaveRetnetionDataPort);
            String accountBalancesUrl = String.format("http://localhost:%d/sanuk/internal/accounts-balances/v1/balances", randomAccountBalancesPort);
            String paymentsServiceUrl = String.format("http://localhost:%d/payments-service/internalTransfer", randomPaymentsServicePort);
            String mortgageDealsProduct = String.format("http://localhost:%d/sanuk/internal/mortgage-deals/v2/products", randomPaymentsServicePort);

            String productDirectoryUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-product-directory/products/conditions?result_filter=FARTHEST_COMPLETION_DATE,NEAREST_CHARGE_END_DATE&application_type=INTERNAL_TRANSFER&range_type=STANDARD", randomProductCatalogPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("product-directory.url=%s", productDirectoryUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.createCase=" + createCaseUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.createCase.port=" + randomCreateCasePort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.updateOfferInfo=" + updateOfferInfoUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.updateOfferInfo.port=" + randomUpdateOfferInfoPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.retrieveOfferInfo=" + retrieveOfferInfoUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.getOfferInfo.port=" + randomGetOfferInfoPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.acceptLater=" + acceptLaterUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.acceptLater.port=" + randomAcceptLaterPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "product-transfer-fee-payment.endpoint=" + updateFeeUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.updateFee.port=" + randomUpdateFeePort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.acceptInSession=" + acceptInSessionUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.acceptInSession.port=" + randomAcceptInSessionPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.generateOffer=" + generateOfferUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.generateOfferPort.port=" + randomGenerateOfferPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.retrieveOffer=" + retrieveOfferUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.esis.port=" + randomEsisPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.mortgageEligibility=" + coreMortgageEligibilityUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core.mortgage.api.port=" + randomEligibilityCoreMortgagePort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.riskvaluation=" + riskValuationUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "riskvaluation.port=" + randomRiskValuationPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "productCatalog.port=" + randomProductCatalogPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.accountBalances=" + accountBalancesUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "bksconnect.endpoints.retrievemcc=" + retrieveMccUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "bksconnect.endpoints.contractsInMcc=" + contractsInMccUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.bksConnect.retrieveMcc.port=" + randomRetrieveMccPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.bksConnect.contractsInMcc.port=" + randomContractsInMccPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.paf=" + pafUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "paf.port=" + randomPafPort);

            int randomHeartbeatPort = SocketUtils.findAvailableTcpPort();
            String heartbeatUrl = String.format("http://localhost:%d/get-region", randomHeartbeatPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.get-region=" + heartbeatUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.port=" + randomHeartbeatPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.account-balances.port=" + randomAccountBalancesPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.saveRetentionDataUrl=" + saveRetnetionDataurl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.saveRetentionDataUrl.port=" + randomGetSaveRetnetionDataPort);
            int anmfPort = SocketUtils.findAvailableTcpPort();

            String anmfAccountDetailsUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-account-details/accounts/{account}", anmfPort);
            String anmfCustomerInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-customer-details/accounts/{account}/customers", anmfPort);
            String anmfPropoertyInfoUrl = String.format("http://localhost:%d/sanuk/internal/collateral-asset-administration/accounts/{account}/property", anmfPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.customerservice=%s", anmfCustomerInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.account-details=%s", anmfAccountDetailsUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.property=%s", anmfPropoertyInfoUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "anmf.port=" + anmfPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "payments-service.endpoint=" + paymentsServiceUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.paymentsService.port=" + randomPaymentsServicePort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "mortgage-deals.products.url=" + mortgageDealsProduct);

        }
    }
}

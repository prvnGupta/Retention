package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafDetailResponse;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafIdResponse;
import com.santanderuk.corinthian.services.retentions.config.Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class PafClientTest {
    private String postcode;
    private String pafid;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private Config config;

    @Mock
    private PafClient pafClient;

    @BeforeEach
    public void setUp() {
        pafClient = new PafClient(config, restTemplate);
        postcode = "MK1 1AB";
        pafid = "paf-id";
        Mockito.when(config.getClientIdHeaderKey()).thenReturn("x-ibm-client-id");
        Mockito.when(config.getClientIdHeaderValue()).thenReturn("b9cb939f-6c4d-4f3b-9cc4-9ffb36187cd1");
        Mockito.when(config.getPafMaxAttempts()).thenReturn(3);
    }

    @Test
    public void testWeCallMaxAttemptsWhenFetchPafIdResponseIsDown() {
        Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(PafIdResponse.class))).thenThrow(new RestClientException("Exception1"));
        assertThrows(ConnectionException.class, () -> pafClient.fetchPafIdResponse(postcode));
        verify(restTemplate, times(3)).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(PafIdResponse.class));
    }

    @Test
    public void testWeCallMaxAttemptsWhenfetchPafDetailResponseIsDown() {
        Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(PafDetailResponse.class))).thenThrow(new RestClientException("Exception2"));
        assertThrows(ConnectionException.class, () -> pafClient.fetchPafDetailResponse(pafid));
        verify(restTemplate, times(3)).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(PafDetailResponse.class));
    }

    @Test
    public void testWeCallMaxAttemptsWhenfetchPafIdAndPostcodeResponseIsDown() {
        Mockito.when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(PafIdResponse.class))).thenThrow(new RestClientException("Exception3"));
        assertThrows(ConnectionException.class, () -> pafClient.fetchPafIdAndPostcodeResponse(postcode, pafid));
        verify(restTemplate, times(3)).exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(PafIdResponse.class));
    }
}

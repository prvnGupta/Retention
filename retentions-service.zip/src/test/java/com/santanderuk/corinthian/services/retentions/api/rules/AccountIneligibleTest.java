package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.ODMEligibilityIneligible;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class AccountIneligibleTest extends RuleTest {

    ODMEligibilityIneligible rule;

    @BeforeEach
    public void setUp() {
        rule = new ODMEligibilityIneligible();
    }

    @Test
    public void testWeGetIneligibleWhenN() {
        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setAccountEligibility("Y");

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        assertThat(eligibilityResponse.getBlockers().isAccountIneligible(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isAccountIneligible(), equalTo(false));
    }

    @Test
    public void testWeGetEligibleWhenY() {
        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setAccountEligibility("N");

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        assertThat(eligibilityResponse.getBlockers().isAccountIneligible(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isAccountIneligible(), equalTo(true));
    }

}

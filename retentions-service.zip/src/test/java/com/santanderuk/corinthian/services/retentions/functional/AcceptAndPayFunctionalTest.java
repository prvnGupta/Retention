package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class AcceptAndPayFunctionalTest extends FunctionalTest {

    private Header authorizationHeader;
    private Header contentType;
    private Header accept;
    private String acceptAndPayEndpoint;

    private static final String ESIS_REF_ID = "esis-ref-id";

    @BeforeEach
    void setUp() {
        authorizationHeader = new Header("authorization", jwtWithCustomer554);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
        acceptAndPayEndpoint = String.format("http://localhost:%s/retentions-service/%s/offer/{esisRefId}/pay-and-accept-in-session", serverPort, ACCOUNT_NUMBER);
    }

    @Test
    void testHappyPathWithCurrentAccount() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-fee-paying-upfront-response.json");
        stubContractsInMcc();
        stubRetrieveMcc();
        stubAccountBalancesOK();
        stubUpdateFee_Ok("case-id-1234");
        stubpaymentsService_OK();
        stubProductSwitchAcceptInSession("case-id-1234", "/product-switch-service/accept-in-session-response.json");
        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid.json")).
                put(parameterisedUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"),
                        "info.code", equalTo("SUCCESS"),
                        "info.message", equalTo("Transfer complete and fee paid"));
    }

    @Test
    void testHappyPathWithSavingsAccount() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-fee-paying-upfront-response.json");
        stubContractsInMcc();
        stubRetrieveMcc();
        stubAccountBalancesOK();
        stubUpdateFee_Ok("case-id-1234");
        stubpaymentsService_OK();
        stubProductSwitchAcceptInSession("case-id-1234", "/product-switch-service/accept-in-session-response.json");
        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid-savings.json")).
                put(parameterisedUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"),
                        "info.code", equalTo("SUCCESS"),
                        "info.message", equalTo("Transfer complete and fee paid"));
    }


    @Test
    void testWeHandleMaintenanceException() {

        stubHeartbeatRegionX();

        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid.json")).
                put(parameterisedUrl).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("MAINTENANCE_REGION_X"),
                        "info.message", equalTo("Maintenance region X"));
    }

    @Test
    void testWeHandleConnectionException() {

        stubHeartBeatDown();

        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid.json")).
                put(parameterisedUrl).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("HEARTBEAT_CONNECTION_ERROR"),
                        "info.message", equalTo("An error occurred when trying to connect with heartbeat"));
    }

    @Test
    void testWeHandleOperativeSecurityException() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");

        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid.json")).
                put(parameterisedUrl).
                then().
                statusCode(401).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer"));
    }

    @Test
    void testWeHandleJsonProcessingException() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-bad-response.json");
        stubContractsInMcc();
        stubRetrieveMcc();
        stubAccountBalancesOK();

        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid.json")).
                put(parameterisedUrl).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("INTERNAL_SERVER_ERROR"),
                        "info.message", equalTo("Failed to read in database object"));
    }

    @Test
    void shouldReturnInvalidRequestResponse() {
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-bad-response.json");
        stubContractsInMcc();
        stubRetrieveMcc();
        stubAccountBalancesOK();
        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-invalid-format.json")).
                put(parameterisedUrl).
                then().
                statusCode(400).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.message", equalTo("accountFrom: invalid format"));
    }

    @Test
    void shouldReturnUnrecognizedPropertyResponse() {
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-bad-response.json");
        stubContractsInMcc();
        stubRetrieveMcc();
        stubAccountBalancesOK();
        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-invalid.json")).
                put(parameterisedUrl).
                then().
                statusCode(400).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.message", equalTo("Unrecognized property in the request"));
    }

    @Test
    void testWeHandlePaymentsException() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-fee-paying-upfront-response.json");
        stubContractsInMcc();
        stubRetrieveMcc();
        stubAccountBalancesOK();
        stubpaymentsServiceForPaymentsException_KO();
        String parameterisedUrl = acceptAndPayEndpoint.replace("{esisRefId}", ESIS_REF_ID);
        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                body(readFileContents("accept-and-pay/accept-and-pay-request-valid.json")).
                put(parameterisedUrl).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("INTERNAL_SERVER_ERROR"),
                        "info.message", equalTo("Error calling payments service from pay and accept in session"));
    }
}

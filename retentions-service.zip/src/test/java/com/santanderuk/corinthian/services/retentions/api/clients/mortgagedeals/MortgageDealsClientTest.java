package com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals;

import com.santanderuk.corinthian.services.retentions.FixtureReader;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.MortgageDealsClientResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class MortgageDealsClientTest {

    @Mock
    RestTemplate restTemplate;

    MortgageDealsClient client;

    @BeforeEach
    void setUp() throws IOException {

        mockRestTemplateOk();

        var configuration = new MortgageDealsClientConfig(
                "xIbmConfigId",
                "xIbmConfigSecret",
                "http://test.corp/mortgage-deals/"
        );

        client = new MortgageDealsClient(configuration, restTemplate);
    }

    @Test
    void restTemplateIsCalled() throws MortgageDealsClientException {

        var input = new MortgageDealsClientRequest();
        client.fetch(input);

        // We call template once
        verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(MortgageDealsClientResponse.class));
    }

    @Test
    void restTemplateIsCalledWithProperConfiguration() throws MortgageDealsClientException {

        var input = new MortgageDealsClientRequest();
        client.fetch(input);

        // Checking parameters sent to the rest template
        var urlCaptor = ArgumentCaptor.forClass(String.class);
        var httpEntittyCaptor = ArgumentCaptor.forClass(HttpEntity.class);

        verify(restTemplate).postForEntity(urlCaptor.capture(), httpEntittyCaptor.capture(), eq(MortgageDealsClientResponse.class));

        // The url sent to the rest te
        assertEquals("http://test.corp/mortgage-deals/", urlCaptor.getValue());

        // Ibm configuration and no more headers
        var headers = httpEntittyCaptor.getValue().getHeaders();
        assertEquals("xIbmConfigId", headers.getFirst("X-IBM-Client-Id"));
        assertEquals(3, headers.size());
    }

    @Test
    void weReturnTheMockedResponse() throws IOException, MortgageDealsClientException {

        var mockedEntity = mockRestTemplateOk();

        var input = new MortgageDealsClientRequest();
        var output = client.fetch(input);

        // is same object than mocked
        assertEquals(mockedEntity.getBody(), output);

        assertEquals("2", output.getProductBand());

        // There is no point in testing each value as far as we see the object is picked up
        assertNotNull(output.getProducts());

    }

    @Test
    void weReturnTheMockedKoWithResponse() throws IOException, MortgageDealsClientException {

        var mockedEntity = mockRestTemplateKoWithResponse();

        var input = new MortgageDealsClientRequest();
        var output = client.fetch(input);

        // Is same object than mocked
        assertEquals(mockedEntity.getBody(), output);

        assertNull(output.getProductBand());

        // There is no point in testing each value as far as we see the object is picked up
        assertNull(output.getProducts());

        assertEquals("Error type", output.getType());
        assertEquals("Title error", output.getTitle());
        assertEquals(1, output.getStatus());
        assertEquals("Detail error", output.getDetail());
        assertEquals("Instance error", output.getInstance());
    }

    @Test
    void restTemplateException() throws IOException {

        mockRestTemplateException();

        var input = new MortgageDealsClientRequest();

        var exception = assertThrows(MortgageDealsClientException.class, () -> client.fetch(input));
        assertEquals("MORTGAGE-DEALS-CLIENT-EXCEPTION", exception.getCode());
        assertEquals("Exception thrown in MortgageDealsClient", exception.getMessage());
    }

    private ResponseEntity<MortgageDealsClientResponse> mockRestTemplateOk() throws IOException {
        MortgageDealsClientResponse response = FixtureReader.get("mortgage-deals/mortgage-deals-ok.json", MortgageDealsClientResponse.class);
        var responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(restTemplate.postForEntity(anyString(), any(), eq(MortgageDealsClientResponse.class))).thenReturn(responseEntity);
        return responseEntity;
    }

    private ResponseEntity<MortgageDealsClientResponse> mockRestTemplateKoWithResponse() throws IOException {
        MortgageDealsClientResponse response = FixtureReader.get("mortgage-deals/mortgage-deals-ko.json", MortgageDealsClientResponse.class);
        var responseEntity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        when(restTemplate.postForEntity(anyString(), any(), eq(MortgageDealsClientResponse.class))).thenReturn(responseEntity);
        return responseEntity;
    }

    private void mockRestTemplateException() throws IOException {
        var exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST);
        when(restTemplate.postForEntity(anyString(), any(), eq(MortgageDealsClientResponse.class))).thenThrow(exception);
    }
}

package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CoreRetentionMapperAccountTest extends CoreRetentionMapperTestBase {


    @Test
    public void mapAccount() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());

        assertEquals(1, coreRetentionRequest.getAccount().getType());
        assertEquals("100001234", coreRetentionRequest.getAccount().getNumber());
        assertEquals("ANMF100001234", coreRetentionRequest.getAccount().getReference());
        assertEquals("1", coreRetentionRequest.getAccount().getPlatform());
        assertEquals(new BigDecimal("3345.45"), coreRetentionRequest.getAccount().getBalance());
        assertNull(coreRetentionRequest.getAccount().getSetupDate());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsRepayment() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("R", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsInterestOnly() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORepaymentType("I");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("I", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsMixed() {

        CoreRetentionsData input = generateDefaultMapperInput();
        // By default has R so for having a mix we need to add ANOTHER with INTEREST_ONLY
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("I");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("M", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsTwoRepaymentsOneInterestOnly() {

        CoreRetentionsData input = generateDefaultMapperInput();
        // By default has R so for having a mix we need to add ANOTHER with INTEREST_ONLY
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("R");
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(2).setORepaymentType("I");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("M", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsOneRepaymentsTwoInterestOnly() {

        CoreRetentionsData input = generateDefaultMapperInput();
        // By default has R so for having a mix we need to add ANOTHER with INTEREST_ONLY
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("I");
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(2).setORepaymentType("I");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("M", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsOnlyTwoRepaymentsNoInterestOnly() {

        CoreRetentionsData input = generateDefaultMapperInput();
        // By default has R so for having a mix we need to add ANOTHER with INTEREST_ONLY
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("R");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("R", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageRepaymentMethodIsOnlyNoRepaymentsTwoInterestOnly() {

        CoreRetentionsData input = generateDefaultMapperInput();
        // By default has R so for having a mix we need to add ANOTHER with INTEREST_ONLY
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORepaymentType("I");
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("I");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("B", coreRetentionRequest.getAccount().getMortgage().getCategory());
        assertEquals("I", coreRetentionRequest.getAccount().getMortgage().getMethodOfRepaymentType());
    }

    @Test
    public void mapAccountMortgageClassType() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());

        assertEquals("3", coreRetentionRequest.getAccount().getMortgage().getClassType());
    }

    @Test
    public void mapAccountMortgageTermSingleLoanRemainingInstallment0() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAnmfAccountServiceResponse(generateANMFLoanResponseRemainingInstalments(0));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage().getTerm());

        assertEquals(0, coreRetentionRequest.getAccount().getMortgage().getTerm().getYears());
        assertEquals(0, coreRetentionRequest.getAccount().getMortgage().getTerm().getMonths());
        assertEquals(0, coreRetentionRequest.getAccount().getMortgage().getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getMortgage().getTerm().isChanged());
    }

    @Test
    public void mapAccountMortgageTermSingleLoanRemainingInstallment1() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAnmfAccountServiceResponse(generateANMFLoanResponseRemainingInstalments(1));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage().getTerm());

        assertEquals(0, coreRetentionRequest.getAccount().getMortgage().getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getMortgage().getTerm().getMonths());
        assertEquals(1, coreRetentionRequest.getAccount().getMortgage().getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getMortgage().getTerm().isChanged());
    }

    @Test
    public void mapAccountMortgageTermSingleLoanRemainingInstallment12() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAnmfAccountServiceResponse(generateANMFLoanResponseRemainingInstalments(12));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage().getTerm());

        assertEquals(1, coreRetentionRequest.getAccount().getMortgage().getTerm().getYears());
        assertEquals(0, coreRetentionRequest.getAccount().getMortgage().getTerm().getMonths());
        assertEquals(12, coreRetentionRequest.getAccount().getMortgage().getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getMortgage().getTerm().isChanged());
    }

    @Test
    public void mapAccountMortgageTermSingleLoanRemainingInstallment13() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAnmfAccountServiceResponse(generateANMFLoanResponseRemainingInstalments(13));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage().getTerm());

        assertEquals(1, coreRetentionRequest.getAccount().getMortgage().getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getMortgage().getTerm().getMonths());
        assertEquals(13, coreRetentionRequest.getAccount().getMortgage().getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getMortgage().getTerm().isChanged());
    }

    @Test
    public void mapAccountMortgageTermSingleLoanRemainingInstallment135() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAnmfAccountServiceResponse(generateANMFLoanResponseRemainingInstalments(135));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage().getTerm());

        assertEquals(11, coreRetentionRequest.getAccount().getMortgage().getTerm().getYears());
        assertEquals(3, coreRetentionRequest.getAccount().getMortgage().getTerm().getMonths());
        assertEquals(135, coreRetentionRequest.getAccount().getMortgage().getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getMortgage().getTerm().isChanged());
    }

    @Test
    public void mapAccountMortgageTermMultiLoanPickUpLongest() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAnmfAccountServiceResponse(generateMultiLoanResponseForPickingTheLongest());
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage());
        assertNotNull(coreRetentionRequest.getAccount().getMortgage().getTerm());

        assertEquals(9, coreRetentionRequest.getAccount().getMortgage().getTerm().getYears());
        assertEquals(6, coreRetentionRequest.getAccount().getMortgage().getTerm().getMonths());
        assertEquals(114, coreRetentionRequest.getAccount().getMortgage().getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getMortgage().getTerm().isChanged());
    }

    @Test
    public void mapAccountProperty() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getProperty());

        assertNull(coreRetentionRequest.getAccount().getProperty().getPrice());

    }


    @Test
    public void mapAccountPropertyAddress() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAddressResponse(createAddressResponse());
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getAccount());
        assertNotNull(coreRetentionRequest.getAccount().getProperty());
        assertNotNull(coreRetentionRequest.getAccount().getProperty().getAddress());

        assertEquals("AddressLine1", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine1());
        assertEquals("AddressLine2", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine2());
        assertEquals("", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine3());
        assertEquals("AddressLine3", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine4());
        assertEquals("AddressLine4", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine5());
        assertEquals("", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine6());
        assertEquals("", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine7());
        assertEquals("UNITED KINGDOM", coreRetentionRequest.getAccount().getProperty().getAddress().getAddressLine8());
        assertEquals("MK9 1LA", coreRetentionRequest.getAccount().getProperty().getAddress().getPostcode());

        assertFalse(coreRetentionRequest.getAccount().getProperty().getAddress().isCorrespondenceChangeIndicator());
    }


    @Test
    public void mapAccountDrawdownAmount() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAddressResponse(createAddressResponse());
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getAccount().getDrawdownAmount());

    }

    @Test
    public void mapAccountBonusProductId() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.setAddressResponse(createAddressResponse());
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNull(coreRetentionRequest.getAccount().getBonusProductID());

    }

    @Test
    public void mapAccountTotalPortedLoansOneLoan() {

        CoreRetentionsData input = generateDefaultMapperInput();

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("1.00"), coreRetentionRequest.getAccount().getTotalPortedLoans());

    }

    @Test
    public void mapAccountTotalCapitalRepaymentAmount() {

        CoreRetentionsData input = generateDefaultMapperInput();

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getAccount().getTotalCapitalRepaymentAmount());

    }

    @Test
    public void mapAccountTotalPortedLoansTwoLoan() {

        CoreRetentionsData input = generateDefaultMapperInput();
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        // Add second loan - first one is cap balance 1.11
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOLoanScheme("3T");
        oLoans.get(1).setOApplSeqNo(2);
        oLoans.get(1).setOCapitalBalance(new BigDecimal("10.00"));

        // Add second selected loan
        LoanIdentifier selectedLoan = new LoanIdentifier();
        selectedLoan.setLoanScheme("3T");
        selectedLoan.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(selectedLoan);


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("11.00"), coreRetentionRequest.getAccount().getTotalPortedLoans());

    }

    @Test
    public void mapAccountTotalPortedLoansThreeLoan() {

        CoreRetentionsData input = generateDefaultMapperInput();
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        // Add second loan - first one is cap balance 1.11
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOLoanScheme("3T");
        oLoans.get(1).setOApplSeqNo(2);
        oLoans.get(1).setOCapitalBalance(new BigDecimal("10.00"));

        // Add third loan
        oLoans.add(generateDefaultLoan());
        oLoans.get(2).setOLoanScheme("3T");
        oLoans.get(2).setOApplSeqNo(3);
        oLoans.get(2).setOCapitalBalance(new BigDecimal("100.00"));

        // Add second selected loan
        LoanIdentifier selectedLoan2 = new LoanIdentifier();
        selectedLoan2.setLoanScheme("3T");
        selectedLoan2.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(selectedLoan2);

        // Add third selected loan
        LoanIdentifier selectedLoan3 = new LoanIdentifier();
        selectedLoan3.setLoanScheme("3T");
        selectedLoan3.setSequenceNumber(3);
        input.getCaseRequest().getLoansSelected().add(selectedLoan3);


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("111.00"), coreRetentionRequest.getAccount().getTotalPortedLoans());

    }

    @Test
    public void mapAccountTotalPortedLoansThreeLoansInANMFButOnlyTwoSelected() {

        CoreRetentionsData input = generateDefaultMapperInput();
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        // Add second loan - first one is cap balance 1.11
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOLoanScheme("3T");
        oLoans.get(1).setOApplSeqNo(2);
        oLoans.get(1).setOCapitalBalance(new BigDecimal("10.00"));

        // Add third loan
        oLoans.add(generateDefaultLoan());
        oLoans.get(2).setOLoanScheme("3T");
        oLoans.get(2).setOApplSeqNo(3);
        oLoans.get(2).setOCapitalBalance(new BigDecimal("100.00"));

        // Add second selected loan
        LoanIdentifier selectedLoan2 = new LoanIdentifier();
        selectedLoan2.setLoanScheme("3T");
        selectedLoan2.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(selectedLoan2);


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(new BigDecimal("11.00"), coreRetentionRequest.getAccount().getTotalPortedLoans());

    }

}

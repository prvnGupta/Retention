package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.TermRemaining;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class TermRemainingTest extends RuleTest {

    TermRemaining rule;

    @BeforeEach
    public void setUp() {
        rule = new TermRemaining();
    }

    @Test
    public void testWeSetBlockerWhenMinimumRemainingTermIsNo() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setMinimumRemainingTermAccountEligibility("N");

        assertThat(eligibilityResponse.getBlockers().isTermRemaining(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isTermRemaining(), equalTo(true));
    }

    @Test
    public void testWeSetBlockerWhenMinimumRemainingTermIsYes() {


        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setMinimumRemainingTermAccountEligibility("Y");

        assertThat(eligibilityResponse.getBlockers().isTermRemaining(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isTermRemaining(), equalTo(false));
    }


}

package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.validations.Validations;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class EligibilityFormatValidationTest {

    @Spy
    Validations validations;

    @InjectMocks
    EligibilityFormatValidation eligibilityFormatValidation;

    @BeforeEach
    public void setUp() {
        eligibilityFormatValidation = new EligibilityFormatValidation(validations);
    }

    @Test
    public void shouldThrowValidationExceptionWhenLoanSchemeIsNotValid() {

        List<LoanIdentifier> selectedLoan = Arrays.asList(
                new LoanIdentifier("3@", 1),
                new LoanIdentifier("3$", 1),
                new LoanIdentifier("3*", 1),
                new LoanIdentifier("3{", 1),
                new LoanIdentifier("3%", 1),
                new LoanIdentifier("3!", 1)
        );


        selectedLoan.forEach(loanIdentifier -> {

            List<LoanIdentifier> selectedLoanOneElement = createSelectedLoanWithOneElement(loanIdentifier);

            boolean validationThrown = false;

            try {
                eligibilityFormatValidation.validate(1, selectedLoanOneElement);
            } catch (ValidationsException ve) {
                validationThrown = true;
                assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", ve.getCode());
                assertEquals("The loan selected is not valid", ve.getMessage());
            }
            assertTrue(validationThrown, "Loan " + selectedLoanOneElement.toString() + " did not triggered the exception");
        });
    }

    @Test
    public void shouldThrowValidationExceptionWhenApplicationSequenceNumberIsNotValid() {

        List<LoanIdentifier> selectedLoan = Arrays.asList(
                new LoanIdentifier("3R", -11),
                new LoanIdentifier("3R", -1),
                new LoanIdentifier("3R", 123),
                new LoanIdentifier("3R", 1234),
                new LoanIdentifier("3R", 12345),
                new LoanIdentifier("3R", 123456)
        );


        selectedLoan.forEach(loanIdentifier -> {

            List<LoanIdentifier> selectedLoanOneElement = createSelectedLoanWithOneElement(loanIdentifier);

            boolean validationThrown = false;

            try {
                eligibilityFormatValidation.validate(1, selectedLoanOneElement);
            } catch (ValidationsException ve) {
                validationThrown = true;
                assertEquals("The loan selected is not valid", ve.getMessage());
                assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", ve.getCode());
            }
            assertTrue(validationThrown, "Loan " + selectedLoanOneElement.toString() + " did not triggered the exception");
        });
    }

    @Test
    public void shouldThrowValidationExceptionWhenAccountNumberIsNotValid() {
        int[] invalidValues = new int[]{-111111, -1111, -111, -11, -1, 1234567890};
        List<LoanIdentifier> selectedLoan = Collections.singletonList(new LoanIdentifier("3R", 1));

        Arrays.stream(invalidValues).forEach(invalidValue -> {
            boolean validationThrown = false;

            try {
                eligibilityFormatValidation.validate(invalidValue, selectedLoan);
            } catch (ValidationsException ve) {
                validationThrown = true;
                assertEquals("EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT", ve.getCode());
                assertEquals("The input account format is not valid", ve.getMessage());
            }
            assertTrue(validationThrown, "Account " + selectedLoan.toString() + " did not triggered the exception");
        });

    }

    @Test
    public void shouldThrowValidationExceptionWhenAccountNumberIsValidButLoanSchemeIsNot() {
        List<LoanIdentifier> selectedLoan = Collections.singletonList(new LoanIdentifier("3^", 1));

        boolean validationThrown = false;

        try {
            eligibilityFormatValidation.validate(1, selectedLoan);
        } catch (ValidationsException ve) {
            validationThrown = true;
            assertEquals("The loan selected is not valid", ve.getMessage());
            assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", ve.getCode());
        }
        assertTrue(validationThrown, "Loan " + selectedLoan.toString() + " did not triggered the exception");


    }

    @Test
    public void shouldThrowValidationExceptionWhenAccountNumberIsValidButApplicationSequenceNumberIsNot() {
        List<LoanIdentifier> selectedLoan = Collections.singletonList(new LoanIdentifier("3R", -1));

        boolean validationThrown = false;

        try {
            eligibilityFormatValidation.validate(1, selectedLoan);
        } catch (ValidationsException ve) {
            validationThrown = true;
            assertEquals("The loan selected is not valid", ve.getMessage());
            assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", ve.getCode());
        }
        assertTrue(validationThrown, "Loan " + selectedLoan.toString() + " did not triggered the exception");


    }


    private List<LoanIdentifier> createSelectedLoanWithOneElement(LoanIdentifier loanIdentifier) {
        return Collections.singletonList(
                new LoanIdentifier(loanIdentifier.getLoanScheme(), loanIdentifier.getSequenceNumber())
        );
    }
}

package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.model.esis.RetrieveEsisResponse;
import com.santanderuk.corinthian.services.retentions.config.Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class EsisClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private Config config;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    private EsisClient esisClient;

    private static final String ESIS_REF_ID = "esis-ref-id";


    @BeforeEach
    public void setUp() {
        esisClient = new EsisClient(restTemplate, config, apiManagerConfig);
        Mockito.when(config.getRetrieveOfferUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/mrs-esis-core/v1/esis/{esisRefId}");
        Mockito.when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
    }

    @Test
    public void testGetExceptionWhenClientFails() {
        when(restTemplate.exchange(anyString(), ArgumentMatchers.any(), ArgumentMatchers.any(), eq(RetrieveEsisResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> esisClient.retrieveOffer(ESIS_REF_ID));
    }

    @Test
    public void testWeCanRetrieveOffer() throws ConnectionException {

        RetrieveEsisResponse response = new RetrieveEsisResponse();
        RetrieveEsisResponse.Output output = new RetrieveEsisResponse.Output();
        output.setValue("pdfEncoded");
        response.setOutput(output);

        when(restTemplate.exchange(anyString(), ArgumentMatchers.any(), ArgumentMatchers.any(), eq(RetrieveEsisResponse.class))).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        RetrieveEsisResponse result = esisClient.retrieveOffer(ESIS_REF_ID);
        assertNotNull(result);

        assertEquals("pdfEncoded", result.getOutput().getValue());
    }

}

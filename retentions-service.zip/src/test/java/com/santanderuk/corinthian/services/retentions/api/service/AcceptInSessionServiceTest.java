package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorFeeRolledIntoMortgage;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AcceptInSessionServiceTest {

    @Mock
    private OperativeSecurityService operativeSecurityService;

    @Mock
    private GassService gassService;

    @Mock
    private CacheableOperations cacheableOperations;

    @Mock
    private OfferInfoValidatorFeeRolledIntoMortgage offerInfoValidatorFeeRolledIntoMortgage;

    @Mock
    private ProductSwitchClient productSwitchClient;

    private AcceptInSessionService acceptInSessionService;

    @Mock
    private HttpServletRequest httpServletRequest;

    public static final int ACCOUNT_NUMBER = 123456;
    public static final String JWT = "Bearer jwt-token";
    public static final String ESIS_REF_ID = "esis-ref-id";

    @BeforeEach
    public void setUp() {
        acceptInSessionService = new AcceptInSessionService(operativeSecurityService, cacheableOperations, productSwitchClient, offerInfoValidatorFeeRolledIntoMortgage, gassService);
    }

    @Test
    public void testWeCallCacheableOperationsForRegion() throws GeneralException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        acceptInSessionService.acceptInSession(ACCOUNT_NUMBER, JWT, ESIS_REF_ID, httpServletRequest);

        verify(cacheableOperations, times(1)).getAnmfActiveRegion();
    }


    @Test
    public void testWeCallOperativeSecurityToValidateJwt() throws GeneralException {
        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        acceptInSessionService.acceptInSession(ACCOUNT_NUMBER, JWT, ESIS_REF_ID, httpServletRequest);

        verify(operativeSecurityService, times(1)).checkAnmfAccountBelongToCustomerInJwt(anyInt(), anyString(), any());
    }

    @Test
    public void testWeCallProductSwitchClientForOfferInfo() throws GeneralException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));

        acceptInSessionService.acceptInSession(ACCOUNT_NUMBER, JWT, ESIS_REF_ID, httpServletRequest);

        verify(productSwitchClient, times(1)).retrieveOfferInfo(anyString());
    }

    @Test
    public void testWeCallProductSwitchClientForAcceptInSession() throws ConnectionException, MaintenanceException, OperativeSecurityException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));

        acceptInSessionService.acceptInSession(ACCOUNT_NUMBER, JWT, ESIS_REF_ID, httpServletRequest);

        verify(productSwitchClient, times(1)).retrieveOfferInfo(anyString());
        verify(productSwitchClient, times(1)).acceptInSession(anyString());
    }


    @Test
    public void testWeCallGassService() throws GeneralException, JsonProcessingException {
        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        OfferInfoResponse offerInfoResponse = buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(offerInfoResponse);
        acceptInSessionService.acceptInSession(ACCOUNT_NUMBER, JWT, ESIS_REF_ID, httpServletRequest);
        verify(gassService, times(1)).auditProductSwitchAcceptNowInGass(offerInfoResponse.getData().getCoreRetentionsData(), "Bearer jwt-token", 123456, null, httpServletRequest, "1");
    }

    @Test
    public void testWeCallGassServiceWhenAcceptInSessionCallFails() throws GeneralException, JsonProcessingException {
        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        OfferInfoResponse offerInfoResponse = buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(offerInfoResponse);
        Mockito.when(productSwitchClient.acceptInSession(anyString())).thenThrow(ConnectionException.class);
        assertThrows(ConnectionException.class, () -> acceptInSessionService.acceptInSession(ACCOUNT_NUMBER, JWT, ESIS_REF_ID, httpServletRequest));
        verify(gassService, times(1)).auditProductSwitchAcceptNowInGass(offerInfoResponse.getData().getCoreRetentionsData(), "Bearer jwt-token", 123456, null, httpServletRequest, "2");
    }

    private OfferInfoResponse buildRetrieveOfferInfoResponse(String esisRefId, String anmfAccountNumber) {
        OfferInfoResponse response = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setEsisRefId(esisRefId);
        data.setCaseId("case-id");
        data.setAnmfAccountNumber(anmfAccountNumber);

        response.setData(data);
        return response;
    }


}

package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.OutputStructure;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.PropertyEnquiryResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.retentions.FixtureReader;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import com.santanderuk.corinthian.services.retentions.api.service.PafService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
public class CoreRetentionMapperTestBase {

    @Mock
    PafService pafService;

    @InjectMocks
    CoreRetentionMapper mapper;

    @BeforeEach
    public void setUp() throws Exception {

        lenient().when(pafService.fetchCountry(anyString())).thenReturn("UNITED KINGDOM");

        CoreRetentionMapperAccountLoan loanMapper = new CoreRetentionMapperAccountLoan();
        CoreRetentionMapperAccountBorrowers borrowersMapper = new CoreRetentionMapperAccountBorrowers(pafService);
        CoreRetentionMapperAccount coreRetentionMapperAccount = new CoreRetentionMapperAccount(loanMapper, borrowersMapper, pafService);
        CoreRetentionMapperProduct coreRetentionMapperProduct = new CoreRetentionMapperProduct();
        CoreRetentionMapperFlags coreRetentionMapperFlags = new CoreRetentionMapperFlags();
        CoreRetentionMapperGeneralInformation coreRetentionMapperGeneralInformation = new CoreRetentionMapperGeneralInformation();
        CoreRetentionMapperAdvisorInformation coreRetentionMapperAdvisorInformation = new CoreRetentionMapperAdvisorInformation();
        CoreRetentionMapperBookingInformation coreRetentionMapperBookingInformation = new CoreRetentionMapperBookingInformation();
        CoreRetentionMapperApplicationInformation coreRetentionMapperApplicationInformation = new CoreRetentionMapperApplicationInformation();
        CoreRetentionMapperOfferConversionDetails coreRetentionMapperOfferConversionDetails = new CoreRetentionMapperOfferConversionDetails();

        mapper = new CoreRetentionMapper(
                coreRetentionMapperAccount,
                coreRetentionMapperProduct,
                coreRetentionMapperFlags,
                coreRetentionMapperGeneralInformation,
                coreRetentionMapperAdvisorInformation,
                coreRetentionMapperBookingInformation,
                coreRetentionMapperApplicationInformation,
                coreRetentionMapperOfferConversionDetails);
    }

    protected ANMFPropertyResponse createAddressResponse() {
        OutputStructure output = new OutputStructure();
        output.setOPropertyAddr1("AddressLine1");
        output.setOPropertyAddr2("AddressLine2");
        output.setOPropertyAddr3("AddressLine3");
        output.setOPropertyAddr4("AddressLine4");
        output.setOPropertyPostcode("MK9 1LA");
        output.setOPropertyCountry("ENGLAND & WALES");
        output.setOPropertyCountryComm("ENGLAND");
        output.setOPropertyCounty("MK9");
        output.setOSpecialPurchase("A");

        PropertyEnquiryResponse operation = new PropertyEnquiryResponse();
        operation.setOutputStructure(output);
        ANMFPropertyResponse anmfAddressResponse = new ANMFPropertyResponse();
        anmfAddressResponse.setPropertyEnquiryResponse(operation);
        return anmfAddressResponse;
    }

    protected AnmfAccountServiceResponse generateMultiLoanResponseForPickingTheLongest() {
        AnmfAccountServiceResponse loanPartsResponse = generateANMFLoanResponseRemainingInstalments(1);
        // Adding second loan with bigger remainingInstallment
        OActiveLoanDetail loan = generateDefaultLoan();
        loan.setORemainingInstlm(114);
        loanPartsResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(loan);
        return loanPartsResponse;
    }

    protected AnmfAccountServiceResponse generateANMFLoanResponseRemainingInstalments(int i) {
        AnmfAccountServiceResponse loanPartsResponse = generateDefaultAnmfAccountResponse();
        loanPartsResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORemainingInstlm(i);
        return loanPartsResponse;
    }

    protected OActiveLoanDetail generateDefaultLoan() {
        OActiveLoanDetail oLoan = new OActiveLoanDetail();

        oLoan.setORemainingInstlm(0);
        oLoan.setORepaymentType("R");
        oLoan.setOLoanScheme("3T");
        oLoan.setOApplSeqNo(1);
        oLoan.setOProductType("FIXED");
        oLoan.setOCapitalBalance(new BigDecimal("1.00"));
        oLoan.setOProductCode("PR00");
        oLoan.setOInterestRate(new BigDecimal("1.00"));
        oLoan.setOProductEndDate("28/08/2019");
        oLoan.setORedemptionDate("29/09/2020");
        return oLoan;
    }

    protected CoreRetentionsData generateDefaultMapperInput() {
        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setCaseRequest(generateDefaultCaseRequest());
        coreRetentionsData.setSelectedDeal(generateDefaultDeal());
        coreRetentionsData.setAccount(100001234);
        coreRetentionsData.setAnmfAccountServiceResponse(generateDefaultAnmfAccountResponse());
        coreRetentionsData.setAddressResponse(createAddressResponse());
        coreRetentionsData.setCustomerDetailsResponse(generateDefaultAnmfBorrowerInfoResponse());
        coreRetentionsData.setBdpType("F");
        coreRetentionsData.setBdpNumber(12345678);
        return coreRetentionsData;
    }

    protected CoreRetentionsData generateDefaultMapperInputTwo() throws IOException {
        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setCaseRequest(generateDefaultCaseRequestTwo());
        coreRetentionsData.setAnmfAccountServiceResponse(generateDefaultAnmfAccountResponseTwo());
        coreRetentionsData.setSelectedDeal(generateSelectedDeal());
        coreRetentionsData.setAccount(100001234);
        coreRetentionsData.setAddressResponse(createAddressResponse());
        coreRetentionsData.setCustomerDetailsResponse(generateDefaultAnmfBorrowerInfoResponse());
        coreRetentionsData.setBdpType("F");
        coreRetentionsData.setBdpNumber(12345678);
        return coreRetentionsData;
    }

    private AnmfAccountServiceResponse generateDefaultAnmfAccountResponseTwo() throws IOException {
        return FixtureReader.get("account-details/account-details-12204702.json", AnmfAccountServiceResponse.class);
    }

    private Deal generateSelectedDeal() throws IOException {
        return FixtureReader.get("deal-service-response/deal-service-response-12204702.json", Deal.class);
    }

    protected CustomerDetailsResponse generateDefaultAnmfBorrowerInfoResponse() {
        CustomerDetailsResponse customerDetailsResponse = new CustomerDetailsResponse();

        CustomerServiceResponse operationResponse = new CustomerServiceResponse();
        com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc outputStruct = new com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc();
        List<OCustomer> customerList = new ArrayList<>();
        customerList.add(generateDefaultBorrower());
        outputStruct.setOCustomerList(customerList);
        operationResponse.setOStruc(outputStruct);
        customerDetailsResponse.setCustomerServiceResponse(operationResponse);
        return customerDetailsResponse;
    }

    protected OCustomer generateDefaultBorrower() {

        OCustomer oCustomer = new OCustomer();
        oCustomer.setOCustomerNo(1);
        oCustomer.setOBdpType("F");
        oCustomer.setOCustomerId(12345678);
        oCustomer.setOCustomerTitle("Mr");
        oCustomer.setOSurname("Surname");
        oCustomer.setOForename1("Forename1");
        oCustomer.setOForename2("Forename2");
        oCustomer.setOForename3("Forename3");
        oCustomer.setOCcnFlag("CnnFlag");
        oCustomer.setOCcnFlagDate("CnnFlagDate");

        oCustomer.setOInitials("J K");
        oCustomer.setOStaffMortgage("Y");
        oCustomer.setODateOfBirth("02/12/1976");

        oCustomer.setOMobilePhone("07777111111");
        oCustomer.setOHomePhone("02222111111");
        oCustomer.setOEMailAddress("a@a.com");
        oCustomer.setOCorrespAddr1("address1");
        oCustomer.setOCorrespAddr2("address2");
        oCustomer.setOCorrespAddr3("address3");
        oCustomer.setOCorrespAddr4("address4");
        oCustomer.setOCorrespPostcode("postcode");
        oCustomer.setOCorrespCountry("country");

        return oCustomer;
    }

    protected OCustomer generateAdditionalBorrower(int i) {
        OCustomer borrower = new OCustomer();
        borrower.setOCustomerNo(i);
        borrower.setOBdpType("F" + i);
        borrower.setOCustomerId(900000000 + i);
        borrower.setOCustomerTitle("Mr" + i);
        borrower.setOSurname("Surname" + i);
        borrower.setOForename1("Forename1" + i);
        borrower.setOForename2("Forename2" + i);
        borrower.setOForename3("Forename3" + i);
        borrower.setOCcnFlag("CnnFlag" + i);
        borrower.setOCcnFlagDate("CnnFlagDate" + i);
        borrower.setOInitials("J K" + i);

        borrower.setOStaffMortgage("N");
        borrower.setODateOfBirth("02/12/1977");
        borrower.setOMobilePhone("07777222222");
        borrower.setOHomePhone("02222222222");
        borrower.setOEMailAddress("b@b.com");
        borrower.setOCorrespAddr1("2address1");
        borrower.setOCorrespAddr2("2address2");
        borrower.setOCorrespAddr3("2address3");
        borrower.setOCorrespAddr4("2address4");
        borrower.setOCorrespPostcode("2postcode");
        borrower.setOCorrespCountry("2country");

        return borrower;
    }

    protected AnmfAccountServiceResponse generateDefaultAnmfAccountResponse() {
        OActiveLoan loan = new OActiveLoan();
        loan.setOLoanId(1);
        loan.setOLoanSch("3T");
        loan.setOApplSeqNo(1);

        ArrayList<OActiveLoan> oActiveLoans = new ArrayList<>();
        oActiveLoans.add(loan);

        List<OActiveLoanDetail> oActiveLoanDetails = new ArrayList<>();
        OActiveLoanDetail oLoan = generateDefaultLoan();
        oActiveLoanDetails.add(oLoan);

        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoans(oActiveLoans);
        oStruc.setOActiveLoanDetails(oActiveLoanDetails);
        oStruc.setOGovernanceType("FSA");
        oStruc.setOCapitalBalance(new BigDecimal("3345.45"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse response = new AnmfAccountServiceResponse();
        response.setAccountServiceResponse(accountServiceResponse);
        return response;
    }

    protected Deal generateDefaultDeal() {
        Deal deal = new Deal();

        Product product1 = new Product();
        product1.setProductCode("PR00");
        product1.setDescription("Desc0");
        product1.setProductFee(new BigDecimal("0.00"));
        product1.setRate(new BigDecimal("1.39"));
        product1.setType("FIXED");
        deal.setProduct(product1);
        deal.setLoanToApplyTheFeeTo(2);

        List<DealLoanView> loanList = new ArrayList<>();
        loanList.add(generateLoan1());
        loanList.add(generateLoan2());

        deal.setDealLoans(loanList);
        return deal;
    }

    private DealLoanView generateLoan1() {
        DealLoanView loan = new DealLoanView();
        loan.setApplyFeeInThisLoan(true);
        return loan;
    }

    private DealLoanView generateLoan2() {
        DealLoanView loan = new DealLoanView();
        loan.setApplyFeeInThisLoan(false);
        return loan;
    }

    protected CreateCaseRequest generateDefaultCaseRequest() {
        CreateCaseRequest createCaseRequest = new CreateCaseRequest();
        createCaseRequest.setEmailAddress("c@c.com");
        createCaseRequest.setMobileNumber("07777333333");
        createCaseRequest.setProductCode("PR00");
        createCaseRequest.setFeeAddedInMortgage(true);
        createCaseRequest.setLoansSelected(generateDefaultSelectedLoans());
        return createCaseRequest;
    }

    protected List<LoanIdentifier> generateDefaultSelectedLoans() {
        ArrayList<LoanIdentifier> loanIdentifiers = new ArrayList<>();

        LoanIdentifier loanIdentifier = new LoanIdentifier();
        loanIdentifier.setLoanScheme("3T");
        loanIdentifier.setSequenceNumber(1);

        LoanIdentifier loanIdentifierTwo = new LoanIdentifier();
        loanIdentifierTwo.setLoanScheme("YOU");
        loanIdentifierTwo.setSequenceNumber(3);

        loanIdentifiers.add(loanIdentifier);
        loanIdentifiers.add(loanIdentifierTwo);
        return loanIdentifiers;
    }

    protected CreateCaseRequest generateDefaultCaseRequestTwo() {
        CreateCaseRequest createCaseRequest = new CreateCaseRequest();
        createCaseRequest.setEmailAddress("c@c.com");
        createCaseRequest.setMobileNumber("07777333333");
        createCaseRequest.setProductCode("PR00");
        createCaseRequest.setFeeAddedInMortgage(true);
        createCaseRequest.setLoansSelected(generateDefaultSelectedLoansTwo());
        return createCaseRequest;
    }

    protected List<LoanIdentifier> generateDefaultSelectedLoansTwo() {
        ArrayList<LoanIdentifier> loanIdentifiers = new ArrayList<>();

        LoanIdentifier loanIdentifier = new LoanIdentifier();
        loanIdentifier.setLoanScheme("3T");
        loanIdentifier.setSequenceNumber(6);

        LoanIdentifier loanIdentifierTwo = new LoanIdentifier();
        loanIdentifierTwo.setLoanScheme("3T");
        loanIdentifierTwo.setSequenceNumber(8);

        loanIdentifiers.add(loanIdentifier);
        loanIdentifiers.add(loanIdentifierTwo);
        return loanIdentifiers;
    }

    protected CreateCaseRequest genericOfferRequest() {
        CreateCaseRequest caseRequest = new CreateCaseRequest();
        caseRequest.setProductCode("PR00");
        List<LoanIdentifier> loansSelected = createLoansSelected();
        caseRequest.setLoansSelected(loansSelected);
        caseRequest.setMobileNumber("07123444444");
        caseRequest.setEmailAddress("a@a.com");
        caseRequest.setFeeAddedInMortgage(true);
        return caseRequest;
    }

    private List<LoanIdentifier> createLoansSelected() {
        List<LoanIdentifier> loans = new ArrayList<>();
        loans.add(createLoan());
        return loans;
    }

    private LoanIdentifier createLoan() {
        LoanIdentifier loanIdentifier = new LoanIdentifier();
        loanIdentifier.setLoanScheme("3T");
        loanIdentifier.setSequenceNumber(1);
        return loanIdentifier;
    }
}

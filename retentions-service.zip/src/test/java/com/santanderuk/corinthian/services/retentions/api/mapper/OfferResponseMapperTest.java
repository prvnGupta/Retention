package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve.RetrieveOfferResponse;
import com.santanderuk.corinthian.services.retentions.api.model.esis.RetrieveEsisResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class OfferResponseMapperTest {

    private OfferResponseMapper mapper;

    @BeforeEach
    public void setUp() throws Exception {
        mapper = new OfferResponseMapper();
    }

    @Test
    public void testWeReturnDownloadedTrueWhenDateExists() {

        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setOfferDownloadedDateTime("2020-04-10T00:00:00.000");
        offerInfoResponse.setData(data);

        RetrieveEsisResponse esisResponse = new RetrieveEsisResponse();
        RetrieveEsisResponse.Output output = new RetrieveEsisResponse.Output();
        output.setValue("pdfString");
        esisResponse.setOutput(output);

        RetrieveOfferResponse offerResponse = mapper.mapToResponse(offerInfoResponse, esisResponse);

        assertThat(offerResponse.getPdfString(), equalTo("pdfString"));
        assertThat(offerResponse.isDownloaded(), equalTo(true));
    }

    @Test
    public void testWeReturnDownloadedFalseWhenDateIsNull() {

        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        offerInfoResponse.setData(data);

        RetrieveEsisResponse esisResponse = new RetrieveEsisResponse();
        RetrieveEsisResponse.Output output = new RetrieveEsisResponse.Output();
        output.setValue("pdfString");
        esisResponse.setOutput(output);

        RetrieveOfferResponse offerResponse = mapper.mapToResponse(offerInfoResponse, esisResponse);

        assertThat(offerResponse.getPdfString(), equalTo("pdfString"));
        assertThat(offerResponse.isDownloaded(), equalTo(false));
    }
}

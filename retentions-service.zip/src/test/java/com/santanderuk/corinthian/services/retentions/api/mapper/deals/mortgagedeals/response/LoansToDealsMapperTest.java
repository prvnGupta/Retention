package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.retentions.FixtureReader;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MapperSourceData;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.InterestRateChange;
import com.santanderuk.corinthian.services.retentions.api.utils.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response.MortgageDealsClientResponseMapperTest.loanMortgageDealsFixture;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class LoansToDealsMapperTest {

    LoansToDealsMapper loansToDealsMapper;

    @Mock
    private DateUtils mockDateUtils;

    @BeforeEach
    void setUp() {
        loansToDealsMapper = new LoansToDealsMapper(mockDateUtils);
    }

    @Test
    void shouldMapDataCorrectlyWhenProductHasFee() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-12204702.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceData());

        // element 1
        assertFalse(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertEquals("3 Year Fixed", dealLoansViewList.get(0).getProductTitle());
        assertEquals(new BigDecimal("1.49"), dealLoansViewList.get(0).getInterestRate());
        assertEquals(new BigDecimal("3009"), dealLoansViewList.get(0).getLoanBalance());
        assertEquals(new BigDecimal("10.00"), dealLoansViewList.get(0).getAnnualOverpaymentAllowance());
        assertEquals(new BigDecimal("90.27"), dealLoansViewList.get(0).getEarlyRepaymentChargeAsAmount());
        assertEquals("INTEREST_ONLY", dealLoansViewList.get(0).getRepaymentType());
        assertEquals("5 years 6 months", dealLoansViewList.get(0).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), dealLoansViewList.get(0).getBankOfEnglandBaseRate());
        assertFalse(dealLoansViewList.get(0).isVariable());
        assertEquals(new BigDecimal("3.74"), dealLoansViewList.get(0).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("3.74"), dealLoansViewList.get(0).getMonthlyPaymentWithoutFee());
        assertFalse(dealLoansViewList.get(0).isProductWithFee());
        assertFalse(dealLoansViewList.get(0).isApplyFeeInThisLoan());
        assertEquals(new BigDecimal("3009"), dealLoansViewList.get(0).getNewOutstandingBalance());
        assertTrue(dealLoansViewList.get(0).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(0).isLifetimeTermFlag());
        assertFalse(dealLoansViewList.get(0).isCurrentProductTrackerFlag());
        assertFalse(dealLoansViewList.get(0).isStepErc());
        assertEquals(new BigDecimal("3.35"), dealLoansViewList.get(0).getSantanderFollowOnRate());
        assertEquals(new BigDecimal("5.00"), dealLoansViewList.get(0).getEarlyRepaymentChargeAsPercentage());
        assertEquals("FoR", dealLoansViewList.get(0).getReversionProduct());

        // element 2
        assertTrue(dealLoansViewList.get(1).isTransferring());
        assertEquals(2, dealLoansViewList.get(1).getLoanId());
        assertEquals("2 Year Tracker", dealLoansViewList.get(1).getProductTitle());
        assertEquals(new BigDecimal("1.19"), dealLoansViewList.get(1).getInterestRate());
        assertEquals(new BigDecimal("15021.34"), dealLoansViewList.get(1).getLoanBalance());
        assertEquals(new BigDecimal("0.00"), dealLoansViewList.get(1).getAnnualOverpaymentAllowance());
        assertEquals("REPAYMENT", dealLoansViewList.get(1).getRepaymentType());
        assertEquals("5 years 6 months", dealLoansViewList.get(1).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), dealLoansViewList.get(1).getBankOfEnglandBaseRate());
        assertTrue(dealLoansViewList.get(1).isVariable());
        assertEquals(new BigDecimal("341.93"), dealLoansViewList.get(1).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("320.61"), dealLoansViewList.get(1).getMonthlyPaymentWithoutFee());
        assertTrue(dealLoansViewList.get(1).isProductWithFee());
        assertEquals(new BigDecimal("16020.34"), dealLoansViewList.get(1).getNewOutstandingBalance());
        assertEquals(new BigDecimal("999"), dealLoansViewList.get(1).getProductFee());
        assertEquals(new BigDecimal("3"), dealLoansViewList.get(1).getTrackingRate());
        assertTrue(dealLoansViewList.get(1).isApplyFeeInThisLoan());
        assertTrue(dealLoansViewList.get(1).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(1).isLifetimeTermFlag());
        assertTrue(dealLoansViewList.get(1).isCurrentProductTrackerFlag());
        assertEquals("2 Year Tracker(variable) at 1.19%", dealLoansViewList.get(1).getPreviousProduct());
        assertEquals(new BigDecimal("0"), dealLoansViewList.get(1).getEarlyRepaymentChargeAsPercentage());
        assertEquals(InterestRateChange.SAME, dealLoansViewList.get(1).getInterestRateChange());
        assertFalse(dealLoansViewList.get(1).isStepErc());
        assertEquals(new BigDecimal("3.75"), dealLoansViewList.get(1).getSantanderFollowOnRate());
        assertEquals("FoR", dealLoansViewList.get(1).getReversionProduct());

        // element 3
        assertFalse(dealLoansViewList.get(2).isTransferring());
        assertEquals(3, dealLoansViewList.get(2).getLoanId());
        assertEquals("3 Year Fixed", dealLoansViewList.get(2).getProductTitle());
        assertEquals(new BigDecimal("1.49"), dealLoansViewList.get(2).getInterestRate());
        assertEquals(new BigDecimal("9233.16"), dealLoansViewList.get(2).getLoanBalance());
        assertEquals(new BigDecimal("10.00"), dealLoansViewList.get(2).getAnnualOverpaymentAllowance());
        assertEquals(new BigDecimal("276.99"), dealLoansViewList.get(2).getEarlyRepaymentChargeAsAmount());
        assertEquals("REPAYMENT", dealLoansViewList.get(2).getRepaymentType());
        assertEquals("5 years 6 months", dealLoansViewList.get(2).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), dealLoansViewList.get(2).getBankOfEnglandBaseRate());
        assertFalse(dealLoansViewList.get(2).isVariable());
        assertEquals(new BigDecimal("198.26"), dealLoansViewList.get(2).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("198.26"), dealLoansViewList.get(2).getMonthlyPaymentWithoutFee());
        assertFalse(dealLoansViewList.get(2).isProductWithFee());
        assertEquals(new BigDecimal("9233.16"), dealLoansViewList.get(2).getNewOutstandingBalance());
        assertFalse(dealLoansViewList.get(2).isApplyFeeInThisLoan());
        assertTrue(dealLoansViewList.get(2).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(2).isLifetimeTermFlag());
        assertFalse(dealLoansViewList.get(2).isCurrentProductTrackerFlag());
        assertFalse(dealLoansViewList.get(2).isStepErc());
        assertEquals(new BigDecimal("3.35"), dealLoansViewList.get(2).getSantanderFollowOnRate());
        assertEquals("FoR", dealLoansViewList.get(2).getReversionProduct());


        // element 4
        assertTrue(dealLoansViewList.get(3).isTransferring());
        assertEquals(4, dealLoansViewList.get(3).getLoanId());
        assertEquals("2 Year Tracker", dealLoansViewList.get(3).getProductTitle());
        assertEquals(new BigDecimal("1.19"), dealLoansViewList.get(3).getInterestRate());
        assertEquals(new BigDecimal("1956.19"), dealLoansViewList.get(3).getLoanBalance());
        assertEquals(new BigDecimal("0.00"), dealLoansViewList.get(3).getAnnualOverpaymentAllowance());
        assertEquals("REPAYMENT", dealLoansViewList.get(3).getRepaymentType());
        assertEquals("5 years 6 months", dealLoansViewList.get(3).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), dealLoansViewList.get(3).getBankOfEnglandBaseRate());
        assertTrue(dealLoansViewList.get(3).isVariable());
        assertEquals(new BigDecimal("41.75"), dealLoansViewList.get(3).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("41.75"), dealLoansViewList.get(3).getMonthlyPaymentWithoutFee());
        assertTrue(dealLoansViewList.get(3).isProductWithFee());
        assertEquals(new BigDecimal("1956.19"), dealLoansViewList.get(3).getNewOutstandingBalance());
        assertEquals(new BigDecimal("999"), dealLoansViewList.get(3).getProductFee());
        assertEquals(new BigDecimal("3"), dealLoansViewList.get(3).getTrackingRate());
        assertFalse(dealLoansViewList.get(3).isApplyFeeInThisLoan());
        assertFalse(dealLoansViewList.get(3).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(3).isLifetimeTermFlag());
        assertTrue(dealLoansViewList.get(3).isCurrentProductTrackerFlag());
        assertEquals("Lifetime Tracker(variable) at 3.35%", dealLoansViewList.get(3).getPreviousProduct());
        assertEquals(new BigDecimal("0"), dealLoansViewList.get(3).getEarlyRepaymentChargeAsPercentage());
        assertEquals(InterestRateChange.HIGHER, dealLoansViewList.get(3).getInterestRateChange());
        assertFalse(dealLoansViewList.get(3).isStepErc());
        assertEquals(new BigDecimal("3.75"), dealLoansViewList.get(3).getSantanderFollowOnRate());
        assertEquals("FoR", dealLoansViewList.get(3).getReversionProduct());

    }

    @Test
    void setLoanReversionProductForLoansNotTransferring() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-12204702.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceDataLifetimeLoanNotTransferring());

        // element 1
        assertFalse(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertEquals("3 Year Fixed", dealLoansViewList.get(0).getProductTitle());
        assertEquals("FoR", dealLoansViewList.get(0).getReversionProduct());

        // element 2
        assertTrue(dealLoansViewList.get(1).isTransferring());
        assertEquals(2, dealLoansViewList.get(1).getLoanId());
        assertEquals("2 Year Tracker", dealLoansViewList.get(1).getProductTitle());
        assertEquals("FoR", dealLoansViewList.get(1).getReversionProduct());

        // element 3
        assertFalse(dealLoansViewList.get(2).isTransferring());
        assertEquals(3, dealLoansViewList.get(2).getLoanId());
        assertEquals("3 Year Fixed", dealLoansViewList.get(2).getProductTitle());
        assertEquals("SVR", dealLoansViewList.get(2).getReversionProduct());

        // element 4
        assertFalse(dealLoansViewList.get(3).isTransferring());
        assertEquals(4, dealLoansViewList.get(3).getLoanId());
        assertEquals("Lifetime Tracker", dealLoansViewList.get(3).getProductTitle());
        assertEquals("N/A", dealLoansViewList.get(3).getReversionProduct());

    }

    @Test
    void setLoanReversionProductProductSelectedRevertingToSVR() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(4), createSourceDataForSVR());

        // element 1
        assertTrue(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertEquals("2 Year Tracker", dealLoansViewList.get(0).getProductTitle());
        assertEquals("SVR", dealLoansViewList.get(0).getReversionProduct());
    }

    @Test
    void setLoanReversionProductProductSelectedRevertingToSFOR() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(3), createSourceDataForSVR());

        // element 1
        assertTrue(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertEquals("2 Year Tracker", dealLoansViewList.get(0).getProductTitle());
        assertEquals("FoR", dealLoansViewList.get(0).getReversionProduct());
    }

    @Test
    void setLoanReversionProductProductSelectedSVR() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(11), createSourceDataForSVR());

        // element 1
        assertTrue(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertEquals("Standard Variable Rate", dealLoansViewList.get(0).getProductTitle());
        assertEquals("N/A", dealLoansViewList.get(0).getReversionProduct());
    }

    @Test
    void setLoanReversionProductProductSelectedLifetimeTracker() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(12), createSourceDataForSVR());

        // element 1
        assertTrue(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertEquals("Lifetime Tracker", dealLoansViewList.get(0).getProductTitle());
        assertEquals("N/A", dealLoansViewList.get(0).getReversionProduct());
    }

    @Test
    void shouldMapProductOverpaymentAllowanceOnlyIfERCisApplicable() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-12204702.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        mortgageDealsResponse.getProducts().get(0).setOverpaymentAllowance(new BigDecimal("10.00"));
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceData());

        // element 1
        assertFalse(dealLoansViewList.get(0).isTransferring());
        assertEquals(new BigDecimal("10.00"), dealLoansViewList.get(0).getAnnualOverpaymentAllowance());

        // element 2
        assertTrue(dealLoansViewList.get(1).isTransferring());
        assertEquals(new BigDecimal("0.00"), dealLoansViewList.get(1).getAnnualOverpaymentAllowance());

        // element 3
        assertFalse(dealLoansViewList.get(2).isTransferring());
        assertEquals(new BigDecimal("10.00"), dealLoansViewList.get(2).getAnnualOverpaymentAllowance());

        // element 4
        assertTrue(dealLoansViewList.get(3).isTransferring());
        assertEquals(new BigDecimal("0.00"), dealLoansViewList.get(3).getAnnualOverpaymentAllowance());

    }

    @Test
    void mapProductStartDateAndProductEndDate() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-12204702.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceData());

        // element 1
        assertFalse(dealLoansViewList.get(0).isTransferring());
        assertEquals("02/04/2025", dealLoansViewList.get(0).getProductEndDate());
        assertNull(dealLoansViewList.get(0).getProductStartDate());

        // element 2
        assertTrue(dealLoansViewList.get(1).isTransferring());
        assertEquals("24 months", dealLoansViewList.get(1).getProductEndDate());
        assertNull(dealLoansViewList.get(1).getProductStartDate());


        // element 3
        assertFalse(dealLoansViewList.get(2).isTransferring());
        assertEquals("02/04/2025", dealLoansViewList.get(2).getProductEndDate());
        assertNull(dealLoansViewList.get(2).getProductStartDate());
        // element 4
        assertTrue(dealLoansViewList.get(3).isTransferring());
        assertEquals("24 months", dealLoansViewList.get(3).getProductEndDate());
        assertEquals("14/12/2021", dealLoansViewList.get(3).getProductStartDate());

    }

    @Test
    void shouldMapHigherERCStepValueToERCPercentageFieldForTransferringLoans() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-SteppedERC.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceData());
        assertEquals(new BigDecimal("3"), dealLoansViewList.get(1).getEarlyRepaymentChargeAsPercentage());
        assertEquals(new BigDecimal("3"), dealLoansViewList.get(3).getEarlyRepaymentChargeAsPercentage());
    }

    @Test
    void standardVariableRateNameTransferringLoansToSVR() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceDataForSVR());
        assertEquals("5 Year Fixed", dealLoansViewList.get(0).getProductTitle());


        List<DealLoanView> dealLoansViewList1 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(1), createSourceDataForSVR());
        assertEquals("7 Year Fixed", dealLoansViewList1.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList2 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(2), createSourceDataForSVR());
        assertEquals("5 Year Fixed", dealLoansViewList2.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList3 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(3), createSourceDataForSVR());
        assertEquals("2 Year Tracker", dealLoansViewList3.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList4 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(4), createSourceDataForSVR());
        assertEquals("2 Year Tracker", dealLoansViewList4.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList5 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(5), createSourceDataForSVR());
        assertEquals("2 Year Fixed", dealLoansViewList5.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList6 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(6), createSourceDataForSVR());
        assertEquals("2 Year Fixed", dealLoansViewList6.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList7 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(7), createSourceDataForSVR());
        assertEquals("3 Year Fixed", dealLoansViewList7.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList8 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(8), createSourceDataForSVR());
        assertEquals("1 Year Fixed", dealLoansViewList8.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList9 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(9), createSourceDataForSVR());
        assertEquals("2 Year Fixed", dealLoansViewList9.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList10 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(10), createSourceDataForSVR());
        assertEquals("Lifetime Tracker", dealLoansViewList10.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList11 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(11), createSourceDataForSVR());
        assertEquals("Standard Variable Rate", dealLoansViewList11.get(0).getProductTitle());

        List<DealLoanView> dealLoansViewList12 = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(12), createSourceDataForSVR());
        assertEquals("Lifetime Tracker", dealLoansViewList12.get(0).getProductTitle());

    }

    @Test
    void shouldMapDataForIsStepErcFlagForLoansTransferringAndNotTransferring() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-SteppedERC.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), createSourceData());
        assertFalse(dealLoansViewList.get(0).isStepErc());
        assertTrue(dealLoansViewList.get(1).isStepErc());
        assertFalse(dealLoansViewList.get(2).isStepErc());
        assertTrue(dealLoansViewList.get(3).isStepErc());
    }

    @Test
    void shouldMapDataCorrectlyWhenProductHasNoFee() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-12204702.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        List<DealLoanView> serviceResponse = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(1), createSourceData());

        // element 1
        assertFalse(serviceResponse.get(0).isTransferring());
        assertEquals(1, serviceResponse.get(0).getLoanId());
        assertEquals("3 Year Fixed", serviceResponse.get(0).getProductTitle());
        assertEquals(new BigDecimal("1.49"), serviceResponse.get(0).getInterestRate());
        assertEquals(new BigDecimal("3009"), serviceResponse.get(0).getLoanBalance());
        assertEquals(new BigDecimal("3.35"), serviceResponse.get(0).getSantanderFollowOnRate());
        assertEquals(new BigDecimal("10.00"), serviceResponse.get(0).getAnnualOverpaymentAllowance());
        assertEquals(new BigDecimal("90.27"), serviceResponse.get(0).getEarlyRepaymentChargeAsAmount());
        assertEquals("02/04/2025", serviceResponse.get(0).getProductEndDate());
        assertEquals("INTEREST_ONLY", serviceResponse.get(0).getRepaymentType());
        assertEquals("5 years 6 months", serviceResponse.get(0).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), serviceResponse.get(0).getBankOfEnglandBaseRate());
        assertFalse(serviceResponse.get(0).isVariable());
        assertEquals(new BigDecimal("3.74"), serviceResponse.get(0).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("3.74"), serviceResponse.get(0).getMonthlyPaymentWithoutFee());
        assertFalse(serviceResponse.get(0).isProductWithFee());
        assertFalse(serviceResponse.get(0).isApplyFeeInThisLoan());
        assertEquals(new BigDecimal("3009"), serviceResponse.get(0).getNewOutstandingBalance());
        assertTrue(serviceResponse.get(0).isCurrentProductFixedTermFlag());
        assertFalse(serviceResponse.get(0).isLifetimeTermFlag());
        assertFalse(serviceResponse.get(0).isCurrentProductTrackerFlag());

        // element 2
        assertTrue(serviceResponse.get(1).isTransferring());
        assertEquals(2, serviceResponse.get(1).getLoanId());
        assertEquals("Lifetime Tracker", serviceResponse.get(1).getProductTitle());
        assertEquals(new BigDecimal("3.35"), serviceResponse.get(1).getInterestRate());
        assertEquals(new BigDecimal("15021.34"), serviceResponse.get(1).getLoanBalance());
        assertEquals(new BigDecimal("3.75"), serviceResponse.get(1).getSantanderFollowOnRate());
        assertEquals(new BigDecimal("0.00"), serviceResponse.get(1).getAnnualOverpaymentAllowance());
        assertEquals("REPAYMENT", serviceResponse.get(1).getRepaymentType());
        assertEquals("5 years 6 months", serviceResponse.get(1).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), serviceResponse.get(1).getBankOfEnglandBaseRate());
        assertTrue(serviceResponse.get(1).isVariable());
        assertEquals(new BigDecimal("334.82"), serviceResponse.get(1).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("334.82"), serviceResponse.get(1).getMonthlyPaymentWithoutFee());
        assertFalse(serviceResponse.get(1).isProductWithFee());
        assertEquals(new BigDecimal("15021.34"), serviceResponse.get(1).getNewOutstandingBalance());
        assertEquals(new BigDecimal("0"), serviceResponse.get(1).getProductFee());
        assertEquals(new BigDecimal("0.1"), serviceResponse.get(1).getTrackingRate());
        assertFalse(serviceResponse.get(1).isApplyFeeInThisLoan());
        assertTrue(serviceResponse.get(1).isCurrentProductFixedTermFlag());
        assertTrue(serviceResponse.get(1).isLifetimeTermFlag());
        assertTrue(serviceResponse.get(1).isCurrentProductTrackerFlag());
        assertEquals("2 Year Tracker(variable) at 1.19%", serviceResponse.get(1).getPreviousProduct());
        assertEquals(InterestRateChange.HIGHER, serviceResponse.get(1).getInterestRateChange());

        // element 3
        assertFalse(serviceResponse.get(2).isTransferring());
        assertEquals(3, serviceResponse.get(2).getLoanId());
        assertEquals("3 Year Fixed", serviceResponse.get(2).getProductTitle());
        assertEquals(new BigDecimal("1.49"), serviceResponse.get(2).getInterestRate());
        assertEquals(new BigDecimal("9233.16"), serviceResponse.get(2).getLoanBalance());
        assertEquals(new BigDecimal("3.35"), serviceResponse.get(2).getSantanderFollowOnRate());
        assertEquals(new BigDecimal("10.00"), serviceResponse.get(2).getAnnualOverpaymentAllowance());
        assertEquals(new BigDecimal("276.99"), serviceResponse.get(2).getEarlyRepaymentChargeAsAmount());
        assertEquals("REPAYMENT", serviceResponse.get(2).getRepaymentType());
        assertEquals("5 years 6 months", serviceResponse.get(2).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), serviceResponse.get(2).getBankOfEnglandBaseRate());
        assertFalse(serviceResponse.get(2).isVariable());
        assertEquals(new BigDecimal("198.26"), serviceResponse.get(2).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("198.26"), serviceResponse.get(2).getMonthlyPaymentWithoutFee());
        assertFalse(serviceResponse.get(2).isProductWithFee());
        assertEquals(new BigDecimal("9233.16"), serviceResponse.get(2).getNewOutstandingBalance());
        assertFalse(serviceResponse.get(2).isApplyFeeInThisLoan());
        assertTrue(serviceResponse.get(2).isCurrentProductFixedTermFlag());
        assertFalse(serviceResponse.get(2).isLifetimeTermFlag());
        assertFalse(serviceResponse.get(2).isCurrentProductTrackerFlag());

        // element 4
        assertTrue(serviceResponse.get(3).isTransferring());
        assertEquals(4, serviceResponse.get(3).getLoanId());
        assertEquals("Lifetime Tracker", serviceResponse.get(3).getProductTitle());
        assertEquals(new BigDecimal("3.35"), serviceResponse.get(3).getInterestRate());
        assertEquals(new BigDecimal("1956.19"), serviceResponse.get(3).getLoanBalance());
        assertEquals(new BigDecimal("3.75"), serviceResponse.get(3).getSantanderFollowOnRate());
        assertEquals(new BigDecimal("0.00"), serviceResponse.get(3).getAnnualOverpaymentAllowance());
        assertEquals("REPAYMENT", serviceResponse.get(3).getRepaymentType());
        assertEquals("5 years 6 months", serviceResponse.get(3).getRemainingTerm());
        assertEquals(new BigDecimal("0.1"), serviceResponse.get(3).getBankOfEnglandBaseRate());
        assertTrue(serviceResponse.get(3).isVariable());
        assertEquals(new BigDecimal("43.60"), serviceResponse.get(3).getMonthlyPaymentWithFee());
        assertEquals(new BigDecimal("43.60"), serviceResponse.get(3).getMonthlyPaymentWithoutFee());
        assertFalse(serviceResponse.get(3).isProductWithFee());
        assertEquals(new BigDecimal("1956.19"), serviceResponse.get(3).getNewOutstandingBalance());
        assertEquals(new BigDecimal("0"), serviceResponse.get(3).getProductFee());
        assertEquals(new BigDecimal("0.1"), serviceResponse.get(3).getTrackingRate());
        assertFalse(serviceResponse.get(3).isApplyFeeInThisLoan());
        assertFalse(serviceResponse.get(3).isCurrentProductFixedTermFlag());
        assertTrue(serviceResponse.get(3).isLifetimeTermFlag());
        assertTrue(serviceResponse.get(3).isCurrentProductTrackerFlag());
        assertEquals("Lifetime Tracker(variable) at 3.35%", serviceResponse.get(3).getPreviousProduct());
        assertEquals(InterestRateChange.SAME, serviceResponse.get(3).getInterestRateChange());
    }

    @Test
    void lifetermFlagIsTrueWhenCurrentProductFixedTermFlagFalseInTheTransferringLoan() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-12204702.json");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        var sourceData = createSourceData();
        // We will modify last loan to be

        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), sourceData);

        // element 1
        assertFalse(dealLoansViewList.get(0).isTransferring());
        assertEquals(1, dealLoansViewList.get(0).getLoanId());
        assertTrue(dealLoansViewList.get(0).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(0).isLifetimeTermFlag());
        assertFalse(dealLoansViewList.get(0).isCurrentProductTrackerFlag());

        // element 2
        assertTrue(dealLoansViewList.get(1).isTransferring());
        assertEquals(2, dealLoansViewList.get(1).getLoanId());
        assertTrue(dealLoansViewList.get(1).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(1).isLifetimeTermFlag());
        assertTrue(dealLoansViewList.get(1).isCurrentProductTrackerFlag());

        // element 3
        assertFalse(dealLoansViewList.get(2).isTransferring());
        assertEquals(3, dealLoansViewList.get(2).getLoanId());
        assertTrue(dealLoansViewList.get(2).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(2).isLifetimeTermFlag());
        assertFalse(dealLoansViewList.get(2).isCurrentProductTrackerFlag());

        // element 4
        assertTrue(dealLoansViewList.get(3).isTransferring());
        assertEquals(4, dealLoansViewList.get(3).getLoanId());
        assertFalse(dealLoansViewList.get(3).isCurrentProductFixedTermFlag());
        assertFalse(dealLoansViewList.get(3).isLifetimeTermFlag());
        assertTrue(dealLoansViewList.get(3).isCurrentProductTrackerFlag());

    }
    @Test
    void CORINTHIAN_8031_whenMovingToTrackerWeReturnLoanBreakdownEndDate() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("new-deals/mortgage-deals-products/one-product.json");

        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        var sourceData = createSourceDataWithOneLoan();
        // We will modify last loan to be

        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), sourceData);

        assertEquals(1, dealLoansViewList.size());
        assertEquals("24 months", dealLoansViewList.get(0).getProductEndDate());

    }

    @Test
    void CORINTHIAN_8031_whenMovingToFixedWeReturnLoanBreakdownEndDate() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("new-deals/mortgage-deals-products/one-product.json");
        mortgageDealsResponse.getProducts().get(0).setType("Fixed");
        mortgageDealsResponse.getProducts().get(0).setProductDescription("2 Yr Fixed");
        Mockito.when(mockDateUtils.toYearsAndMonths(ArgumentMatchers.anyInt())).thenReturn("5 years 6 months");
        var sourceData = createSourceDataWithOneLoan();
        // We will modify last loan to be

        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), sourceData);

        assertEquals(1, dealLoansViewList.size());
        assertEquals("01/04/2026", dealLoansViewList.get(0).getProductEndDate());

    }

    @Test
    void CORINTHIAN_5922_shouldReturnERCPercentageForNonTransferringLoan() throws IOException {
        var mortgageDealsResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-SteppedERC.json");

        var sourceData = createSourceDataWithStepERC();

        List<DealLoanView> dealLoansViewList = loansToDealsMapper.map(mortgageDealsResponse.getProducts().get(0), sourceData);
        //Stepped ERC
        assertEquals(new BigDecimal("3.60"), dealLoansViewList.get(0).getEarlyRepaymentChargeAsPercentage());
        //Flat ERC
        assertEquals(new BigDecimal("8.00"), dealLoansViewList.get(1).getEarlyRepaymentChargeAsPercentage());
        //NO REC
        assertEquals(new BigDecimal("0.00"), dealLoansViewList.get(2).getEarlyRepaymentChargeAsPercentage());
    }

    private MapperSourceData createSourceDataForSVR() throws IOException {
        MapperSourceData sourceData = new MapperSourceData();
        sourceData.setAccountServiceResponse(serializeAnmfResponse("11169738/anmf-account-details.json"));
        LoanIdentifier loanOne = new LoanIdentifier("3I", 2);
        ArrayList<LoanIdentifier> selectedLoans = new ArrayList<>();
        selectedLoans.add(loanOne);
        DealsRequest dealsRequest = new DealsRequest();
        dealsRequest.setLoansSelected(selectedLoans);
        sourceData.setDealsRequest(dealsRequest);
        return sourceData;
    }


    private MapperSourceData createSourceData() throws IOException {
        MapperSourceData sourceData = new MapperSourceData();
        sourceData.setAccountServiceResponse(serializeAnmfResponse("account-details/account-details-12204702.json"));
        LoanIdentifier loanOne = new LoanIdentifier("3T", 6);
        LoanIdentifier loanTwo = new LoanIdentifier("3T", 8);
        ArrayList<LoanIdentifier> selectedLoans = new ArrayList<>();
        selectedLoans.add(loanOne);
        selectedLoans.add(loanTwo);
        DealsRequest dealsRequest = new DealsRequest();
        dealsRequest.setLoansSelected(selectedLoans);
        sourceData.setDealsRequest(dealsRequest);
        return sourceData;
    }

    private MapperSourceData createSourceDataLifetimeLoanNotTransferring() throws IOException {
        MapperSourceData sourceData = new MapperSourceData();
        AnmfAccountServiceResponse accountServiceResponse = serializeAnmfResponse("account-details/account-details-12204702.json");
        accountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(2).getORevisionaryDetails().setOReviProdDesc("STANDARD VARIABLE RATE");
        sourceData.setAccountServiceResponse(accountServiceResponse);
        LoanIdentifier loanOne = new LoanIdentifier("3T", 6);
        ArrayList<LoanIdentifier> selectedLoans = new ArrayList<>();
        selectedLoans.add(loanOne);
        DealsRequest dealsRequest = new DealsRequest();
        dealsRequest.setLoansSelected(selectedLoans);
        sourceData.setDealsRequest(dealsRequest);
        return sourceData;
    }

    private MapperSourceData createSourceDataWithStepERC() throws IOException {
        MapperSourceData sourceData = new MapperSourceData();
        sourceData.setAccountServiceResponse(serializeAnmfResponse("account-details/account-details-with-step-erc.json"));
        LoanIdentifier loanOne = new LoanIdentifier("3T", 6);
        LoanIdentifier loanTwo = new LoanIdentifier("3T", 8);
        ArrayList<LoanIdentifier> selectedLoans = new ArrayList<>();
        selectedLoans.add(loanOne);
        selectedLoans.add(loanTwo);
        DealsRequest dealsRequest = new DealsRequest();
        dealsRequest.setLoansSelected(selectedLoans);
        sourceData.setDealsRequest(dealsRequest);
        return sourceData;
    }

    private MapperSourceData createSourceDataWithOneLoan() throws IOException {
        MapperSourceData sourceData = new MapperSourceData();
        sourceData.setAccountServiceResponse(serializeAnmfResponse("new-deals/anmf-account-service/one-loan.json"));
        LoanIdentifier loanOne = new LoanIdentifier("3R", 2);
        ArrayList<LoanIdentifier> selectedLoans = new ArrayList<>();
        selectedLoans.add(loanOne);
        DealsRequest dealsRequest = new DealsRequest();
        dealsRequest.setLoansSelected(selectedLoans);
        sourceData.setDealsRequest(dealsRequest);
        return sourceData;
    }

    public AnmfAccountServiceResponse serializeAnmfResponse(String filename) throws IOException {
        return FixtureReader.get(filename, AnmfAccountServiceResponse.class);
    }
}

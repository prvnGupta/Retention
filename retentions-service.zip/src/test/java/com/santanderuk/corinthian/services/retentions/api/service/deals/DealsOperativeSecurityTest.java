package com.santanderuk.corinthian.services.retentions.api.service.deals;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import com.santanderuk.corinthian.services.retentions.config.Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class DealsOperativeSecurityTest {

    @Mock
    HeartBeatClient heartBeatClient;

    @Mock
    Config config;

    @Mock
    AnmfConfiguration anmfConfiguration;

    @Mock
    AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;

    DealsOperativeSecurity dealsOperativeSecurity;


    @BeforeEach
    void setUp() {
        dealsOperativeSecurity = new DealsOperativeSecurity(anmfBelongToCustomerWithBorrowerListService, anmfConfiguration, config, heartBeatClient);
    }

    @Test
    void happyPath() throws ConnectionException, ValidationsException, MaintenanceException {
        mockAnmBelongsToCustomer(true);
        mockOperativeSecurity(true);
        mockConfig();
        mockHeartBeat(AnmfRegion.A);

        assertDoesNotThrow(
                () -> dealsOperativeSecurity.check(12345678, "jwt-token")
        );

        verify(anmfBelongToCustomerWithBorrowerListService, times(1)).anmfBelongsToCustomerWithBorrowerList(anyInt(), anyString(), anyString(), any());

        var acccountCaptor = ArgumentCaptor.forClass(Integer.class);
        var jwtTokenCaptor = ArgumentCaptor.forClass(String.class);
        var urlCaptor = ArgumentCaptor.forClass(String.class);
        var anmfRegionArgumentCaptor = ArgumentCaptor.forClass(AnmfRegion.class);


        verify(anmfBelongToCustomerWithBorrowerListService).anmfBelongsToCustomerWithBorrowerList(
                acccountCaptor.capture(),
                jwtTokenCaptor.capture(),
                urlCaptor.capture(),
                anmfRegionArgumentCaptor.capture()
        );

        assertEquals(12345678, acccountCaptor.getValue());
        assertEquals("jwt-token", jwtTokenCaptor.getValue());
        assertEquals("http://customer-service-url", urlCaptor.getValue());
        assertEquals(AnmfRegion.A, anmfRegionArgumentCaptor.getValue());
    }

    @Test
    void operativeSecurityDisabledSoNothingHappens() throws ConnectionException, ValidationsException, MaintenanceException {
        mockAnmBelongsToCustomer(true);
        mockOperativeSecurity(false);
        mockConfig();
        mockHeartBeat(AnmfRegion.A);

        assertDoesNotThrow(
                () -> dealsOperativeSecurity.check(12345678, "jwt-token")
        );
    }

    @Test
    void doesNotBelongToCustomer() throws ConnectionException, ValidationsException, MaintenanceException {
        mockAnmBelongsToCustomer(false);
        mockOperativeSecurity(true);
        mockConfig();
        mockHeartBeat(AnmfRegion.A);

        assertThrows(

                OperativeSecurityException.class,
                () -> dealsOperativeSecurity.check(12345678, "jwt-token")
        );
    }
    private void mockHeartBeat(AnmfRegion region) throws MaintenanceException, ConnectionException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(region);
    }

    private void mockAnmBelongsToCustomer(boolean anmfBelongsToCustomer) throws ConnectionException, ValidationsException {

        var result = new AnmfBelongsToCustomerWithBorrowerList();
        result.setAnmfBelongsToCustomer(anmfBelongsToCustomer);
        when(anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(anyInt(), anyString(), anyString(), any())).thenReturn(result);

    }

    private void mockOperativeSecurity(boolean value) {
        when(config.isOperativeSecurity()).thenReturn(value);
    }

    private void mockConfig() {
        when(anmfConfiguration.getAnmfCustomerServiceUrl()).thenReturn("http://customer-service-url");
    }
}

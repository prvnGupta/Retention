package com.santanderuk.corinthian.services.retentions.functional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;


@ActiveProfiles("test")
public class VersionFunctionalTest extends FunctionalTest {

    String healthUrl;

    @BeforeEach
    public void setup() {
        healthUrl = String.format("http://localhost:%s/retentions-service/version", serverPort);
    }

    @Test
    public void customVersionReturnsUp() throws Exception {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200);

    }

}

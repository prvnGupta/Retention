package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.rules.account.AccountEligibilityRule;
import com.santanderuk.corinthian.services.retentions.api.rules.account.ODMEligibilityRule;
import com.santanderuk.corinthian.services.retentions.api.rules.bespoke.BespokeRule;
import com.santanderuk.corinthian.services.retentions.api.rules.loan.LoanRule;
import com.santanderuk.corinthian.services.retentions.api.validation.EligibilityFormatValidation;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import com.santanderuk.corinthian.services.retentions.config.AnmfConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EligibilityServiceTest {

    @Mock
    private CacheableOperations cacheableOperations;

    @Mock
    private AnmfCoreClient mockAnmfClient;

    @Mock
    private EligibilityFormatValidation eligibilityFormatValidation;

    @Mock
    private OperativeSecurityService operativeSecurityService;

    @Mock
    private AnmfConfiguration anmfConfiguration;

    @Mock
    private List<ODMEligibilityRule> allEligiblityODMEligibilityRules;

    @Mock
    private List<AccountEligibilityRule> allAccountEligibilityRules;

    @Mock
    private List<LoanRule> allLoanRules;

    @Mock
    private List<BespokeRule> bespokeRules;

    @InjectMocks
    private EligibilityService eligibilityService;


    @Test
    public void fetchEligibilityThrowsExcValidationAnmfInput() throws MaintenanceException, ConnectionException, ValidationsException, OperativeSecurityException {

        int accountNumber = 123456;
        String jwtToken = "fhiu34fhnvo39htf7tyfgh73";

        EStruc eStruc = new EStruc();
        eStruc.setECode("KABOOM");

        OStruc oStruc = new OStruc();
        oStruc.setEStruc(eStruc);

        Response response1 = new Response();
        response1.setOStruc(oStruc);

        AccountServiceResponse accountServiceResponse = new AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse response = new AnmfAccountServiceResponse();
        response.setAccountServiceResponse(accountServiceResponse);

        AnmfRegion region = AnmfRegion.A;
        when(cacheableOperations.getAnmfActiveRegion()).thenReturn(region);

        when(mockAnmfClient.fetchMortgageAccountDetailsV5(accountNumber, anmfConfiguration.getAnmfAccountDetailsUrl(), region)).thenReturn(response);
        doNothing().when(eligibilityFormatValidation).validate(accountNumber);
        doNothing().when(operativeSecurityService).checkAnmfAccountBelongToCustomerInJwt(accountNumber, jwtToken, AnmfRegion.A);

        assertThrows(ReportedException.class, () -> eligibilityService.fetchEligibilityByLoan(accountNumber, jwtToken));
    }
}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.gassaudit.writer.GassMQFactory;
import com.santanderuk.corinthian.gassaudit.writer.GassMessageGenerator;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.retentions.api.mapper.ProductSwitchGassFormattedDataMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.GassDataFetcherRetentionsService;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import javax.servlet.http.HttpServletRequest;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GassServiceTest {

    private GassService gassService;

    @Mock
    private ProductSwitchGassFormattedDataMapper productSwitchGassFormattedDataMapper;

    @Mock
    private GassDataFetcherRetentionsService mockGassData;

    @Mock
    private GassMessageGenerator gassMessageGenerator;

    @Mock
    private GassMQFactory gassMQFactory;

    @Mock
    private HttpServletRequest httpServletRequest;

    private static final String JWT_TOKEN = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    private static final int ACCOUNT = 123456;

    @BeforeEach
    void setUp() throws GeneralException {
        gassService = new GassService(productSwitchGassFormattedDataMapper, mockGassData, gassMessageGenerator, gassMQFactory);
        when(mockGassData.fetchCustomerNumber(JWT_TOKEN)).thenReturn("customer_number");
        ReflectionTestUtils.setField(gassService, "transactionGroup", "group");
        ReflectionTestUtils.setField(gassService, "transactionNameProductSwitch", "name");
        ReflectionTestUtils.setField(gassService, "transactionNameFeePayment", "name");
    }

    @Test
    public void testWeCallGassComponentsInCreateCaseMethod() throws GeneralException {
//        when(JwtUtilities.getLdapUidFromJWT(JWT_TOKEN)).thenReturn("ldap_uid");
        gassService.auditCreateRetentionCaseInGass(ACCOUNT, JWT_TOKEN, httpServletRequest, new CoreRetentionsData(), "offer_id");

        verify(productSwitchGassFormattedDataMapper, times(1)).createFormattedData(anyInt(), anyString(), any());
        verify(gassMessageGenerator, times(1)).createGassMessage(anyInt(), anyString(), anyString(), any(), anyString(), anyString(), anyString(), anyString());
        verify(gassMessageGenerator, times(1)).addFormattedDataPayload(any(), any());
        verify(gassMQFactory, times(1)).publishToQueue(any());
    }

    @Test
    public void testWeCallGassComponentsInProductSwitchAcceptLaterMethod() throws JsonProcessingException, GeneralException {

        gassService.auditProductSwitchAcceptLaterInGass("{}", JWT_TOKEN, ACCOUNT, "12/12/2020", httpServletRequest, "1");

        verify(productSwitchGassFormattedDataMapper, times(1)).createProductSwitchAcceptLaterFormattedData(any(), anyString(), anyInt(), anyString());
        verify(gassMessageGenerator, times(1)).createGassMessage(anyInt(), anyString(), anyString(), any(), anyString(), anyString(), anyString(), anyString());
        verify(gassMessageGenerator, times(1)).addFormattedDataPayload(any(), any());
        verify(gassMQFactory, times(1)).publishToQueue(any());
    }

    @Test
    public void testWeCallGassComponentsInProductSwitchAcceptNowMethod() throws JsonProcessingException, GeneralException {

        gassService.auditProductSwitchAcceptNowInGass("{}", JWT_TOKEN, ACCOUNT, "12/12/2020", httpServletRequest, "1");

        verify(productSwitchGassFormattedDataMapper, times(1)).createProductSwitchAcceptNowFormattedData(any(), anyString(), anyInt(), anyString());
        verify(gassMessageGenerator, times(1)).createGassMessage(anyInt(), anyString(), anyString(), any(), anyString(), anyString(), anyString(), anyString());
        verify(gassMessageGenerator, times(1)).addFormattedDataPayload(any(), any());
        verify(gassMQFactory, times(1)).publishToQueue(any());
    }

    @Test
    public void shouldCallGassForProductSwitchFee() throws JsonProcessingException, GeneralException {

        gassService.auditProductSwitchFeeInGass("{\"selectedDeal\":{\"product\":{\"productFee\":999}}}", JWT_TOKEN, ACCOUNT, new AcceptAndPayInSessionRequest(), httpServletRequest, "1");

        verify(productSwitchGassFormattedDataMapper, times(1)).createProductSwitchFeeFormattedData(any(), anyString(), anyInt(), any());
        verify(gassMessageGenerator, times(1)).createGassMessage(anyInt(), anyString(), anyString(), any(), anyString(), anyString(), anyString(), anyString());
        verify(gassMessageGenerator, times(1)).addFormattedDataPayload(any(), any());
        verify(gassMQFactory, times(1)).publishToQueue(any());
    }
}

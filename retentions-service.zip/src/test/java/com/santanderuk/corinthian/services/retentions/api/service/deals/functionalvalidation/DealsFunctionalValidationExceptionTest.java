package com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
class DealsFunctionalValidationExceptionTest {


    @Test
    public void test_extendsGeneralException() {
        // Check that the exception extends GeneralException
        assertTrue(GeneralException.class.isAssignableFrom(DealsFunctionalValidationException.class));
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage() {

        var exc = new DealsFunctionalValidationException(DealsFunctionalValidationException.Type.EXC_DEALS_NO_LOANS_IN_REQUEST);

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage_contructorWithException() {

        var exc = new DealsFunctionalValidationException(DealsFunctionalValidationException.Type.EXC_DEALS_NO_LOANS_IN_REQUEST, new Exception());

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_correctMessageNoAccountsInRequest() {

        var expectedCode = "EXC_DEALS_NO_LOANS_IN_REQUEST";
        var expectedMessage = "There are not loans in the request";


        var exc = new DealsFunctionalValidationException(DealsFunctionalValidationException.Type.EXC_DEALS_NO_LOANS_IN_REQUEST);
        var expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());
    }

    @Test
    public void test_correctMessageLoanInRequestNotFoundInAccountResponse() {

        var expectedCode = "EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT";
        var expectedMessage = "One or more of the loans does not belong to the account";


        var exc = new DealsFunctionalValidationException(DealsFunctionalValidationException.Type.EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT);
        var expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());
    }
}

package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.AccountEligibilityRule;
import com.santanderuk.corinthian.services.retentions.api.rules.account.AccountInArrearsButEligible;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class AccountEligibleInArrearsTest extends RuleTest {

    AccountEligibilityRule rule;

    @BeforeEach
    public void setUp() {
        rule = new AccountInArrearsButEligible();
    }

    @Test
    public void testEligibleWhenAccountIsInArrearsAndBandIsNotW() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setAccountBalanceEligibility("N");

        AnmfCoreResponse anmfCoreResponse = new AnmfCoreResponse();
        anmfCoreResponse.setCustomerOnArrears(true);

        assertThat(eligibilityResponse.getBlockers().isAccountBalanceBelowThreshold(), equalTo(false));

        rule.isEligible(eligibilityResponse, anmfCoreResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isEligibleInArrears(), equalTo(true));
    }

    @Test
    public void testNotEligibleWhenAccountIsInArrearsAndBandIsW() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("W");
        odmEligibilityResponse.getAccountResponse().setAccountBalanceEligibility("N");

        AnmfCoreResponse anmfCoreResponse = new AnmfCoreResponse();
        anmfCoreResponse.setCustomerOnArrears(true);

        assertThat(eligibilityResponse.getBlockers().isAccountBalanceBelowThreshold(), equalTo(false));

        rule.isEligible(eligibilityResponse, anmfCoreResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isEligibleInArrears(), equalTo(false));
    }

    @Test
    public void testNotEligibleWhenAccountIsNotInArrearsAndBandIsNotW() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("W");
        odmEligibilityResponse.getAccountResponse().setAccountBalanceEligibility("N");

        AnmfCoreResponse anmfCoreResponse = new AnmfCoreResponse();
        anmfCoreResponse.setCustomerOnArrears(false);

        assertThat(eligibilityResponse.getBlockers().isAccountBalanceBelowThreshold(), equalTo(false));

        rule.isEligible(eligibilityResponse, anmfCoreResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isEligibleInArrears(), equalTo(false));
    }

}

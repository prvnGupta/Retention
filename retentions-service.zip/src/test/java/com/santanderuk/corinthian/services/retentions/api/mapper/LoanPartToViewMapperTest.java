package com.santanderuk.corinthian.services.retentions.api.mapper;


import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.mappers.View;
import com.santanderuk.corinthian.services.commons.mappers.anmf.LoanPartToViewMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LoanPartToViewMapperTest {


    @Test
    public void testIsTrackingBecauseTheProductIsFixed() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("2 Year Fixed (to check that we remove it)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsVariable() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("year variable");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsYearTrackerSTT() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("2 Year Tracker(Variable)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsStandarVariableRate() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Standard VARIABLE Rate");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsFollowOnRateFOR() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Santander's Follow-On Rate");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsLifeTimeTrackerLTT() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Lifetime Tracker(Variable)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsFlexi() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("FLEXIBLE(VARIABLE)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsUnkown() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("NaNaNaNaNaNaNa....BATMAAAAAAAN!!!!!");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsWAT() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("WAT");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }


    @Test
    public void testIsTrackingBecauseTheProductIsNull() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription(null);

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    private OActiveLoanDetail createLoanWithProductDescription(String productDescription) {
        OActiveLoanDetail oLoan = new OActiveLoanDetail();
        oLoan.setOProductDesc(productDescription);
        return oLoan;
    }

}

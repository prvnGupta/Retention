package com.santanderuk.corinthian.services.retentions.api.service.deals;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClient;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.MortgageDealsClientResponse;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MapperSourceData;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response.MortgageDealsClientResponseMapper;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.service.deals.anmfdatafetcher.AnmfDataFetcher;
import com.santanderuk.corinthian.services.retentions.api.service.deals.anmfdatafetcher.AnmfDataFetcherOutput;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidation;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class DealsServiceTest {

    @Mock
    DealsOperativeSecurity operativeSecurity;

    @Mock
    DealsFunctionalValidation dealsFunctionalValidation;

    @Mock
    AnmfDataFetcher anmfDataFetcher;

    @Mock
    MortgageDealsClientResponseMapper responseMapper;

    @Mock
    MortgageDealsClient mortgageDealsClient;

    @Mock
    MortgageDealsClientRequestMapper mortgageDealsClientRequestMapper;

    DealsService dealsService;

    @BeforeEach
    void setUp() throws MortgageDealsClientException, MaintenanceException, ConnectionException {
        mockAnmfFetcher();
        mockMortageDealsClient();
        mockedMortgageDealsClientRequest();

        dealsService = new DealsService(
                responseMapper, mortgageDealsClient, mortgageDealsClientRequestMapper,
                anmfDataFetcher, dealsFunctionalValidation, operativeSecurity);
    }

    @Test
    void weAreReturningTheObjectCreatedByTheResponseMapper() throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {

        var mockedMapperResponse = mockResponseMapper();
        var dealsResponse = dealsService.get(12345678, new DealsRequest(), "jwt-token");

        assertNotNull(dealsResponse);
        assertSame(mockedMapperResponse, dealsResponse);
    }

    @Test
    void weAreSendingToTheMapperTheCorrectParameters() throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        var mockedMortgageDealsClientResponse = mockMortageDealsClient();
        var mockedMortgageDealsClientRequest = mockedMortgageDealsClientRequest();

        dealsService.get(12345678, new DealsRequest(), "jwt-token");

        var mortgageDealsClientResponseArgumentCaptor = ArgumentCaptor.forClass(MortgageDealsClientResponse.class);
        var mortgageDealsClientRequestArgumentCaptor = ArgumentCaptor.forClass(MortgageDealsClientRequest.class);
        var mapperSourceDataArgumentCaptor = ArgumentCaptor.forClass(MapperSourceData.class);
        verify(responseMapper).map(mortgageDealsClientResponseArgumentCaptor.capture(), mortgageDealsClientRequestArgumentCaptor.capture(), mapperSourceDataArgumentCaptor.capture());

        assertSame(mockedMortgageDealsClientResponse, mortgageDealsClientResponseArgumentCaptor.getValue());
        assertSame(mockedMortgageDealsClientRequest, mortgageDealsClientRequestArgumentCaptor.getValue());
    }

    @Test
    void weAreSendingToTheMortageDealsClientTheProperParameter() throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        var mockedMortgageDealsClientRequest = mockedMortgageDealsClientRequest();

        dealsService.get(12345678, new DealsRequest(), "jwt-token");

        var mortgageDealsClientRequestArgumentCaptor = ArgumentCaptor.forClass(MortgageDealsClientRequest.class);
        verify(mortgageDealsClient).fetch(mortgageDealsClientRequestArgumentCaptor.capture());

        assertSame(mockedMortgageDealsClientRequest, mortgageDealsClientRequestArgumentCaptor.getValue());
    }

    @Test
    void weAreSendingTheCorrectDataToTheClientRequestMapper() throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        var mockedAnmfFetcherResponse = mockAnmfFetcher();
        var dealsRequest = new DealsRequest();
        dealsService.get(12345678, dealsRequest, "jwt-token");

        var mapperSourceDataArgumentCaptor = ArgumentCaptor.forClass(MapperSourceData.class);
        verify(mortgageDealsClientRequestMapper).create(mapperSourceDataArgumentCaptor.capture());

        assertEquals(12345678, mapperSourceDataArgumentCaptor.getValue().getAccount());
        assertSame(dealsRequest, mapperSourceDataArgumentCaptor.getValue().getDealsRequest());
        assertSame(mockedAnmfFetcherResponse.getAccountServiceResponse(), mapperSourceDataArgumentCaptor.getValue().getAccountServiceResponse());
        assertSame(mockedAnmfFetcherResponse.getAnmfPropertyResponse(), mapperSourceDataArgumentCaptor.getValue().getAnmfPropertyResponse());
    }

    @Test
    void weAreSendingToAnmfFetcherTheProperAccountPassedToTheService() throws MortgageDealsClientException, MaintenanceException, ConnectionException, DealsFunctionalValidationException, OperativeSecurityException, ValidationsException {
        var dealsRequest = new DealsRequest();
        dealsService.get(12345678, dealsRequest, "jwt-token");

        var accountArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        verify(anmfDataFetcher).fetch(accountArgumentCaptor.capture());

        assertEquals(12345678, accountArgumentCaptor.getValue());
    }

    @Test
    void weAreCallingTheFunctionalValidationWithTheProperData() throws DealsFunctionalValidationException, MaintenanceException, MortgageDealsClientException, ConnectionException, OperativeSecurityException, ValidationsException {
        var mockedAnmfFetcherData = mockAnmfFetcher();

        var dealsRequest = new DealsRequest();

        dealsService.get(12345678, dealsRequest, "jwt-token");

        verify(dealsFunctionalValidation, times(1)).run(any(), any());

        var dealsRequestArgumentCaptor = ArgumentCaptor.forClass(DealsRequest.class);
        var anmfAccountServiceResponseCaptor = ArgumentCaptor.forClass(AnmfAccountServiceResponse.class);

        verify(dealsFunctionalValidation).run(dealsRequestArgumentCaptor.capture(), anmfAccountServiceResponseCaptor.capture());

        assertSame(dealsRequest, dealsRequestArgumentCaptor.getValue());
        assertSame(mockedAnmfFetcherData.getAccountServiceResponse(), anmfAccountServiceResponseCaptor.getValue());
    }

    @Test
    void functionalValidationThrowsProperException() throws DealsFunctionalValidationException {

        doThrow(new DealsFunctionalValidationException(DealsFunctionalValidationException.Type.EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT))
                .when(dealsFunctionalValidation).run(any(), any());

        assertThrows(
                DealsFunctionalValidationException.class,
                () -> dealsService.get(12345678, new DealsRequest(), "jwt-token")
        );
    }

    @Test
    void weAreSendingToTheOperativeSecurityTheProperData() throws MaintenanceException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, OperativeSecurityException, ValidationsException {
        var dealsRequest = new DealsRequest();
        dealsService.get(12345678, dealsRequest, "jwt-token");

        var accountCaptor = ArgumentCaptor.forClass(Integer.class);
        var jwtTokenCaptor = ArgumentCaptor.forClass(String.class);

        verify(operativeSecurity).check(accountCaptor.capture(), jwtTokenCaptor.capture());

        assertEquals(12345678, accountCaptor.getValue());
        assertEquals("jwt-token", jwtTokenCaptor.getValue());
    }

    private AnmfDataFetcherOutput mockAnmfFetcher() throws ConnectionException, MaintenanceException {
        var anmfFetcherOutput = new AnmfDataFetcherOutput();
        anmfFetcherOutput.setAccountServiceResponse(new AnmfAccountServiceResponse());
        anmfFetcherOutput.setAnmfPropertyResponse(new ANMFPropertyResponse());

        when(anmfDataFetcher.fetch(anyInt())).thenReturn(anmfFetcherOutput);

        return anmfFetcherOutput;
    }

    private MortgageDealsClientRequest mockedMortgageDealsClientRequest() {
        var mockedMortgageDealsClientRequest = new MortgageDealsClientRequest();

        when(mortgageDealsClientRequestMapper.create(any())).thenReturn(mockedMortgageDealsClientRequest);

        return mockedMortgageDealsClientRequest;
    }

    private MortgageDealsClientResponse mockMortageDealsClient() throws MortgageDealsClientException {
        var clientResponse = new MortgageDealsClientResponse();

        when(mortgageDealsClient.fetch(any())).thenReturn(clientResponse);

        return clientResponse;
    }


    private DealsResponse mockResponseMapper() {
        var dealsResponse = new DealsResponse();

        when(responseMapper.map(any(), any(), any())).thenReturn(dealsResponse);

        return dealsResponse;
    }
}

package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.OutputStructure;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.PropertyEnquiryResponse;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;

import java.util.ArrayList;

public class MortgageDealsClientRequestMapperTestData {

    public static MapperSourceData createEmptyMapperSourceData() {
        var mapperSourceData = new MapperSourceData();
        mapperSourceData.setAccount(12345678);
        mapperSourceData.setAccountServiceResponse(createEmptyAnmfAccountServiceResponse());
        mapperSourceData.setAnmfPropertyResponse(createEmptyAnmfPropertyResponse());
        mapperSourceData.setDealsRequest(createEmptyDealsRequest());
        return mapperSourceData;
    }

    public static DealsRequest createEmptyDealsRequest() {
        var dealsRequest = new DealsRequest();
        var loansList = new ArrayList<LoanIdentifier>();
        dealsRequest.setLoansSelected(loansList);
        return dealsRequest;
    }

    public static void addLoanInDealsRequest(DealsRequest dealsRequest, String loanScheme, int sequenceNumber) {
        var loanSelected = new LoanIdentifier();
        loanSelected.setLoanScheme(loanScheme);
        loanSelected.setSequenceNumber(sequenceNumber);
        dealsRequest.getLoansSelected().add(loanSelected);
    }

    public static AnmfAccountServiceResponse createEmptyAnmfAccountServiceResponse() {
        var anmfAccountServiceResponse = new AnmfAccountServiceResponse();
        var accountService = new AccountServiceResponse();
        var response = new Response();
        var struct = new OStruc();
        var activeLoans = new ArrayList<OActiveLoanDetail>();
        struct.setOActiveLoanDetails(activeLoans);
        response.setOStruc(struct);
        accountService.setResponse(response);
        anmfAccountServiceResponse.setAccountServiceResponse(accountService);
        return anmfAccountServiceResponse;
    }

    public static ANMFPropertyResponse createEmptyAnmfPropertyResponse() {
        var anmfPropertyResponse = new ANMFPropertyResponse();
        var propertyEnquiry = new PropertyEnquiryResponse();
        var output = new OutputStructure();
        propertyEnquiry.setOutputStructure(output);
        anmfPropertyResponse.setPropertyEnquiryResponse(propertyEnquiry);
        return anmfPropertyResponse;
    }
}

package com.santanderuk.corinthian.services.retentions.api.utils;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.InterestRateChange;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ProductUtilsTest {

    @Mock
    private DateUtils mockDateUtils;

    ProductUtils productUtils;

    Clock fixedClock = Clock.fixed(Instant.parse("2019-10-03T10:15:30.00Z"), ZoneId.of("UTC"));
    LocalDate fixedToday = LocalDate.now(fixedClock);

    @BeforeEach
    public void setUp() {
        productUtils = new ProductUtils(mockDateUtils);
    }

    @Test
    public void aFixedProductReturnsTrue() {

        Loan loan = new Loan();
        loan.setProductDescription("2 Year tracker");

        boolean result = productUtils.isFixedTerm(loan);

        assertThat(result, equalTo(true));

        loan.setProductDescription("3 YeAr fixed");
        result = productUtils.isFixedTerm(loan);

        assertThat(result, equalTo(true));

        loan.setProductDescription("lifetime tracker");
        result = productUtils.isFixedTerm(loan);

        assertThat(result, equalTo(false));

        loan.setProductDescription("");
        result = productUtils.isFixedTerm(loan);

        assertThat(result, equalTo(false));
    }


    @Test
    public void isTrackerLTT() {
        Loan loan = new Loan();
        loan.setProductDescription("Lifetime Tracker(Variable)");
        assertTrue(productUtils.isTracker(loan));
    }

    @Test
    public void isTrackerSTT() {
        Loan loan = new Loan();
        loan.setProductDescription("2 Year Tracker(Variable)");
        assertTrue(productUtils.isTracker(loan));
    }

    @Test
    public void isTrackerShortVariable() {
        Loan loan = new Loan();
        loan.setProductDescription("2 years VARIABLE");
        assertFalse(productUtils.isTracker(loan));
    }

    @Test
    public void isTrackerShortFixed() {
        Loan loan = new Loan();
        loan.setProductDescription("2 YEARS FIXED");
        assertFalse(productUtils.isTracker(loan));
    }

    @Test
    public void isTrackerSVR() {
        Loan loan = new Loan();
        loan.setProductDescription("standard variable rate");
        assertFalse(productUtils.isTracker(loan));
    }

    @Test
    public void isTrackerSFOR() {
        Loan loan = new Loan();
        loan.setProductDescription("santander's follow-on rate");
        assertFalse(productUtils.isTracker(loan));
    }

    @Test
    public void isTrackerFlexi() {
        Loan loan = new Loan();
        loan.setProductDescription("FLEXIBLE(VARIABLE)");
        assertFalse(productUtils.isTracker(loan));
    }

    @Test
    public void testLoanSwitchDateLifetimeToHigherRate() {
        String productCompletionDate = "2020-02-05";
        DealLoanView loanToSwitch = generateDefaultLifetimeLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.HIGHER);
        Mockito.when(mockDateUtils.subtractOneDay("05/02/2020")).thenReturn("04/02/2020");
        assertEquals("04/02/2020", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));
    }

    @Test
    public void testLoanSwitchDateLifetimeToLowerRate() {
        String productCompletionDate = "2020-02-05";
        DealLoanView loanToSwitch = generateDefaultLifetimeLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.LOWER);
        assertEquals("", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));

    }

    @Test
    public void testLoanSwitchDateLifetimeToSameRate() {
        String productCompletionDate = "2020-02-05";
        DealLoanView loanToSwitch = generateDefaultLifetimeLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.SAME);
        assertEquals("", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));

    }

    @Test
    public void testLoanSwitchDateFixedToHigherRate() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        String currentProductEndDate = loanToSwitch.getProductEndDate();
        loanToSwitch.setInterestRateChange(InterestRateChange.HIGHER);
        String productCompletionDate = "2020-02-05";
        Mockito.when(mockDateUtils.addOneDay(currentProductEndDate)).thenReturn("13/12/2019");
        assertEquals("13/12/2019", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));
    }

    @Test
    public void testLoanSwitchDateFixedTrackerToHigherRatePEDBeforePCD() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.HIGHER);
        loanToSwitch.setCurrentProductTrackerFlag(true);
        loanToSwitch.setProductEndDate("12/12/2019");
        String currentProductEndDate = loanToSwitch.getProductEndDate();// 12/12/2019
        String productCompletionDate = "2020-02-05";

        Mockito.when(mockDateUtils.date1SoonerThanDate2("05/02/2020", currentProductEndDate)).thenReturn(false);
        Mockito.when(mockDateUtils.addOneDay(currentProductEndDate)).thenReturn("13/12/2019");

        assertEquals("13/12/2019", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));
    }

    @Test
    public void testLoanSwitchDateFixedTrackerToHigherRatePCDBeforePED() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.HIGHER);
        loanToSwitch.setCurrentProductTrackerFlag(true);
        loanToSwitch.setProductEndDate("12/12/2019");
        String currentProductEndDate = loanToSwitch.getProductEndDate();// 12/12/2019
        String productCompletionDate = "2019-12-10";

        Mockito.when(mockDateUtils.date1SoonerThanDate2("10/12/2019", currentProductEndDate)).thenReturn(true);
        Mockito.when(mockDateUtils.subtractOneDay("10/12/2019")).thenReturn("09/12/2019");

        assertEquals("09/12/2019", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));
    }

    @Test
    public void testLoanSwitchDateFixedToLowerRate() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.LOWER);
        String productCompletionDate = "2020-02-05";
        assertEquals("", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));
    }

    @Test
    public void testLoanSwitchDateFixedToSameRate() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        loanToSwitch.setInterestRateChange(InterestRateChange.SAME);
        String productCompletionDate = "2020-02-05";
        assertEquals("", productUtils.calculateLoanSwitchDate(productCompletionDate, loanToSwitch));
    }

    @Test
    public void testLoanSwitchProductEndDateSwitchingToLifetimeProduct() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        Product product = generateDefaultProductLifetimeTermVariableInterest();
        assertEquals("31/12/2035", productUtils.calculateLoanSwitchingProductEndDate(loanToSwitch, product));
    }

    @Test
    public void testLoanSwitchProductEndDateSwitchingToLifetimeProduct_NoStartDate() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        Product product = generateDefaultProductLifetimeTermVariableInterest();
        assertEquals("31/12/2035", productUtils.calculateLoanSwitchingProductEndDate(loanToSwitch, product));
    }

    @Test
    public void testLoanSwitchProductEndDateSwitchingToFixedTermFixedInterest_NoStartDate() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        Product product = generateDefaultProductFixedTermFixedInterest();
        assertEquals("12/12/2021", productUtils.calculateLoanSwitchingProductEndDate(loanToSwitch, product));
    }

    @Test
    public void testLoanSwitchProductEndDateSwitchingToFixedTermFixedInterest() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        Product product = generateDefaultProductFixedTermFixedInterest();
        assertEquals("12/12/2021", productUtils.calculateLoanSwitchingProductEndDate(loanToSwitch, product));
    }

    @Test
    public void testLoanSwitchProductEndDateSwitchingToFixedTermVariableInterest_NoStartDate() {
        DealLoanView loanToSwitch = generateDefaultFixedTermLoan();
        Product product = generateDefaultProductFixedTermVariableInterest();
        assertEquals("24 months", productUtils.calculateLoanSwitchingProductEndDate(loanToSwitch, product));
    }
    @Test
    public void testCalculateSwitchDate_NoStartDate() {
        DealLoanView loanToSwitch = generateFixedTermLoanSwitchingToHigherInterestRate();
        Product product = generateDefaultProductFixedTermVariableInterest();
        assertEquals("24 months", productUtils.calculateLoanSwitchingProductEndDate(loanToSwitch, product));
    }

    private DealLoanView generateFixedTermLoanSwitchingToHigherInterestRate() {
        DealLoanView loan = new DealLoanView();
        loan.setProductEndDate("31/12/2035");
        return loan;

    }

    private Product generateDefaultProductFixedTermFixedInterest() {
        Product product = new Product();
        product.setTerm("2 year");
        product.setType("Fixed");
        product.setChargeEndDate("12/12/2021");
        return product;
    }

    private Product generateDefaultProductFixedTermVariableInterest() {
        Product product = new Product();
        product.setTerm("2 year");
        product.setType("Tracker");
        product.setChargeEndDate("2nd Anniversary");
        return product;
    }

    private Product generateDefaultProductLifetimeTermVariableInterest() {
        Product product = new Product();
        product.setTerm("Lifetime");
        product.setType("Tracker");
        product.setChargeEndDate("Not Applicable");
        return product;
    }

    private DealLoanView generateDefaultLifetimeLoan() {
        DealLoanView loan = new DealLoanView();
        loan.setLifetimeTermFlag(true);
        return loan;
    }

    private DealLoanView generateDefaultFixedTermLoan() {
        DealLoanView loan = new DealLoanView();
        loan.setCurrentProductFixedTermFlag(true);
        loan.setProductEndDate("31/12/2035");
        return loan;
    }

}

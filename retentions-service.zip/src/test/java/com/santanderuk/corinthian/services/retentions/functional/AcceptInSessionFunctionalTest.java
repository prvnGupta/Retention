package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class AcceptInSessionFunctionalTest extends FunctionalTest {

    private Header authorizationHeader;
    private Header contentType;
    private Header accept;
    private String acceptInSessionEndpoint;

    public static final String DEFAULT_ESIS_ID = "esisrefid";

    @BeforeEach
    public void setUp() {
        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
        acceptInSessionEndpoint = String.format("http://localhost:%s/retentions-service/%s/offer/{esisRefId}/accept-in-session", serverPort, ACCOUNT_NUMBER);
    }

    @Test
    public void testWeReturn200FromController() {

        String esisRefId = "esis-ref-id";
        String caseId = "case-id-1234";

        // stubs
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");
        stubProductSwitchAcceptInSession(caseId, "/product-switch-service/accept-in-session-response.json");

        String url = acceptInSessionEndpoint.replace("{esisRefId}", esisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                put(url).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"));
    }

    @Test
    public void testWeReturn401WhenCustomerFailsJwtValidation() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");

        String url = acceptInSessionEndpoint.replace("{esisRefId}", esisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                put(url).
                then().
                statusCode(401).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer"));
    }

    @Test
    public void testWeReturn400WhenEsisRefIdContainsSpecialCharacters() {

        String badEsisRefId = "esisref^id";
        String url = acceptInSessionEndpoint.replace("{esisRefId}", badEsisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(url).
                then().
                statusCode(400).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("ESIS_ID_BAD_FORMAT"),
                        "info.message", equalTo("esis_ref_id format is not valid"));
    }

    @Test
    public void testWeReturn500WhenProductSwitchServiceIsDown() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfoDown();

        String url = acceptInSessionEndpoint.replace("{esisRefId}", DEFAULT_ESIS_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(url).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("PRODUCT_SWITCH_CONNECTION_ERROR"),
                        "info.message", equalTo("Exception while calling product switch service"));
    }

    @Test
    public void testWeReturn403WhenProductSwitchClientReturnsRowWithDifferentEsisRefId() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-mismatch-esis-ref-id-response.json");

        String url = acceptInSessionEndpoint.replace("{esisRefId}", esisRefId);


        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(url).
                then().
                statusCode(403).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("ESIS_REF_ID_NOT_MATCHING"),
                        "info.message", equalTo("esis ref id returned does not match request"));
    }

    @Test
    public void testWeReturn403WhenAccountIsForbiddenFromAccessingResource() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-mismatch-account-response.json");

        String url = acceptInSessionEndpoint.replace("{esisRefId}", esisRefId);


        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(url).
                then().
                statusCode(403).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("ACCOUNT_NOT_MATCHING"),
                        "info.message", equalTo("The account is not allowed to access this resource"));
    }

    @Test
    public void testWeReturn403ForFeePaidUpFrontRequestFromAccessingResource() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-fee-paying-upfront-response.json");

        String url = acceptInSessionEndpoint.replace("{esisRefId}", esisRefId);


        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(url).
                then().
                statusCode(403).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("NOT_THE_RIGHT_API_TO_USE"),
                        "info.message", equalTo("for fee paying upfront use the correct api"));
    }

    @Test
    public void testWeReturn500WhenProductSwitchServiceIsDownForAcceptInSessionCall() {

        String esisRefId = "esis-ref-id";
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");
        stubProductSwitchAcceptInSessionDown(esisRefId);

        String url = acceptInSessionEndpoint.replace("{esisRefId}", esisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(url).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("PRODUCT_SWITCH_CONNECTION_ERROR"),
                        "info.message", equalTo("Exception while calling product switch service"));
    }
}

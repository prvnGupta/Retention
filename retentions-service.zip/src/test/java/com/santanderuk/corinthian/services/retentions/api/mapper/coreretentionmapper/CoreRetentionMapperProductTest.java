package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

public class CoreRetentionMapperProductTest extends CoreRetentionMapperTestBase {

    @Test
    public void mapProductDataFeeAddedInMortgageTrueToCoreRetentionsRequest() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getCode()),
                () -> assertEquals("Desc0", coreRetentionRequest.getProduct().getDescription()),
                () -> assertEquals("Fee Rolled In", coreRetentionRequest.getProduct().getFeeReceived())
        );
    }

    @Test
    public void mapProductDataFeeAddedInMortgageFalseToCoreRetentionsRequest() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.getCaseRequest().setFeeAddedInMortgage(false);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getCode()),
                () -> assertEquals("Desc0", coreRetentionRequest.getProduct().getDescription()),
                () -> assertEquals("Fee Paid Upfront", coreRetentionRequest.getProduct().getFeeReceived())
        );
    }

    @Test
    public void mapProductDataFeeIndicatorFalseWhenThereIsNotFee() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getCode()),
                () -> assertEquals("Desc0", coreRetentionRequest.getProduct().getDescription()),
                () -> assertEquals("Fee Rolled In", coreRetentionRequest.getProduct().getFeeReceived()),
                () -> assertFalse(coreRetentionRequest.getProduct().getFees().isIndicator()),
                () -> assertEquals("0", coreRetentionRequest.getProduct().getFees().getRequiredType()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getTotalFeesAddedAmount())
        );
    }

    @Test
    public void mapProductDataFeeIndicatorTrueWhenThereIsFee() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.getSelectedDeal().getProduct().setProductFee(new BigDecimal("999.00"));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getCode()),
                () -> assertEquals("Desc0", coreRetentionRequest.getProduct().getDescription()),
                () -> assertEquals("Fee Rolled In", coreRetentionRequest.getProduct().getFeeReceived()),
                () -> assertTrue(coreRetentionRequest.getProduct().getFees().isIndicator()),
                () -> assertEquals("0", coreRetentionRequest.getProduct().getFees().getRequiredType()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getTotalFeesAddedAmount())
        );
    }

    @Test
    public void mapProductDataFeeIndicatorAddedIndicator1BecauseProductFee() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.getSelectedDeal().getProduct().setProductFee(new BigDecimal("999.00"));
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getCode()),
                () -> assertEquals("Desc0", coreRetentionRequest.getProduct().getDescription()),
                () -> assertEquals("Fee Rolled In", coreRetentionRequest.getProduct().getFeeReceived()),
                () -> assertTrue(coreRetentionRequest.getProduct().getFees().isIndicator()),
                () -> assertEquals("0", coreRetentionRequest.getProduct().getFees().getRequiredType()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getTotalFeesAddedAmount()),
                () -> assertEquals(1, coreRetentionRequest.getProduct().getFees().getAddedIndicator())
        );

    }

    @Test
    public void mapProductDataFeeIndicatorAddedIndicator4BecauseNoFee() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getCode()),
                () -> assertEquals("Desc0", coreRetentionRequest.getProduct().getDescription()),
                () -> assertEquals("Fee Rolled In", coreRetentionRequest.getProduct().getFeeReceived()),
                () -> assertFalse(coreRetentionRequest.getProduct().getFees().isIndicator()),
                () -> assertEquals("0", coreRetentionRequest.getProduct().getFees().getRequiredType()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getTotalFeesAddedAmount()),
                () -> assertEquals(4, coreRetentionRequest.getProduct().getFees().getAddedIndicator())
        );
    }

    @Test
    public void mapFeePartsCheckByDefaultFeeIsThere() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals(11, coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getType()),
                () -> assertEquals("Repayment Fee", coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getDescription()),
                () -> assertEquals(new BigDecimal("225.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmount()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountWaived()),
                () -> assertEquals(new BigDecimal("225.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountPayable()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountCapitalised()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountDueByCheque()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountPaidOnApplication()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountAddedToLoan()),
                () -> assertEquals("", coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getBookingFeeProduct()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getBookingFeePercentage()),
                () -> assertFalse(coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).isCanAddToLoan()),
                () -> assertEquals(0, coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAddedToLoanPartId()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getAmountDueByCard()),
                () -> assertEquals("0", coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getCapitalisedLoanID())
        );
    }

    @Test
    public void mapFeePartsOnlyDefaultFeePartBecauseThereIsNoOtherFee() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        assertEquals(11, coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getType());
        assertEquals(1, coreRetentionRequest.getProduct().getFees().getFeeParts().size());
    }

    @Test
    public void mapFeePartsSecondFeeAddedToTheDefaultOne() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.getSelectedDeal().getProduct().setProductFee(new BigDecimal("999.00"));

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals(2, coreRetentionRequest.getProduct().getFees().getFeeParts().size()),

                () -> assertEquals(11, coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getType()),

                () -> assertEquals(48, coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getType()),
                () -> assertEquals("Booking Fee", coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getDescription()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmount()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountWaived()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountPayable()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountCapitalised()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountDueByCheque()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountPaidOnApplication()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountAddedToLoan()),
                () -> assertEquals("PR00", coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getBookingFeeProduct()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getBookingFeePercentage()),
                () -> assertTrue(coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).isCanAddToLoan()),
                () -> assertEquals(2, coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAddedToLoanPartId()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountDueByCard()),
                () -> assertEquals("2", coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getCapitalisedLoanID())
        );
    }

    @Test
    public void mapFeePartsWhenFeeIsNotAddedToLoan() {

        CoreRetentionsData input = generateDefaultMapperInput();
        input.getCaseRequest().setFeeAddedInMortgage(false);
        input.getSelectedDeal().getProduct().setProductFee(new BigDecimal("999.00"));

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertAll(
                () -> assertEquals(2, coreRetentionRequest.getProduct().getFees().getFeeParts().size()),

                () -> assertEquals(11, coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getType()),
                () -> assertEquals(11, coreRetentionRequest.getProduct().getFees().getFeeParts().get(0).getType()),

                () -> assertEquals(48, coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getType()),
                () -> assertFalse(coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).isCanAddToLoan()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountDueByCard()),
                () -> assertEquals(0, coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAddedToLoanPartId()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountAddedToLoan()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountDueByCheque()),
                () -> assertEquals(new BigDecimal("999.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountPaidOnApplication()),
                () -> assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getAmountCapitalised()),
                () -> assertEquals("0", coreRetentionRequest.getProduct().getFees().getFeeParts().get(1).getCapitalisedLoanID())
        );
    }
}

package com.santanderuk.corinthian.services.retentions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
@Slf4j
@Profile("local")
public class DeleteCacheForLocalProfile {

    @Autowired
    @Qualifier("cacheManagerLongLife")
    private CacheManager cacheManagerLongLife;

    @Autowired
    @Qualifier("cacheManagerShortLife")
    private CacheManager cacheManagerShortLife;

    @Scheduled(cron = "${caching.longExpirationCron}")
    private void clearLongCacheValues() {
        log.info("Clearing cache for local profile");
        deleteLongInMemoryCache();
    }

    @Scheduled(cron = "${caching.shortExpirationCron}")
    private void clearShortCacheValues() {
        log.info("Clearing cache for local profile");
        deleteShortInMemoryCache();
    }

    private void deleteShortInMemoryCache() {
        for (String cacheName : cacheManagerShortLife.getCacheNames()) {
            cacheManagerShortLife.getCache(cacheName).clear();
        }
    }

    private void deleteLongInMemoryCache() {
        for (String cacheName : cacheManagerLongLife.getCacheNames()) {
            cacheManagerLongLife.getCache(cacheName).clear();
        }
    }
}


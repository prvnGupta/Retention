package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@Slf4j
@ActiveProfiles("test")
public class RetrieveOfferFunctionalTest extends FunctionalTest {

    private Header authorizationHeader;
    private Header contentType;
    private String baseEndpoint;

    private static final String PDF_STRING = "JVBERi0xLjMKJcTl8uXrp/Og0MTGCjQgMCBvYmoKPDwgL0xlbmd0aCA1IDAgUiAvRmlsdGVyIC9GbGF0ZURlY29kZSA+PgpzdHJlYW0KeAGVkDEPgjAUhHd+xSmK1IRa+ijQVePiRvI2dSJxMGEg/P/E0kqUOKjpcO3Ly32969Ggx+4w5GgHKH+G1o2U1EV4j5e8lHWBUpMkjbbDnmHCshNNWlprK5hSRdxhx6yRg29IFwJ8x5E95aulkkopArfv5qaSVBb20/yMdBmvhCOla4Er+PQzKPMkHc1IRLWsyKfALIUDJbFA5kDJJuglfaoIuhXRXx94lWe0kaQsjfkmbBTKc6mm8poHKqVWAwplbmRzdHJlYW0KZW5kb2JqCjUgMCBvYmoKMTkwCmVuZG9iagoyIDAgb2JqCjw8IC9UeXBlIC9QYWdlIC9QYXJlbnQgMyAwIFIgL1Jlc291cmNlcyA2IDAgUiAvQ29udGVudHMgNCAwIFIgL01lZGlhQm94IFswIDAgNTk1IDg0Ml0KPj4KZW5kb2JqCjYgMCBvYmoKPDwgL1Byb2NTZXQgWyAvUERGIC9UZXh0IF0gL0NvbG9yU3BhY2UgPDwgL0NzMSA3IDAgUiA+PiAvRm9udCA8PCAvVFQyIDkgMCBSCj4+ID4+CmVuZG9iagoxMCAwIG9iago8PCAvTGVuZ3RoIDExIDAgUiAvTiAzIC9BbHRlcm5hdGUgL0RldmljZVJHQiAvRmlsdGVyIC9GbGF0ZURlY29kZSA+PgpzdHJlYW0KeAGdlndUU9kWh8+9N73QEiIgJfQaegkg0jtIFQRRiUmAUAKGhCZ2RAVGFBEpVmRUwAFHhyJjRRQLg4Ji1wnyEFDGwVFEReXdjGsJ7601896a/cdZ39nnt9fZZ+9917oAUPyCBMJ0WAGANKFYFO7rwVwSE8vE9wIYEAEOWAHA4WZmBEf4RALU/L09mZmoSMaz9u4ugGS72yy/UCZz1v9/kSI3QyQGAApF1TY8fiYX5QKUU7PFGTL/BMr0lSkyhjEyFqEJoqwi48SvbPan5iu7yZiXJuShGlnOGbw0noy7UN6aJeGjjAShXJgl4GejfAdlvVRJmgDl9yjT0/icTAAwFJlfzOcmoWyJMkUUGe6J8gIACJTEObxyDov5OWieAHimZ+SKBIlJYqYR15hp5ejIZvrxs1P5YjErlMNN4Yh4TM/0tAyOMBeAr2+WRQElWW2ZaJHtrRzt7VnW5mj5v9nfHn5T/T3IevtV8Sbsz55BjJ5Z32zsrC+9FgD2JFqbHbO+lVUAtG0GQOXhrE/vIADyBQC03pzzHoZsXpLE4gwnC4vs7GxzAZ9rLivoN/ufgm/Kv4Y595nL7vtWO6YXP4EjSRUzZUXlpqemS0TMzAwOl89k/fcQ/+PAOWnNycMsnJ/AF/GF6FVR6JQJhIlou4U8gViQLmQKhH/V4X8YNicHGX6daxRodV8AfYU5ULhJB8hvPQBDIwMkbj96An3rWxAxCsi+vGitka9zjzJ6/uf6Hwtcim7hTEEiU+b2DI9kciWiLBmj34RswQISkAd0oAo0gS4wAixgDRyAM3AD3iAAhIBIEAOWAy5IAmlABLJBPtgACkEx2AF2g2pwANSBetAEToI2cAZcBFfADXALDIBHQAqGwUswAd6BaQiC8BAVokGqkBakD5lC1hAbWgh5Q0FQOBQDxUOJkBCSQPnQJqgYKoOqoUNQPfQjdBq6CF2D+qAH0CA0Bv0BfYQRmALTYQ3YALaA2bA7HAhHwsvgRHgVnAcXwNvhSrgWPg63whfhG/AALIVfwpMIQMgIA9FGWAgb8URCkFgkAREha5EipAKpRZqQDqQbuY1IkXHkAwaHoWGYGBbGGeOHWYzhYlZh1mJKMNWYY5hWTBfmNmYQM4H5gqVi1bGmWCesP3YJNhGbjS3EVmCPYFuwl7ED2GHsOxwOx8AZ4hxwfrgYXDJuNa4Etw/XjLuA68MN4SbxeLwq3hTvgg/Bc/BifCG+Cn8cfx7fjx/GvyeQCVoEa4IPIZYgJGwkVBAaCOcI/YQRwjRRgahPdCKGEHnEXGIpsY7YQbxJHCZOkxRJhiQXUiQpmbSBVElqIl0mPSa9IZPJOmRHchhZQF5PriSfIF8lD5I/UJQoJhRPShxFQtlOOUq5QHlAeUOlUg2obtRYqpi6nVpPvUR9Sn0vR5Mzl/OX48mtk6uRa5Xrl3slT5TXl3eXXy6fJ18hf0r+pvy4AlHBQMFTgaOwVqFG4bTCPYVJRZqilWKIYppiiWKD4jXFUSW8koGStxJPqUDpsNIlpSEaQtOledK4tE20Otpl2jAdRzek+9OT6cX0H+i99AllJWVb5SjlHOUa5bPKUgbCMGD4M1IZpYyTjLuMj/M05rnP48/bNq9pXv+8KZX5Km4qfJUilWaVAZWPqkxVb9UU1Z2qbapP1DBqJmphatlq+9Uuq43Pp893ns+dXzT/5PyH6rC6iXq4+mr1w+o96pMamhq+GhkaVRqXNMY1GZpumsma5ZrnNMe0aFoLtQRa5VrntV4wlZnuzFRmJbOLOaGtru2nLdE+pN2rPa1jqLNYZ6NOs84TXZIuWzdBt1y3U3dCT0svWC9fr1HvoT5Rn62fpL9Hv1t/ysDQINpgi0GbwaihiqG/YZ5ho+FjI6qRq9Eqo1qjO8Y4Y7ZxivE+41smsImdSZJJjclNU9jU3lRgus+0zwxr5mgmNKs1u8eisNxZWaxG1qA5wzzIfKN5m/krCz2LWIudFt0WXyztLFMt6ywfWSlZBVhttOqw+sPaxJprXWN9x4Zq42Ozzqbd5rWtqS3fdr/tfTuaXbDdFrtOu8/2DvYi+yb7MQc9h3iHvQ732HR2KLuEfdUR6+jhuM7xjOMHJ3snsdNJp9+dWc4pzg3OowsMF/AX1C0YctFx4bgccpEuZC6MX3hwodRV25XjWuv6zE3Xjed2xG3E3dg92f24+ysPSw+RR4vHlKeT5xrPC16Il69XkVevt5L3Yu9q76c+Oj6JPo0+E752vqt9L/hh/QL9dvrd89fw5/rX+08EOASsCegKpARGBFYHPgsyCRIFdQTDwQHBu4IfL9JfJFzUFgJC/EN2hTwJNQxdFfpzGC4sNKwm7Hm4VXh+eHcELWJFREPEu0iPyNLIR4uNFksWd0bJR8VF1UdNRXtFl0VLl1gsWbPkRoxajCCmPRYfGxV7JHZyqffS3UuH4+ziCuPuLjNclrPs2nK15anLz66QX8FZcSoeGx8d3xD/iRPCqeVMrvRfuXflBNeTu4f7kufGK+eN8V34ZfyRBJeEsoTRRJfEXYljSa5JFUnjAk9BteB1sl/ygeSplJCUoykzqdGpzWmEtPi000IlYYqwK10zPSe9L8M0ozBDuspp1e5VE6JA0ZFMKHNZZruYjv5M9UiMJJslg1kLs2qy3mdHZZ/KUcwR5vTkmuRuyx3J88n7fjVmNXd1Z752/ob8wTXuaw6thdauXNu5Tnddwbrh9b7rj20gbUjZ8MtGy41lG99uit7UUaBRsL5gaLPv5sZCuUJR4b0tzlsObMVsFWzt3WazrWrblyJe0fViy+KK4k8l3JLr31l9V/ndzPaE7b2l9qX7d+B2CHfc3em681iZYlle2dCu4F2t5czyovK3u1fsvlZhW3FgD2mPZI+0MqiyvUqvakfVp+qk6oEaj5rmvep7t+2d2sfb17/fbX/TAY0DxQc+HhQcvH/I91BrrUFtxWHc4azDz+ui6rq/Z39ff0TtSPGRz0eFR6XHwo911TvU1zeoN5Q2wo2SxrHjccdv/eD1Q3sTq+lQM6O5+AQ4ITnx4sf4H++eDDzZeYp9qukn/Z/2ttBailqh1tzWibakNml7THvf6YDTnR3OHS0/m/989Iz2mZqzymdLz5HOFZybOZ93fvJCxoXxi4kXhzpXdD66tOTSna6wrt7LgZevXvG5cqnbvfv8VZerZ645XTt9nX297Yb9jdYeu56WX+x+aem172296XCz/ZbjrY6+BX3n+l37L972un3ljv+dGwOLBvruLr57/17cPel93v3RB6kPXj/Mejj9aP1j7OOiJwpPKp6qP6391fjXZqm99Oyg12DPs4hnj4a4Qy//lfmvT8MFz6nPK0a0RupHrUfPjPmM3Xqx9MXwy4yX0+OFvyn+tveV0auffnf7vWdiycTwa9HrmT9K3qi+OfrW9m3nZOjk03dp76anit6rvj/2gf2h+2P0x5Hp7E/4T5WfjT93fAn88ngmbWbm3/eE8/sKZW5kc3RyZWFtCmVuZG9iagoxMSAwIG9iagoyNjEyCmVuZG9iago3IDAgb2JqClsgL0lDQ0Jhc2VkIDEwIDAgUiBdCmVuZG9iagozIDAgb2JqCjw8IC9UeXBlIC9QYWdlcyAvTWVkaWFCb3ggWzAgMCA1OTUgODQyXSAvQ291bnQgMSAvS2lkcyBbIDIgMCBSIF0gPj4KZW5kb2JqCjEyIDAgb2JqCjw8IC9UeXBlIC9DYXRhbG9nIC9QYWdlcyAzIDAgUiA+PgplbmRvYmoKOSAwIG9iago8PCAvVHlwZSAvRm9udCAvU3VidHlwZSAvVHJ1ZVR5cGUgL0Jhc2VGb250IC9RV1dVUkYrQ2FsaWJyaSAvRm9udERlc2NyaXB0b3IKMTMgMCBSIC9Ub1VuaWNvZGUgMTQgMCBSIC9GaXJzdENoYXIgMzMgL0xhc3RDaGFyIDQyIC9XaWR0aHMgWyA0ODcgNTI3IDUyNQozNDkgMjI2IDc5OSAyNTIgNTI1IDUyNSAzMDUgXSA+PgplbmRvYmoKMTQgMCBvYmoKPDwgL0xlbmd0aCAxNSAwIFIgL0ZpbHRlciAvRmxhdGVEZWNvZGUgPj4Kc3RyZWFtCngBXZHLasMwEEX3+got00Ww7ObRgDGElIAXfVC3H2BLYyOoZSErC/997yhpCl2cxdHMFaNRdqqfa2ejzN7DpBuKsrfOBJqnS9AkOxqsE3khjdXxZulMj60XGcLNMkcaa9dPsiyFlNkHInMMi1wdzdTRA5+9BUPBukGuvk5NOmku3n/TSC5KJapKGupx3UvrX9uRZJai69qgbuOyRuqv43PxJDEREvl1JD0Zmn2rKbRuIFEqVZXncyXImX+lXF0TXX9rLfKqZJTaHipRFgUUKLXrWR+hQKn9lnUDBdCCdQsFShWKdQcFyBrWPRSgSqxPUIBsaj5AAZo3XG2hALpLc/8OyE/gVd9Xoy8hYCvpP9LCeBHW0f3L/OT54Ykf4AyMxQplbmRzdHJlYW0KZW5kb2JqCjE1IDAgb2JqCjI4OAplbmRvYmoKMTMgMCBvYmoKPDwgL1R5cGUgL0ZvbnREZXNjcmlwdG9yIC9Gb250TmFtZSAvUVdXVVJGK0NhbGlicmkgL0ZsYWdzIDQgL0ZvbnRCQm94IFstNTAzIC0zMTMgMTI0MCAxMDI2XQovSXRhbGljQW5nbGUgMCAvQXNjZW50IDk1MiAvRGVzY2VudCAtMjY5IC9DYXBIZWlnaHQgNjMyIC9TdGVtViAwIC9YSGVpZ2h0CjQ2NCAvQXZnV2lkdGggNTIxIC9NYXhXaWR0aCAxMzI4IC9Gb250RmlsZTIgMTYgMCBSID4+CmVuZG9iagoxNiAwIG9iago8PCAvTGVuZ3RoIDE3IDAgUiAvTGVuZ3RoMSAxNzkxNiAvRmlsdGVyIC9GbGF0ZURlY29kZSA+PgpzdHJlYW0KeAHVnHd8U9fd/8/VtmTZ8pCXwJIRtgHZmGlsILbwwhNssEA2yxsDZhnMCsMBAokTsnczSJqEtmRcCxIMIbM0q9mjaZMmJW3aZpHRZpKAf59zv/oy8jx5fn/8Xr/Xq4+stz6fM++533PuuTeyydrunnZhE71CL8a0Lm9eJbRXfhCS1bpurYfSGSVCGI92rFq8nNJZELtvcdfGDkrn3ypEpL+zvbmN0uJHaG4nMiitTIAO71y+dgOl82UHWV0rW8Pl+TuRTlrevCF8fPFnpD0rmpe3U/1SLb2quz1crmB8wz+hMv5UFL0wCYWTUmXCZpgsEhWLsAidcIgcsVuI2FzdRGFAqSw3jR9/Z8RtpxZFT/1aJFtkK/HIJ5tfkPrmDX0dP5w81RvxqSUXyQj0QC+0M99+6m0hrHt/OHlyb8Sn5x8WlWz9Efpps3XP6p4WecKteyas74o83dsioPsT9C3oH8P6B+ibSL8BfR36GvRV6OPQx6CPQo+KgDDo3hETQD3Qn3FtSN0N3gBGsQw9KcKG9oqI1z0lSkAbWAuuA0bUfQxld6NHRXh0Ow9GJCmVngHdDjbb2VzEppfNNjZb2Wxhs5nNhWw2sdnIZgOb9WzWselhs5bNGjar2axis5LNCjbL2XSxWcZmKZslbDrZLGbTwaadTRubVjYtbJrZNLFZxGYhmwVs5rOZx6aRTQObIJu5bOawCbCpZzObzSw2dWxq2cxkM4NNDZtqNlVsKtlUsClnM51NGZtSNiVsitkUsZnGxs+mkE0BmwvYTGUzhc1kNvls8thMYpPLZiKbCWzGsxnHZiybMWxy2Ixmk80mi42PzSg2I9mMYJPJJoNNOpvhbLxshrFJY+Nh42aTymYomyFsXGxS2CSzSWKTyCaBjZNNPJs4NrFsYtg42ESziWJjZxPJxsbGyiaCjYWNmY2JjZGNgY2ejY6NwkaEjTLI5jSbU2x+ZPMDm5NsvmfzHZtv2XzD5ms2X7H5N5t/sfmSzRdsPmfzGZsTbD5l8wmbj9l8xOZDNv9k8w82f2fzAZu/sfkrm/fZHGfzFzbvsXmXzZ/ZvMPmbTZ/YvNHNm+x+QObN9m8weZ1Nq+xeZXNK2xeZvMSmxfZvMDm92yeZ/Mcm2fZPMPmaTa/Y3OMzW/ZPMXmSTZPsHmczWNsHmVzlM0jbI6wOcxmgM0hNg+zeYjNQTYH2ITY9LNR2TzI5gE297O5j81+Nr9h82s2v2Kzj829bO5hczebX7K5i82dbPayuYPN7WxuY3Mrm1+wuYXNzWxuYnMjmxvYXM/mOjbXsrmGzdVsrmJzJZsr2Oxhczmby9j0sbmUzSVsdrPZxeZiNjvZ7GCznc1FbHrZbGOzlc0WNpvZXMhmE5uNbDawWc9mHZseNmvZrGHTzWY1m1VsVrJZwWY5my42y9gsZbOETSebxWw62LSzaWPTyqaFTTObJjaL2Cxks4DNfDbz2DSyaWATZDOXzRw2ATb1bGazmcWmls1MNjPYVLOpYlPJpoJNOZvpbMrYlLIpYVN8QD4tD+h2hlIL3HhmDqU6IdspdVEodTJSvZTaRrI1lBqJzC2U2kxyIckmko2hodNQZUNoaDFkPck6kh4qW0upNSTdlLk6NLQIDVaRrCRZQVWWk3SRLAsNKUXNpSRLSDpJFpN0hIaUoEo7pdpIWklaSJpJmkgWkSykdgsoNZ9kHkkjSQNJkGQuyRySAEk9yWySWSR1JLUkM0lmkNSQVJNUkVSGXBU4hwqS8pCrEqnpJGUhVxVSpSFXNaSEpJikiMqmUTs/SSG1KyC5gGQq1ZxCMpma55PkkUwiySWZSJ1NIBlPvYwjGUsyhjrLIRlN7bJJskh8JKNIRpKMIMmkrjNI0qnP4SRekmHUdRqJh9q5SVJJhpIMIXGRpIRSZiBYySRJoZSZSCWSJFCmkySeMuNIYkliqMxBEk2ZUSR2kkgqs5FYSSKozEJiJjGFkmtxdGMouQ5iINFTpo5SConQRBkkOa1VUU5R6keSH0hOUtn3lPqO5FuSb0i+DiXVuweUr0JJsyH/ptS/SL4k+YLKPqfUZyQnSD6lsk9IPqbMj0g+JPknyT+oyt8p9QGl/kapv5K8T3Kcyv5C8h5lvkvyZ5J3SN6mKn+i1B9J3golzsWp/CGUOAfyJskblPk6yWskr5K8QlVeJnmJMl8keYHk9yTPU5XnSJ6lzGdInib5Hckxkt9Szaco9STJEySPU9ljJI9S5lGSR0iOkBwmGaCahyj1MMlDJAdJDoQSCnHSoVDCPEg/iUryIMkDJPeT3Eeyn+Q3oQTs+sqvqZdfkeyjsntJ7iG5m+SXJHeR3Emyl+QO6ux26uU2klup7Bckt5DcTHITNbiRUjeQXE9yHZVdS71cQ3I1lV1FciXJFSR7SC6nmpdRqo/kUpJLSHaT7Ao5m3HuF4ecLZCdJDtCzg6ktpNcFHIGkOoNOXGzUbaFnLmQrSRbqPlmanchyaaQsw1VNlLzDSTrSdaR9JCsJVlDXXdT89Ukq0LOVvSykjpbQTWXk3SRLCNZSrKE2nWSLKaRdVDzdpI2qtlK0kLSTNJEsohkIZ30AhrZfJJ5dNKN1HUDHShIMpeGO4cOFKBe6klmk8wiqQvF+3FitaF4GdaZoXh5wc4Ixe+A1ITisyHVVKWKpDIUjwcJpYJS5STTKbMsFL8VZaWh+N2QklD8NkhxKL4XUhSKLYNMI/GTFJIUhGLxXKBcQKmpoZgGpKaQTA7FyOsonyQvFDMdqUmhmCAkNxTTCJlIZRNIxodispA5jmqODcXIExsTipEbUg7JaGqeTUfIIvFRZ6NIRlJnI0gySTJI0kMxMkrDSbzU5zDqM40681AvbpJUajeUZAiJiySFJDnkWIA+k0KOhZDEkGMRJIHESRJPEkcSSw1iqIGDMqNJokjsJJFU00Y1rZQZQWIhMZOYqKaRahooU0+iI1FIhH8wusUtOR3d6j4V3eb+Ef4HcBJ8j7zvkPct+AZ8Db5C/r/Bv1D2JdJfgM/BZ+AE8j8Fn6DsY6Q/Ah+Cf4J/RC12/z2q0/0B+Bv4K3gfecehfwHvgXeR/jP0HfA2+BP4o32Z+y37WPcfoG/au9xv2DPcr4PX4F+1+9yvgJfBSyh/EXkv2Je7fw//PPxz8M/al7qfsS9xP23vdP/Ovth9DG1/i/6eAk8C/+AT+HwcPAYejVztPhrZ7X4kco37SORa92EwAA4h/2HwEMoOouwA8kKgH6jgQdtG9wO2Te77bZvd99m2uPfbtrp/A34NfgX2gXvBPbZs993QX4K70OZO6F7bMvcd8LfD3wZuhf8F+roFfd2Mvm5C3o3gBnA9uA5cC65Bu6vR31XWGe4rrTPdV1gXu/dY73Ffbt3nvlif7t6pz3PvUPLc2wO9gYv29wa2BbYEtu7fErBtUWxbXFuqtly4Zf+Wd7b4Y03WzYFNgQv3bwpsDKwPbNi/PnBEt0t06C72Tw2s298TMPTE96zt0X/Vo+zvUUp6lDE9ik70OHo8PfrItYHuwJr93QHRXdvd2612G6ao3ce7daJbsQ4MPnGg25VaBvVv7rY7ylYHVgZW7V8ZWNGxPLAUA1yStzjQuX9xoCOvLdC+vy3QmtcSaM5rCizKWxBYuH9BYH5eY2De/sZAQ14wMBf15+TVBwL76wOz8+oCs/bXBWbmzQjMQH5NXlWgen9VoDKvPFCxvzwwPa8sUIqTF0McQzxD9A45gBlDMBLhUorGuPyu464vXAbhUl1PuPSx0SnuFN3I6GSleGaysjJ5W/KVyfropJeTdP6kkVll0YkvJ/4l8fNEQ5w/ceToMpHgSPAk6J3y3BJq6uW5HUgoLCEdO1E7V3eCN6Ms2qlEO91OXennTmWX0CseBb9DckD0FrQ5qDjdZfpHtV8rGYWiXCXqfVUDFjGrSrXUzlOVS9T02fLTX9eomi5RRaBxXrBfUa5o6Fd0xfVqfFVdI6Uv3rNHDC2qUofODob0e/cOLWqoUnul9/s1Pyi9QJUG38I1PWt8Qf8FIuZ4zBcxeufjjpcduuhoJTp6MFrnj8bgo6PcUTr5MRil90eNnVQWbXfbdfJj0K5P8NuRI0OZGVlbXxZtc9t0gULbTJvObyssLvPbsseU/ZfzPCDPk47sW7twjQ92rU97I9Wg9MgkXijBe81apOUPBGkhS37+RdVQb9EavLRuqPufb/K/oET5XzDG//Ah9gtcIsFpg7qd+F3mDrAdXAR6wTawFWwBm8GFYBPYCDaA9WAd6AFrwRqwGqwCK8EKsBx0gWVgKVgCOsFi0AHaQRtoBS2gGTSBRWAhWADmg3mgETSAIJgL5oAAqAezwSxQB2rBTDAD1IBqUAUqQQUoB9NBGSgFJaAYFIFpwA8KQQG4AEwFU8BkkA/ywCSQCyaCCWA8GAfGgjEgB4wG2SAL+MAoMBKMAJkgA6SD4cALhoE04AFukAqGgiHABVJAMkgCiSABOEE8iAOxIAY4QDSIAnYQCWzACiKABZiBCRiBYdogPvVABxQgRJuCPOU0OAV+BD+Ak+B78B34FnwDvgZfgX+Df4EvwRfgc/AZOAE+BZ+Aj8FH4EPwT/AP8HfwAfgb+Ct4HxwHfwHvgXfBn8E74G3wJ/BH8Bb4A3gTvAFeB6+BV8Er4GXwEngRvAB+D54Hz4FnwTPgafA7cAz8FjwFngRPgMfBY+BRcBQ8Ao6Aw2AAHAIPg4fAQXAAhEA/UMGD4AFwP7gP7Ae/Ab8GvwL7wL3gHnA3+CW4C9wJ9oI7wO3gNnAr+AW4BdwMbgI3ghvA9eA6cC24BlwNrgJXgivAHnA5uAz0gUvBJWA32AUuFm3TepWdcDvAdnAR6AXbwFawBWwGF4JNYCPYANaDdaAHrAVrQDdYDVaBlWAFWA66wDKwFCwBnWAx6ADtoA20ghbQDJrAIrAQLADzwTzQCBpAEMwFc0AA1IPZYBaoBTPBDFANqkAlqADlYDooA6WgBBSLtv/wbfo/fXgN/+kD/A8fn5CPZWcezORgkxYtxJ87mW8X4vS19MdR4c9asVSsEb342SX2iGvF4+Id0SJ2wN0s9op7xa+FKp4Uz4m3zmv1/5g4vdG4XETqD+EPweKEGDw5eOL0vWDAGHVOzrVIxRk8Z3MGHYOf/STvs9PXDjpOD5hihVVra9e9ht7+rZwaPIlbrknYB3NlWrcbPlo70pfm208/eHrfeSdQK+pEo5gn5osFokk04/zbRKdYgsgsE11iuVihpVagbDF8B1KLUAvbi+bP1lopVomVolusFT1iHX5Wwa8Jp2TZai3dI9bjZ4PYKDaJC8VmsSX8uV7L2YySTVruBpRsFdswMxeJ7ZpjpZwdYqe4GLO2W1wiLsWM/Xzq0jO1+sRl4nLM8xXiSvFzfs95JVeJq8TV4hqsh+vE9eIGcRPWxS/ErT/JvVHLv0XcLu7AmpEtrkfOHZq7QdwojoqnxUPiAfGgeFiLZStiSxHhuHRokV6FGGzGOe84Z8QUzfVnorUV0ZDn3Rc+7w2I3/ZzWqwLx1FGbwdqyuj0hedB9rIlnMORuApnRv7secoYyXO48rzz5Bb/t1x5xjJOtyJeHBkZsxuQd8t/yT23xrn+BnEbrsA78SmjKt1d8OTu0Py5+befqbtXK/uluFvcg7nYJ6RjpZx7kbdP/ArX9m/EfnEffs76cx2VPiDu12ZOFf0iJA6Ig5jJh8UhMaDl/09lD2Lv+GmbA+G+Qmd6OSyOiEewQh4TT2CneQo/nPMo8h4P5x7TalH6KfFbcUyrJUufwtp6BjvU8+L34gXxsvgdUi9pn88i9Yp4Tbwu3lLscK+Kj/B5Srxi/EBEiWn4W9kjmI1bxUL8/H98GVOEU+wd/G5w/eB3+nLRodTjAfI+zNJBcTm+mVhx9tCKW1gNfxXx4uDgN/r50BGn3jZ2nr5r8HN/466L167pXr1q5YrlXcuWLulc3NHe1rJo4YL58xobgoH62bPqamfOqKmuqqwon15WWlJcNM1fWHDB1CmT8/Mm5U7MGZ2dNSIjfbh3mDspPsYRbbdZIyxmk9Ggx/N5Vqm3rMmjZjSphgxveXm2THubkdF8TkaT6kFW2fl1VI9s14yi82r6UbPjJzX9VNN/pqbi8EwVU7OzPKVej/piidczoDTWBeH3lHgbPOoJzddo3pChJexIpKWhhac0qbPEoypNnlK1bF1nX2lTSXaW0m+zFnuL263ZWaLfaoO1wakjvKv6lREFimZ0I0on9+uExS4Pq+rTS5vb1Nq6YGmJKy2tQcsTxVpfqqlYNWt9eZaoGLO4zNOf9UTf5QMO0dLki2zztjXPD6r6ZjTq05f29e1WY3zqSG+JOnLTB0kIYLua5S0pVX1eDKxq1pkDKKox3eH19H0tMHjviU8x6nNymsM5pnTH10IWylM8EyZVaWYvMDaMEOeXlibHctmAX7QgofbWBSntES2ukPDn+BpUXZMseYJLnAFZ0sslZ5o3eRHZUm9pU/i9rjNJ7W3xZGdhZrV3umpIR7lH1Wc0tbR2Sm1u7/OW4AwRS1EfVP0lMP7mcDBL+8fkoH5zE05iiQxDXVDN8a5S471FFG1koJP00iWzg1oTyi1V44tV0dQabqXmlKItlkhpn5wYOUDZl7cueFiMHzzeP8HjOjBeTBANchxqQjEmJaO0L9jWobqbXG1Ynx2eoCtN9TcgfA3eYHuDnCWvQx15HIfDCxOotcK5/aQ2V8Zpq+Z0iyeoc+kb5Gwhw1OGD2/RVBQ4VBMl5YwWTfUEFZfgajhKuIZ05/WDhD69uByNoWhaXO5Kw+LWXv/DkFx0AhiGajkzJgMGYTw7JjrOzw6NassBjfSUtpecM8DzOkVCG2C4t/9+nDoZi3AwMASLnM5yeQ7ZWTp4D4otqg7nqWXJWUzyqKLWE/S2exu8WEP+2qCcHBlrbX6rZnvl16vabIdXSf15KSrPozJVpFXVBzkhv3lSy3zavMpp1dLTtfSZZPlPiiu4GPuOqO3ra+sX+nS5lF39imaMxZc1qDN9DV61xedNk+PMzuq3iMi0+qZiXL1l2Dm9Zc1ej8NT1tc8MNjb0tfv9/etKm3qnIzros9b0dbnnR2cisnVNoItrk1yLLGiSqmqL0JXOlHU71Uuqev3K5fMbgwedgjhuaQ+GNLhu+amoob+4SgLHvYI4ddydTJXZsoqHpmQPc1CwqLVdx32C9GrlRq0DC3dOqAILY8qIU8RrQM6ynNo9foztAP58W8nWgcMVOLnHgzIs1BeL9UeEa5tQYlDlhwRuJHgyz+MmV70TaDfavRb/BH+SJ1dh5DKKQkh5wjqRijiQKRiV1z96BNngGz8Sro/wu86rPVEWUeUXtSUeb3oPVxNJ2S1czrCIenEA5DwGQQagwciBfrXPlGjSL6whSR1Yo3hRlPqaZPrb3NDZ19Tg9w9RALWKt6KqngLhKrzFmDEpkjV6m0vUm3eIplfKPMLKd8k883eIlVJUDDZA9h0+5q82IhxTQXx644GLH+HvLx16Z6BwcH6YNqLrhMNabjm54PGoBrhw43OmF6JetMlTcierva2NstxiAD2Mrn1VLQ24GLnDlGlQo1ADxHhHlCjTGsjrzc0asVaw4LU2vciofY2qA0+edDgEjkij8ehinLvZNWUQX0aM+SBchr6Yr3j5JWLqqo1fbeUCIxNzA5SjgtJHAx3FHlG5kiMvNWLotYmD6KONTIb1zLdLKxyHSKnHXu+IaNdw+oKFwp5Wvp0m92qRoxGh3hLbxuNDvE2NyAo8uS11O5wBRzbodowooxzQhlugOigqEKOBe/dGLys+qTspm5AzPJuwN4vB60dyoxi1Z5e0Yy7G7W3Icebx43RlyVdZsk+jlGuWZ55JOKOLWFgcJ93o9zi+JWd5ZV3P7n+hOswLlTR0PfTDHWeLzvL8tNcu5bd12ex//cNKF4W+xmVveBEWuVtDSoXnLbePKXyBuut7NfNQA2oomlfpRc3NV26BA86elw+aZ62BlkLQ67V9jLvz1VCF2cqydu01nmfY4p8KpEplGspJPDuUxefn+w8kyxDcRkeBtNHA+2dgYmR+/5Sl9qFlYlirYqcEU+fx+Gd7JUfOFU9rgbQhHk6c1lg+WPVyYumt9UTbMFiR3jKmvrK+nAQT2szmsk1GD6SusJ3Xpe4LhRchwiIjILaW+tpavA04dFUqQumpblwNUI9Hc2q39ssbwW1OD7etbglQZr75BIXDTioSzXjxtTR3O5Nww0HeQ1aXLX5wdHpshGuvj5vn6ptBGWojO4zcNlVSMF7lc/b3C4foXE8T3O71rYMw9WiI8fnKvXiWm7HaGXccV7411+iRX609nnR24ImHyIR0xfb58nvwxa8AHcPQ0brnCbcquQdyaNNdbMLKcS1QqYa0BFVjEiXFekSkKNZ7utfYE4/myOvRXWljypbtF4xsllBtZYbadeTrLXap+oS81CIkarKLOxsiL/cpxA8Y3oFwuvH0nPJ1h5Vh9srTY/WvkI2xdZAE0bNkKPdRLRLDDdJvtvwfWi+CzH92XxhiBICX9cL/T9EqmGCaNKtFummNnGzIU80In2z7nn4CfhHdkb81zmq4ke+IvEdUSo0TVhxDzHh3xFaUGJEyox/xGfQ6jwuHlemKB/rtuk3GZINzxpnGb82eVBHnF6jfw3fQOlRN1/UiBniRvViX/Ao7j+zRIKYrDz0kLOkxJJtfkwpRucefL+MzpVif7RBZz+UklLoPTTRtEcfUzGgZB8sNO/Bb04KT7136qWcU++diM3POaHkvPv+e+87vnwpJj9n/PtvvD8Wv0mPT7Ef6kLTid5DXRP1pj1d+phC2d4f0VXo15n3dKGTpEJfyku+l3J8L/nQjW/M2AYlJi1GIz5KZzbHm7zDRusmZmbkjh8/rkA3cUKGd1iUTsubkDupQD9+XKpOj5qUU6CTaUX/2o+N+pmnTLqt3sI5442pKdHxdpNRNyQpNntqumP2vPSpo4ea9WaT3mgxj5hUNKyqq3TY2+aYoc6EobEWS+zQBOfQGPOpd4xRJ/9ljPqh2ND1w3V605T5hcP1N1ktOoPJNJCalDxqSlrFnOg4h8EW54hJsJhjYyJHlMw/tcs5RPYxxOmkvk7VYI5SB0/qnzHGi1FitYw6NuHBDw84lBoxMPjFgeiw2jX9Bs8cMv/DAzboEV2MiMRfESQqNZHyt+uRqBSZPstlip1lCojCwtj8QiXH53tf+7oXMT90pixJK9TiyeGJUTIycnNlhBLjEhISx+fmToqTEUxIMJl1FZb4YUnJaU7L6WtsxujMtNT0BJvxQPK4FF3i2OSDelvcsJThIx1Gm/Ltaa8l0mw0miMtyru6txNTogwGs916+vKJa6fkr56krLNGmQ3GqJQELKOmwRP6W/FNagbW3FF55n534RTF5sp34DzyrTjTfAfCkO9ADPKTcML5j+DXbULkDB4/gBo5Mgwoh2ph0hSNtHzUzhnQWf3WuLQyW36myxA1akAxhpIqJwwohgNRNcZqxOdE4YnYRBkjitAbJOPyx45Z4PJbuWGSbHmwK6kySrY92KU1RgB9hT7ZGkFM5xhONNGCnCCXWkJijKapOqc+Q1uYzvhU5BfoJulvNccMiZdrYfrN81ovnztiXMvVi2bu8Jvj3UnJntiIe4u3lBQGJyU7J8yZlnaBvywzGUFFICMt62vm1Ozob1n7yM7ppcU6m9kuY203nyqdPXdqy2Z/yfb2C2JHFY/FqkrHd8i7jBvEVHGJjG0owYF1c/ygXDcuGTFEUOrBaIdSDaOtLKi2slwDyvehMaPSBwZf8cc6YpTqdOuJ3OkpGSfGlHuqHeUIXeGJcYW4rH3Hxn8pV9cx3/hj8qKOybWe6ELNMRknusJ1EalC37hC7eINx0lepE6nXGpOXMHeGA5fjHdYxkQZs/Ha57hUg26XwWgxmZ2pI13pEzxRz1lsEcbY6OcscZ6kJE+cZZvDYbBEWrZ5y5dXeouGR1r0xui4xChjhC0iaXzd5BZzTErccM+Pn1hsFoMBH3qnZ3hcSox5wcLdc0baoyPjXHL/vHnwpPEV/fOiVknVVqEr1oEoxckVl+GwRSrVmUnyc9UspSwuHCioFijoF3INaoplCv1YRjZuQPnOn5qaAJuaOs4q17JVrmqr7NTqkDG3IsaHav0xSk1tQWa4W6jWLVTrVlN0qymaZz6C3zWPEw7FFKqqHD6gmPz2aZUFZdl5FdnVydXampYXdr5c2byq89+gDQBbb3gnkOtb+wsZV3+VA50c7KqqnKb1FtV1fndy7rT+sNbPXecxE0ZjTzWZz87cf82g3dbpDO8ptBk7ja9YYj1Y43GW+KyS0flrSuVUJqbFmROyikfnry1BaTJm1myKHZKYMNRhrr6yIq+hZIwju65q+vC56yrcyTyXOm/+wpLhwcCpy34+R78TC0avj7BZ1gdmpuRMGzG2ZFTcBR2XVmP3acTu8x5mPU5kiue0eR9SOFIZEauMxE5oVzIilQyLkmFWRumVkTolNbzZQLXNBqptQtDP5J6slWNuU+Wmk5pjVazxSVgX8XLvivdg6uJjUSteTn/8EfzpgRh84lC0qFmF5Zc8oCih6ErvgKLrN9YImrsF4bnKWcC79wJ+ufqjZZODXdGVRtko1IVWuFOed4mFLyCdWZsYXG7hrUf/3uQ193evvGdFbv6a+9ZAJz3gKlg6s2JJSZqrcOnM8qUlHuXvKw7vqiraerAbWgndXLG9JX/Cou01ldub8ycs3C4QvZtPX6d/E9EbJS4Q/TJ6DxUWKmm5+MM9bWeBahuKTGs7DIy2srHqv/MnOn0yJD4ZEl+SvBh8MjA+GbsI4bTmTkwzGMdg1304o9JV4ZiZDxsODTYebLpKDu3VDi04tGEfomYZsh2eIailUTY9EyBsRGgs73rhHSfznAXM65UWKsfNHJOQILds/ZvjW69ZOKJkmn/4OUs03umKNY+srqnLbumbO+IB5/g5fk8BtuuSTcUFDZNSlI/WHd0x3TFsgvd0AbYpbEH4+AirUa/Hutw4qmCks3rngz2lF7VNjRtZPPb0LfiqpW0z7Ui6fYjueLFLxvbgqolKRnQ4pFAtklAKrTRyz4mWoY0V/jjs8HJbETLGIgURT/dH+Cozop2eCqe87WkbhJJzDPu2Fj/tftfv0ypau87W1B4S8s9bVnLnPveqPy9oJt0+nSnCYkkcOtyZPGbiZO85kdIu5vRpk/OH2tOGD4006BV9S0JqTEREhCV+dPWkUypfxGcv2R25JZnReovVGhHlQkyuk08L+qPY/ga0q9VdOEGxZcpNNVNur5kWrKBMbWfNlNt3JrbXhykO7nCAoNqihH6nLUpp5IOUrMAZX1CG8r0/Ii67ItNmTK7A1mg8+8ggo8d7qy+8t/rokSEi3CBKtjj3QUG2OXf/5OeEMw8IMdrlmTvpTAaeEGKHOhOHxphqbqhpvLA6zRxPt7zEnPIxBReW4kkB+2RsxJntcH1gxtTFl7bohvGOd+qrmYuK04MBXQ/nyHvdjYPf4o9QjuP/xTJSRrFfmPDg+DDiZ4rQY228iFv6k7iRH4jwI5lUmPKiNmw81eDGjIfDBGVFTsHU0ZLl03NGlwL5HxaKiAXyZcJvpkTd3LmBWWW+4uauJS3dS/4PaVaRpAplbmRzdHJlYW0KZW5kb2JqCjE3IDAgb2JqCjg3MTkKZW5kb2JqCjE4IDAgb2JqCihNaWNyb3NvZnQgV29yZCAtIERvY3VtZW50MSkKZW5kb2JqCjE5IDAgb2JqCihtYWNPUyBWZXJzaW9uIDEwLjE0LjUgXChCdWlsZCAxOEYyMDNcKSBRdWFydHogUERGQ29udGV4dCkKZW5kb2JqCjIwIDAgb2JqCihXb3JkKQplbmRvYmoKMjEgMCBvYmoKKEQ6MjAyMDA0MjAxMzIwMDNaMDAnMDAnKQplbmRvYmoKMjIgMCBvYmoKKCkKZW5kb2JqCjIzIDAgb2JqClsgXQplbmRvYmoKMSAwIG9iago8PCAvVGl0bGUgMTggMCBSIC9Qcm9kdWNlciAxOSAwIFIgL0NyZWF0b3IgMjAgMCBSIC9DcmVhdGlvbkRhdGUgMjEgMCBSIC9Nb2REYXRlCjIxIDAgUiAvS2V5d29yZHMgMjIgMCBSIC9BQVBMOktleXdvcmRzIDIzIDAgUiA+PgplbmRvYmoKeHJlZgowIDI0CjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAxMzI4NCAwMDAwMCBuIAowMDAwMDAwMzA1IDAwMDAwIG4gCjAwMDAwMDMyNzggMDAwMDAgbiAKMDAwMDAwMDAyMiAwMDAwMCBuIAowMDAwMDAwMjg2IDAwMDAwIG4gCjAwMDAwMDA0MDkgMDAwMDAgbiAKMDAwMDAwMzI0MiAwMDAwMCBuIAowMDAwMDAwMDAwIDAwMDAwIG4gCjAwMDAwMDM0MTEgMDAwMDAgbiAKMDAwMDAwMDUwNiAwMDAwMCBuIAowMDAwMDAzMjIxIDAwMDAwIG4gCjAwMDAwMDMzNjEgMDAwMDAgbiAKMDAwMDAwMzk5MyAwMDAwMCBuIAowMDAwMDAzNjA5IDAwMDAwIG4gCjAwMDAwMDM5NzMgMDAwMDAgbiAKMDAwMDAwNDIyOSAwMDAwMCBuIAowMDAwMDEzMDM5IDAwMDAwIG4gCjAwMDAwMTMwNjAgMDAwMDAgbiAKMDAwMDAxMzEwNSAwMDAwMCBuIAowMDAwMDEzMTgwIDAwMDAwIG4gCjAwMDAwMTMyMDMgMDAwMDAgbiAKMDAwMDAxMzI0NSAwMDAwMCBuIAowMDAwMDEzMjY0IDAwMDAwIG4gCnRyYWlsZXIKPDwgL1NpemUgMjQgL1Jvb3QgMTIgMCBSIC9JbmZvIDEgMCBSIC9JRCBbIDxhNTlhMjk3NTViNWFhZjIxZDBkNzgxNDYxNmZjYzM5OT4KPGE1OWEyOTc1NWI1YWFmMjFkMGQ3ODE0NjE2ZmNjMzk5PiBdID4+CnN0YXJ0eHJlZgoxMzQyOAolJUVPRgo=";

    @BeforeEach
    public void setUp() {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        baseEndpoint = String.format("http://localhost:%s/retentions-service", serverPort);
    }

    @Test
    public void testWeReturn200AndDownloadedTrue() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");
        stubEsisResponse("esis/esis-retrieve-sucess-response.xml");

        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(200).
            body("data.pdfString", equalTo(PDF_STRING),
                    "data.downloaded", equalTo(true),
                    "info.status", equalTo("ok"),
                    "info.code", equalTo(""),
                    "info.message", equalTo("Data found"));
    }

    @Test
    public void testWeReturn200AndDownloadedFalse() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-false-response.json");
        stubEsisResponse("esis/esis-retrieve-sucess-response.xml");

        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(200).
            body("data.pdfString", equalTo(PDF_STRING),
                    "data.downloaded", equalTo(false),
                    "info.status", equalTo("ok"),
                    "info.code", equalTo(""),
                    "info.message", equalTo("Data found"));
    }

    @Test
    public void testWeReturn400WhenEsisRefIdContainsSpecialCharacters() {

        String badEsisRefId = "esis&ref^id";
        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, badEsisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(400).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("ESIS_ID_BAD_FORMAT"),
                    "info.message", equalTo("esis_ref_id format is not valid"));
    }

    @Test
    public void testWeReturn401WhenCustomerFailsJwtValidation() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");

        String esisRefId = "esis-ref-id";
        int badAccountNumber = 1234567890;
        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, badAccountNumber, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(401).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("SECURITY_KO"),
                    "info.message", equalTo("Mortgage does not belong to customer"));
    }

    @Test
    public void testWeReturn500WhenProductSwitchServiceIsDown() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfoDown();

        String esisRefId = "esis-ref-id";
        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(500).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("PRODUCT_SWITCH_CONNECTION_ERROR"),
                    "info.message", equalTo("Exception while calling product switch service"));
    }

    @Test
    public void testWeReturn403WhenProductSwitchClientReturnsRowWithDifferentEsisRefId() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-mismatch-esis-ref-id-response.json");

        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(403).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("ESIS_REF_ID_NOT_MATCHING"),
                    "info.message", equalTo("esis ref id returned does not match request"));
    }

    @Test
    public void testWeReturn403WhenAccountIsForbiddenFromAccessingResource() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-mismatch-account-response.json");

        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(403).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("ACCOUNT_NOT_MATCHING"),
                    "info.message", equalTo("The account is not allowed to access this resource"));
    }

    @Test
    public void testWeReturn500WhenEsisIsDown() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");
        stubEsisDown();

        String url = String.format("%s/%s/offer/retrieve/%s", baseEndpoint, ACCOUNT_NUMBER, esisRefId);

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            get(url).
        then().
            statusCode(500).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("ESIS_CONNECTION_ERROR"),
                    "info.message", equalTo("Exception while calling Esis service"));
    }
}

package com.santanderuk.corinthian.services.retentions.api.model;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.retentions.api.mapper.ProductSwitchGassFormattedDataMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Calculations;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealLoanView;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import com.santanderuk.corinthian.services.retentions.api.model.gass.AcceptanceGassFormattedData;
import com.santanderuk.corinthian.services.retentions.api.model.gass.CreateCaseRequestFormattedData;
import com.santanderuk.corinthian.services.retentions.api.model.gass.ProductFeeFormattedData;
import com.santanderuk.corinthian.services.retentions.api.utils.DateUtils;
import com.santanderuk.corinthian.services.retentions.api.utils.ProductUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProductSwitchGassFormattedDataMapperTest {

    @Mock
    private GassDataFetcherRetentionsService gassDataFetcherRetentionsService;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ProductUtils productUtils;

    @Mock
    private GassConfig mockConfig;

    ProductSwitchGassFormattedDataMapper messageGenerator;

    Clock fixedClock = Clock.fixed(Instant.parse("2019-10-03T10:15:30.00Z"), ZoneId.systemDefault());

    private static final String JWT_TOKEN = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";
    private static final String CUSTOMER_NUMBER = "ldap-uid";
    private static final int ACCOUNT = 123456;
    private static final String MCC_ID = "my-mcc-id";


    @BeforeEach
    void setUp() {

        messageGenerator = new ProductSwitchGassFormattedDataMapper(gassDataFetcherRetentionsService, dateUtils, productUtils, fixedClock, mockConfig);
    }

    @Test
    void testWeGenerateFormattedDataSingleLoan() {

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();

        when(productUtils.calculateLoanSwitchingProductEndDate(any(DealLoanView.class), any(Product.class))).thenReturn("12/12/2035");
        when(productUtils.calculateLoanSwitchDate(anyString(), any(DealLoanView.class))).thenReturn("12/12/2015");
        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        when(mockConfig.getAnmfSortcode()).thenReturn("090128");

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.getCustomerNumber(), equalTo(CUSTOMER_NUMBER));
        assertThat(formattedData.getUid(), equalTo("pgwe51ZD"));
        assertThat(formattedData.getMultiChannelContractId(), equalTo(MCC_ID));
        assertThat(formattedData.getMortgageSortcode(), equalTo("090128"));
        assertThat(formattedData.getMortgageAccount(), equalTo("000123456"));
        assertThat(formattedData.isJointMortgage(), equalTo(true));

        assertEquals(2, formattedData.getSwitchedLoanParts().size());

        assertThat(formattedData.getSwitchedLoanParts().get(0).getPartId(), equalTo(9));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getCurrentProductDescription(), equalTo("2 YEAR FIXED"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getLoanScheme(), equalTo("PR"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getApplicationSequenceNumber(), equalTo(1));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getCurrentProductEndDate(), equalTo("12/12/2022"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getCurrentInterestRate(), equalTo("1.11%"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getLoanEndDate(), equalTo("12/12/2032"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getLoanBalance(), equalTo("£11111.11"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getCurrentProductCode(), equalTo("PR001"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).isFeeAddedToThisLoan(), equalTo(true));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getSwitchDate(), equalTo("12/12/2015"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getNewProductEndDate(), equalTo("12/12/2035"));

        assertThat(formattedData.getSwitchedLoanParts().get(1).getPartId(), equalTo(10));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getCurrentProductDescription(), equalTo("STANDARD VARIABLE RATE"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getLoanScheme(), equalTo("3T"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getApplicationSequenceNumber(), equalTo(2));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getCurrentProductEndDate(), equalTo("11/11/2031"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getCurrentInterestRate(), equalTo("2.22%"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getLoanEndDate(), equalTo("11/11/2031"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getLoanBalance(), equalTo("£22222.22"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).getCurrentProductCode(), equalTo("PR002"));
        assertThat(formattedData.getSwitchedLoanParts().get(1).isFeeAddedToThisLoan(), equalTo(false));

        assertThat(formattedData.getNewProductDetails().getProductCode(), equalTo("PR003"));
        assertThat(formattedData.getNewProductDetails().getProductDescription(), equalTo("some-mortgage-productDescription"));
        assertThat(formattedData.getNewProductDetails().getInterestRate(), equalTo("0.23%"));
        assertThat(formattedData.getNewProductDetails().getProductFee(), equalTo("£999.00"));
        assertThat(formattedData.getNewProductDetails().getEarlyRepaymentCharge(), equalTo("3.00%"));
        assertThat(formattedData.getNewProductDetails().getOverpaymentAllowance(), equalTo("10.00%"));
        assertThat(formattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));
        assertThat(formattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));

    }

    @Test
    void testERCPercentageNoChargeAndAnnualOverpaymentAllowanceUnlimitedForTrackerProducts() {

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        CreateCaseRequest createCaseRequest = getCreateCaseRequest();
        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setSelectedDeal(getDeal());
        coreRetentionsData.getSelectedDeal().getProduct().setErcPercentage(new BigDecimal("0"));
        coreRetentionsData.getSelectedDeal().getProduct().setAnnualOverpaymentAllowancePercentage(new BigDecimal("0"));
        coreRetentionsData.setCustomerDetailsResponse(generateDefaultCustomerData());
        coreRetentionsData.setAnmfAccountServiceResponse(getAnmfAccountInfoResponse());
        coreRetentionsData.setCaseRequest(createCaseRequest);

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.getNewProductDetails().getEarlyRepaymentCharge(), equalTo("No charge"));
        assertThat(formattedData.getNewProductDetails().getOverpaymentAllowance(), equalTo("Unlimited"));
        assertThat(formattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));
    }

    @Test
    void testMonthlyPayment_DealCostAndRemainingBalance() {

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.getNewProductDetails().getRemainingBalance(), equalTo("£22222.33"));
        assertThat(formattedData.getNewProductDetails().getMonthlyPayment(), equalTo("£111.22"));
    }

    @Test
    void testMonthlyPayment_DealCostAndRemainingBalanceWithOutFee() {

        CreateCaseRequest createCaseRequest = getCreateCaseRequest();
        createCaseRequest.setFeeAddedInMortgage(false);

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData(createCaseRequest);

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.getNewProductDetails().getRemainingBalance(), equalTo("£22222.22"));
        assertThat(formattedData.getNewProductDetails().getMonthlyPayment(), equalTo("£111.11"));
    }


    @Test
    void testRemainingTermAndRepaymentType() {

        CreateCaseRequest createCaseRequest = getCreateCaseRequest();
        createCaseRequest.setFeeAddedInMortgage(false);
        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData(createCaseRequest);

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);
        when(dateUtils.toYearsAndMonths(any())).thenReturn("12 years 6 months");

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.getSwitchedLoanParts().get(0).getRemainingTerm(), equalTo("12 years 6 months"));
        assertThat(formattedData.getSwitchedLoanParts().get(0).getRepaymentType(), equalTo("Interest only"));
    }

    @Test
    void testRepaymentTypeRepayment() {

        CreateCaseRequest createCaseRequest = getCreateCaseRequest();
        createCaseRequest.setFeeAddedInMortgage(false);

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setSelectedDeal(getDeal());
        coreRetentionsData.getSelectedDeal().getProduct().setErcPercentage(new BigDecimal("0"));
        coreRetentionsData.getSelectedDeal().getProduct().setAnnualOverpaymentAllowancePercentage(new BigDecimal("0"));
        coreRetentionsData.setCustomerDetailsResponse(generateDefaultCustomerData());
        AnmfAccountServiceResponse anmfAccountServiceResponse = getAnmfAccountInfoResponse();
        anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORepaymentType("R");
        coreRetentionsData.setAnmfAccountServiceResponse(anmfAccountServiceResponse);
        coreRetentionsData.setCaseRequest(createCaseRequest);

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);
        assertThat(formattedData.getSwitchedLoanParts().get(0).getRepaymentType(), equalTo("Repayment"));
    }

    @Test
    void testWeGenerateFormattedDataJointAccount() {

        CreateCaseRequest createCaseRequest = getCreateCaseRequest();

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setSelectedDeal(getDeal());
        CustomerDetailsResponse customerDetailsResponse = generateDefaultCustomerData();
        customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().remove(1);

        coreRetentionsData.setCustomerDetailsResponse(customerDetailsResponse);
        coreRetentionsData.setAnmfAccountServiceResponse(getAnmfAccountInfoResponse());
        coreRetentionsData.setCaseRequest(createCaseRequest);

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.isJointMortgage(), equalTo(false));


    }

    @Test
    void testWeStartDateEmpty() {

        CreateCaseRequest createCaseRequest = getCreateCaseRequest();
        when(productUtils.calculateLoanSwitchDate(anyString(), any(DealLoanView.class))).thenReturn("");
        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);

        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setSelectedDeal(getDeal());
        CustomerDetailsResponse customerDetailsResponse = generateDefaultCustomerData();
        customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().remove(1);

        coreRetentionsData.setCustomerDetailsResponse(customerDetailsResponse);
        coreRetentionsData.setAnmfAccountServiceResponse(getAnmfAccountInfoResponse());
        coreRetentionsData.setCaseRequest(createCaseRequest);

        CreateCaseRequestFormattedData formattedData = messageGenerator.createFormattedData(ACCOUNT, JWT_TOKEN, coreRetentionsData);

        assertThat(formattedData.getSwitchedLoanParts().get(0).getSwitchDate(), equalTo("Mortgage Offer acceptance date"));
    }

    @Test
    void testWeMapAcceptLaterProductDetailsFeeRolledIntoMortgage() {

        when(productUtils.calculateLoanSwitchingProductEndDate(any(DealLoanView.class), any(Product.class))).thenReturn("12/12/2035");
        when(productUtils.calculateLoanSwitchDate(anyString(), any(DealLoanView.class))).thenReturn("12/12/2015");
        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);
        when(mockConfig.getAnmfSortcode()).thenReturn("090128");

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();

        AcceptanceGassFormattedData acceptanceGassFormattedData = messageGenerator.createProductSwitchAcceptLaterFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, "12/12/2020");

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductCode(), equalTo("PR003"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductDescription(), equalTo("some-mortgage-productDescription"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getInterestRate(), equalTo("0.23%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductFee(), equalTo("£999.00"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getEarlyRepaymentCharge(), equalTo("3.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getOverpaymentAllowance(), equalTo("10.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));
        assertFalse(acceptanceGassFormattedData.getNewProductDetails().isFeePaidUpfront());

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getMonthlyPayment(), equalTo("£111.22"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getRemainingBalance(), equalTo("£22222.33"));

        assertEquals(2, acceptanceGassFormattedData.getSwitchedLoanParts().size());

        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getPartId(), equalTo(9));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentProductDescription(), equalTo("2 YEAR FIXED"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getLoanScheme(), equalTo("PR"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getApplicationSequenceNumber(), equalTo(1));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentProductEndDate(), equalTo("12/12/2022"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentInterestRate(), equalTo("1.11%"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getLoanEndDate(), equalTo("12/12/2032"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getLoanBalance(), equalTo("£11111.11"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentProductCode(), equalTo("PR001"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).isFeeAddedToThisLoan(), equalTo(true));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getSwitchDate(), equalTo("12/12/2015"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getNewProductEndDate(), equalTo("12/12/2035"));

        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getPartId(), equalTo(10));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentProductDescription(), equalTo("STANDARD VARIABLE RATE"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getLoanScheme(), equalTo("3T"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getApplicationSequenceNumber(), equalTo(2));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentProductEndDate(), equalTo("11/11/2031"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentInterestRate(), equalTo("2.22%"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getLoanEndDate(), equalTo("11/11/2031"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getLoanBalance(), equalTo("£22222.22"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentProductCode(), equalTo("PR002"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).isFeeAddedToThisLoan(), equalTo(false));

        assertThat(acceptanceGassFormattedData.getMultiChannelContractId(), equalTo(MCC_ID));
        assertThat(acceptanceGassFormattedData.getCustomerNumber(), equalTo(CUSTOMER_NUMBER));
        assertThat(acceptanceGassFormattedData.getUid(), equalTo("pgwe51ZD"));

        assertThat(acceptanceGassFormattedData.getMortgageSortcode(), equalTo("090128"));
        assertThat(acceptanceGassFormattedData.getMortgageAccount(), equalTo("000123456"));
        assertThat(acceptanceGassFormattedData.isJointMortgage(), equalTo(true));

        assertThat(acceptanceGassFormattedData.getCorrespondenceDetails().getEmailAddress(), equalTo("example@email.com"));
        assertThat(acceptanceGassFormattedData.getCorrespondenceDetails().getMobileNumber(), equalTo("07696969696"));

        assertTrue(acceptanceGassFormattedData.isAcceptanceEmailSent());
        assertFalse(acceptanceGassFormattedData.isOfferAccepted());
        assertTrue(acceptanceGassFormattedData.isOfferDownloaded());
    }

    @Test
    void testWeMapAcceptLaterProductDetailsFeePaidUpfront() {


        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();
        coreRetentionsData.getCaseRequest().setFeeAddedInMortgage(false);

        AcceptanceGassFormattedData acceptanceGassFormattedData = messageGenerator.createProductSwitchAcceptLaterFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, null);

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductCode(), equalTo("PR003"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductDescription(), equalTo("some-mortgage-productDescription"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getInterestRate(), equalTo("0.23%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductFee(), equalTo("£999.00"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getEarlyRepaymentCharge(), equalTo("3.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getOverpaymentAllowance(), equalTo("10.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));
        assertTrue(acceptanceGassFormattedData.getNewProductDetails().isFeePaidUpfront());

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getMonthlyPayment(), equalTo("£111.11"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getRemainingBalance(), equalTo("£22222.22"));

        assertFalse(acceptanceGassFormattedData.isOfferDownloaded());
    }

    @Test
    void testWeMapAcceptNowProductDetailsFeeRolledIntoMortgage() {

        when(productUtils.calculateLoanSwitchingProductEndDate(any(DealLoanView.class), any(Product.class))).thenReturn("12/12/2035");
        when(productUtils.calculateLoanSwitchDate(anyString(), any(DealLoanView.class))).thenReturn("12/12/2015");
        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);
        when(mockConfig.getAnmfSortcode()).thenReturn("090128");

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();

        AcceptanceGassFormattedData acceptanceGassFormattedData = messageGenerator.createProductSwitchAcceptNowFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, "19/12/2021");

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductCode(), equalTo("PR003"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductDescription(), equalTo("some-mortgage-productDescription"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getInterestRate(), equalTo("0.23%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductFee(), equalTo("£999.00"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getEarlyRepaymentCharge(), equalTo("3.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getOverpaymentAllowance(), equalTo("10.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));
        assertFalse(acceptanceGassFormattedData.getNewProductDetails().isFeePaidUpfront());

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getMonthlyPayment(), equalTo("£111.22"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getRemainingBalance(), equalTo("£22222.33"));

        assertEquals(2, acceptanceGassFormattedData.getSwitchedLoanParts().size());

        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getPartId(), equalTo(9));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentProductDescription(), equalTo("2 YEAR FIXED"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getLoanScheme(), equalTo("PR"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getApplicationSequenceNumber(), equalTo(1));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentProductEndDate(), equalTo("12/12/2022"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentInterestRate(), equalTo("1.11%"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getLoanEndDate(), equalTo("12/12/2032"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getLoanBalance(), equalTo("£11111.11"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getCurrentProductCode(), equalTo("PR001"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).isFeeAddedToThisLoan(), equalTo(true));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getSwitchDate(), equalTo("12/12/2015"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getNewProductEndDate(), equalTo("12/12/2035"));

        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getPartId(), equalTo(10));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentProductDescription(), equalTo("STANDARD VARIABLE RATE"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getLoanScheme(), equalTo("3T"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getApplicationSequenceNumber(), equalTo(2));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentProductEndDate(), equalTo("11/11/2031"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentInterestRate(), equalTo("2.22%"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getLoanEndDate(), equalTo("11/11/2031"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getLoanBalance(), equalTo("£22222.22"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getCurrentProductCode(), equalTo("PR002"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).isFeeAddedToThisLoan(), equalTo(false));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getSwitchDate(), equalTo("12/12/2015"));
        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(1).getNewProductEndDate(), equalTo("12/12/2035"));

        assertThat(acceptanceGassFormattedData.getMultiChannelContractId(), equalTo(MCC_ID));
        assertThat(acceptanceGassFormattedData.getCustomerNumber(), equalTo(CUSTOMER_NUMBER));
        assertThat(acceptanceGassFormattedData.getUid(), equalTo("pgwe51ZD"));

        assertThat(acceptanceGassFormattedData.getMortgageSortcode(), equalTo("090128"));
        assertThat(acceptanceGassFormattedData.getMortgageAccount(), equalTo("000123456"));
        assertThat(acceptanceGassFormattedData.isJointMortgage(), equalTo(true));

        assertThat(acceptanceGassFormattedData.getCorrespondenceDetails().getEmailAddress(), equalTo("example@email.com"));
        assertThat(acceptanceGassFormattedData.getCorrespondenceDetails().getMobileNumber(), equalTo("07696969696"));

        assertTrue(acceptanceGassFormattedData.isAcceptanceEmailSent());
        assertTrue(acceptanceGassFormattedData.isOfferAccepted());
        assertTrue(acceptanceGassFormattedData.isOfferDownloaded());
    }

    @Test
    void shouldDecorateProductSwitchFeeFormattedDataObject() {

        when(gassDataFetcherRetentionsService.fetchCustomerNumber(JWT_TOKEN)).thenReturn(CUSTOMER_NUMBER);
        when(gassDataFetcherRetentionsService.fetchMccId(JWT_TOKEN)).thenReturn(MCC_ID);
        when(mockConfig.getAnmfSortcode()).thenReturn("090128");

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();

        ProductFeeFormattedData productFeeFormattedData = messageGenerator.createProductSwitchFeeFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, createAcceptAndPayInSessionRequest());

        assertEquals("ldap-uid", productFeeFormattedData.getCustomerNumber());
        assertEquals("example@email.com", productFeeFormattedData.getEmailAddress());
        assertEquals("£999.00", productFeeFormattedData.getFeeAmount());
        assertTrue(productFeeFormattedData.isJointMortgage());
        assertEquals("my-mcc-id", productFeeFormattedData.getMccContractNumber());
        assertEquals("07696969696", productFeeFormattedData.getMobileNumber());
        assertEquals("000123456", productFeeFormattedData.getMortgageAccountNumber());
        assertEquals("090128", productFeeFormattedData.getMortgageSortCode());
        assertEquals("090127", productFeeFormattedData.getRemitterSortCode());
        assertEquals("02100882", productFeeFormattedData.getRemitterAccount());
        assertEquals("2019-10-03T11:15:30", productFeeFormattedData.getTimeStamp());
        assertEquals("pgwe51ZD", productFeeFormattedData.getUid());
    }

    private AcceptAndPayInSessionRequest createAcceptAndPayInSessionRequest() {
        AcceptAndPayInSessionRequest request = new AcceptAndPayInSessionRequest();
        request.setAccountFrom("09012702100882");
        return request;
    }

    @Test
    void testWeMapAcceptNowProductDetailsFeePaidUpfront() {


        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();
        coreRetentionsData.getCaseRequest().setFeeAddedInMortgage(false);

        AcceptanceGassFormattedData acceptanceGassFormattedData = messageGenerator.createProductSwitchAcceptNowFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, null);

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductCode(), equalTo("PR003"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductDescription(), equalTo("some-mortgage-productDescription"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getInterestRate(), equalTo("0.23%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getProductFee(), equalTo("£999.00"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getEarlyRepaymentCharge(), equalTo("3.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getOverpaymentAllowance(), equalTo("10.00%"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getSantanderFollowOnRate(), equalTo("4.00%"));
        assertTrue(acceptanceGassFormattedData.getNewProductDetails().isFeePaidUpfront());

        assertThat(acceptanceGassFormattedData.getNewProductDetails().getMonthlyPayment(), equalTo("£111.11"));
        assertThat(acceptanceGassFormattedData.getNewProductDetails().getRemainingBalance(), equalTo("£22222.22"));

        assertFalse(acceptanceGassFormattedData.isOfferDownloaded());
    }

    @Test
    void testWeMapSwitchDateToTodayDateWhenInterestRateChangeIsLower() {
        when(productUtils.calculateLoanSwitchDate(anyString(), any(DealLoanView.class))).thenReturn("03/10/2019");

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();
        AcceptanceGassFormattedData acceptanceGassFormattedData = messageGenerator.createProductSwitchAcceptNowFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, null);

        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getSwitchDate(), equalTo("03/10/2019"));
    }

    @Test
    void testWeMapSwitchDateToTodayDateWhenInterestRateChangeIsSame() {

        when(productUtils.calculateLoanSwitchDate(anyString(), any(DealLoanView.class))).thenReturn("03/10/2019");

        CoreRetentionsData coreRetentionsData = generateCoreRetentionsData();
        AcceptanceGassFormattedData acceptanceGassFormattedData = messageGenerator.createProductSwitchAcceptNowFormattedData(coreRetentionsData, JWT_TOKEN, ACCOUNT, null);

        assertThat(acceptanceGassFormattedData.getSwitchedLoanParts().get(0).getSwitchDate(), equalTo("03/10/2019"));
    }

    private Deal getDeal() {
        Product product = new Product();
        product.setType("some-mortgage-type");
        product.setProductCode("PR003");
        product.setDescription("some-mortgage-productDescription");
        product.setProductFee(new BigDecimal("999.00"));
        product.setTerm("43");
        product.setRate(new BigDecimal("0.23"));
        product.setErcPercentage(new BigDecimal("3.00"));
        product.setSantanderRevisionaryRate(new BigDecimal("4.00"));
        product.setAnnualOverpaymentAllowancePercentage(new BigDecimal("10.00"));
        product.setChargeEndDate("12/12/2024");
        product.setProductCompletionDate("2021-08-06");

        Deal deal = new Deal();
        deal.setCalculations(getCalculations());
        deal.setProduct(product);
        deal.setDealLoans(generateDefaultLoanList());
        return deal;
    }

    private List<DealLoanView> generateDefaultLoanList() {
        DealLoanView loan1 = new DealLoanView();
        loan1.setLoanId(9);
        loan1.setApplyFeeInThisLoan(true);
        loan1.setTransferring(true);
        DealLoanView loan2 = new DealLoanView();
        loan2.setLoanId(10);
        loan2.setApplyFeeInThisLoan(false);
        loan2.setTransferring(true);
        DealLoanView loan3 = new DealLoanView();
        loan3.setLoanId(11);
        loan3.setApplyFeeInThisLoan(false);
        loan3.setTransferring(false);
        return Arrays.asList(loan1, loan2, loan3);

    }

    private Calculations getCalculations() {
        Calculations calculations = new Calculations();
        calculations.setMonthlyPaymentWithFee(new BigDecimal("111.22"));
        calculations.setMonthlyPaymentWithoutFee(new BigDecimal("111.11"));
        calculations.setRemainingBalanceWithoutFee(new BigDecimal("22222.22"));
        calculations.setRemainingBalanceWithFee(new BigDecimal("22222.33"));
        return calculations;
    }

    private AnmfAccountServiceResponse getAnmfAccountInfoResponse() {
        ArrayList<OActiveLoan> oActiveLoans = createOActiveLoans();
        ArrayList<OActiveLoanDetail> oActiveLoanDetails = createOActiveLoanDetails();

        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoans(oActiveLoans);
        oStruc.setOActiveLoanDetails(oActiveLoanDetails);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse response = new AnmfAccountServiceResponse();
        response.setAccountServiceResponse(accountServiceResponse);

        return response;
    }

    private ArrayList<OActiveLoan> createOActiveLoans() {
        OActiveLoan loan1 = new OActiveLoan();
        loan1.setOLoanId(9);
        loan1.setOLoanSch("PR");
        loan1.setOApplSeqNo(1);

        OActiveLoan loan2 = new OActiveLoan();
        loan2.setOLoanSch("3T");
        loan2.setOApplSeqNo(2);
        loan2.setOLoanId(10);

        OActiveLoan loan3 = new OActiveLoan();
        loan3.setOLoanId(11);
        loan3.setOLoanSch("3T");
        loan3.setOApplSeqNo(3);

        ArrayList<OActiveLoan> oActiveLoans = new ArrayList<>(3);
        oActiveLoans.add(loan1);
        oActiveLoans.add(loan2);
        oActiveLoans.add(loan3);
        return oActiveLoans;
    }

    private ArrayList<OActiveLoanDetail> createOActiveLoanDetails() {
        OActiveLoanDetail oLoanDetails1 = new OActiveLoanDetail();
        oLoanDetails1.setOLoanId(9);
        oLoanDetails1.setOCapitalBalance(new BigDecimal("11111.11"));
        oLoanDetails1.setOLoanScheme("PR");
        oLoanDetails1.setOApplSeqNo(1);
        oLoanDetails1.setOProductEndDate("12/12/2022");
        oLoanDetails1.setORedemptionDate("12/12/2032");
        oLoanDetails1.setOInterestRate(new BigDecimal("1.11"));
        oLoanDetails1.setOProductDesc("2 YEAR FIXED");
        oLoanDetails1.setOProductCode("PR001");
        oLoanDetails1.setORemainingInstlm(150);
        oLoanDetails1.setORepaymentType("I");

        OActiveLoanDetail oLoanDetails2 = new OActiveLoanDetail();
        oLoanDetails2.setOLoanId(10);
        oLoanDetails2.setOCapitalBalance(new BigDecimal("22222.22"));
        oLoanDetails2.setOLoanScheme("3T");
        oLoanDetails2.setOApplSeqNo(2);
        oLoanDetails2.setORedemptionDate("11/11/2031");
        oLoanDetails2.setOInterestRate(new BigDecimal("2.22"));
        oLoanDetails2.setOProductDesc("STANDARD VARIABLE RATE");
        oLoanDetails2.setOProductCode("PR002");
        oLoanDetails2.setORemainingInstlm(160);
        oLoanDetails2.setORepaymentType("R");

        OActiveLoanDetail oLoanDetails3 = new OActiveLoanDetail();
        oLoanDetails3.setOLoanId(11);
        oLoanDetails3.setOCapitalBalance(new BigDecimal("33333.33"));
        oLoanDetails3.setOProductDesc("5 YEAR FIXED");
        oLoanDetails3.setOLoanScheme("3T");
        oLoanDetails3.setOApplSeqNo(3);
        oLoanDetails3.setOProductEndDate("13/03/2023");
        oLoanDetails3.setOInterestRate(new BigDecimal("3.33"));
        oLoanDetails3.setORemainingInstlm(170);
        oLoanDetails3.setORepaymentType("R");

        ArrayList<OActiveLoanDetail> oActiveLoanDetails = new ArrayList<>(3);
        oActiveLoanDetails.add(oLoanDetails1);
        oActiveLoanDetails.add(oLoanDetails2);
        oActiveLoanDetails.add(oLoanDetails3);
        return oActiveLoanDetails;
    }

    private CustomerDetailsResponse generateDefaultCustomerData() {
        CustomerDetailsResponse customerDetailsResponse = new CustomerDetailsResponse();

        CustomerServiceResponse customerResponse = new CustomerServiceResponse();
        com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc output = new com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc();
        output.setOCustomerList(generateNewCustomerList());
        customerResponse.setOStruc(output);
        customerDetailsResponse.setCustomerServiceResponse(customerResponse);
        return customerDetailsResponse;

    }

    private List<OCustomer> generateNewCustomerList() {
        List<OCustomer> customerList = new ArrayList<>(2);
        customerList.add(generateDefaultCustomer(1));
        customerList.add(generateDefaultCustomer(2));
        return customerList;
    }

    private OCustomer generateDefaultCustomer(int index) {
        OCustomer customer = new OCustomer();
        customer.setOCustomerId(index);
        return customer;
    }

    private CreateCaseRequest getCreateCaseRequest() {
        LoanIdentifier loanIdentifierOne = new LoanIdentifier();
        loanIdentifierOne.setLoanScheme("PR");
        loanIdentifierOne.setSequenceNumber(1);

        LoanIdentifier loanIdentifierTwo = new LoanIdentifier();
        loanIdentifierTwo.setLoanScheme("3T");
        loanIdentifierTwo.setSequenceNumber(2);

        CreateCaseRequest createCaseRequest = new CreateCaseRequest();
        createCaseRequest.setLoansSelected(Arrays.asList(loanIdentifierOne, loanIdentifierTwo));
        createCaseRequest.setProductCode("PR003");

        createCaseRequest.setFeeAddedInMortgage(true);
        createCaseRequest.setEmailAddress("example@email.com");
        createCaseRequest.setMobileNumber("07696969696");
        return createCaseRequest;
    }

    private CoreRetentionsData generateCoreRetentionsData(CreateCaseRequest createCaseRequest) {
        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setSelectedDeal(getDeal());
        coreRetentionsData.setCustomerDetailsResponse(generateDefaultCustomerData());
        coreRetentionsData.setAnmfAccountServiceResponse(getAnmfAccountInfoResponse());
        coreRetentionsData.setCaseRequest(createCaseRequest);
        return coreRetentionsData;
    }

    private CoreRetentionsData generateCoreRetentionsData() {
        CreateCaseRequest createCaseRequest = getCreateCaseRequest();
        CoreRetentionsData coreRetentionsData = new CoreRetentionsData();
        coreRetentionsData.setSelectedDeal(getDeal());
        coreRetentionsData.setCustomerDetailsResponse(generateDefaultCustomerData());
        coreRetentionsData.setAnmfAccountServiceResponse(getAnmfAccountInfoResponse());
        coreRetentionsData.setCaseRequest(createCaseRequest);
        return coreRetentionsData;
    }

}

package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class CreateCaseFunctionalValidationTest {

    @Test
    public void test_no_errors() throws ValidationsException {
        CreateCaseFunctionalValidation validation = new CreateCaseFunctionalValidation();

        validation.validate(createGenericInputTestForValidation());
    }

    @Test
    public void test_product_code_in_request_doesnt_belong_to_customer() {
        CreateCaseFunctionalValidation validation = new CreateCaseFunctionalValidation();

        ValidationsException ve = assertThrows(ValidationsException.class, () -> validation.validate(createInputWithWrongProductCode()));
        assertThat(ve.getCode(), equalTo("EXC_FUNCTIONAL_VALIDATION_PRODUCT_CODE_NOT_VALID"));
        assertThat(ve.getMessage(), equalTo("The product code is not available for the customer"));
    }

    private CreateCaseFunctionalValidationInput createInputWithWrongProductCode() {
        CreateCaseFunctionalValidationInput input = createGenericInputTestForValidation();
        input.getCaseRequest().setProductCode("WRONG");
        return input;
    }

    private CreateCaseFunctionalValidationInput createGenericInputTestForValidation() {
        CreateCaseFunctionalValidationInput input = new CreateCaseFunctionalValidationInput();
        input.setCaseRequest(generateGenericCaseRequest());
        input.setDealsResponse(generateGenericDealsResponse());
        return input;
    }

    private DealsResponse generateGenericDealsResponse() {
        DealsResponse response = new DealsResponse();
        List<Deal> deals = new ArrayList<>();
        deals.add(createDeal(0));
        deals.add(createDeal(1));
        response.setDeals(deals);
        return response;
    }

    private Deal createDeal(int i) {
        Deal deal = new Deal();
        Product product = new Product();
        product.setProductCode("F000" + i);
        deal.setProduct(product);
        return deal;
    }

    private CreateCaseRequest generateGenericCaseRequest() {
        CreateCaseRequest createCaseRequest = new CreateCaseRequest();
        createCaseRequest.setProductCode("F0001");
        return createCaseRequest;
    }
}

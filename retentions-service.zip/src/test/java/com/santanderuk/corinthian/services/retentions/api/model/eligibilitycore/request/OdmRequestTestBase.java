package com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.request;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OdmRequestTestBase {

    public OdmRequestWrapper createOdmRequestWrapper() {
        OdmRequestWrapper odmRequestWrapper = new OdmRequestWrapper();
        odmRequestWrapper.setOdmRequest(createOdmRequest());
        return odmRequestWrapper;
    }

    public OdmRequest createOdmRequest() {
        OdmRequest odmRequest = new OdmRequest();

        odmRequest.setChannelID("channelID");
        odmRequest.setAccountNumber("accountNumber");
        odmRequest.setAccountNumberType("accountNumberType");
        odmRequest.setAccountBalance(new BigDecimal("0.00"));
        odmRequest.setIsBuyToLet("isBuyToLet");
        odmRequest.setIsConsentToLet("isConsentToLet");
        odmRequest.setIsFlexi("isFlexi");
        odmRequest.setRiskLevel("riskLevel");
        odmRequest.setCustomerNumber("customerNumber");
        odmRequest.setPostCode("postCode");
        odmRequest.setChargeEndDate("chargeEndDate");
        odmRequest.setCompletionDate("completionDate");
        odmRequest.setLoanRequest(createLoanRequestList());
        odmRequest.setLtvio(new BigDecimal("0.00"));
        odmRequest.setLtvgeneral(new BigDecimal("0.00"));

        return odmRequest;
    }

    private List<ODMLoanRequest> createLoanRequestList() {
        List<ODMLoanRequest> odmLoanRequestList = new ArrayList<>();

        ODMLoanRequest odmLoanRequest = new ODMLoanRequest();
        odmLoanRequest.setLoanID("1");
        odmLoanRequest.setLoanBalance(new BigDecimal("0.00"));
        odmLoanRequest.setIsOnReversionRate("N");
        odmLoanRequest.setRemainingTerm(1);
        odmLoanRequest.setRollOffDate("20/08/2025");

        odmLoanRequestList.add(odmLoanRequest);

        return odmLoanRequestList;
    }
}

package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.AllLoansErc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class AllLoansErcTest extends RuleTest {

    AllLoansErc rule;

    @BeforeEach
    public void setUp() {
        rule = new AllLoansErc();
    }


    @Test
    public void testWeSetBlockerWhenAllLoansHaveErc() {


        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        ODMLoanResponse loan1 = new ODMLoanResponse();
        loan1.setErcEligibility("N");


        ODMLoanResponse loan2 = new ODMLoanResponse();
        loan2.setErcEligibility("N");

        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isAllLoansERC(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);
        assertThat(eligibilityResponse.getBlockers().isAllLoansERC(), equalTo(true));
    }

    @Test
    public void testWeSetBlockerWhenOneLoanHaveErc() {


        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        ODMLoanResponse loan1 = new ODMLoanResponse();
        loan1.setErcEligibility("N");


        ODMLoanResponse loan2 = new ODMLoanResponse();
        loan2.setErcEligibility("Y");

        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isAllLoansERC(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);
        assertThat(eligibilityResponse.getBlockers().isAllLoansERC(), equalTo(false));
    }

    @Test
    public void testWeSetBlockerWhenNoLoanHaveErc() {


        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        ODMLoanResponse loan1 = new ODMLoanResponse();
        loan1.setErcEligibility("Y");


        ODMLoanResponse loan2 = new ODMLoanResponse();
        loan2.setErcEligibility("Y");

        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isAllLoansERC(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);
        assertThat(eligibilityResponse.getBlockers().isAllLoansERC(), equalTo(false));
    }

}

package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@ActiveProfiles("test")
public class EligibilityFunctionalTest extends FunctionalTest {

    private String eligibilityEndpoint;
    private Header authorizationHeader;
    private Header contentType;
    private Header accept;

    @BeforeEach
    public void setUp() {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerIsEligible() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success-customer-is-eligible.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.productCompletionDate", equalTo("03/03/2022"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false),
                        "response.blockers.notOnline", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.loans[0].interestRate", equalTo(new BigDecimal("4.75")),
                        "response.loans[0].onReversionRate", equalTo(true),
                        "response", not(hasKey("bandId")),
                        "response", hasKey("blockers"),
                        "response", hasKey("info"),
                        "response", hasKey("loans")
                );

    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerIsEligible3DecimalsInInterests() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success-three-decimals.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].interestRate", equalTo(new BigDecimal("0.001")),
                        "response.loans[0].followOnRate", equalTo(new BigDecimal("0.002")),
                        "response", not(hasKey("bandId")),
                        "response", hasKey("blockers"),
                        "response", hasKey("info"),
                        "response", hasKey("loans")
                );

    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerIsEligible4DecimalsInInterests() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success-four-decimals.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].interestRate", equalTo(new BigDecimal("0.0001")),
                        "response.loans[0].followOnRate", equalTo(new BigDecimal("0.0002")),
                        "response", not(hasKey("bandId")),
                        "response", hasKey("blockers"),
                        "response", hasKey("info"),
                        "response", hasKey("loans")
                );

    }

    @Test
    public void testWeGetErrorResponseWhenRiskAndValuationIsZeroValue() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response-zero-valuation.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("RISK_CORE_NOT_FOUND"),
                        "info.message", equalTo("Risk valuation core returned empty or zero valuation")
                );

    }

    @Test
    public void testWeGetErrorResponseWhenRiskAndValuationConnectionError() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuationConnectionDown(accountNumber);
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("RISK_CORE_CONNECTION")
                );

    }


    @Test
    public void testWeGetResponseWhenRiskAndValuationIsNotFound() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuationAccountNotFound(accountNumber);
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("ACCOUNT_NOT_FOUND"),
                        "info.message", equalTo("Account Not Found in Risk Valuation table"),
                        "response", equalTo(null)
                );

    }


    @Test
    public void testWeGetResponseWhenRiskAndValuationIsNotFoundWith200() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuationAccountNotFoundWith200(accountNumber);
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("ACCOUNT_NOT_FOUND"),
                        "info.message", equalTo("Account Not Found in Risk Valuation table"),
                        "response", equalTo(null)
                );

    }

    @Test
    public void testWeGetResponseWhenRiskAndValuationErrors() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuationConnectionDown(accountNumber);
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("RISK_CORE_CONNECTION"),
                        "info.message", equalTo("Exception while calling Risk Valuation Core Service")
                );
    }


    @Test
    public void testWeGetCorrectResponseWhenCustomerIsNotEligible() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-non-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.productCompletionDate", equalTo("03/03/2022"),
                        "response.blockers.accountIneligible", equalTo(true),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false)
                );
    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerIsNotEligibleDueToBalance() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-non-eligible-account-balance.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(true),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(true)
                );
    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerIsNotEligibleDueToERC() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-non-eligible-erc.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(true),
                        "response.blockers.allLoansIneligible", equalTo(true),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.allLoansERC", equalTo(true)
                );
    }

    @Test
    public void testWeReturnCorrectResponseWhenEligibilityCoreServiceErrorResponse() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/error-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("ELIGIBILITY_CORE_ERROR"),
                        "info.message", equalTo("Error Received in Eligibility Core Service Response"));
    }

    @Test
    public void testWeReturnCorrectResponseWhenEligibilityCoreServiceIsDown() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibilityDown();
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("ELIGIBILITY_CORE_ERROR"),
                        "info.message", equalTo("Exception while calling Eligibility Core Service")
                );
    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerIsEligibleWithBand_I() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-i-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false),
                        "response.blockers.notOnline", equalTo(true)
                );
    }

    @Test
    public void testWeGetCorrectResponseWhenCustomerAccountEligibleButInBandW() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-w-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false),
                        "response.blockers.notOnline", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.financialDifficulties", equalTo(true)
                );
    }

    @Test
    public void testWeReturnTheProductListForTheBandOdmReturn() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-a-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.blockers.notOnline", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false)
                );
    }

    @Test
    public void testWeReturnTheProductListForTheTermWindow() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/non-eligible-term-window-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.blockers.notOnline", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false),
                        "response.blockers.outsideDealWindow", equalTo(true)
                );
    }

    @Test
    public void testWeReturnTheBlockerWhenLoanPartsAreWithin2YearsOfMaturity() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-a-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.blockers.notOnline", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false),
                        "response.blockers.outsideDealWindow", equalTo(false),
                        "response.blockers.termRemaining", equalTo((false))
                );
    }

    @Test
    public void testWeReturnTheBlockerWhenAllLoanPartsHaveLessThan30MonthsRemaining() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/less-than-30-months-remaining-on-loans.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.consentToLet", equalTo(false),
                        "response.blockers.accountIneligible", equalTo(true),
                        "response.blockers.notOnline", equalTo(false),
                        "response.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00")),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false),
                        "response.blockers.outsideDealWindow", equalTo(false),
                        "response.blockers.termRemaining", equalTo((true))
                );
    }

    // @Test
    @Disabled //Ignored until we have Property service returning the consent to let
    public void testWeReturnTheBlockerWhenConsentToLet() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property-consent-to-let.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/less-than-30-months-remaining-on-loans.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.consentToLet", equalTo(true),
                        "response.blockers.minimumBalanceForSwitching", equalTo(new BigDecimal("1000.00"))
                );
    }

    @Test
    public void testWeReturnTheBlockerWhenInArrearsAndNotBandW() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success-arrears.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property-consent-to-let.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-a-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.eligibleInArrears", equalTo(true)
                );
    }

    @Test
    public void testBugLoanWithoutProductEndDate() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/Bug-LoanWithoutProductEndDate/anmf-acc-info-response.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/Bug-LoanWithoutProductEndDate/risk-valuation-response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/Bug-LoanWithoutProductEndDate/odm-core-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found"),
                        "response.blockers.accountIneligible", equalTo(false),
                        "response.bandId", equalTo("2"),
                        "response.blockers.accountBalanceBelowThreshold", equalTo(false)
                );
    }

    @Test
    public void testBug2402() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/bug2402/anmf-acc-response.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/bug2402/risk-and-valuation-response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/bug2402/odm-core-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].loanId", equalTo(1),
                        "response.loans[1].loanId", equalTo(2),
                        "response.loans[1].eligibleToTransfer", equalTo(false),
                        "response.loans[2].loanId", equalTo(3),
                        "response.loans[3].loanId", equalTo(4)
                );
    }

    @Test
    public void testWeGetBlockedBecauseOdmReturnedFlexiEligibilityY() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.flexi", equalTo(false)
                );

    }

    @Test
    public void testWeGetBlockedBecauseOdmReturendFlexiEligibilityN() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
//        stubProductCompletionDate("/product/completion-date-success-response.json");
//        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-flexi-eligible-no-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.flexi", equalTo(true)
                );

    }
}

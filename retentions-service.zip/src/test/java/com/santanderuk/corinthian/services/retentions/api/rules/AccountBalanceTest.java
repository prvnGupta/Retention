package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.ODMEligibilityBalance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class AccountBalanceTest extends RuleTest {

    ODMEligibilityBalance rule;

    @BeforeEach
    public void setUp() {
        rule = new ODMEligibilityBalance();
    }

    @Test
    public void testWeGetBlockerWhenAccountBalanceLow() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setAccountBalanceEligibility("N");

        assertThat(eligibilityResponse.getBlockers().isAccountBalanceBelowThreshold(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isAccountBalanceBelowThreshold(), equalTo(true));

    }

}

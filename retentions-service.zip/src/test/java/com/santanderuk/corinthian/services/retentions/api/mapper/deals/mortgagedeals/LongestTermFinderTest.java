package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.retentions.FixtureReader;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.Loan;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
class LongestTermFinderTest {

    LongestTermFinder finder;

    public static AnmfAccountServiceResponse readAccountsInfoResponseFromFixture(String filename) throws IOException {
        return FixtureReader.get(filename, AnmfAccountServiceResponse.class);
    }

    @BeforeEach
    void setUp() {
        finder = new LongestTermFinder();
    }

    @Test
    void happyPathOneLoan() throws IOException {

        var mortgageDealsClientRequest = new MortgageDealsClientRequest();
        addRemainingInstallments(mortgageDealsClientRequest, 1);

        var longestTermInMonths = finder.get(mortgageDealsClientRequest);

        assertEquals(1, longestTermInMonths);
    }

    @Test
    void happyPathTwoLoans() throws IOException {

        var mortgageDealsClientRequest = new MortgageDealsClientRequest();
        addRemainingInstallments(mortgageDealsClientRequest, 1);
        addRemainingInstallments(mortgageDealsClientRequest, 2);

        var longestTermInMonths = finder.get(mortgageDealsClientRequest);

        assertEquals(2, longestTermInMonths);
    }

    @Test
    void happyPathTwoLoansReverse() throws IOException {

        var mortgageDealsClientRequest = new MortgageDealsClientRequest();
        addRemainingInstallments(mortgageDealsClientRequest, 2);
        addRemainingInstallments(mortgageDealsClientRequest, 1);

        var longestTermInMonths = finder.get(mortgageDealsClientRequest);

        assertEquals(2, longestTermInMonths);
    }

    @Test
    void happyPathThreeLoans() throws IOException {

        var mortgageDealsClientRequest = new MortgageDealsClientRequest();
        addRemainingInstallments(mortgageDealsClientRequest, 1);
        addRemainingInstallments(mortgageDealsClientRequest, 2);
        addRemainingInstallments(mortgageDealsClientRequest, 3);

        var longestTermInMonths = finder.get(mortgageDealsClientRequest);

        assertEquals(3, longestTermInMonths);
    }

    @Test
    void happyPathThreeLoansReverse() throws IOException {

        var mortgageDealsClientRequest = new MortgageDealsClientRequest();
        addRemainingInstallments(mortgageDealsClientRequest, 3);
        addRemainingInstallments(mortgageDealsClientRequest, 2);
        addRemainingInstallments(mortgageDealsClientRequest, 1);

        var longestTermInMonths = finder.get(mortgageDealsClientRequest);

        assertEquals(3, longestTermInMonths);
    }

    private void addRemainingInstallments(MortgageDealsClientRequest mortgageDealsClientRequest, int remainingInstallments) {
        if(null == mortgageDealsClientRequest.getLoans()) {
            var loans = new ArrayList<Loan>();
            mortgageDealsClientRequest.setLoans(loans);
        }
        var loan = new Loan();
        loan.setRemainingInstalments(remainingInstallments);
        mortgageDealsClientRequest.getLoans().add(loan);
    }
    
}

package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.Loan;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapperTestData.createEmptyMapperSourceData;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class MortgageDealsClientRequestMapperTest {

    @Mock
    MortgageDealsClientLoanRequestMapper loanRequestMapper;

    MortgageDealsClientRequestMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new MortgageDealsClientRequestMapper(loanRequestMapper);
    }

    @Test
    void testAccountNumber() {

        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertEquals("12345678", mortgageDealsClientRequest.getAccountNumber());
    }

    @Test
    void testSalesChannel() {

        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertEquals("Digital", mortgageDealsClientRequest.getSalesChannel());
    }

    @Test
    void testIsBuyToLetTrue() {
        var mapperSourceData = createEmptyMapperSourceData();
        mapperSourceData.getAnmfPropertyResponse().getPropertyEnquiryResponse().getOutputStructure().setOSpecialPurchase("L");

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertTrue(mortgageDealsClientRequest.isBuyToLet());
    }

    @Test
    void testIsBuyToLetFalse() {
        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertFalse(mortgageDealsClientRequest.isBuyToLet());
    }

    @Test
    void testIsBuyToLetFalseBecauseValueWasNull() {
        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertFalse(mortgageDealsClientRequest.isBuyToLet());
    }

    @Test
    void testConsentToLetIsTrue() {
        var mapperSourceData = createEmptyMapperSourceData();
        mapperSourceData.getAnmfPropertyResponse().getPropertyEnquiryResponse().getOutputStructure().setOConsentToLet("Y");

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertTrue(mortgageDealsClientRequest.isConsentToLet());
    }

    @Test
    void testConsentToLetIsFalse() {
        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertFalse(mortgageDealsClientRequest.isConsentToLet());
    }

    @Test
    void testConsentToLetIsFalseBecauseWasNull() {
        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertFalse(mortgageDealsClientRequest.isConsentToLet());
    }

    @Test
    void testFlexiIndIsTrue() {
        var mapperSourceData = createEmptyMapperSourceData();
        mapperSourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().setOFlexiInd("Y");

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertTrue(mortgageDealsClientRequest.isFlexi());
    }

    @Test
    void testFlexiIndIsFalse() {
        var mapperSourceData = createEmptyMapperSourceData();
        mapperSourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().setOFlexiInd("N");

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertFalse(mortgageDealsClientRequest.isFlexi());
    }

    @Test
    void testFlexiIndIsFalseBecauseNull() {
        var mapperSourceData = createEmptyMapperSourceData();
        mapperSourceData.getAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().setOFlexiInd(null);

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertFalse(mortgageDealsClientRequest.isFlexi());
    }

    @Test
    void testWeAreAddingTheLoanMapperResultCorrectlyToTheResultObject() {

        var mockedLoanRequest = new ArrayList<Loan>();
        Loan loan = new Loan();
        loan.setLoanId(1);
        mockedLoanRequest.add(loan);
        when(loanRequestMapper.create(any())).thenReturn(mockedLoanRequest);

        var mapperSourceData = createEmptyMapperSourceData();

        var mortgageDealsClientRequest = mapper.create(mapperSourceData);

        assertEquals(mockedLoanRequest, mortgageDealsClientRequest.getLoans());
    }

}

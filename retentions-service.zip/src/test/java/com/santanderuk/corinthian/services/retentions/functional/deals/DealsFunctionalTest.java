package com.santanderuk.corinthian.services.retentions.functional.deals;

import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.retentions.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class DealsFunctionalTest extends FunctionalTest {


    private Header authorizationHeader;
    private Header contentType;
    private Header accept;


    @BeforeEach
    public void setUp() {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");

    }

    @Test
    void oneProductInResponse() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/one-product.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.deals.size()", equalTo(1),
                        "response.deals[0].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(34027.05)),
                        "response.deals[0].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(34700.28)),
                        "response.deals[0].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),

                        "response.deals[0].product.productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].product.description", equalTo("2 Yr Tracker BBR plus 0.99% then FoR"),
                        "response.deals[0].product.productCode", equalTo("B139T"),
                        "response.deals[0].product.chargeEndDate", equalTo("01/04/2026"),
                        "response.deals[0].product.type", equalTo("Tracker"),
                        "response.deals[0].product.rate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].product.term", equalTo("2 Year"),
                        "response.deals[0].product.termInMonths", equalTo(24),
                        "response.deals[0].product.reversionProduct", equalTo("FoR"),
                        "response.deals[0].product.mortgageTermInMonthsAfterProduct", equalTo(48),
                        "response.deals[0].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].product.ercPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].product.annualOverpaymentAllowancePercentage", equalTo(BigDecimal.valueOf(23.56)),
                        "response.deals[0].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75)),
                        "response.deals[0].loanToApplyTheFeeTo", equalTo(1),

                        // deal-loans-view: IF loanTransferring -> TRUE
                        "response.deals[0].dealLoans.size()", equalTo(1),
                        "response.deals[0].dealLoans[0].loanId", equalTo(1),
                        "response.deals[0].dealLoans[0].productTitle", equalTo("2 Year Tracker"),
                        "response.deals[0].dealLoans[0].interestRate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].dealLoans[0].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].dealLoans[0].variable", equalTo(true),
                        "response.deals[0].dealLoans[0].trackingRate", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].dealLoans[0].transferring", equalTo(true),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].dealLoans[0].loanBalance", equalTo(BigDecimal.valueOf(50500.77)),
                        "response.deals[0].dealLoans[0].productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].dealLoans[0].productWithFee", equalTo(true),
                        "response.deals[0].dealLoans[0].newOutstandingBalance", equalTo(BigDecimal.valueOf(51491.5)),
                        "response.deals[0].dealLoans[0].previousProduct", equalTo("Standard Variable Rate at 4.34%"),
                        "response.deals[0].dealLoans[0].productStartDate", equalTo(null),
                        "response.deals[0].dealLoans[0].productEndDate", equalTo("24 months"),
                        "response.deals[0].dealLoans[0].remainingTerm", equalTo("6 years"),
                        "response.deals[0].dealLoans[0].repaymentType", equalTo("REPAYMENT"),
                        "response.deals[0].dealLoans[0].annualOverpaymentAllowance", equalTo(new BigDecimal("23.56")),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(null),
                        "response.deals[0].dealLoans[0].santanderFollowOnRate", equalTo(new BigDecimal("3.75")),
                        "response.deals[0].dealLoans[0].applyFeeInThisLoan", equalTo(true),
                        "response.deals[0].dealLoans[0].interestRateChange", equalTo("LOWER"),
                        "response.deals[0].dealLoans[0].currentProductFixedTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].lifetimeTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].currentProductTrackerFlag", equalTo(false)

                );
    }

    @Test
    void testingReversionProductCombinations() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/11169738/anmf-customer-info.json");

        stubANMFAccountInfo(accountNumber, "/11169738/anmf-account-details.json");
        stubANMFPropertyInfoV2(accountNumber, "/11169738/anmf-property-info.json");

        stubMortgageDealsProduct("/11169738/mortgage-deals.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3I\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.deals.size()", equalTo(10),
                        "response.deals[0].product.description", equalTo("2 Yr Tracker BBR plus 0.34% then FoR"),
                        "response.deals[0].product.reversionProduct", equalTo("FoR"),
                        "response.deals[0].dealLoans[0].reversionProduct", equalTo("FoR"),
                        "response.deals[1].product.description", equalTo("2 Yr Tracker BBR plus 0.34% then SVR"),
                        "response.deals[1].product.reversionProduct", equalTo("SVR"),
                        "response.deals[1].dealLoans[0].reversionProduct", equalTo("SVR"),
                        "response.deals[9].product.description", equalTo("Flexible Offset - Lifetime tracker BBR plus 3.30%"),
                        "response.deals[9].product.reversionProduct", equalTo("N/A"),
                        "response.deals[9].dealLoans[0].reversionProduct", equalTo("N/A")
                );
    }

    @Test
    void oneProductInResponseButNoChargeDate() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/one-loan-no-charge-date.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(1),
                        "response.deals[0].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(34027.05)),
                        "response.deals[0].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(34700.28)),
                        "response.deals[0].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),

                        "response.deals[0].product.productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].product.description", equalTo("2 Yr Tracker BBR plus 0.99% then FoR"),
                        "response.deals[0].product.productCode", equalTo("B139T"),
                        "response.deals[0].product.chargeEndDate", equalTo(""),
                        "response.deals[0].product.type", equalTo("Tracker"),
                        "response.deals[0].product.rate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].product.term", equalTo("2 Year"),
                        "response.deals[0].product.termInMonths", equalTo(24),
                        "response.deals[0].product.mortgageTermInMonthsAfterProduct", equalTo(48),
                        "response.deals[0].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].product.ercPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].product.annualOverpaymentAllowancePercentage", equalTo(BigDecimal.valueOf(23.56)),
                        "response.deals[0].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75))
                );
    }

    @Test
    void loanSchemeSelectedIsNotTheOneInTheLoan() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/one-product.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3Z\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT"),
                        "info.message", equalTo("One or more of the loans does not belong to the account")
                );
    }

    @Test
    void sequenceNumberSelectedIsNotTheOneInTheLoan() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/one-product.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":999}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(400).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT"),
                        "info.message", equalTo("One or more of the loans does not belong to the account")
                );
    }

    @Test
    void twoProductsInMorgagteDealsResponse() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/two-products.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(2),
                        "response.deals[0].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(34027.05)),
                        "response.deals[0].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(34700.28)),
                        "response.deals[0].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),

                        "response.deals[0].product.productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].product.description", equalTo("2 Yr Tracker BBR plus 0.99% then FoR"),
                        "response.deals[0].product.productCode", equalTo("B139T"),
                        "response.deals[0].product.chargeEndDate", equalTo("01/04/2026"),
                        "response.deals[0].product.type", equalTo("Tracker"),
                        "response.deals[0].product.rate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].product.term", equalTo("2 Year"),
                        "response.deals[0].product.termInMonths", equalTo(24),
                        "response.deals[0].product.mortgageTermInMonthsAfterProduct", equalTo(48),
                        "response.deals[0].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].product.ercPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].product.annualOverpaymentAllowancePercentage", equalTo(BigDecimal.valueOf(23.56)),
                        "response.deals[0].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75)),


                        "response.deals[1].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(44027.05)),
                        "response.deals[1].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(44700.28)),
                        "response.deals[1].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(824.79)),
                        "response.deals[1].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(839.12)),

                        "response.deals[1].product.productFee", equalTo(BigDecimal.valueOf(1099.99)),
                        "response.deals[1].product.description", equalTo("3 years product"),
                        "response.deals[1].product.productCode", equalTo("B140U"),
                        "response.deals[1].product.chargeEndDate", equalTo("01/04/2026"),
                        "response.deals[1].product.type", equalTo("Fixed"),
                        "response.deals[1].product.rate", equalTo(BigDecimal.valueOf(2.09)),
                        "response.deals[1].product.term", equalTo("3 Year"),
                        "response.deals[1].product.termInMonths", equalTo(36),
                        "response.deals[1].product.mortgageTermInMonthsAfterProduct", equalTo(36),
                        "response.deals[1].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.5)),
                        "response.deals[1].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(1.99)),
                        "response.deals[1].product.ercPercentage", equalTo(BigDecimal.valueOf(22.12)),
                        "response.deals[1].product.annualOverpaymentAllowancePercentage", equalTo(BigDecimal.valueOf(33.56)),
                        "response.deals[1].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75)),

                        //deals[0] deal-loans-view[0]: IF loanTransferring -> TRUE
                        "response.deals[0].dealLoans.size()", equalTo(1),
                        "response.deals[0].dealLoans[0].loanId", equalTo(1),
                        "response.deals[0].dealLoans[0].productTitle", equalTo("2 Year Tracker"),
                        "response.deals[0].dealLoans[0].interestRate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].dealLoans[0].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].dealLoans[0].variable", equalTo(true),
                        "response.deals[0].dealLoans[0].trackingRate", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].dealLoans[0].transferring", equalTo(true),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].dealLoans[0].loanBalance", equalTo(BigDecimal.valueOf(50500.77)),
                        "response.deals[0].dealLoans[0].productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].dealLoans[0].productWithFee", equalTo(true),
                        "response.deals[0].dealLoans[0].newOutstandingBalance", equalTo(BigDecimal.valueOf(51491.5)),
                        "response.deals[0].dealLoans[0].previousProduct", equalTo("Standard Variable Rate at 4.34%"),
                        "response.deals[0].dealLoans[0].productStartDate", equalTo(null),
                        "response.deals[0].dealLoans[0].productEndDate", equalTo("24 months"),
                        "response.deals[0].dealLoans[0].remainingTerm", equalTo("6 years"),
                        "response.deals[0].dealLoans[0].repaymentType", equalTo("REPAYMENT"),
                        "response.deals[0].dealLoans[0].annualOverpaymentAllowance", equalTo(new BigDecimal("23.56")),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(null),
                        "response.deals[0].dealLoans[0].santanderFollowOnRate", equalTo(new BigDecimal("3.75")),
                        "response.deals[0].dealLoans[0].applyFeeInThisLoan", equalTo(true),
                        "response.deals[0].dealLoans[0].interestRateChange", equalTo("LOWER"),
                        "response.deals[0].dealLoans[0].currentProductFixedTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].lifetimeTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].currentProductTrackerFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].reversionProduct", equalTo("FoR"),

                        // deals[1] deal-loans-view[0]: IF loanTransferring -> TRUE
                        "response.deals[1].dealLoans.size()", equalTo(1),
                        "response.deals[1].dealLoans[0].loanId", equalTo(1),
                        "response.deals[1].dealLoans[0].productTitle", equalTo("3 Year Fixed"),
                        "response.deals[1].dealLoans[0].interestRate", equalTo(BigDecimal.valueOf(2.09)),
                        "response.deals[1].dealLoans[0].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.5)),
                        "response.deals[1].dealLoans[0].variable", equalTo(false),
                        "response.deals[1].dealLoans[0].trackingRate", equalTo(null),
                        "response.deals[1].dealLoans[0].transferring", equalTo(true),
                        "response.deals[1].dealLoans[0].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),
                        "response.deals[1].dealLoans[0].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[1].dealLoans[0].loanBalance", equalTo(BigDecimal.valueOf(50500.77)),
                        "response.deals[1].dealLoans[0].productFee", equalTo(BigDecimal.valueOf(1099.99)),
                        "response.deals[1].dealLoans[0].productWithFee", equalTo(true),
                        "response.deals[1].dealLoans[0].newOutstandingBalance", equalTo(BigDecimal.valueOf(51491.5)),
                        "response.deals[1].dealLoans[0].previousProduct", equalTo("Standard Variable Rate at 4.34%"),
                        "response.deals[1].dealLoans[0].productStartDate", equalTo(null),
                        // By Corinthian-8036, when we are moving to a fixed like in thgis case we have to use product->chargeEndDate
                        // Old
                        // "response.deals[1].dealLoans[0].productEndDate", equalTo("24 months")
                        // New is below
                        "response.deals[1].dealLoans[0].productEndDate", equalTo("01/04/2026"),
                        "response.deals[1].dealLoans[0].remainingTerm", equalTo("6 years"),
                        "response.deals[1].dealLoans[0].repaymentType", equalTo("REPAYMENT"),
                        "response.deals[1].dealLoans[0].annualOverpaymentAllowance", equalTo(new BigDecimal("33.56")),
                        "response.deals[1].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(BigDecimal.valueOf(22.12)),
                        "response.deals[1].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(null),
                        "response.deals[1].dealLoans[0].santanderFollowOnRate", equalTo(new BigDecimal("3.75")),
                        "response.deals[1].dealLoans[0].applyFeeInThisLoan", equalTo(true),
                        "response.deals[1].dealLoans[0].interestRateChange", equalTo("LOWER"),
                        "response.deals[1].dealLoans[0].currentProductFixedTermFlag", equalTo(false),
                        "response.deals[1].dealLoans[0].lifetimeTermFlag", equalTo(false),
                        "response.deals[1].dealLoans[0].currentProductTrackerFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].reversionProduct", equalTo("FoR")
                );
    }

    @Test
    void twoProductsAndTwoActiveLoansInMortgageDealsResponse() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/account-details/account-details-12204702.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/mortgage-deals/mortgage-deals-products-has-fee.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3T\"," +
                        "\"sequenceNumber\":6}," +
                        "{\"loanScheme\":\"3T\"," +
                        "\"sequenceNumber\":8}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(3),
                        "response.deals[0].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(8589.73)),
                        "response.deals[0].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(9095.17)),
                        "response.deals[0].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(564.36)),
                        "response.deals[0].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(585.68)),

                        "response.deals[0].product.productFee", equalTo(999),
                        "response.deals[0].product.description", equalTo("2 Yr Tracker BBR plus 1.09% then FoR"),
                        "response.deals[0].product.productCode", equalTo("B142T"),
                        "response.deals[0].product.chargeEndDate", equalTo(""),
                        "response.deals[0].product.type", equalTo("Tracker"),
                        "response.deals[0].product.rate", equalTo(BigDecimal.valueOf(1.19)),
                        "response.deals[0].product.term", equalTo("2 Year"),
                        "response.deals[0].product.termInMonths", equalTo(24),
                        "response.deals[0].product.mortgageTermInMonthsAfterProduct", equalTo(24),
                        "response.deals[0].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].product.ercPercentage", equalTo(new BigDecimal("0.00")),
                        "response.deals[0].product.annualOverpaymentAllowancePercentage", equalTo(new BigDecimal("0.00")),
                        "response.deals[0].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75)),


                        "response.deals[1].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(7531.34)),
                        "response.deals[1].calculations.remainingBalanceWithFee", equalTo(new BigDecimal("7974.50")),
                        "response.deals[1].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(564.72)),
                        "response.deals[1].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(586.07)),

                        "response.deals[1].product.productFee", equalTo(999),
                        "response.deals[1].product.description", equalTo("(c 2 Yr) Fixed until 02 Apr 2024 then FoR"),
                        "response.deals[1].product.productCode", equalTo("F623T"),
                        "response.deals[1].product.chargeEndDate", equalTo("02/04/2024"),
                        "response.deals[1].product.type", equalTo("Fixed"),
                        "response.deals[1].product.rate", equalTo(BigDecimal.valueOf(1.24)),
                        "response.deals[1].product.term", equalTo("2 Year"),
                        "response.deals[1].product.termInMonths", equalTo(24),
                        "response.deals[1].product.mortgageTermInMonthsAfterProduct", equalTo(24),
                        "response.deals[1].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.5)),
                        "response.deals[1].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(1.14)),
                        "response.deals[1].product.ercPercentage", equalTo(new BigDecimal("3.00")),
                        "response.deals[1].product.annualOverpaymentAllowancePercentage", equalTo(new BigDecimal("10.00")),
                        "response.deals[1].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75)),

                        // deals[0], deal-loans-view[0]
                        "response.deals[0].dealLoans.size()", equalTo(4),
                        "response.deals[0].dealLoans[0].loanId", equalTo(1),
                        "response.deals[0].dealLoans[0].productTitle", equalTo("3 Year Fixed"),
                        "response.deals[0].dealLoans[0].interestRate", equalTo(BigDecimal.valueOf(1.49)),
                        "response.deals[0].dealLoans[0].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].dealLoans[0].variable", equalTo(false),
                        "response.deals[0].dealLoans[0].stepErc", equalTo(false),
                        "response.deals[0].dealLoans[0].trackingRate", equalTo(null),
                        "response.deals[0].dealLoans[0].transferring", equalTo(false),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(3.74)),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(3.74)),
                        "response.deals[0].dealLoans[0].loanBalance", equalTo(3009),
                        "response.deals[0].dealLoans[0].productFee", equalTo(null),
                        "response.deals[0].dealLoans[0].productWithFee", equalTo(false),
                        "response.deals[0].dealLoans[0].newOutstandingBalance", equalTo(3009),
                        "response.deals[0].dealLoans[0].previousProduct", equalTo(null),
                        "response.deals[0].dealLoans[0].productStartDate", equalTo(null),
                        "response.deals[0].dealLoans[0].productEndDate", equalTo("02/04/2025"),
                        "response.deals[0].dealLoans[0].remainingTerm", equalTo("4 years"),
                        "response.deals[0].dealLoans[0].repaymentType", equalTo("INTEREST_ONLY"),
                        "response.deals[0].dealLoans[0].annualOverpaymentAllowance", equalTo(new BigDecimal("10.00")),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(new BigDecimal("5.00")),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(BigDecimal.valueOf(90.27)),
                        "response.deals[0].dealLoans[0].santanderFollowOnRate", equalTo(BigDecimal.valueOf(3.35)),
                        "response.deals[0].dealLoans[0].applyFeeInThisLoan", equalTo(false),
                        "response.deals[0].dealLoans[0].interestRateChange", equalTo(null),
                        "response.deals[0].dealLoans[0].currentProductFixedTermFlag", equalTo(true),
                        "response.deals[0].dealLoans[0].lifetimeTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].currentProductTrackerFlag", equalTo(false),

                        //deals[0], deal-loans-view[1]
                        "response.deals[0].dealLoans[1].loanId", equalTo(2),
                        "response.deals[0].dealLoans[1].productTitle", equalTo("2 Year Tracker"),
                        "response.deals[0].dealLoans[1].interestRate", equalTo(BigDecimal.valueOf(1.19)),
                        "response.deals[0].dealLoans[1].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].dealLoans[1].variable", equalTo(true),
                        "response.deals[0].dealLoans[1].stepErc", equalTo(false),
                        "response.deals[0].dealLoans[1].trackingRate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].dealLoans[1].transferring", equalTo(true),
                        "response.deals[0].dealLoans[1].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(341.93)),
                        "response.deals[0].dealLoans[1].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(320.61)),
                        "response.deals[0].dealLoans[1].loanBalance", equalTo(BigDecimal.valueOf(15021.34)),
                        "response.deals[0].dealLoans[1].productFee", equalTo(999),
                        "response.deals[0].dealLoans[1].productWithFee", equalTo(true),
                        "response.deals[0].dealLoans[1].newOutstandingBalance", equalTo(BigDecimal.valueOf(16020.34)),
                        "response.deals[0].dealLoans[1].previousProduct", equalTo("2 Year Tracker(variable) at 1.19%"),
                        "response.deals[0].dealLoans[1].productStartDate", equalTo(null),
                        "response.deals[0].dealLoans[1].productEndDate", equalTo("24 months"),
                        "response.deals[0].dealLoans[1].remainingTerm", equalTo("4 years"),
                        "response.deals[0].dealLoans[1].repaymentType", equalTo("REPAYMENT"),
                        "response.deals[0].dealLoans[1].annualOverpaymentAllowance", equalTo(new BigDecimal("0.00")),
                        "response.deals[0].dealLoans[1].earlyRepaymentChargeAsPercentage", equalTo(0),
                        "response.deals[0].dealLoans[1].earlyRepaymentChargeAsAmount", equalTo(null),
                        "response.deals[0].dealLoans[1].santanderFollowOnRate", equalTo(BigDecimal.valueOf(3.75)),
                        "response.deals[0].dealLoans[1].applyFeeInThisLoan", equalTo(true),
                        "response.deals[0].dealLoans[1].interestRateChange", equalTo("SAME"),
                        "response.deals[0].dealLoans[1].currentProductFixedTermFlag", equalTo(true),
                        "response.deals[0].dealLoans[1].lifetimeTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[1].currentProductTrackerFlag", equalTo(true),


                        // deals[1], deal-loans-view[0]
                        "response.deals[1].dealLoans.size()", equalTo(4),
                        "response.deals[1].dealLoans[0].loanId", equalTo(1),
                        "response.deals[1].dealLoans[0].productTitle", equalTo("3 Year Fixed"),
                        "response.deals[1].dealLoans[0].interestRate", equalTo(BigDecimal.valueOf(1.49)),
                        "response.deals[1].dealLoans[0].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[1].dealLoans[0].variable", equalTo(false),
                        "response.deals[1].dealLoans[0].trackingRate", equalTo(null),
                        "response.deals[1].dealLoans[0].transferring", equalTo(false),
                        "response.deals[1].dealLoans[0].stepErc", equalTo(false),
                        "response.deals[1].dealLoans[0].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(3.74)),
                        "response.deals[1].dealLoans[0].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(3.74)),
                        "response.deals[1].dealLoans[0].loanBalance", equalTo(3009),
                        "response.deals[1].dealLoans[0].productFee", equalTo(null),
                        "response.deals[1].dealLoans[0].productWithFee", equalTo(false),
                        "response.deals[1].dealLoans[0].newOutstandingBalance", equalTo(3009),
                        "response.deals[1].dealLoans[0].previousProduct", equalTo(null),
                        "response.deals[1].dealLoans[0].productStartDate", equalTo(null),
                        "response.deals[1].dealLoans[0].productEndDate", equalTo("02/04/2025"),
                        "response.deals[1].dealLoans[0].remainingTerm", equalTo("4 years"),
                        "response.deals[1].dealLoans[0].repaymentType", equalTo("INTEREST_ONLY"),
                        "response.deals[1].dealLoans[0].annualOverpaymentAllowance", equalTo(new BigDecimal("10.00")),
                        "response.deals[1].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(new BigDecimal("5.00")),
                        "response.deals[1].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(BigDecimal.valueOf(90.27)),
                        "response.deals[1].dealLoans[0].santanderFollowOnRate", equalTo(BigDecimal.valueOf(3.35)),
                        "response.deals[1].dealLoans[0].applyFeeInThisLoan", equalTo(false),
                        "response.deals[1].dealLoans[0].interestRateChange", equalTo(null),
                        "response.deals[1].dealLoans[0].currentProductFixedTermFlag", equalTo(true),
                        "response.deals[1].dealLoans[0].lifetimeTermFlag", equalTo(false),
                        "response.deals[1].dealLoans[0].currentProductTrackerFlag", equalTo(false),

                        //deals[1], deal-loans-view[1]
                        "response.deals[1].dealLoans[1].loanId", equalTo(2),
                        "response.deals[1].dealLoans[1].productTitle", equalTo("2 Year Fixed"),
                        "response.deals[1].dealLoans[1].interestRate", equalTo(BigDecimal.valueOf(1.24)),
                        "response.deals[1].dealLoans[1].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.5)),
                        "response.deals[1].dealLoans[1].variable", equalTo(false),
                        "response.deals[1].dealLoans[1].stepErc", equalTo(false),
                        "response.deals[1].dealLoans[1].trackingRate", equalTo(null),
                        "response.deals[1].dealLoans[1].transferring", equalTo(true),
                        "response.deals[1].dealLoans[1].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(342.28)),
                        "response.deals[1].dealLoans[1].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(320.93)),
                        "response.deals[1].dealLoans[1].loanBalance", equalTo(BigDecimal.valueOf(15021.34)),
                        "response.deals[1].dealLoans[1].productFee", equalTo(999),
                        "response.deals[1].dealLoans[1].productWithFee", equalTo(true),
                        "response.deals[1].dealLoans[1].newOutstandingBalance", equalTo(BigDecimal.valueOf(16020.34)),
                        "response.deals[1].dealLoans[1].previousProduct", equalTo("2 Year Tracker(variable) at 1.19%"),
                        "response.deals[1].dealLoans[1].productStartDate", equalTo("04/05/2022"),
                        // By Corinthian-8036, when we are moving to a fixed like in thgis case we have to use product->chargeEndDate
                        // Old
                        // "response.deals[1].dealLoans[1].productEndDate", equalTo("04/05/2024")
                        // New is below
                        "response.deals[1].dealLoans[1].productEndDate", equalTo("02/04/2024"),
                        "response.deals[1].dealLoans[1].remainingTerm", equalTo("4 years"),
                        "response.deals[1].dealLoans[1].repaymentType", equalTo("REPAYMENT"),
                        "response.deals[1].dealLoans[1].annualOverpaymentAllowance", equalTo(new BigDecimal("10.00")),
                        "response.deals[1].dealLoans[1].earlyRepaymentChargeAsPercentage", equalTo(3),
                        "response.deals[1].dealLoans[1].earlyRepaymentChargeAsAmount", equalTo(null),
                        "response.deals[1].dealLoans[1].santanderFollowOnRate", equalTo(BigDecimal.valueOf(3.75)),
                        "response.deals[1].dealLoans[1].applyFeeInThisLoan", equalTo(true),
                        "response.deals[1].dealLoans[1].interestRateChange", equalTo("HIGHER"),
                        "response.deals[1].dealLoans[1].currentProductFixedTermFlag", equalTo(true),
                        "response.deals[1].dealLoans[1].lifetimeTermFlag", equalTo(false),
                        "response.deals[1].dealLoans[1].currentProductTrackerFlag", equalTo(true),

                        // product 3 has no fee, but we should still return withFee and withoutFee variables in the response
                        "response.deals[2].product.productFee", equalTo(0),
                        "response.deals[2].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(51975.88)),
                        "response.deals[2].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(51975.88)),
                        "response.deals[2].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(344.82)),
                        "response.deals[2].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(344.82)),
                        "response.deals[2].calculations.newMortgageOutstandingBalanceWithFee", equalTo(BigDecimal.valueOf(72269.84)),
                        "response.deals[2].calculations.newMortgageOutstandingBalanceWithoutFee", equalTo(BigDecimal.valueOf(72269.84))
                );
    }

    @Test
    void twoProductsInMortgageDealsResponseButOnlyOneIsEligible() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/two-products-only-first-eligible.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(1),
                        "response.deals[0].calculations.remainingBalanceWithoutFee", equalTo(BigDecimal.valueOf(34027.05)),
                        "response.deals[0].calculations.remainingBalanceWithFee", equalTo(BigDecimal.valueOf(34700.28)),
                        "response.deals[0].calculations.monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].calculations.monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),

                        "response.deals[0].product.productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].product.description", equalTo("2 Yr Tracker BBR plus 0.99% then FoR"),
                        "response.deals[0].product.productCode", equalTo("B139T"),
                        "response.deals[0].product.chargeEndDate", equalTo("01/04/2026"),
                        "response.deals[0].product.type", equalTo("Tracker"),
                        "response.deals[0].product.rate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].product.term", equalTo("2 Year"),
                        "response.deals[0].product.termInMonths", equalTo(24),
                        "response.deals[0].product.mortgageTermInMonthsAfterProduct", equalTo(48),
                        "response.deals[0].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].product.bankOfEnglandRateDifference", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].product.ercPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].product.annualOverpaymentAllowancePercentage", equalTo(BigDecimal.valueOf(23.56)),
                        "response.deals[0].product.santanderRevisionaryRate", equalTo(BigDecimal.valueOf(3.75)),

                        // deal-loans-view: IF loanTransferring -> TRUE
                        "response.deals[0].dealLoans.size()", equalTo(1),
                        "response.deals[0].dealLoans[0].loanId", equalTo(1),
                        "response.deals[0].dealLoans[0].productTitle", equalTo("2 Year Tracker"),
                        "response.deals[0].dealLoans[0].interestRate", equalTo(BigDecimal.valueOf(1.09)),
                        "response.deals[0].dealLoans[0].bankOfEnglandBaseRate", equalTo(BigDecimal.valueOf(0.1)),
                        "response.deals[0].dealLoans[0].variable", equalTo(true),
                        "response.deals[0].dealLoans[0].trackingRate", equalTo(BigDecimal.valueOf(0.99)),
                        "response.deals[0].dealLoans[0].transferring", equalTo(true),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithFee", equalTo(BigDecimal.valueOf(739.12)),
                        "response.deals[0].dealLoans[0].monthlyPaymentWithoutFee", equalTo(BigDecimal.valueOf(724.79)),
                        "response.deals[0].dealLoans[0].loanBalance", equalTo(BigDecimal.valueOf(50500.77)),
                        "response.deals[0].dealLoans[0].productFee", equalTo(BigDecimal.valueOf(999.99)),
                        "response.deals[0].dealLoans[0].productWithFee", equalTo(true),
                        "response.deals[0].dealLoans[0].newOutstandingBalance", equalTo(BigDecimal.valueOf(51491.5)),
                        "response.deals[0].dealLoans[0].previousProduct", equalTo("Standard Variable Rate at 4.34%"),
                        "response.deals[0].dealLoans[0].productStartDate", equalTo(null),
                        "response.deals[0].dealLoans[0].productEndDate", equalTo("24 months"),
                        "response.deals[0].dealLoans[0].remainingTerm", equalTo("6 years"),
                        "response.deals[0].dealLoans[0].repaymentType", equalTo("REPAYMENT"),
                        "response.deals[0].dealLoans[0].annualOverpaymentAllowance", equalTo(new BigDecimal("23.56")),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(BigDecimal.valueOf(12.12)),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(null),
                        "response.deals[0].dealLoans[0].santanderFollowOnRate", equalTo(new BigDecimal("3.75")),
                        "response.deals[0].dealLoans[0].applyFeeInThisLoan", equalTo(true),
                        "response.deals[0].dealLoans[0].interestRateChange", equalTo("LOWER"),
                        "response.deals[0].dealLoans[0].currentProductFixedTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].lifetimeTermFlag", equalTo(false),
                        "response.deals[0].dealLoans[0].currentProductTrackerFlag", equalTo(false)
                );
    }

    @Test
    void noEligibleProducts() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/no-eligible-products.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(0)
                );
    }

    @Test
    void notProductAtAllInNewDealsResponse() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/no-product-at-all.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(0)
                );
    }

    @Test
    void lifetimeTrackerProducts() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("mortgage-deals/mortgage-deals-one-deal-lifetime.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals[0].product.bankOfEnglandRate", equalTo(BigDecimal.valueOf(0.1))
                );
    }

    @Test
    void shouldERCPercentageInNonTranferringLoan() {

        var accountNumber = 123456;
        var dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/account-details/account-details-with-step-erc.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/two-products-only-first-eligible.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                body("{\"loansSelected\":[" +
                        "{\"loanScheme\":\"3R\"," +
                        "\"sequenceNumber\":2}" +
                        "]}").
                when().
                post(dealsEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "response.deals.size()", equalTo(1),
                        // stepped ERC
                        "response.deals[0].dealLoans.size()", equalTo(4),
                        "response.deals[0].dealLoans[0].transferring", equalTo(false),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsPercentage", equalTo(new BigDecimal("3.60")),
                        "response.deals[0].dealLoans[0].earlyRepaymentChargeAsAmount", equalTo(new BigDecimal("3644.57")),
                         // Flat ERC
                        "response.deals[0].dealLoans[1].transferring", equalTo(false),
                        "response.deals[0].dealLoans[1].earlyRepaymentChargeAsPercentage", equalTo(new BigDecimal("8.00")),
                        "response.deals[0].dealLoans[1].earlyRepaymentChargeAsAmount", equalTo(new BigDecimal("3644.57")),
                        // No ERC
                        "response.deals[0].dealLoans[2].transferring", equalTo(false),
                        "response.deals[0].dealLoans[2].earlyRepaymentChargeAsPercentage", equalTo(new BigDecimal("0.00")),
                        "response.deals[0].dealLoans[2].earlyRepaymentChargeAsAmount", equalTo(0)

                );
    }
}

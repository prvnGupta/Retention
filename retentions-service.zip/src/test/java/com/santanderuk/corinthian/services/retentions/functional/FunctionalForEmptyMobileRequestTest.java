package com.santanderuk.corinthian.services.retentions.functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.config.JsonPathConfig;
import com.santanderuk.corinthian.services.retentions.RetentionsServiceApplication;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.jayway.restassured.config.JsonConfig.jsonConfig;
import static com.jayway.restassured.config.RestAssuredConfig.newConfig;

@ContextConfiguration(initializers = FunctionalForEmptyMobileRequestTest.RandomPortInitailizer.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = RetentionsServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class FunctionalForEmptyMobileRequestTest {

    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";
    protected String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    private WireMockServer coreMortgageEligibilityWireMock;

    private WireMockServer riskValuationWiremock;

    private WireMockServer productCatalogWiremock;

    private WireMockServer heartbeatWiremock;

    private WireMockServer anmfWiremock;

    private WireMockServer pafWiremock;

    private WireMockServer createCaseWiremock;
    @Value("${service.bksConnect.port}")
    protected int bksConnectPort;

    @LocalServerPort
    protected String serverPort;

    @Value("${core.mortgage.api.port}")
    protected int coreMortgageEligibilityWireMockPort;

    @Value("${riskvaluation.port}")
    protected int riskValuationPort;

    @Value("${productCatalog.port}")
    protected int productCatalogPort;

    @Value("${heartbeat.port}")
    protected int heartbeatPort;

    @Value("${anmf.port}")
    protected int anmfPort;

    @Value("${paf.port}")
    protected int pafPort;

    @Value("${service.createCase.port}")
    protected int createCasePort;
    private WireMockServer bksConnectWiremock;

    @Value("${caching.inMemoryCacheNames}")
    private String inMemoryCacheNames;

    @Autowired
    @Qualifier("cacheManagerHeartbeat")
    private CacheManager cacheManagerHeartbeat;

    @BeforeEach
    public void baseSetUp() {

        RestAssured.config =
                newConfig().jsonConfig(jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));

        coreMortgageEligibilityWireMock = new WireMockServer(coreMortgageEligibilityWireMockPort);
        coreMortgageEligibilityWireMock.start();

        riskValuationWiremock = new WireMockServer(riskValuationPort);
        riskValuationWiremock.start();

        productCatalogWiremock = new WireMockServer(productCatalogPort);
        productCatalogWiremock.start();

        heartbeatWiremock = new WireMockServer(heartbeatPort);
        heartbeatWiremock.start();

        anmfWiremock = new WireMockServer(anmfPort);
        anmfWiremock.start();

        createCaseWiremock = new WireMockServer(createCasePort);
        createCaseWiremock.start();

        bksConnectWiremock = new WireMockServer(bksConnectPort);
        bksConnectWiremock.start();

        pafWiremock = new WireMockServer(pafPort);
        pafWiremock.start();
    }

    @AfterEach
    public void baseTearDown() {
        deleteInMemoryCacheForTests();
        riskValuationWiremock.stop();
        coreMortgageEligibilityWireMock.stop();
        productCatalogWiremock.stop();
        heartbeatWiremock.stop();
        anmfWiremock.stop();
        createCaseWiremock.stop();
        bksConnectWiremock.stop();
        pafWiremock.stop();
    }

    private void deleteInMemoryCacheForTests() {
        String[] cacheNames = inMemoryCacheNames.split(",");

        for (String cacheName : cacheNames) {
            cacheManagerHeartbeat.getCache(cacheName).clear();
        }
    }

    protected void stubPafId() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses"))
                .withQueryParam("query", notMatching("fhjkdhasfkjhsal"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-id-response.json"))));
    }

    protected void stubPafIdAndPostcode() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses"))
                .withQueryParam("container", equalTo("GB|RM|ENG|MILTON_KEYNES-MILTON_KEYNES_VILLAGE"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-id-response-2.json"))));
    }

    protected void stubPafDetails() {
        pafWiremock.stubFor(any(urlPathEqualTo("/sanuk/playground-internal/paf2/v2/addresses/GB|RM|ENG|MILTON_KEYNES-MILTON_KEYNES_VILLAGE"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("paf/paf-details-response.json"))));
    }

    protected void stubBksConnect() {
        bksConnectWiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect/bks-connect-retrieve-mcc-ok-response.json"))));
    }

    protected void stubProductCompletionDate(String testFixture) {
        productCatalogWiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/product-band/productCompletionDates"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubShortestChargeEndDate() {

        productCatalogWiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/product-band/nearest-fixed-charge-end-date"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("product/shortest-term-success-response.json"))));
    }

    protected void stubShortestChargeEndDate(String testFixture) {

        productCatalogWiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/product-band/nearest-fixed-charge-end-date"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubHeartBeat(String testFixture) {
        heartbeatWiremock.stubFor(get(urlPathEqualTo("/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubRiskValuation(int accountNumber, String testFixture) {
        riskValuationWiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/risk-valuation/accounts/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubANMFAccountInfo(int accountNumber, String testFixture) {
        anmfWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/mortgage-details/v3/a/accountdata/%s", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubANMFPropertyInfoV2(int accountNumber, String testFixture) {
        anmfWiremock.stubFor(any(urlPathEqualTo(String.format("/sanuk/internal/collateral-asset-administration/v2/a/accounts/%s/property", accountNumber)))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubAnmfCustomerInfo(String testFixture) {
        anmfWiremock.stubFor(get(urlMatching("/sanuk/internal/mortgage-customer-details/v2/a/account/.*/customer"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubODMCoreEligibility(String testFixture) {
        coreMortgageEligibilityWireMock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-api/v1/api"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    public static class RandomPortInitailizer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {

            int randomEligibilityCoreMortgagePort = SocketUtils.findAvailableTcpPort();
            int randomRiskValuationPort = SocketUtils.findAvailableTcpPort();
            int randomProductCatalogPort = SocketUtils.findAvailableTcpPort();
            int randomCreateCasePort = SocketUtils.findAvailableTcpPort();
            int randomBksConnectPort = SocketUtils.findAvailableTcpPort();
            int randomPafPort = SocketUtils.findAvailableTcpPort();

            String coreMortgageEligibilityUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-api/v1/api", randomEligibilityCoreMortgagePort);
            String riskValuationUrl = String.format("http://localhost:%d/sanuk/internal/risk-valuation/accounts", randomRiskValuationPort);
            String productCatalogCompletionUrl = String.format("http://localhost:%d/sanuk/internal/product-band/productCompletionDates", randomProductCatalogPort);
            String productCatalogDataUrl = String.format("http://localhost:%d/sanuk/internal/product-band/products/{band}", randomProductCatalogPort);
            String productCatalogEndDateUrl = String.format("http://localhost:%d/sanuk/internal/product-band/nearest-fixed-charge-end-date", randomProductCatalogPort);
            String createCaseUrl = String.format("http://localhost:%d/sanuk/internal/core-retentions/case", randomCreateCasePort);
            String bksConnectUrl = String.format("http://localhost:%d/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user", randomBksConnectPort);
            String pafUrl = String.format("http://localhost:%d/sanuk/playground-internal/paf2/v2/addresses", randomPafPort);


            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.createCase=" + createCaseUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.createCase.port=" + randomCreateCasePort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.mortgageEligibility=" + coreMortgageEligibilityUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core.mortgage.api.port=" + randomEligibilityCoreMortgagePort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.riskvaluation=" + riskValuationUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "riskvaluation.port=" + randomRiskValuationPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.productCompletionDate=" + productCatalogCompletionUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "productCatalog.port=" + randomProductCatalogPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.productData=" + productCatalogDataUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.shortestChargeEndDate=" + productCatalogEndDateUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "bksconnect.endpoints.retrievemcc=" + bksConnectUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.bksConnect.port=" + randomBksConnectPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "service.core.paf=" + pafUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "paf.port=" + randomPafPort);

            int randomHeartbeatPort = SocketUtils.findAvailableTcpPort();
            String heartbeatUrl = String.format("http://localhost:%d/get-region", randomHeartbeatPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.get-region=" + heartbeatUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.port=" + randomHeartbeatPort);

            int anmfPort = SocketUtils.findAvailableTcpPort();

            String anmfBaseUrl = String.format("http://localhost:%d/sanuk/internal/anmf/a", anmfPort);


            String anmfAccInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-details/v3/a/accountdata/{account}", anmfPort);
            String anmfProductInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-details/v3/a/accountproductdata/{account}/{prodcode}", anmfPort);
            String anmfCustomerInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-customer-details/v2/a/account/{account}/customer", anmfPort);
            String anmfPropoertyInfoUrl = String.format("http://localhost:%d/sanuk/internal/collateral-asset-administration/v2/a/accounts/{account}/property", anmfPort);
            String anmfDirectDebitInfoUrl = String.format("http://localhost:%d/sanuk/internal/anmf/a/directdebit/view/{account}/directdebit", anmfPort);
            String anmfAvailableDateUrl = String.format("http://localhost:%d/sanuk/internal/anmf/a/paymentdate/view/{account}", anmfPort);
            String anmfRegularOverpaymentUrl = String.format("http://localhost:%d/sanuk/internal/anmf/a/overpayment/{account}/overpayinstruction/DIRECT_DEBIT", anmfPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.productinfo.aregion=%s", anmfProductInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.productinfo.wregion=%s", anmfProductInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.payments.aregion=%s/overpayment", anmfBaseUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.payments.wregion=%s/overpayment", anmfBaseUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.directdebit.aregion=%s/directdebit/view", anmfBaseUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.directdebit.wregion=%s/directdebit/view", anmfBaseUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.paymentdate.aregion=%s/paymentdate/view", anmfBaseUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.paymentdate.wregion=%s/paymentdate/view", anmfBaseUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.customerservice.aregion=%s", anmfCustomerInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.customerservice.wregion=%s", anmfCustomerInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.account-details.aregion=%s", anmfAccInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.account-details.wregion=%s", anmfAccInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.directdebit.aregion=%s", anmfDirectDebitInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.directdebit.wregion=%s", anmfDirectDebitInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.property.aregion=%s", anmfPropoertyInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.property.wregion=%s", anmfPropoertyInfoUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.paymentdate.aregion=%s", anmfAvailableDateUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.paymentdate.wregion=%s", anmfAvailableDateUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.overpayments-instructions.aregion=%s", anmfRegularOverpaymentUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.overpayments-instructions.wregion=%s", anmfRegularOverpaymentUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "anmf.port=" + anmfPort);
        }
    }
}

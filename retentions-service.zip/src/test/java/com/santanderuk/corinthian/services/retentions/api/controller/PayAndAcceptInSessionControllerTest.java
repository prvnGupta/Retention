package com.santanderuk.corinthian.services.retentions.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.retentions.api.model.ServiceInfoWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.service.PayAndAcceptInSessionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PayAndAcceptInSessionControllerTest {

    private PayAndAcceptInSessionController payAndAcceptInSessionController;

    @Mock
    private PayAndAcceptInSessionService payAndAcceptInSessionService;
    @Mock
    private HttpServletRequest httpServletRequest;

    @BeforeEach
    void setUp() {
        payAndAcceptInSessionController = new PayAndAcceptInSessionController(payAndAcceptInSessionService);
    }

    @Test
    void testWeCallTheService() throws GeneralException, JsonProcessingException {

        AcceptAndPayInSessionRequest request = new AcceptAndPayInSessionRequest();
        request.setAccountFrom("090128 02100882");

        ResponseEntity<ServiceInfoWrapper> response = payAndAcceptInSessionController.payAndAcceptInSession(request, 123456, "esis-ref-id", "jwt",httpServletRequest);

        verify(payAndAcceptInSessionService, times(1)).payFeeAndAcceptOffer(request, 123456, "esis-ref-id", "jwt", httpServletRequest);

        assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
    }
}

package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CoreRetentionMapperOfferConversionDetailsTest extends CoreRetentionMapperTestBase {


    @Test
    public void testOneLoan() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getOfferConversionDetails());
        assertFalse(coreRetentionRequest.getOfferConversionDetails().isConversionFromCCAFlexiIndicator());
        assertFalse(coreRetentionRequest.getOfferConversionDetails().isConversionFromUnitaryFlexiIndicator());
        assertFalse(coreRetentionRequest.getOfferConversionDetails().isMultiConversionDateIndicator());
        assertFalse(coreRetentionRequest.getOfferConversionDetails().isSplitLoanIndicator());

    }

}

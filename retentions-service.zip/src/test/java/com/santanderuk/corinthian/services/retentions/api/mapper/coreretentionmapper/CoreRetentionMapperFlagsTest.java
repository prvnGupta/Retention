package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class CoreRetentionMapperFlagsTest extends CoreRetentionMapperTestBase {

    @Test
    public void mapFlags() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getFlags());

        assertEquals(2, coreRetentionRequest.getFlags().getAdvised());
        assertFalse(coreRetentionRequest.getFlags().isIntroduced());
        assertFalse(coreRetentionRequest.getFlags().isInitialAdvance());
        assertEquals(3, coreRetentionRequest.getFlags().getCallingService());
        assertNull(coreRetentionRequest.getFlags().getEsisDoc());
    }

    @Test
    public void mapFlagsIsBuyToLet() {
        CoreRetentionsData input = generateDefaultMapperInput();
        input.getAddressResponse().getPropertyEnquiryResponse().getOutputStructure().setOSpecialPurchase("L");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getFlags());

        assertEquals("B", coreRetentionRequest.getFlags().getBtlClassification());
    }

    @Test
    public void mapFlagsIsNoBuyToLet() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getFlags());

        assertEquals("N", coreRetentionRequest.getFlags().getBtlClassification());
    }

}

package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.AllIneligibleLoans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class AllIneligibleLoansTest extends RuleTest {

    AllIneligibleLoans rule;

    @BeforeEach
    public void setUp() {
        rule = new AllIneligibleLoans();
    }


    @Test
    public void testWeSetBlockerWhenAllLoansIneligible() {


        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        ODMLoanResponse loan1 = new ODMLoanResponse();
        loan1.setLoanEligibility("N");

        ODMLoanResponse loan2 = new ODMLoanResponse();
        loan2.setLoanEligibility("N");

        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isAllLoansIneligible(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);
        assertThat(eligibilityResponse.getBlockers().isAllLoansIneligible(), equalTo(true));
    }

    @Test
    public void testWeDontSetBlockerWhenSomelLoansIneligible() {


        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        ODMLoanResponse loan1 = new ODMLoanResponse();
        loan1.setLoanEligibility("N");

        ODMLoanResponse loan2 = new ODMLoanResponse();
        loan2.setLoanEligibility("Y");

        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isAllLoansIneligible(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);
        assertThat(eligibilityResponse.getBlockers().isAllLoansIneligible(), equalTo(false));
    }

    @Test
    public void testWeDontSetBlockerWhenNoLoansIneligible() {


        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));

        ODMLoanResponse loan1 = new ODMLoanResponse();
        loan1.setLoanEligibility("Y");

        ODMLoanResponse loan2 = new ODMLoanResponse();
        loan2.setLoanEligibility("Y");

        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isAllLoansIneligible(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);
        assertThat(eligibilityResponse.getBlockers().isAllLoansIneligible(), equalTo(false));
    }

}

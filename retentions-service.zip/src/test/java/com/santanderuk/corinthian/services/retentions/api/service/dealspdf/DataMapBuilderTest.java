package com.santanderuk.corinthian.services.retentions.api.service.dealspdf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.retentions.FixtureReader;
import com.santanderuk.corinthian.services.retentions.TestDataCreator;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.*;
import com.santanderuk.corinthian.services.retentions.api.model.dealspdf.PdfLoan;
import com.santanderuk.corinthian.services.retentions.api.model.dealspdf.PdfProduct;
import com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher.DealsPdfAnmfDataFetcherOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapperTestData.addLoanInDealsRequest;
import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapperTestData.createEmptyDealsRequest;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
class DataMapBuilderTest {

    DataMapBuilder dataMapBuilder;

    @BeforeEach
    void setUp() {
        dataMapBuilder = new DataMapBuilder();

    }

    @Test
    void mapForProductsIsDoneCorrectly() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        dealsResponse.setStepErcActive(false);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("5 Year Fixed", firstElementProductTable.getProductDescription());
        assertEquals("1.00%", firstElementProductTable.getInitialRate());
        assertEquals("£999", firstElementProductTable.getProductFee());
        assertEquals("£95.00", firstElementProductTable.getMonthlyPaymentWithoutFee());
        assertEquals("£101.00", firstElementProductTable.getMonthlyPaymentWithFee());
        assertEquals("10%", firstElementProductTable.getOverpaymentAllowance());
        assertEquals("3%", firstElementProductTable.getErc());
        assertEquals("Fixed", firstElementProductTable.getType());
        assertEquals("2.50%", firstElementProductTable.getDiffBankOfEnglandBaseRate());
        assertFalse((boolean) map.get("stepErcActive"));

    }

    @Test
    void ShouldRemoveSvrProductFromProductsIfCurrentlyOnSvrAndSingleLoan() throws IOException {
        var dealsResponse = FixtureReader.convertResponseToObject("{\"stepErcActive\":true,\"deals\":[{\"calculations\":{\"remainingBalanceWithFee\":675469.67,\"remainingBalanceWithoutFee\":674684.59,\"monthlyPaymentWithFee\":5908.98,\"monthlyPaymentWithoutFee\":5902.12,\"newMortgageOutstandingBalanceWithFee\":859523.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":999,\"description\":\"c 5 Yr Fixed til 02 May 2029 then SVR\",\"productCode\":\"F048J\",\"chargeEndDate\":\"02/05/2029\",\"type\":\"Fixed\",\"rate\":4.71,\"term\":\"5 Year\",\"termInMonths\":60,\"mortgageTermInMonthsAfterProduct\":156,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":5,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":1,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"5 Year Fixed\",\"interestRate\":4.71,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5908.98,\"monthlyPaymentWithoutFee\":5902.12,\"loanBalance\":858524.64,\"productFee\":999,\"productWithFee\":true,\"newOutstandingBalance\":859523.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2029\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":5,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":true,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]},{\"calculations\":{\"remainingBalanceWithFee\":677139.2,\"remainingBalanceWithoutFee\":677139.2,\"monthlyPaymentWithFee\":5984.85,\"monthlyPaymentWithoutFee\":5984.85,\"newMortgageOutstandingBalanceWithFee\":858524.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":false,\"productFee\":0,\"description\":\"Standard Variable Rate\",\"productCode\":\"SV995\",\"chargeEndDate\":\"\",\"type\":\"Variable\",\"rate\":7.5,\"term\":\"Lifetime\",\"termInMonths\":31,\"mortgageTermInMonthsAfterProduct\":0,\"bankOfEnglandRate\":7.5,\"bankOfEnglandRateDifference\":0,\"ercPercentage\":0,\"annualOverpaymentAllowancePercentage\":0,\"santanderRevisionaryRate\":0,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"N/A\"},\"loanToApplyTheFeeTo\":0,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"5 Year Fixed\",\"interestRate\":4.89,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5984.85,\"monthlyPaymentWithoutFee\":5984.85,\"loanBalance\":858524.64,\"productFee\":0,\"productWithFee\":false,\"newOutstandingBalance\":858524.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2029\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":5,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":false,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]},{\"calculations\":{\"remainingBalanceWithFee\":784911.14,\"remainingBalanceWithoutFee\":783998.86,\"monthlyPaymentWithFee\":5927.34,\"monthlyPaymentWithoutFee\":5920.45,\"newMortgageOutstandingBalanceWithFee\":859523.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":999,\"description\":\"c 2 Yr Fixed til 02 May 2026 then SVR\",\"productCode\":\"F044J\",\"chargeEndDate\":\"02/05/2026\",\"type\":\"Fixed\",\"rate\":4.75,\"term\":\"2 Year\",\"termInMonths\":24,\"mortgageTermInMonthsAfterProduct\":192,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":2,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":1,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"2 Year Fixed\",\"interestRate\":4.75,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5927.34,\"monthlyPaymentWithoutFee\":5920.45,\"loanBalance\":858524.64,\"productFee\":999,\"productWithFee\":true,\"newOutstandingBalance\":859523.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2026\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":2,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":true,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]},{\"calculations\":{\"remainingBalanceWithFee\":595149.15,\"remainingBalanceWithoutFee\":595149.15,\"monthlyPaymentWithFee\":5961.8,\"monthlyPaymentWithoutFee\":5961.8,\"newMortgageOutstandingBalanceWithFee\":858524.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":0,\"description\":\"c 7 Yr Fixed til 02 May 2031 then SVR\",\"productCode\":\"F050J\",\"chargeEndDate\":\"02/05/2031\",\"type\":\"Fixed\",\"rate\":4.84,\"term\":\"7 Year\",\"termInMonths\":84,\"mortgageTermInMonthsAfterProduct\":132,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":5,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":0,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"7 Year Fixed\",\"interestRate\":4.84,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5961.8,\"monthlyPaymentWithoutFee\":5961.8,\"loanBalance\":858524.64,\"productFee\":0,\"productWithFee\":false,\"newOutstandingBalance\":858524.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2031\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":5,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":false,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]}]}", DealsResponse.class);
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        dealsResponse.setStepErcActive(false);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("5 Year Fixed", firstElementProductTable.getProductDescription());
        var secondElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(1);
        assertEquals("2 Year Fixed", secondElementProductTable.getProductDescription());
        var thirdElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(2);
        assertEquals("7 Year Fixed", thirdElementProductTable.getProductDescription());
        assertEquals(3, ((List<?>) map.get("productsTable")).size());
        assertFalse((boolean) map.get("stepErcActive"));
    }

    @Test
    void ShouldNotRemoveSvrProductFromProductsIfCurrentlyNotOnSvr() throws IOException {
        var dealsResponse = FixtureReader.convertResponseToObject("{\"stepErcActive\":true,\"deals\":[{\"calculations\":{\"remainingBalanceWithFee\":675469.67,\"remainingBalanceWithoutFee\":674684.59,\"monthlyPaymentWithFee\":5908.98,\"monthlyPaymentWithoutFee\":5902.12,\"newMortgageOutstandingBalanceWithFee\":859523.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":999,\"description\":\"c 5 Yr Fixed til 02 May 2029 then SVR\",\"productCode\":\"F048J\",\"chargeEndDate\":\"02/05/2029\",\"type\":\"Fixed\",\"rate\":4.71,\"term\":\"5 Year\",\"termInMonths\":60,\"mortgageTermInMonthsAfterProduct\":156,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":5,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":1,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"5 Year Fixed\",\"interestRate\":4.71,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5908.98,\"monthlyPaymentWithoutFee\":5902.12,\"loanBalance\":858524.64,\"productFee\":999,\"productWithFee\":true,\"newOutstandingBalance\":859523.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2029\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":5,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":true,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]},{\"calculations\":{\"remainingBalanceWithFee\":784911.14,\"remainingBalanceWithoutFee\":783998.86,\"monthlyPaymentWithFee\":5927.34,\"monthlyPaymentWithoutFee\":5920.45,\"newMortgageOutstandingBalanceWithFee\":859523.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":999,\"description\":\"c 2 Yr Fixed til 02 May 2026 then SVR\",\"productCode\":\"F044J\",\"chargeEndDate\":\"02/05/2026\",\"type\":\"Fixed\",\"rate\":4.75,\"term\":\"2 Year\",\"termInMonths\":24,\"mortgageTermInMonthsAfterProduct\":192,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":2,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":1,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"2 Year Fixed\",\"interestRate\":4.75,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5927.34,\"monthlyPaymentWithoutFee\":5920.45,\"loanBalance\":858524.64,\"productFee\":999,\"productWithFee\":true,\"newOutstandingBalance\":859523.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2026\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":2,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":true,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]},{\"calculations\":{\"remainingBalanceWithFee\":595149.15,\"remainingBalanceWithoutFee\":595149.15,\"monthlyPaymentWithFee\":5961.8,\"monthlyPaymentWithoutFee\":5961.8,\"newMortgageOutstandingBalanceWithFee\":858524.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":0,\"description\":\"c 7 Yr Fixed til 02 May 2031 then SVR\",\"productCode\":\"F050J\",\"chargeEndDate\":\"02/05/2031\",\"type\":\"Fixed\",\"rate\":4.84,\"term\":\"7 Year\",\"termInMonths\":84,\"mortgageTermInMonthsAfterProduct\":132,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":5,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":0,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"7 Year Fixed\",\"interestRate\":4.84,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5961.8,\"monthlyPaymentWithoutFee\":5961.8,\"loanBalance\":858524.64,\"productFee\":0,\"productWithFee\":false,\"newOutstandingBalance\":858524.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2031\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":5,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":false,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]},{\"calculations\":{\"remainingBalanceWithFee\":677139.2,\"remainingBalanceWithoutFee\":677139.2,\"monthlyPaymentWithFee\":5984.85,\"monthlyPaymentWithoutFee\":5984.85,\"newMortgageOutstandingBalanceWithFee\":858524.64,\"newMortgageOutstandingBalanceWithoutFee\":858524.64},\"product\":{\"stepErc\":true,\"productFee\":0,\"description\":\"c 5 Yr Fixed til 02 May 2029 then SVR\",\"productCode\":\"F049J\",\"chargeEndDate\":\"02/05/2029\",\"type\":\"Fixed\",\"rate\":4.89,\"term\":\"5 Year\",\"termInMonths\":60,\"mortgageTermInMonthsAfterProduct\":156,\"bankOfEnglandRate\":0,\"bankOfEnglandRateDifference\":null,\"ercPercentage\":5,\"annualOverpaymentAllowancePercentage\":10,\"santanderRevisionaryRate\":7.5,\"productCompletionDate\":\"05/07/2024\",\"reversionProduct\":\"SVR\"},\"loanToApplyTheFeeTo\":0,\"dealLoans\":[{\"loanId\":1,\"productTitle\":\"5 Year Fixed\",\"interestRate\":4.89,\"bankOfEnglandBaseRate\":0,\"variable\":false,\"transferring\":true,\"monthlyPaymentWithFee\":5984.85,\"monthlyPaymentWithoutFee\":5984.85,\"loanBalance\":858524.64,\"productFee\":0,\"productWithFee\":false,\"newOutstandingBalance\":858524.64,\"previousProduct\":\"Standard Variable Rate at 7.5%\",\"productEndDate\":\"02/05/2029\",\"remainingTerm\":\"18 years\",\"repaymentType\":\"REPAYMENT\",\"annualOverpaymentAllowance\":10,\"earlyRepaymentChargeAsPercentage\":5,\"santanderFollowOnRate\":7.5,\"applyFeeInThisLoan\":false,\"interestRateChange\":\"LOWER\",\"currentProductFixedTermFlag\":false,\"lifetimeTermFlag\":false,\"currentProductTrackerFlag\":false,\"stepErc\":true}]}]}", DealsResponse.class);
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        dealsResponse.setStepErcActive(false);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("5 Year Fixed", firstElementProductTable.getProductDescription());
        var secondElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(1);
        assertEquals("2 Year Fixed", secondElementProductTable.getProductDescription());
        var thirdElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(2);
        assertEquals("7 Year Fixed", thirdElementProductTable.getProductDescription());
        var fourthElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(3);
        assertEquals("5 Year Fixed", fourthElementProductTable.getProductDescription());
        assertEquals(4, ((List<?>) map.get("productsTable")).size());
        assertFalse((boolean) map.get("stepErcActive"));
    }

    @Test
    void mapForSVRProductDoneCorrectly() throws IOException {

        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(TestDataCreator.getDealsResponseWithSVRProduct(), anmfData, dealsRequest);

        assertEquals(10, ((List<?>) map.get("productsTable")).size());
        var svrProduct = (PdfProduct) ((List<?>) map.get("productsTable")).get(8);
        assertEquals("Standard Variable Rate", svrProduct.getProductDescription());
        var lifetimeTrackerProduct = (PdfProduct) ((List<?>) map.get("productsTable")).get(9);
        assertEquals("Lifetime Tracker", lifetimeTrackerProduct.getProductDescription());
        assertTrue((boolean) map.get("SVRReversionActive"));

    }

    @Test
    void mapForSVRReversionFalse() throws IOException {
        var dealsResponse = getDealsResponseTwoProducts();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        dealsResponse.setStepErcActive(false);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        assertFalse((boolean) map.get("SVRReversionActive"));

    }


    @Test
    void testNullDiffBankOfEnglandBaseRateIsHandled() {
        var dealsResponse = getDealsResponseOneProduct();
        dealsResponse.getDeals().get(0).getProduct().setBankOfEnglandRateDifference(null);
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);

        assertEquals("", firstElementProductTable.getDiffBankOfEnglandBaseRate());


    }

    @Test
    void mapStepErcTrueCorrectly() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("5 Year Fixed", firstElementProductTable.getProductDescription());
        assertEquals("1.00%", firstElementProductTable.getInitialRate());
        assertEquals("£999", firstElementProductTable.getProductFee());
        assertEquals("£95.00", firstElementProductTable.getMonthlyPaymentWithoutFee());
        assertEquals("£101.00", firstElementProductTable.getMonthlyPaymentWithFee());
        assertEquals("10%", firstElementProductTable.getOverpaymentAllowance());
        assertEquals("3%", firstElementProductTable.getErc());
        assertEquals("Fixed", firstElementProductTable.getType());
        assertEquals("2.50%", firstElementProductTable.getDiffBankOfEnglandBaseRate());
        assertTrue((boolean) map.get("stepErcActive"));

    }

    @Test
    void mapForProductsIsDoneCorrectlyButErcChageIsZeroSoAnnualAllowanceShouldBeUnlimited() {
        var dealsResponse = getDealsResponseOneProduct();
        dealsResponse.getDeals().get(0).getProduct().setErcPercentage(BigDecimal.ZERO);
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("Unlimited", firstElementProductTable.getOverpaymentAllowance());
        assertEquals("No charge", firstElementProductTable.getErc());

    }

    @Test
    void mapForTwoProductsIsDoneCorrectly() {
        var dealsResponse = getDealsResponseTwoProducts();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("5 Year Fixed", firstElementProductTable.getProductDescription());
        assertEquals("1.00%", firstElementProductTable.getInitialRate());
        assertEquals("£999", firstElementProductTable.getProductFee());
        assertEquals("£95.00", firstElementProductTable.getMonthlyPaymentWithoutFee());
        assertEquals("£101.00", firstElementProductTable.getMonthlyPaymentWithFee());
        assertEquals("10%", firstElementProductTable.getOverpaymentAllowance());
        assertEquals("3%", firstElementProductTable.getErc());
        assertEquals("Fixed", firstElementProductTable.getType());
        assertEquals("2.50%", firstElementProductTable.getDiffBankOfEnglandBaseRate());

        // No need of testing every field. Enough seeing tha that second row is different
        var secondElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(1);
        assertEquals("2 Year Tracker", secondElementProductTable.getProductDescription());

    }


    @Test
    void mapForTwoProductsIsDoneCorrectlyButErcChageIsZeroSoAnnualAllowanceShouldBeUnlimited() {
        var dealsResponse = getDealsResponseTwoProducts();
        dealsResponse.getDeals().get(0).getProduct().setErcPercentage(BigDecimal.ZERO);
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(0);
        assertEquals("Unlimited", firstElementProductTable.getOverpaymentAllowance());
        assertEquals("No charge", firstElementProductTable.getErc());

        // No need of testing every field. Enough seeing tha that second row is different
        var secondElementProductTable = (PdfProduct) ((List<?>) map.get("productsTable")).get(1);
        assertEquals("10%", secondElementProductTable.getOverpaymentAllowance());
        assertEquals("3%", secondElementProductTable.getErc());


    }

    @Test
    void mapForCurrentDateForPdfIsCorrect() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy");
        var today = LocalDate.now().format(formatter);

        assertEquals(today, map.get("currentDate"));

    }

    @Test
    void mapForBankOfEnglandBaseRate() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        assertEquals("0.5%", map.get("bankOfEnglandRate"));

    }

    @Test
    void mapForCurrentLoanList() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstElementProductTable = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("1.45%", firstElementProductTable.getInterestRate());
        assertEquals("£1,000.00", firstElementProductTable.getLoanBalance());
        assertEquals("£56.00", firstElementProductTable.getMonthlyPayment());
        assertEquals("Standard variable rate", firstElementProductTable.getProductDescription());
        // Select is complex so we will do it in its own tests
        // assertEquals("Yes", firstElementProductTable.getSelected());

    }

    @Test
    void mapForTwoCurrentLoansLists() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataTwoLoans();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("1.45%", firstLoan.getInterestRate());
        assertEquals("£1,000.00", firstLoan.getLoanBalance());
        assertEquals("£56.00", firstLoan.getMonthlyPayment());
        assertEquals("Standard variable rate", firstLoan.getProductDescription());
        // Select is complex so we will do it in its own tests
        // assertEquals("Yes", firstElementProductTable.getSelected());

        var secondLoand = (PdfLoan) ((List<?>) map.get("currentLoans")).get(1);
        assertEquals("2.45%", secondLoand.getInterestRate());
        assertEquals("£2,000.00", secondLoand.getLoanBalance());
        assertEquals("£57.00", secondLoand.getMonthlyPayment());
        assertEquals("Other fixed product", secondLoand.getProductDescription());
    }

    @Test
    void mapLoanInRequestIsNotInTheAccountsSoNotSelected() {
        // Not that this scenario can happen realisticaly becasue there is a functional validation
        // y the application process but anyway...
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();

        var dealsRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealsRequest, "3R", 999);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("No", firstLoan.getSelected());

    }

    @Test
    void mapLoanInRequestIsInThgeAccountsSoWillBeSelected() {

        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();

        var dealsRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealsRequest, "3R", 1);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        var firstLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("Yes", firstLoan.getSelected());

    }

    @Test
    void mapTwoLoansInRequestTheTwoAreInTheAccountsSoWillBeSelected() {

        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataTwoLoans();

        var dealsRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealsRequest, "3R", 1);
        addLoanInDealsRequest(dealsRequest, "3R", 2);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var firstLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("Yes", firstLoan.getSelected());


        var secondLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(1);
        assertEquals("Yes", secondLoan.getSelected());

    }

    @Test
    void mapTwoLoansInRequestNoneOfTheTwoAreInTheAccountsSoWillBeSelected() {

        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataTwoLoans();

        var dealsRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealsRequest, "3R", 99);
        addLoanInDealsRequest(dealsRequest, "3R", 100);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var firstLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("No", firstLoan.getSelected());


        var secondLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(1);
        assertEquals("No", secondLoan.getSelected());

    }

    @Test
    void mapTwoLoansInRequestFirstOfTheTwoAreInTheAccountsSoWillBeSelected() {

        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataTwoLoans();

        var dealsRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealsRequest, "3R", 1);
        addLoanInDealsRequest(dealsRequest, "3R", 100);

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var firstLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(0);
        assertEquals("Yes", firstLoan.getSelected());


        var secondLoan = (PdfLoan) ((List<?>) map.get("currentLoans")).get(1);
        assertEquals("No", secondLoan.getSelected());

    }

    @Test
    void mapDiffSFORwithBOE() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var diffSFORwitBOE = ((String) map.get("diffSFORwithBoE"));
        assertEquals("0.22%", diffSFORwitBOE);
    }

    @Test
    void mapTotalBalanceOneLoan() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var diffSFORwitBOE = ((String) map.get("totalBalance"));
        assertEquals("£1,000.00", diffSFORwitBOE);
    }

    @Test
    void mapTotalBalanceTwoLoan() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataTwoLoans();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var diffSFORwitBOE = ((String) map.get("totalBalance"));
        assertEquals("£3,000.00", diffSFORwitBOE);
    }

    @Test
    void mapTotalMonthlyPaymentOneLoan() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var totalMonthlyPayment = ((String) map.get("totalMonthlyPayment"));
        assertEquals("£56.00", totalMonthlyPayment);
    }

    @Test
    void mapTotalMonthlyPaymentTwoLoans() {
        var dealsResponse = getDealsResponseOneProduct();
        var anmfData = getAnmfDataTwoLoans();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);


        var totalMonthlyPayment = ((String) map.get("totalMonthlyPayment"));
        assertEquals("£113.00", totalMonthlyPayment);
    }

    @Test
    void dealsResponseReturnedAEmptyList() {
        var dealsResponse = getDealsResponseEmptyList();
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        assertEquals("", map.get("bankOfEnglandRate"));

        var diffSFORwitBOE = ((String) map.get("diffSFORwithBoE"));
        assertEquals("", diffSFORwitBOE);
    }

    @Test
    void dealsResponseReturnedANullList() {
        var dealsResponse = getDealsResponseEmptyList();
        dealsResponse.setDeals(null);
        var anmfData = getAnmfDataOneLoan();
        var dealsRequest = createEmptyDealsRequest();

        var map = dataMapBuilder.build(dealsResponse, anmfData, dealsRequest);

        assertEquals("", map.get("bankOfEnglandRate"));

        var diffSFORwitBOE = ((String) map.get("diffSFORwithBoE"));
        assertEquals("", diffSFORwitBOE);
    }

    private DealsPdfAnmfDataFetcherOutput getAnmfDataTwoLoans() {
        var anmfData = getAnmfDataOneLoan();
        var secondActiveLoanDetails = getAnmfDataOneLoan().getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0);

        secondActiveLoanDetails.setOInterestRate(BigDecimal.valueOf(2.45));
        secondActiveLoanDetails.setOOutstandingBalance(BigDecimal.valueOf(2000));
        secondActiveLoanDetails.setOMonthlyPay(BigDecimal.valueOf(57));
        secondActiveLoanDetails.setOProductDesc("Other fixed product");
        secondActiveLoanDetails.setOLoanScheme("3R");
        secondActiveLoanDetails.setOApplSeqNo(2);

        anmfData.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(secondActiveLoanDetails);

        return anmfData;
    }

    private DealsPdfAnmfDataFetcherOutput getAnmfDataOneLoan() {
        var dealsPdfAnmfDataFetcherOutput = new DealsPdfAnmfDataFetcherOutput();
        AnmfAccountServiceResponse anmfAccountServiceResponse = new AnmfAccountServiceResponse();
        AccountServiceResponse accountServiceResponse = new AccountServiceResponse();
        Response response = new Response();
        OStruc oStruct = new OStruc();
        List<OActiveLoanDetail> activeLoansDetails = new ArrayList<>();
        OActiveLoanDetail activeLoan = new OActiveLoanDetail();
        activeLoan.setOInterestRate(BigDecimal.valueOf(1.45));
        activeLoan.setOOutstandingBalance(BigDecimal.valueOf(1000));
        activeLoan.setOMonthlyPay(BigDecimal.valueOf(56));
        activeLoan.setOProductDesc("Standard variable rate");
        activeLoan.setOLoanScheme("3R");
        activeLoan.setOApplSeqNo(1);
        activeLoansDetails.add(activeLoan);
        oStruct.setOActiveLoanDetails(activeLoansDetails);
        response.setOStruc(oStruct);
        accountServiceResponse.setResponse(response);
        anmfAccountServiceResponse.setAccountServiceResponse(accountServiceResponse);
        dealsPdfAnmfDataFetcherOutput.setAnmfAccountServiceResponse(anmfAccountServiceResponse);
        return dealsPdfAnmfDataFetcherOutput;
    }

    private DealsResponse getDealsResponseOneProduct() {
        var dealsResposne = new DealsResponse();
        var deals = new ArrayList<Deal>();
        var deal = new Deal();

        var product = new Product();
        product.setTerm("5 Year");
        product.setType("Fixed");
        product.setRate(new BigDecimal("1"));
        product.setProductFee(new BigDecimal(999));
        product.setAnnualOverpaymentAllowancePercentage(new BigDecimal(10));

        product.setBankOfEnglandRate(new BigDecimal("0.5"));
        product.setErcPercentage(new BigDecimal(3));
        product.setBankOfEnglandRateDifference(new BigDecimal("2.5"));
        product.setSantanderRevisionaryRate(new BigDecimal("0.72"));
        product.setReversionProduct("FOR");

        deal.setCalculations(new Calculations());
        deal.getCalculations().setMonthlyPaymentWithoutFee(new BigDecimal(95));
        deal.getCalculations().setMonthlyPaymentWithFee(new BigDecimal(101));

        ArrayList<DealLoanView> dealLoans = new ArrayList<>();
        DealLoanView dealLoanView = new DealLoanView();
        dealLoanView.setPreviousProduct("Standard variable rate at 7.5%");
        dealLoans.add(dealLoanView);

        deal.setProduct(product);
        deals.add(deal);
        dealsResposne.setDeals(deals);
        deal.setDealLoans(dealLoans);
        dealsResposne.setStepErcActive(true);

        return dealsResposne;
    }

    private DealsResponse getDealsResponseTwoProducts() {
        var dealsResponse = getDealsResponseOneProduct();

        // Second call again so is new product
        var secondDeals = getDealsResponseOneProduct().getDeals().get(0);
        secondDeals.getProduct().setTerm("2 Year");
        secondDeals.getProduct().setType("Tracker");
        secondDeals.getProduct().setReversionProduct("NA");
        dealsResponse.getDeals().add(secondDeals);
        return dealsResponse;
    }

    private DealsResponse getDealsResponseEmptyList() {
        var dealsResposne = new DealsResponse();
        var deals = new ArrayList<Deal>();
        dealsResposne.setDeals(deals);
        return dealsResposne;
    }
}

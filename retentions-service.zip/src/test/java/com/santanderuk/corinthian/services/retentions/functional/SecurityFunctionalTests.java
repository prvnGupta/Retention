package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;

@ActiveProfiles("test")
public class SecurityFunctionalTests extends FunctionalTest {

    String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    String jwtWithNoCustomer = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";

    String accountInfoUrl;
    Header header = new Header("authorization", jwtWithCustomer554);
    int accountNumber;
    String regularUrl;

    private String availableDatesUrl;
    private String directDebitUrl;

    @BeforeEach
    public void setup() {
        accountNumber = 123456789;
        accountInfoUrl = String.format("http://localhost:%s/accounts-service/account/{account}", serverPort);
        regularUrl = String.format("http://localhost:%s/accounts-service/account/{account}/regular-instruction", serverPort);
        availableDatesUrl = String.format("http://localhost:%s/accounts-service/account/{account}/regular-instruction/available-dates", serverPort);
        directDebitUrl = String.format("http://localhost:%s/accounts-service/account/{account}/direct-debit", serverPort);

    }


    @Test
    public void corsAcceptedDomainTest() {

        int accountNumber = 123456;
        String eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductCompletionDate("/product/completion-date-success-response.json");
        stubShortestChargeEndDate();
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                header("Origin", "http://localhost:4200").
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200);

    }


    @Test
    public void corsNotAcceptedDomainTest() {

        int accountNumber = 123456;
        String eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductCompletionDate("/product/completion-date-success-response.json");
        stubShortestChargeEndDate();
        stubODMCoreEligibility("/odm/response-eligible-account.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                header("Origin", "taherah.hacker.com").
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(403);

    }

    private String replaceAccountNumber(String url, int accountNumber) {
        return url.replaceAll("\\{account}", Integer.toString(accountNumber));
    }
}

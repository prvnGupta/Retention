package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.OutputStructure;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.PropertyEnquiryResponse;
import com.santanderuk.corinthian.services.retentions.api.mapper.AnmfClientMapper;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.AnmfCoreResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class AnmfCoreResponseBuilderTest {

    @Mock
    AnmfClientMapper mockAnmfClientMapper;

    AnmfCoreResponseBuilder builder;

    @BeforeEach
    void setUp() {
        builder = new AnmfCoreResponseBuilder(mockAnmfClientMapper);
    }

    @Test
    public void testWeBuildANMFCoreResponseWhenArrears() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = buildAnmfAccountInfoResponseWithArreas();
        ANMFPropertyResponse anmfAddressResponse = buildAnmfAddressResponse("Y");

        AnmfCoreResponse actualResponse = builder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);

        assertTrue(actualResponse.isCustomerOnArrears());
    }

    @Test
    public void testWeBuildANMFCoreResponseWhenWithReceivableBalanceArrears() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = buildAnmfAccountInfoResponseWithOnlyReceivableArreas(new BigDecimal("13.13"), new BigDecimal("0.0"));
        ANMFPropertyResponse anmfAddressResponse = buildAnmfAddressResponse("Y");

        AnmfCoreResponse actualResponse = builder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);

        assertTrue(actualResponse.isCustomerOnArrears());
    }

    @Test
    public void testWeBuildANMFCoreResponseWhenWithSundriesReceivableBalanceArrears() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = buildAnmfAccountInfoResponseWithOnlyReceivableArreas(new BigDecimal("0.0"), new BigDecimal("22.22"));
        ANMFPropertyResponse anmfAddressResponse = buildAnmfAddressResponse("Y");

        AnmfCoreResponse actualResponse = builder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);

        assertTrue(actualResponse.isCustomerOnArrears());
    }

    @Test
    public void testWeBuildANMFCoreResponseWhenNotArrears() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = buildAnmfAccountInfoResponse();
        ANMFPropertyResponse anmfAddressResponse = buildAnmfAddressResponse("Y");

        AnmfCoreResponse actualResponse = builder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);

        assertFalse(actualResponse.isCustomerOnArrears());
    }

    @Test
    public void testWeBuildANMFCoreResponseWhenConsentToLet() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = buildAnmfAccountInfoResponse();
        ANMFPropertyResponse anmfAddressResponse = buildAnmfAddressResponse("Y");

        AnmfCoreResponse actualResponse = builder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);

        assertTrue(actualResponse.isBuyToLet());
        assertTrue(actualResponse.isConsentToLet());

    }

    @Test
    public void testWeBuildANMFCoreResponseWhenNotConsentToLet() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = buildAnmfAccountInfoResponse();
        ANMFPropertyResponse anmfAddressResponse = buildAnmfAddressResponse("N");

        AnmfCoreResponse actualResponse = builder.buildAnmfCoreResponse(anmfAccountServiceResponse, anmfAddressResponse);

        assertTrue(actualResponse.isBuyToLet());
        assertFalse(actualResponse.isConsentToLet());

    }

    private ANMFPropertyResponse buildAnmfAddressResponse(String consentToLet) {

        OutputStructure oStruc = new OutputStructure();
        oStruc.setOSpecialPurchase("L");
        oStruc.setOConsentToLet(consentToLet);

        PropertyEnquiryResponse propertyEnquiryResponse = new PropertyEnquiryResponse();
        propertyEnquiryResponse.setOutputStructure(oStruc);

        ANMFPropertyResponse anmfAddressResponse = new ANMFPropertyResponse();
        anmfAddressResponse.setPropertyEnquiryResponse(propertyEnquiryResponse);

        return anmfAddressResponse;
    }

    private AnmfAccountServiceResponse buildAnmfAccountInfoResponse() {

        OStruc oStruc = new OStruc();
        oStruc.setOArrearsBalance(new BigDecimal("0.00"));
        oStruc.setORecBalance(new BigDecimal("0.00"));
        oStruc.setOSundriesArrears(new BigDecimal("0.00"));
        oStruc.setOSundriesRec(new BigDecimal("0.00"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse response = new AnmfAccountServiceResponse();
        response.setAccountServiceResponse(accountServiceResponse);

        return response;
    }

    private AnmfAccountServiceResponse buildAnmfAccountInfoResponseWithArreas() {
        OStruc oStruc = new OStruc();
        oStruc.setOArrearsBalance(new BigDecimal("12.12"));
        oStruc.setORecBalance(new BigDecimal("13.13"));
        oStruc.setOSundriesArrears(new BigDecimal("14.14"));
        oStruc.setOSundriesRec(new BigDecimal("15.15"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse response = new AnmfAccountServiceResponse();
        response.setAccountServiceResponse(accountServiceResponse);

        return response;
    }

    private AnmfAccountServiceResponse buildAnmfAccountInfoResponseWithOnlyReceivableArreas(BigDecimal recBalance, BigDecimal sundriesRec) {
        OStruc oStruc = new OStruc();
        oStruc.setOArrearsBalance(new BigDecimal("0"));
        oStruc.setORecBalance(recBalance);
        oStruc.setOSundriesArrears(new BigDecimal("0"));
        oStruc.setOSundriesRec(sundriesRec);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse response = new AnmfAccountServiceResponse();
        response.setAccountServiceResponse(accountServiceResponse);

        return response;
    }
}

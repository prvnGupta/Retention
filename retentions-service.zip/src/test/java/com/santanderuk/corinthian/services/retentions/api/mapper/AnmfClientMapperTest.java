package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.commons.mappers.anmf.LoanPartToViewMapper;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

@ExtendWith(MockitoExtension.class)
class AnmfClientMapperTest {

    @Spy
    private LoanPartToViewMapper loanPartToViewMapper;

    AnmfClientMapper anmfClientMapper;

    @BeforeEach
    public void setUp() {
        anmfClientMapper = new AnmfClientMapper(loanPartToViewMapper);
    }

    @Test
    public void checkWeCreateAValidAnmfCoreResponse() {

        List<OActiveLoanDetail> loansList = new ArrayList<>();
        OActiveLoanDetail loan1 = new OActiveLoanDetail();
        loan1.setOLoanId(5);
        loan1.setOCapitalBalance(new BigDecimal("1024.92"));
        loan1.setORepaymentType("R");
        loan1.setORemainingInstlm(20);
        loan1.setOProductDesc("STANDARD VARIABLE RATE");
        loan1.setOLoanScheme("3R");
        loan1.setOMonthlyPay(new BigDecimal("1000"));
        loan1.setOInterestRate(new BigDecimal("4.79"));
        ORevisionaryDetails oRevisionaryDetails1 = new ORevisionaryDetails();
        oRevisionaryDetails1.setOReviInterestRate(new BigDecimal("4.00"));
        loan1.setORevisionaryDetails(oRevisionaryDetails1);
        loan1.setOApplSeqNo(1);
        OErcDetailsGrp oErcDetailsGrp = new OErcDetailsGrp();
        oErcDetailsGrp.setOErcAllowPerc("10.0%");
        oErcDetailsGrp.setORdmStmErc(new BigDecimal("123.00"));
        loan1.setOErcDetailsGrp(oErcDetailsGrp);
        loan1.setOBaseRateDiff(new BigDecimal("0.0007"));
        loansList.add(loan1);

        OActiveLoanDetail loan2 = new OActiveLoanDetail();
        loan2.setOLoanId(6);
        loan2.setOCapitalBalance(new BigDecimal("50.00"));
        loan2.setORepaymentType("I");
        loan2.setORemainingInstlm(20);
        loan2.setOProductDesc("2 YEAR FIXED");
        loan2.setOLoanScheme("3R");
        loan2.setOMonthlyPay(new BigDecimal("1000"));
        loan2.setOInterestRate(new BigDecimal("3.79"));
        ORevisionaryDetails oRevisionaryDetails2 = new ORevisionaryDetails();
        oRevisionaryDetails2.setOReviInterestRate(new BigDecimal("3.00"));
        loan2.setORevisionaryDetails(oRevisionaryDetails2);
        loan2.setOApplSeqNo(2);
        OErcDetailsGrp oErcDetailsGrp2 = new OErcDetailsGrp();
        oErcDetailsGrp2.setOErcAllowPerc("1.00%");
        oErcDetailsGrp2.setOErcApplFlag("N");
        oErcDetailsGrp2.setORdmStmErc(new BigDecimal("123.01"));
        loan2.setOErcDetailsGrp(oErcDetailsGrp2);
        loan2.setOBaseRateDiff(new BigDecimal("0.0008"));
        loansList.add(loan2);

        OActiveLoanDetail loan3 = new OActiveLoanDetail();
        loan3.setOCapitalBalance(new BigDecimal("50.00"));
        loan3.setORepaymentType("I");
        loan3.setORemainingInstlm(20);
        loan3.setOProductDesc("2 YEAR FIXED");
        loan3.setOLoanScheme("3R");
        loan3.setOMonthlyPay(new BigDecimal("1000"));
        loan3.setOInterestRate(new BigDecimal("3.79"));
        ORevisionaryDetails oRevisionaryDetails3 = new ORevisionaryDetails();
        oRevisionaryDetails3.setOReviInterestRate(new BigDecimal("3.00"));
        loan3.setORevisionaryDetails(oRevisionaryDetails3);
        loan3.setOApplSeqNo(2);

        OErcDetailsGrp oErcDetailsGrp3 = new OErcDetailsGrp();
        oErcDetailsGrp3.setOErcAllowPerc("NOT_APPLICABLE");
        oErcDetailsGrp3.setOErcApplFlag("Y");
        oErcDetailsGrp3.setORdmStmErc(new BigDecimal("123.02"));
        loan3.setOErcDetailsGrp(oErcDetailsGrp3);

        loansList.add(loan3);


        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan1.setOApplSeqNo(1);
        activeLoan1.setOLoanSch("3R");
        activeLoan1.setOLoanId(5);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan2 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan2.setOApplSeqNo(2);
        activeLoan2.setOLoanSch("3R");
        activeLoan2.setOLoanId(6);

        ArrayList<com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan> oActiveLoans = new ArrayList<>();
        oActiveLoans.add(activeLoan1);
        oActiveLoans.add(activeLoan2);

        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoanDetails(loansList);
        oStruc.setOActiveLoans(oActiveLoans);
        oStruc.setOCapitalBalance(new BigDecimal("3345.45"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse anmfResponse = new AnmfAccountServiceResponse();
        anmfResponse.setAccountServiceResponse(accountServiceResponse);

        List<Loan> response = anmfClientMapper.toLoans(anmfResponse);
        assertThat(response.size(), equalTo(3));

        Loan loanOne = response.get(0);
        Loan loanTwo = response.get(1);
        Loan loanThree = response.get(2);

        assertThat(loanOne.isOnReversionRate(), equalTo(true));
        assertThat(loanOne.getLoanBalance(), equalTo(new BigDecimal("1024.92")));
        assertThat(loanOne.getProductDescription(), equalTo("Standard Variable Rate"));
        assertThat(loanOne.getLoanId(), equalTo(5));
        assertThat(loanOne.getScheme(), equalTo("3R"));
        assertThat(loanOne.getSequenceNumber(), equalTo(1));
        assertThat(loanOne.getMonthlyPayment(), equalTo(new BigDecimal(1000)));
        assertThat(loanOne.getInterestRate(), equalTo(new BigDecimal("4.79")));
        assertThat(loanOne.getFollowOnRate(), equalTo(new BigDecimal("4.00")));
        assertThat(loanOne.getAnnualOverpaymentAllowance(), equalTo(new BigDecimal("10.00")));
        assertThat(loanOne.getEarlyRepaymentChargeAsAmount(), equalTo(new BigDecimal("123.00")));
        assertThat(loanOne.getBaseRateDifference(), equalTo(new BigDecimal("0.0007")));

        assertThat(loanTwo.isOnReversionRate(), equalTo(true));
        assertThat(loanTwo.getLoanBalance(), equalTo(new BigDecimal("50.00")));
        assertThat(loanTwo.getProductDescription(), equalTo("2 Year Fixed"));
        assertThat(loanTwo.getLoanId(), equalTo(6));
        assertThat(loanTwo.getScheme(), equalTo("3R"));
        assertThat(loanTwo.getSequenceNumber(), equalTo(2));
        assertThat(loanTwo.getMonthlyPayment(), equalTo(new BigDecimal(1000)));
        assertThat(loanTwo.getInterestRate(), equalTo(new BigDecimal("3.79")));
        assertThat(loanTwo.getFollowOnRate(), equalTo(new BigDecimal("3.00")));
        assertThat(loanTwo.getAnnualOverpaymentAllowance(), equalTo(new BigDecimal("1.00")));
        assertThat(loanTwo.getEarlyRepaymentChargeAsAmount(), equalTo(new BigDecimal("123.01")));
        assertThat(loanTwo.getBaseRateDifference(), equalTo(new BigDecimal("0.0008")));

        assertThat(loanThree.isOnReversionRate(), equalTo(false));
        assertThat(loanThree.getAnnualOverpaymentAllowance(), equalTo(new BigDecimal("0.00")));
        assertThat(loanThree.getEarlyRepaymentChargeAsAmount(), equalTo(new BigDecimal("123.02")));
    }

    @Test
    public void checkWeCreateAValidAnmfCoreResponseLoanWithAMethodThatTakesOnlyOneOne() {

        List<OActiveLoanDetail> activeLoanDetailsList = new ArrayList<>();
        OActiveLoanDetail activeLoanDetail = new OActiveLoanDetail();
        activeLoanDetail.setOLoanId(5);
        activeLoanDetail.setOCapitalBalance(new BigDecimal("1024.92"));
        activeLoanDetail.setORepaymentType("R");
        activeLoanDetail.setORemainingInstlm(20);
        activeLoanDetail.setOProductDesc("STANDARD VARIABLE RATE");
        activeLoanDetail.setOLoanScheme("3R");
        activeLoanDetail.setOMonthlyPay(new BigDecimal("1000"));
        activeLoanDetail.setOInterestRate(new BigDecimal("4.79"));
        ORevisionaryDetails oRevisionaryDetails1 = new ORevisionaryDetails();
        oRevisionaryDetails1.setOReviInterestRate(new BigDecimal("4.00"));
        activeLoanDetail.setORevisionaryDetails(oRevisionaryDetails1);
        activeLoanDetail.setOApplSeqNo(1);

        OErcDetailsGrp oErcDetailsGrp = new OErcDetailsGrp();
        oErcDetailsGrp.setOErcAllowPerc("10.0%");
        oErcDetailsGrp.setORdmStmErc(new BigDecimal("123.00"));
        activeLoanDetail.setOErcDetailsGrp(oErcDetailsGrp);

        activeLoanDetail.setOBaseRateDiff(new BigDecimal("0.0007"));
        activeLoanDetailsList.add(activeLoanDetail);


        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan.setOApplSeqNo(1);
        activeLoan.setOLoanSch("3R");
        activeLoan.setOLoanId(5);

        ArrayList<com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan> oActiveLoans = new ArrayList<>();
        oActiveLoans.add(activeLoan);

        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoanDetails(activeLoanDetailsList);
        oStruc.setOActiveLoans(oActiveLoans);
        oStruc.setOCapitalBalance(new BigDecimal("3345.45"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse anmfResponse = new AnmfAccountServiceResponse();
        anmfResponse.setAccountServiceResponse(accountServiceResponse);

        Loan response = anmfClientMapper.toLoan(activeLoanDetail);


        assertThat(response.isOnReversionRate(), equalTo(true));
        assertThat(response.getLoanBalance(), equalTo(new BigDecimal("1024.92")));
        assertThat(response.getProductDescription(), equalTo("Standard Variable Rate"));
        assertThat(response.getLoanId(), equalTo(5));
        assertThat(response.getScheme(), equalTo("3R"));
        assertThat(response.getSequenceNumber(), equalTo(1));
        assertThat(response.getMonthlyPayment(), equalTo(new BigDecimal(1000)));
        assertThat(response.getInterestRate(), equalTo(new BigDecimal("4.79")));
        assertThat(response.getFollowOnRate(), equalTo(new BigDecimal("4.00")));
        assertThat(response.getAnnualOverpaymentAllowance(), equalTo(new BigDecimal("10.00")));
        assertThat(response.getEarlyRepaymentChargeAsAmount(), equalTo(new BigDecimal("123.00")));
        assertThat(response.getBaseRateDifference(), equalTo(new BigDecimal("0.0007")));
    }

    @Test
    public void checkWeCreateAValidAnmfCoreResponse3DecimalsInInterest() {

        List<OActiveLoanDetail> loansList = new ArrayList<>();
        OActiveLoanDetail loan1 = new OActiveLoanDetail();
        loan1.setOCapitalBalance(new BigDecimal("1024.92"));
        loan1.setORepaymentType("R");
        loan1.setORemainingInstlm(20);
        loan1.setOProductDesc("STANDARD VARIABLE RATE");
        loan1.setOLoanScheme("3R");
        loan1.setOMonthlyPay(new BigDecimal("1000"));
        loan1.setOInterestRate(new BigDecimal("0.001")); // <-----------------------
        ORevisionaryDetails oRevisionaryDetails1 = new ORevisionaryDetails();
        oRevisionaryDetails1.setOReviInterestRate(new BigDecimal("0.002"));
        loan1.setORevisionaryDetails(oRevisionaryDetails1);
        loan1.setOApplSeqNo(1);

        OErcDetailsGrp oErcDetailsGrp = new OErcDetailsGrp();
        oErcDetailsGrp.setOErcAllowPerc("10.0%");
        oErcDetailsGrp.setORdmStmErc(new BigDecimal("123.00"));
        loan1.setOErcDetailsGrp(oErcDetailsGrp);

        loansList.add(loan1);

        OActiveLoanDetail loan2 = new OActiveLoanDetail();
        loan2.setOCapitalBalance(new BigDecimal("50.00"));
        loan2.setORepaymentType("I");
        loan2.setORemainingInstlm(20);
        loan2.setOProductDesc("2 YEAR FIXED");
        loan2.setOLoanScheme("3R");
        loan2.setOMonthlyPay(new BigDecimal("1000"));
        loan2.setOInterestRate(new BigDecimal("0.003")); // <-----------------------
        ORevisionaryDetails oRevisionaryDetails2 = new ORevisionaryDetails();
        oRevisionaryDetails2.setOReviInterestRate(new BigDecimal("0.004"));
        loan2.setORevisionaryDetails(oRevisionaryDetails2);
        loan2.setOApplSeqNo(2);

        OErcDetailsGrp oErcDetailsGrp2 = new OErcDetailsGrp();
        oErcDetailsGrp2.setOErcAllowPerc("1.00%");
        oErcDetailsGrp2.setOErcApplFlag("N");
        oErcDetailsGrp2.setORdmStmErc(new BigDecimal("123.01"));
        loan2.setOErcDetailsGrp(oErcDetailsGrp2);

        loansList.add(loan2);

        /////////////////////////////
        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan1.setOApplSeqNo(1);
        activeLoan1.setOLoanSch("3R");
        activeLoan1.setOLoanId(5);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan2 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan2.setOApplSeqNo(2);
        activeLoan2.setOLoanSch("3R");
        activeLoan2.setOLoanId(6);

        ArrayList<com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan> oActiveLoans = new ArrayList<>();
        oActiveLoans.add(activeLoan1);
        oActiveLoans.add(activeLoan2);

        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoanDetails(loansList);
        oStruc.setOActiveLoans(oActiveLoans);
        oStruc.setOCapitalBalance(new BigDecimal("3345.45"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse anmfResponse = new AnmfAccountServiceResponse();
        anmfResponse.setAccountServiceResponse(accountServiceResponse);

        List<Loan> response = anmfClientMapper.toLoans(anmfResponse);
        assertThat(response.size(), equalTo(2));

        Loan loanOne = response.get(0);
        Loan loanTwo = response.get(1);

        assertThat(loanOne.getInterestRate(), equalTo(new BigDecimal("0.001")));
        assertThat(loanOne.getFollowOnRate(), equalTo(new BigDecimal("0.002")));

        assertThat(loanTwo.getInterestRate(), equalTo(new BigDecimal("0.003")));
        assertThat(loanTwo.getFollowOnRate(), equalTo(new BigDecimal("0.004")));
    }

    @Test
    public void checkWeCreateAValidAnmfCoreResponse4DecimalsInInterest() {

        List<OActiveLoanDetail> loansList = new ArrayList<>();
        OActiveLoanDetail loan1 = new OActiveLoanDetail();
        loan1.setOCapitalBalance(new BigDecimal("1024.92"));
        loan1.setORepaymentType("R");
        loan1.setORemainingInstlm(20);
        loan1.setOProductDesc("STANDARD VARIABLE RATE");
        loan1.setOLoanScheme("3R");
        loan1.setOMonthlyPay(new BigDecimal("1000"));
        loan1.setOInterestRate(new BigDecimal("0.0001")); // <-----------------------
        ORevisionaryDetails oRevisionaryDetails1 = new ORevisionaryDetails();
        oRevisionaryDetails1.setOReviInterestRate(new BigDecimal("0.0002"));
        loan1.setORevisionaryDetails(oRevisionaryDetails1);
        loan1.setOApplSeqNo(1);

        OErcDetailsGrp oErcDetailsGrp = new OErcDetailsGrp();
        oErcDetailsGrp.setOErcAllowPerc("10.0%");
        oErcDetailsGrp.setORdmStmErc(new BigDecimal("123.00"));
        loan1.setOErcDetailsGrp(oErcDetailsGrp);

        loansList.add(loan1);

        OActiveLoanDetail loan2 = new OActiveLoanDetail();
        loan2.setOCapitalBalance(new BigDecimal("50.00"));
        loan2.setORepaymentType("I");
        loan2.setORemainingInstlm(20);
        loan2.setOProductDesc("2 YEAR FIXED");
        loan2.setOLoanScheme("3R");
        loan2.setOMonthlyPay(new BigDecimal("1000"));
        loan2.setOInterestRate(new BigDecimal("0.0003")); // <-----------------------
        ORevisionaryDetails oRevisionaryDetails2 = new ORevisionaryDetails();
        oRevisionaryDetails2.setOReviInterestRate(new BigDecimal("0.0004"));
        loan2.setORevisionaryDetails(oRevisionaryDetails2);
        loan2.setOApplSeqNo(2);
        OErcDetailsGrp oErcDetailsGrp2 = new OErcDetailsGrp();
        oErcDetailsGrp2.setOErcAllowPerc("1.00%");
        oErcDetailsGrp2.setOErcApplFlag("N");
        oErcDetailsGrp2.setORdmStmErc(new BigDecimal("123.01"));
        loan2.setOErcDetailsGrp(oErcDetailsGrp2);
        loansList.add(loan2);
        /////////////////////////////

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan1.setOApplSeqNo(1);
        activeLoan1.setOLoanSch("3R");
        activeLoan1.setOLoanId(5);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan activeLoan2 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan();
        activeLoan2.setOApplSeqNo(2);
        activeLoan2.setOLoanSch("3R");
        activeLoan2.setOLoanId(6);

        ArrayList<com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan> oActiveLoans = new ArrayList<>();
        oActiveLoans.add(activeLoan1);
        oActiveLoans.add(activeLoan2);

        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoanDetails(loansList);
        oStruc.setOActiveLoans(oActiveLoans);
        oStruc.setOCapitalBalance(new BigDecimal("3345.45"));

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response response1 = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response();
        response1.setOStruc(oStruc);

        com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse accountServiceResponse = new com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse();
        accountServiceResponse.setResponse(response1);

        AnmfAccountServiceResponse anmfResponse = new AnmfAccountServiceResponse();
        anmfResponse.setAccountServiceResponse(accountServiceResponse);

        List<Loan> response = anmfClientMapper.toLoans(anmfResponse);
        assertThat(response.size(), equalTo(2));

        Loan loanOne = response.get(0);
        Loan loanTwo = response.get(1);

        assertThat(loanOne.getInterestRate(), equalTo(new BigDecimal("0.0001")));
        assertThat(loanOne.getFollowOnRate(), equalTo(new BigDecimal("0.0002")));

        assertThat(loanTwo.getInterestRate(), equalTo(new BigDecimal("0.0003")));
        assertThat(loanTwo.getFollowOnRate(), equalTo(new BigDecimal("0.0004")));
    }
}

package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoan;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

public class CoreRetentionMapperAccountLoanTest extends CoreRetentionMapperTestBase {

    @Test
    public void testCouldntFindLoanIdInAnmfResponse() {
        CoreRetentionsData input = generateDefaultMapperInput();
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoans().get(0).setOLoanSch("ZZZ");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(0).getPartId());
    }

    @Test
    public void mapLoandID() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getPartId());
        assertEquals("3T", coreRetentionRequest.getAccount().getLoans().get(0).getLoanScheme());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getSequenceNumber());
    }

    @Test
    public void mapLandIDTwoLoans() {
        CoreRetentionsData input = generateDefaultMapperInput();
        OActiveLoan secondActiveLoan = new OActiveLoan();
        secondActiveLoan.setOLoanId(2);
        secondActiveLoan.setOLoanSch("3T");
        secondActiveLoan.setOApplSeqNo(2);
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoans().add(secondActiveLoan);

        OActiveLoanDetail secondLoan = generateDefaultLoan();
        secondLoan.setOLoanScheme("3T");
        secondLoan.setOApplSeqNo(2);
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(secondLoan);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getPartId());
        assertEquals("3T", coreRetentionRequest.getAccount().getLoans().get(0).getLoanScheme());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getSequenceNumber());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getPartId());
        assertEquals("3T", coreRetentionRequest.getAccount().getLoans().get(1).getLoanScheme());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getSequenceNumber());
    }


    @Test
    public void mapProductType() throws IOException {
        CoreRetentionsData input = generateDefaultMapperInputTwo();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(4, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals("F", coreRetentionRequest.getAccount().getLoans().get(0).getProductType());
        assertEquals("A", coreRetentionRequest.getAccount().getLoans().get(1).getProductType());
        assertEquals("F", coreRetentionRequest.getAccount().getLoans().get(2).getProductType());
        assertEquals("A", coreRetentionRequest.getAccount().getLoans().get(3).getProductType());
    }

    @Test
    public void mapProductCodeOneLoan() {
        CoreRetentionsData input = generateDefaultMapperInput();
        // This product will be change to the one comming in the request in newProductDetails
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setOProductCode("PR05");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);
        // This PR000 is coming from newProductDetails
        assertEquals("PR00", coreRetentionRequest.getAccount().getLoans().get(0).getProductCode());
    }

    @Test
    public void mapProductCodeTwoLoansOnlyOneSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // This is the new selected product
        input.getCaseRequest().setProductCode("PR05");

        OActiveLoanDetail secondLoan = generateDefaultLoan();
        secondLoan.setOLoanScheme("3T");
        secondLoan.setOApplSeqNo(2);
        secondLoan.setOProductCode("PR01");
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(secondLoan);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());

        // PR0005 becasuse that one is the
        Loan loanOne = coreRetentionRequest.getAccount().getLoans().get(0);
        Loan loanTwo = coreRetentionRequest.getAccount().getLoans().get(1);

        assertEquals("PR05", loanOne.getProductCode());
        assertEquals("PR01", loanTwo.getProductCode());
        assertThat(loanOne.isTransferring(), equalTo(true));
        assertThat(loanTwo.isTransferring(), equalTo(false));
    }

    @Test
    public void mapProductCodeTwoLoansTwoSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // We add another select loand to move
        LoanIdentifier secondLoanSelected = new LoanIdentifier();
        secondLoanSelected.setLoanScheme("3T");
        secondLoanSelected.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(secondLoanSelected);

        // This is the new selected product
        input.getCaseRequest().setProductCode("PR05");

        OActiveLoanDetail secondLoan = generateDefaultLoan();
        secondLoan.setOLoanScheme("3T");
        secondLoan.setOApplSeqNo(2);
        secondLoan.setOProductCode("PR01");
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(secondLoan);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());

        // PR0005 both of them becasue we add the new deals to both loans
        assertEquals("PR05", coreRetentionRequest.getAccount().getLoans().get(0).getProductCode());
        assertEquals("PR05", coreRetentionRequest.getAccount().getLoans().get(1).getProductCode());
    }

    @Test
    public void mapBalanceRequestAmount() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("1.00"), coreRetentionRequest.getAccount().getLoans().get(0).getBalanceRequestAmount());

        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setOCapitalBalance(new BigDecimal("23.23"));

        coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("23.23"), coreRetentionRequest.getAccount().getLoans().get(0).getBalanceRequestAmount());
    }

    @Test
    public void mapBalanceRequestAmountTwoLoans() {
        CoreRetentionsData input = generateDefaultMapperInput();

        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOCapitalBalance(new BigDecimal("2.00"));


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("1.00"), coreRetentionRequest.getAccount().getLoans().get(0).getBalanceRequestAmount());
        assertEquals(new BigDecimal("2.00"), coreRetentionRequest.getAccount().getLoans().get(1).getBalanceRequestAmount());

    }


    @Test
    public void mapRepaymentType1BecasueRepayment() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getRepaymentType());
    }

    @Test
    public void mapRepaymentType2BecasueInterestOnly() {
        CoreRetentionsData input = generateDefaultMapperInput();
        // Modify loan to INTEREST_ONLY
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORepaymentType("I");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(0).getRepaymentType());

    }

    @Test
    public void mapRepaymentTypeBothPossibleValues() {
        CoreRetentionsData input = generateDefaultMapperInput();
        // Add second loan with INTEREST_ONLY
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setORepaymentType("I");


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getRepaymentType());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getRepaymentType());
    }

    @Test
    public void mapCapitalRepaymentAmount() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("0.00"), coreRetentionRequest.getAccount().getLoans().get(0).getCapitalRepaymentAmt());
    }

    @Test
    public void mapCapitalrepaymentMade() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).isCapitalRepaymentMade());

    }

    @Test
    public void mapRepaymentTypeChange() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).isRepaymentTypeChanged());

    }

    @Test
    public void mapNewProduct() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertTrue(coreRetentionRequest.getAccount().getLoans().get(0).isNewProduct());

    }

    @Test
    public void mapLoanSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).isPortedLoan());

    }

    @Test
    public void mapNewProductMultiLoanFirstIsSelectedSecondIsNot() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // Add second loan that is not selected - that's why the 9
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOApplSeqNo(9);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertTrue(coreRetentionRequest.getAccount().getLoans().get(0).isNewProduct());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).isNewProduct());

    }

    @Test
    public void mapLoanPartChangedMultiLoanFirstIsSelectedSecondIsNot() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // Add second loan that is not selected - that's why the 9
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOApplSeqNo(9);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).isPortedLoan());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).isPortedLoan());

    }

    @Test
    public void mapNewProductMultiLoanBothLoansSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();
        // We add another select loan to move
        LoanIdentifier secondLoanSelected = new LoanIdentifier();
        secondLoanSelected.setLoanScheme("3T");
        secondLoanSelected.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(secondLoanSelected);

        // Add second loan that is selected
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOApplSeqNo(2);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertTrue(coreRetentionRequest.getAccount().getLoans().get(0).isNewProduct());
        assertTrue(coreRetentionRequest.getAccount().getLoans().get(1).isNewProduct());

    }

    @Test
    public void mapLoanPartChangeMultiLoanBothLoansSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();
        // We add another select loan to move
        LoanIdentifier secondLoanSelected = new LoanIdentifier();
        secondLoanSelected.setLoanScheme("3T");
        secondLoanSelected.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(secondLoanSelected);

        // Add second loan that is selected
        List<OActiveLoanDetail> oLoans = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        oLoans.add(generateDefaultLoan());
        oLoans.get(1).setOApplSeqNo(2);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).isPortedLoan());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).isPortedLoan());

    }

    @Test
    public void mapInterestRate() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("1.39"), coreRetentionRequest.getAccount().getLoans().get(0).getInterestRate());

    }

    @Test
    public void mapInterestRateMultiLoanOneSelectedOneNotSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();

        //Add second loan to mortgage. It wont be selected, so we expect to send its current interest rate
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        OActiveLoanDetail secondLoan = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1);
        secondLoan.setOInterestRate(new BigDecimal("2.22"));
        secondLoan.setOApplSeqNo(2);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("1.39"), coreRetentionRequest.getAccount().getLoans().get(0).getInterestRate());
        assertEquals(new BigDecimal("2.22"), coreRetentionRequest.getAccount().getLoans().get(1).getInterestRate());
    }

    @Test
    public void mapInterestRateMultiLoanTwoLoansSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();


        //Add second loan to mortgage. It will be selected, so we expect to send the new product interest rate
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        OActiveLoanDetail secondLoan = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1);
        secondLoan.setOInterestRate(new BigDecimal("2.22"));
        secondLoan.setOApplSeqNo(2);

        //add a second selected loan to request
        LoanIdentifier secondLoanSelected = new LoanIdentifier();
        secondLoanSelected.setLoanScheme("3T");
        secondLoanSelected.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(secondLoanSelected);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(new BigDecimal("1.39"), coreRetentionRequest.getAccount().getLoans().get(0).getInterestRate());
        assertEquals(new BigDecimal("1.39"), coreRetentionRequest.getAccount().getLoans().get(1).getInterestRate());
    }

    @Test
    public void mapTermOneLoanRemainingTerm1Month() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(1);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).getTerm().isChanged());
    }

    @Test
    public void mapTermOneLoanRemainingTerm12Months() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(12);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(12, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(12, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).getTerm().isChanged());
    }

    @Test
    public void mapTermOneLoanRemainingTerm13Months() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(13);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(13, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(13, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).getTerm().isChanged());
    }

    @Test
    public void mapTermOneLoanRemainingTerm24Months() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(24);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(24, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(24, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).getTerm().isChanged());
    }

    @Test
    public void mapTermOneLoanRemainingTerm25Months() {
        CoreRetentionsData input = generateDefaultMapperInput();

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(25);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(25, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(25, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(0).getTerm().isChanged());
    }


    @Test
    public void mapTermTwoLoansFirstSelectedSecondNo() {
        CoreRetentionsData input = generateDefaultMapperInput();
        //Add second loan to mortgage. It wont be selected, so we expect to send its current interest rate
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        OActiveLoanDetail secondLoan = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1);
        secondLoan.setORemainingInstlm(2);
        secondLoan.setOApplSeqNo(2);

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(1);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());

        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).getTerm().isChanged());

        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getYears());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getMonths());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getTermRemaining());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).getTerm().isChanged());

    }

    @Test
    public void mapTermTwoLoansBothSelected() {
        CoreRetentionsData input = generateDefaultMapperInput();
        //Add second loan to mortgage. It wont be selected, so we expect to send its current interest rate
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(generateDefaultLoan());
        OActiveLoanDetail secondLoan = input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1);
        secondLoan.setORemainingInstlm(2);
        secondLoan.setOApplSeqNo(2);

        // One month as remaining currentProductDescription
        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setORemainingInstlm(1);

        //add a second selected loan to request
        LoanIdentifier secondLoanSelected = new LoanIdentifier();
        secondLoanSelected.setLoanScheme("3T");
        secondLoanSelected.setSequenceNumber(2);
        input.getCaseRequest().getLoansSelected().add(secondLoanSelected);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(2, coreRetentionRequest.getAccount().getLoans().size());

        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getYears());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getMonths());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTermRemaining());
        assertEquals(1, coreRetentionRequest.getAccount().getLoans().get(0).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).getTerm().isChanged());

        assertEquals(0, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getYears());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getMonths());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getTermRemaining());
        assertEquals(2, coreRetentionRequest.getAccount().getLoans().get(1).getTerm().getTotalMonths());
        assertFalse(coreRetentionRequest.getAccount().getLoans().get(1).getTerm().isChanged());

    }

    @Test
    public void mapOriginalCompletionDate() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals("2019-08-28", coreRetentionRequest.getAccount().getLoans().get(0).getOriginalProductCompletionDate());
    }

    @Test
    public void mapOriginalCompletionDateIsLoanRedeptionDateBecauseANMFProductEndDateIsNull() {
        CoreRetentionsData input = generateDefaultMapperInput();

        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setOProductEndDate(null);

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals("2020-09-29", coreRetentionRequest.getAccount().getLoans().get(0).getOriginalProductCompletionDate());
    }

    @Test
    public void mapOriginalCompletionDateIsLoanRedemtionDateBecauseANMFProductEndDateIsEmpty() {
        CoreRetentionsData input = generateDefaultMapperInput();

        input.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0)
                .setOProductEndDate("");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(1, coreRetentionRequest.getAccount().getLoans().size());
        assertEquals("2020-09-29", coreRetentionRequest.getAccount().getLoans().get(0).getOriginalProductCompletionDate());
    }
}

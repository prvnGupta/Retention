package com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

public class GovernanceTypeTest {

    @Test
    public void testEnumByLabel() {
        assertSame(GovernanceType.FSA, GovernanceType.valueOfLabel("FSA"));
        assertSame(GovernanceType.CCA, GovernanceType.valueOfLabel("CCA"));
        assertSame(GovernanceType.UNREGULATED, GovernanceType.valueOfLabel("UNR"));
        assertSame(GovernanceType.PARTIALCCAREGULATED, GovernanceType.valueOfLabel("Partial CCA Regulated"));
    }

    @Test
    public void getCorrectIdFromLabel() {
        assertEquals("1", GovernanceType.valueOfLabel("FSA").id);
        assertEquals("2", GovernanceType.valueOfLabel("CCA").id);
        assertEquals("3", GovernanceType.valueOfLabel("UNR").id);
        assertEquals("5", GovernanceType.valueOfLabel("Partial CCA Regulated").id);
    }
}

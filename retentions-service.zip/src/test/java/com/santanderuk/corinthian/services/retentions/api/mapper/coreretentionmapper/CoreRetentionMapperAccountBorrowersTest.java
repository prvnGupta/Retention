package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CoreRetentionMapperAccountBorrowersTest extends CoreRetentionMapperTestBase {


    @Test
    public void testBorrowerOneBorrower() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        // Commented lines are because we are waiting for the new version of ANMMF Borrowers service
        Assertions.assertEquals(1, coreRetentionRequest.getAccount().getBorrowers().size());
        Assertions.assertTrue(coreRetentionRequest.getAccount().getBorrowers().get(0).isLeadCustomerInd());
        Assertions.assertEquals("Mr", coreRetentionRequest.getAccount().getBorrowers().get(0).getTitle());
        Assertions.assertEquals("JK", coreRetentionRequest.getAccount().getBorrowers().get(0).getInitials());
        Assertions.assertEquals("Forename1 Forename2 Forename3", coreRetentionRequest.getAccount().getBorrowers().get(0).getForename());
        Assertions.assertEquals("Surname", coreRetentionRequest.getAccount().getBorrowers().get(0).getSurname());
        Assertions.assertTrue(coreRetentionRequest.getAccount().getBorrowers().get(0).isStaffInd());
        Assertions.assertEquals("1976-12-02", coreRetentionRequest.getAccount().getBorrowers().get(0).getDateOfBirth());
        Assertions.assertEquals("F", coreRetentionRequest.getAccount().getBorrowers().get(0).getBdpCustomerType());
        Assertions.assertEquals("12345678", coreRetentionRequest.getAccount().getBorrowers().get(0).getBdpCustomerNumber());
        Assertions.assertEquals("02222111111", coreRetentionRequest.getAccount().getBorrowers().get(0).getHomeTelNumber());
        Assertions.assertEquals("c@c.com", coreRetentionRequest.getAccount().getBorrowers().get(0).getEmailAddress());
        Assertions.assertEquals("07777333333", coreRetentionRequest.getAccount().getBorrowers().get(0).getMobileTelNumber());


        Assertions.assertEquals("address1", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine1());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine2());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine3());
        Assertions.assertEquals("address2", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine4());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine5());
        Assertions.assertEquals("address3", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine6());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine7());
        Assertions.assertEquals("UNITED KINGDOM", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine8());
        Assertions.assertEquals("postcode", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine9());
        Assertions.assertEquals("postcode", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getPostcode());
        Assertions.assertFalse(coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().isCorrespondenceAddressChangedInd());

    }


    @Test
    public void testBorrowerOneBorrowerWithPostcodeEmpty() {

        CoreRetentionsData input = generateDefaultMapperInput();

        input.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).setOCorrespPostcode("");
        input.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).setOCorrespCountry("AFGHANISTAN");

        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        Assertions.assertEquals("AFGHANISTAN", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine8());

    }


    @Test
    public void testBorrowerTwoBorrowers() {
        CoreRetentionsData input = generateDefaultMapperInput();

        //Add second Borrower
        input.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().add(generateAdditionalBorrower(1));


        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        // Commented lines are because we are waiting for the new version of ANMMF Borrowers service
        Assertions.assertEquals(2, coreRetentionRequest.getAccount().getBorrowers().size());

        Assertions.assertTrue(coreRetentionRequest.getAccount().getBorrowers().get(0).isLeadCustomerInd());
        Assertions.assertEquals("Mr", coreRetentionRequest.getAccount().getBorrowers().get(0).getTitle());
        Assertions.assertEquals("JK", coreRetentionRequest.getAccount().getBorrowers().get(0).getInitials());
        Assertions.assertEquals("Forename1 Forename2 Forename3", coreRetentionRequest.getAccount().getBorrowers().get(0).getForename());
        Assertions.assertEquals("Surname", coreRetentionRequest.getAccount().getBorrowers().get(0).getSurname());
        Assertions.assertTrue(coreRetentionRequest.getAccount().getBorrowers().get(0).isStaffInd());
        Assertions.assertEquals("1976-12-02", coreRetentionRequest.getAccount().getBorrowers().get(0).getDateOfBirth());
        Assertions.assertEquals("F", coreRetentionRequest.getAccount().getBorrowers().get(0).getBdpCustomerType());
        Assertions.assertEquals("12345678", coreRetentionRequest.getAccount().getBorrowers().get(0).getBdpCustomerNumber());
        Assertions.assertEquals("02222111111", coreRetentionRequest.getAccount().getBorrowers().get(0).getHomeTelNumber());
        Assertions.assertEquals("c@c.com", coreRetentionRequest.getAccount().getBorrowers().get(0).getEmailAddress());
        Assertions.assertEquals("07777333333", coreRetentionRequest.getAccount().getBorrowers().get(0).getMobileTelNumber());
        Assertions.assertEquals("address1", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine1());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine2());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine3());
        Assertions.assertEquals("address2", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine4());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine5());
        Assertions.assertEquals("address3", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine6());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine7());
        Assertions.assertEquals("UNITED KINGDOM", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine8());
        Assertions.assertEquals("postcode", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getAddressLine9());
        Assertions.assertEquals("postcode", coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().getPostcode());
        Assertions.assertFalse(coreRetentionRequest.getAccount().getBorrowers().get(0).getBorrowerCorrespondenceAddress().isCorrespondenceAddressChangedInd());


        Assertions.assertFalse(coreRetentionRequest.getAccount().getBorrowers().get(1).isLeadCustomerInd());
        Assertions.assertEquals("Mr1", coreRetentionRequest.getAccount().getBorrowers().get(1).getTitle());
        Assertions.assertEquals("JK1", coreRetentionRequest.getAccount().getBorrowers().get(1).getInitials());
        Assertions.assertEquals("Forename11 Forename21 Forename31", coreRetentionRequest.getAccount().getBorrowers().get(1).getForename());
        Assertions.assertEquals("Surname1", coreRetentionRequest.getAccount().getBorrowers().get(1).getSurname());
        Assertions.assertFalse(coreRetentionRequest.getAccount().getBorrowers().get(1).isStaffInd());
        Assertions.assertEquals("1977-12-02", coreRetentionRequest.getAccount().getBorrowers().get(1).getDateOfBirth());
        Assertions.assertEquals("F1", coreRetentionRequest.getAccount().getBorrowers().get(1).getBdpCustomerType());
        Assertions.assertEquals("900000001", coreRetentionRequest.getAccount().getBorrowers().get(1).getBdpCustomerNumber());
        Assertions.assertEquals("02222222222", coreRetentionRequest.getAccount().getBorrowers().get(1).getHomeTelNumber());
        Assertions.assertEquals("b@b.com", coreRetentionRequest.getAccount().getBorrowers().get(1).getEmailAddress());
        Assertions.assertEquals("07777222222", coreRetentionRequest.getAccount().getBorrowers().get(1).getMobileTelNumber());
        Assertions.assertEquals("2address1", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine1());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine2());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine3());
        Assertions.assertEquals("2address2", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine4());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine5());
        Assertions.assertEquals("2address3", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine6());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine7());
        Assertions.assertEquals("UNITED KINGDOM", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine8());
        Assertions.assertEquals("2postcode", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getAddressLine9());
        Assertions.assertEquals("2postcode", coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().getPostcode());
        Assertions.assertFalse(coreRetentionRequest.getAccount().getBorrowers().get(1).getBorrowerCorrespondenceAddress().isCorrespondenceAddressChangedInd());
    }

    @Test
    public void testEmptyMobileNumberFromFrontEndDoesMapEmptyMobileToCoreRetentions() {
        CoreRetentionsData input = generateDefaultMapperInput();
        input.getCaseRequest().setMobileNumber("");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        Assertions.assertEquals("c@c.com", coreRetentionRequest.getAccount().getBorrowers().get(0).getEmailAddress());
        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getMobileTelNumber());

    }

    @Test
    public void testNullMobileNumberFromFrontEndDoesMapEmptyMobileToCoreRetentions() {
        CoreRetentionsData input = generateDefaultMapperInput();
        input.getCaseRequest().setMobileNumber(null);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        Assertions.assertEquals("", coreRetentionRequest.getAccount().getBorrowers().get(0).getMobileTelNumber());

    }

    @Test
    public void testEmptyEmailFromFrontEndDoesMapBorrowerServiceResponseEmailToCoreRetentions() {
        CoreRetentionsData input = generateDefaultMapperInput();
        input.getCaseRequest().setEmailAddress("");
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        Assertions.assertEquals("a@a.com", coreRetentionRequest.getAccount().getBorrowers().get(0).getEmailAddress());

    }

    @Test
    public void testNullEmailFromFrontEndDoesMapBorrowerServiceResponseEmailToCoreRetentions() {
        CoreRetentionsData input = generateDefaultMapperInput();
        input.getCaseRequest().setEmailAddress(null);
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        Assertions.assertEquals("a@a.com", coreRetentionRequest.getAccount().getBorrowers().get(0).getEmailAddress());

    }
}

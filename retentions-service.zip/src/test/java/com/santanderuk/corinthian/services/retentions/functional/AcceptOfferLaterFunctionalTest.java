package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class AcceptOfferLaterFunctionalTest extends FunctionalTest {

    private Header authorizationHeader;
    private Header contentType;
    private Header accept;
    private String acceptLaterEndpoint;

    public static final String DEFAULT_ESIS_ID = "esisrefid";

    @BeforeEach

    public void setUp() {
        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
        acceptLaterEndpoint = String.format("http://localhost:%s/retentions-service/%s/offer", serverPort, ACCOUNT_NUMBER);
    }

    @Test
    public void testWeReturn200FromController() {

        String esisRefId = "esis-ref-id";
        String caseId = "case-id-1234";

        // stubs
        stubRetrieveMcc();
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");
        stubProductSwitchAcceptLater(caseId, "/product-switch-service/accept-later-response.json");

        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, esisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                put(parameterisedUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"));
    }

    @Test
    public void testWeReturn401WhenCustomerFailsJwtValidation() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");

        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, esisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                put(parameterisedUrl).
                then().
                statusCode(401).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer"));
    }

    @Test
    public void testWeReturn400WhenEsisRefIdContainsSpecialCharacters() {

        String badEsisRefId = "esisref^id";
        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, badEsisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(parameterisedUrl).
                then().
                statusCode(400).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("ESIS_ID_BAD_FORMAT"),
                        "info.message", equalTo("esis_ref_id format is not valid"));
    }

    @Test
    public void testWeReturn500WhenProductSwitchServiceIsDown() {

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfoDown();

        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, DEFAULT_ESIS_ID);

        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(parameterisedUrl).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("PRODUCT_SWITCH_CONNECTION_ERROR"),
                        "info.message", equalTo("Exception while calling product switch service"));
    }

    @Test
    public void testWeReturn403WhenProductSwitchClientReturnsRowWithDifferentEsisRefId() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-mismatch-esis-ref-id-response.json");

        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, esisRefId);


        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(parameterisedUrl).
                then().
                statusCode(403).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("ESIS_REF_ID_NOT_MATCHING"),
                        "info.message", equalTo("esis ref id returned does not match request"));
    }

    @Test
    public void testWeReturn403WhenAccountIsForbiddenFromAccessingResource() {

        String esisRefId = "esis-ref-id";

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-mismatch-account-response.json");

        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, esisRefId);


        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(parameterisedUrl).
                then().
                statusCode(403).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("ACCOUNT_NOT_MATCHING"),
                        "info.message", equalTo("The account is not allowed to access this resource"));
    }

    @Test
    public void testWeReturn500WhenProductSwitchServiceIsDownForAcceptLaterCall() {

        String esisRefId = "esis-ref-id";
        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");
        stubProductSwitchAcceptLaterIsDown();

        String parameterisedUrl = String.format("%s/%s/accept-later", acceptLaterEndpoint, esisRefId);

        given().
                header(authorizationHeader).
                header(contentType).
                when().
                put(parameterisedUrl).
                then().
                statusCode(500).
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("PRODUCT_SWITCH_CONNECTION_ERROR"),
                        "info.message", equalTo("Exception while calling product switch service"));
    }
}

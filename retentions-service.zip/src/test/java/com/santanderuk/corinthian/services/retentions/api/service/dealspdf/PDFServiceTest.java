package com.santanderuk.corinthian.services.retentions.api.service.dealspdf;

import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.MortgageDealsClientException;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Calculations;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Deal;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.Product;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.pdfGeneration.PdfGenerator;
import com.santanderuk.corinthian.services.retentions.api.pdfGeneration.PdfGeneratorRequest;
import com.santanderuk.corinthian.services.retentions.api.pdfGeneration.Template;
import com.santanderuk.corinthian.services.retentions.api.service.deals.DealsService;
import com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation.DealsFunctionalValidationException;
import com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher.DealsPdfAnmfDataFetcher;
import com.santanderuk.corinthian.services.retentions.api.service.dealspdf.dealspdfanmfdatafetcher.DealsPdfAnmfDataFetcherOutput;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class PDFServiceTest {

    @Mock
    private PdfGenerator pdfGenerator;

    @Mock
    private DealsService dealsService;

    @Mock
    private DealsPdfAnmfDataFetcher dealsPdfAnmfDataFetcher;

    @Mock
    private DataMapBuilder dataMapBuilder;

    private PDFService pdfService;

    @BeforeEach
    void setUp() throws MaintenanceException, OperativeSecurityException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, ValidationsException, IOException {

        var dealsResponse = getDealsResponseOneProduct();
        mockDealsResponseWith(dealsResponse);

        var dealsPdfAnmfDataFetcherOutput = new DealsPdfAnmfDataFetcherOutput();
        mockDealsPdfAnmfDataFetcherWith(dealsPdfAnmfDataFetcherOutput);

        Map<String, Object> dataMap = new HashMap<>();
        mockDataMapBuilder(dataMap);

        mockPdfGeneratorWithText("This is the content we are writing inside");

        pdfService = new PDFService(pdfGenerator, dealsService, dealsPdfAnmfDataFetcher, dataMapBuilder);
    }

    @Test
    void callingDealsServiceProperly() throws GeneralException, IOException {

        var dealsResponse = getDealsResponseOneProduct();
        mockDealsResponseWith(dealsResponse);

        var account = 12345678;
        var dealsRequest = new DealsRequest();
        var jwtToken = "jwtToken";

        pdfService.createDealsPdf(jwtToken, account, dealsRequest);

        var accountCaptor = ArgumentCaptor.forClass(Integer.class);
        var dealsRequestCaptor = ArgumentCaptor.forClass(DealsRequest.class);
        var jwtTokenCaptor = ArgumentCaptor.forClass(String.class);

        verify(dealsService).get(accountCaptor.capture(), dealsRequestCaptor.capture(), jwtTokenCaptor.capture());

        assertEquals(account, accountCaptor.getValue());
        assertEquals(dealsRequest, dealsRequestCaptor.getValue());
        assertEquals(jwtToken, jwtTokenCaptor.getValue());

    }

    @Test
    void callDealsPdfAnmfFetcher() throws GeneralException, IOException {
        var dealsResponse = getDealsResponseOneProduct();
        mockDealsResponseWith(dealsResponse);

        var jwtToken = "jwtToken";

        pdfService.createDealsPdf(jwtToken, 12345678, new DealsRequest());

        var accountCaptor = ArgumentCaptor.forClass(Integer.class);
        verify(dealsPdfAnmfDataFetcher).fetch(accountCaptor.capture());

        assertEquals(12345678, accountCaptor.getValue());
    }

    @Test
    void callDataMapBuilder() throws GeneralException, IOException {
        var dealsResponse = getDealsResponseOneProduct();
        mockDealsResponseWith(dealsResponse);

        var dealsPdfAnmfDataFetcherOutput = new DealsPdfAnmfDataFetcherOutput();
        mockDealsPdfAnmfDataFetcherWith(dealsPdfAnmfDataFetcherOutput);

        var jwtToken = "jwtToken";

        pdfService.createDealsPdf(jwtToken, 12345678, new DealsRequest());


        var dealsResponseArgumentCaptor = ArgumentCaptor.forClass(DealsResponse.class);
        var dealsPdfAnmfDataFetcherOutputArgumentCaptor = ArgumentCaptor.forClass(DealsPdfAnmfDataFetcherOutput.class);
        var dealsRequestArgumentCaptor = ArgumentCaptor.forClass(DealsRequest.class);

        verify(dataMapBuilder).build(dealsResponseArgumentCaptor.capture(), dealsPdfAnmfDataFetcherOutputArgumentCaptor.capture(), dealsRequestArgumentCaptor.capture());

        assertSame(dealsResponse, dealsResponseArgumentCaptor.getValue());
        assertSame(dealsPdfAnmfDataFetcherOutput, dealsPdfAnmfDataFetcherOutputArgumentCaptor.getValue());
    }


    @Test
    void callPdfGenerator() throws GeneralException, IOException {

        Map<String, Object> dataMap = new HashMap<>();
        mockDataMapBuilder(dataMap);

        var jwtToken = "jwtToken";

        pdfService.createDealsPdf(jwtToken, 12345678, new DealsRequest());

        var pdfGeneratorRequestArgumentCaptor = ArgumentCaptor.forClass(PdfGeneratorRequest.class);

        verify(pdfGenerator).createPdf(pdfGeneratorRequestArgumentCaptor.capture());

        assertEquals(Template.DEALS, pdfGeneratorRequestArgumentCaptor.getValue().getTemplateName());
        assertSame(dataMap, pdfGeneratorRequestArgumentCaptor.getValue().getTemplateElements());
    }


    @Test
    void checkWeAreReturningTheProperInputStreamResource() throws GeneralException, IOException {
        var dealsResponse = getDealsResponseOneProduct();
        mockDealsResponseWith(dealsResponse);

        var dealsPdfAnmfDataFetcherOutput = new DealsPdfAnmfDataFetcherOutput();
        mockDealsPdfAnmfDataFetcherWith(dealsPdfAnmfDataFetcherOutput);

        Map<String, Object> dataMap = new HashMap<>();
        mockDataMapBuilder(dataMap);

        mockPdfGeneratorWithText("This is the content we are writing inside");

        var jwtToken = "jwtToken";

        var resource = pdfService.createDealsPdf(jwtToken, 12345678, new DealsRequest());

        var writer = new StringWriter();
        IOUtils.copy(resource.getInputStream(), writer, Charset.defaultCharset());
        var contents = writer.toString();
        assertTrue(contents.contains("his is the content we are writing inside"));
    }

    private void mockPdfGeneratorWithText(String string) throws IOException {
        var byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(string.getBytes());
        when(pdfGenerator.createPdf(any())).thenReturn(byteArrayOutputStream);
    }

    private void mockDataMapBuilder(Map<String, Object> dataMap) {
        when(dataMapBuilder.build(any(), any(), any())).thenReturn(dataMap);
    }

    private void mockDealsPdfAnmfDataFetcherWith(DealsPdfAnmfDataFetcherOutput dealsPdfAnmfDataFetcherOutput) throws ConnectionException, MaintenanceException {
        when(dealsPdfAnmfDataFetcher.fetch(anyInt())).thenReturn(dealsPdfAnmfDataFetcherOutput);
    }

//    @Test
//    @Disabled
//    public void testProductListForPdf() throws IOException, GeneralException, DocumentException {
//
//
//        int accountNumber = 57863562;
//        String jwtToken = "jwt-token";
//
//        DealsResponse dealsResponse = getDealsResponse();
//
//        LoanIdentifier loanIdentifier = getLoanIdentifier();
//
//        DealsRequest dealsRequest = new DealsRequest();
//        dealsRequest.setLoansSelected(Collections.singletonList(loanIdentifier));
//
//        EligibilityResponse eligibilityResponse = generateEligibilityRespose();
//
//        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//        byteArrayOutputStream.write("Your Mum".getBytes());
//
//        List<LoanIdentifier> loanIdentifierList = Collections.singletonList(loanIdentifier);
//
//        when(pdfGenerator.createPdf(pdfGeneratorRequestArgumentCaptor.capture())).thenReturn(byteArrayOutputStream);
//        when(config.getAnnualOverpaymentAllowance()).thenReturn("10.00");
//
//        InputStreamResource resource = pdfService.createDealsPdf(jwtToken, accountNumber, dealsRequest);
//
//        StringWriter writer = new StringWriter();
//        IOUtils.copy(resource.getInputStream(), writer, Charset.defaultCharset());
//        String contents = writer.toString();
//
//        List<PdfProduct> productsTable = (List<PdfProduct>) pdfGeneratorRequestArgumentCaptor.getValue().getTemplateElements().get("productsTable");
//
//        assertEquals("3%", productsTable.get(0).getErc());
//        assertEquals("10%", productsTable.get(0).getOverpaymentAllowance());
//        assertEquals("No charge", productsTable.get(1).getErc());
//        assertEquals("Unlimited", productsTable.get(1).getOverpaymentAllowance());
//
//        assertThat(contents, equalTo("Your Mum"));
//    }

//    @Test
//    public void testProductListForPdfAllawonceWithDecimalPart() throws IOException, GeneralException, DocumentException {
//
//
//        DealsResponse dealsResponse = getDealsResponse();
//
//        LoanIdentifier loanIdentifier = getLoanIdentifier();
//
//        DealsRequest dealsRequest = new DealsRequest();
//        dealsRequest.setLoansSelected(Collections.singletonList(loanIdentifier));
//
//        EligibilityResponse eligibilityResponse = generateEligibilityRespose();
//
//        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//        byteArrayOutputStream.write("Your Mum".getBytes());
//
//        List<LoanIdentifier> loanIdentifierList = Collections.singletonList(loanIdentifier);
//
//        when(eligibilityService.fetchEligibilityByLoan(accountNumber, loanIdentifierList, jwtToken)).thenReturn(eligibilityResponse);
//        when(oldDealsService.fetchDeals(dealsRequest, eligibilityResponse)).thenReturn(dealsResponse);
//        when(pdfGenerator.createPdf(pdfGeneratorRequestArgumentCaptor.capture())).thenReturn(byteArrayOutputStream);
//        when(config.getAnnualOverpaymentAllowance()).thenReturn("10.13");
//
//        InputStreamResource resource = OldPDFService.createDealsPdf(jwtToken, accountNumber, dealsRequest);
//
//        StringWriter writer = new StringWriter();
//        IOUtils.copy(resource.getInputStream(), writer, Charset.defaultCharset());
//        String contents = writer.toString();
//
//        List<PdfProduct> productsTable = (List<PdfProduct>) pdfGeneratorRequestArgumentCaptor.getValue().getTemplateElements().get("productsTable");
//
//        assertEquals("3%", productsTable.get(0).getErc());
//        assertEquals("10.13%", productsTable.get(0).getOverpaymentAllowance());
//        assertEquals("No charge", productsTable.get(1).getErc());
//        assertEquals("Unlimited", productsTable.get(1).getOverpaymentAllowance());
//
//        assertThat(contents, equalTo("Your Mum"));
//    }

    private LoanIdentifier getLoanIdentifier() {
        LoanIdentifier loanIdentifier = new LoanIdentifier();
        loanIdentifier.setLoanScheme("3B");
        loanIdentifier.setSequenceNumber(1);
        return loanIdentifier;
    }

    private DealsResponse getDealsResponse() {
        Product product1 = new Product();
        product1.setTerm("2 Year");
        product1.setBankOfEnglandRate(new BigDecimal("0.5"));
        product1.setRate(new BigDecimal("3.45"));
        product1.setProductFee(new BigDecimal(99));
        product1.setErcPercentage(new BigDecimal(3));
        product1.setBankOfEnglandRateDifference(new BigDecimal("2.5"));
        product1.setSantanderRevisionaryRate(new BigDecimal("12.7"));

        Product product2 = new Product();
        product2.setTerm("5 Year");
        product2.setBankOfEnglandRate(new BigDecimal("0.5"));
        product2.setRate(new BigDecimal("3.45"));
        product2.setProductFee(new BigDecimal(99));
        product2.setErcPercentage(new BigDecimal(0));
        product2.setBankOfEnglandRateDifference(new BigDecimal("2.5"));
        product2.setSantanderRevisionaryRate(new BigDecimal("12.7"));

        Deal deal = new Deal();
        deal.setProduct(product1);
        deal.setCalculations(new Calculations());
        deal.getCalculations().setMonthlyPaymentWithoutFee(new BigDecimal(95));
        deal.getCalculations().setMonthlyPaymentWithFee(new BigDecimal(101));

        Deal deal2 = new Deal();
        deal2.setProduct(product2);
        deal2.setCalculations(new Calculations());
        deal2.getCalculations().setMonthlyPaymentWithoutFee(new BigDecimal(96));
        deal2.getCalculations().setMonthlyPaymentWithFee(new BigDecimal(102));

        DealsResponse dealsResponse = new DealsResponse();
        dealsResponse.setDeals(Arrays.asList(deal, deal2));
        return dealsResponse;
    }

    private EligibilityResponse generateEligibilityRespose() {
        Loan loan = new Loan();
        loan.setInterestRate(new BigDecimal("2.9"));
        loan.setLoanBalance(new BigDecimal("100000.78"));
        loan.setMonthlyPayment(new BigDecimal("245.67"));
        loan.setScheme("3B");
        loan.setSequenceNumber(1);
        List<Loan> loans = Collections.singletonList(loan);

        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        eligibilityResponse.setLoans(loans);
        return eligibilityResponse;

    }

    private DealsResponse getDealsResponseOneProduct() {
        var dealsResposne = new DealsResponse();
        var deals = new ArrayList<Deal>();
        var deal = new Deal();

        var product = new Product();
        product.setTerm("2 Year");
        product.setBankOfEnglandRate(new BigDecimal("0.5"));
        product.setRate(new BigDecimal("3.45"));
        product.setProductFee(new BigDecimal(99));
        product.setErcPercentage(new BigDecimal(3));
        product.setBankOfEnglandRateDifference(new BigDecimal("2.5"));
        product.setSantanderRevisionaryRate(new BigDecimal("12.7"));

        deal.setCalculations(new Calculations());
        deal.getCalculations().setMonthlyPaymentWithoutFee(new BigDecimal(95));
        deal.getCalculations().setMonthlyPaymentWithFee(new BigDecimal(101));

        deal.setProduct(product);
        deals.add(deal);
        dealsResposne.setDeals(deals);

        return dealsResposne;
    }

    private void mockDealsResponseWith(DealsResponse dealsResponse) throws MaintenanceException, OperativeSecurityException, MortgageDealsClientException, DealsFunctionalValidationException, ConnectionException, ValidationsException {
        when(dealsService.get(anyInt(), any(), anyString())).thenReturn(dealsResponse);
    }
}

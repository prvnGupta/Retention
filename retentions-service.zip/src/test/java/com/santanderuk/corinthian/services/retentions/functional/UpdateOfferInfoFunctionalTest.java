package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class UpdateOfferInfoFunctionalTest extends FunctionalTest {


    private Header authorizationHeader;
    private Header contentType;
    private String updateOfferInfoEndpoint;

    private static final String DEFAULT_ESIS_REF_ID = "AFJIF8585HFH744FF";

    @BeforeEach
    public void setUp() {
        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        updateOfferInfoEndpoint = String.format("http://localhost:%s/retentions-service/%s/offer-info/esis-ref-id", serverPort, ACCOUNT_NUMBER);
    }


    @Test
    public void testWeReturn200WithCorrectBody() {

        String esisRefId = "esis-ref-id";
        String parameterisedUrl = String.format("%s/%s/download", updateOfferInfoEndpoint, esisRefId);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchUpdateDownloadDate(esisRefId, "/product-switch-service/update-offer-info-response.json");
        stubProductSwitchRetrieveOfferInfo(esisRefId, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            put(parameterisedUrl).
        then().
            statusCode(200).
            body("info.status", equalTo("ok"),
                    "info.code", equalTo(""),
                    "info.message", equalTo("Offer info updated"));
    }


    @Test
    public void testWeReturn403WhenAccountIsForbiddenFromAccessingThisOffer() {

        String parameterisedUrl = String.format("%s/%s/download", updateOfferInfoEndpoint, DEFAULT_ESIS_REF_ID);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");
        stubProductSwitchUpdateDownloadDate(DEFAULT_ESIS_REF_ID, "/product-switch-service/update-offer-info-response.json");
        stubProductSwitchRetrieveOfferInfo(DEFAULT_ESIS_REF_ID, "/product-switch-service/retrieve-offer-info-downloaded-true-response.json");

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            put(parameterisedUrl).
        then().
            statusCode(403).
            body("info.status", equalTo("ko"),
                    "info.code", equalTo("ESIS_REF_ID_NOT_MATCHING"),
                    "info.message", equalTo("esis ref id returned does not match request"));
    }


    @Test
    public void testWeReturn400WhenEsisRefIdHasSpecialCharacters() {

        String specialCharacterId = "*!@";
        String parameterisedUrl = String.format("%s/%s/download", updateOfferInfoEndpoint, specialCharacterId);

        stubHeartBeat("/heartbeat/heartbeat-response.json");

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            put(parameterisedUrl).
        then().
            statusCode(400).
            body(
                    "info.status", equalTo("ko"),
                    "info.code", equalTo("ESIS_ID_BAD_FORMAT"),
                    "info.message", equalTo("esis_ref_id format is not valid")
            );
    }


    @Test
    public void testWeReturn500WhenANMFReturnsRegionX() {

        String parameterisedUrl = String.format("%s/%s/download", updateOfferInfoEndpoint, DEFAULT_ESIS_REF_ID);

        stubHeartBeat("/heartbeat/heartbeat-response-x.json");

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            put(parameterisedUrl).
        then().
            statusCode(500).
            body(
                "info.status", equalTo("ko"),
                "info.message", equalTo("Maintenance region X"),
                "info.code", equalTo("MAINTENANCE_REGION_X")
            );
    }


    @Test
    public void testWeReturn500WhenHeartBeatIsDown() {

        String parameterisedUrl = String.format("%s/%s/download", updateOfferInfoEndpoint, DEFAULT_ESIS_REF_ID);

        stubHeartBeatDown();

        given().
            header(authorizationHeader).
            header(contentType).
        when().
            put(parameterisedUrl).
        then().
            statusCode(500).
            body(
                "info.status", equalTo("ko"),
                "info.message", equalTo("An error occurred when trying to connect with heartbeat"),
                "info.code", equalTo("HEARTBEAT_CONNECTION_ERROR")
            );
    }
}

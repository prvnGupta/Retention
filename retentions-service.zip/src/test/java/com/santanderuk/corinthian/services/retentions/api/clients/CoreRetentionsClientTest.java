package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.retentions.api.exceptions.ServerException;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionGenerateResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import com.santanderuk.corinthian.services.retentions.config.Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CoreRetentionsClientTest {

    CoreRetentionsClient client;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    @Mock
    private Config config;

    @BeforeEach
    public void setUp() {
        client = new CoreRetentionsClient(restTemplate, apiManagerConfig, config);
    }

    @Test
    public void testWeCanGenerateOffer() throws ConnectionException {

        Mockito.when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        Mockito.when(config.getGenerateOfferUrl()).thenReturn("dummy-url");

        CoreRetentionGenerateResponse response = createOfferResponse();

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(CoreRetentionGenerateResponse.class))).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));

        CoreRetentionRequest coreRetentionRequest = new CoreRetentionRequest();
        CoreRetentionGenerateResponse result = client.generateOfferInSession(coreRetentionRequest);

        assertEquals("1E1B708E51B2414F818BC845CACF71C7", result.getKfiOfferId());
        assertEquals("ok", result.getInfo().getStatus());
        assertEquals("", result.getInfo().getCode());
        assertEquals("Offer generated", result.getInfo().getMessage());
    }

    @Test
    public void testGetExceptionWhenClientFails() {

        Mockito.when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        Mockito.when(config.getGenerateOfferUrl()).thenReturn("dummy-url");

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), eq(CoreRetentionGenerateResponse.class))).thenThrow(ServerException.class);

        CoreRetentionRequest coreRetentionRequest = new CoreRetentionRequest();


        assertThrows(ConnectionException.class, () -> client.generateOfferInSession(coreRetentionRequest));
    }


    private CoreRetentionGenerateResponse createOfferResponse() {

        ServiceInfo info = new ServiceInfo();
        info.setStatus("ok");
        info.setCode("");
        info.setMessage("Offer generated");

        CoreRetentionGenerateResponse generateOfferResponse = new CoreRetentionGenerateResponse();
        generateOfferResponse.setKfiOfferId("1E1B708E51B2414F818BC845CACF71C7");
        generateOfferResponse.setInfo(info);

        return generateOfferResponse;
    }
}

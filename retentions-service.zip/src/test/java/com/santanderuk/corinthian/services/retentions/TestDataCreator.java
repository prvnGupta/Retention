package com.santanderuk.corinthian.services.retentions;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.retentions.api.model.deals.response.DealsResponse;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.PaymentsInternalTransferRequest;

import java.io.IOException;

public class TestDataCreator {

    public static DealsResponse getDealsResponseWithSVRProduct() throws IOException {
        return FixtureReader.get("deals-service/deals-response-with-SVR.json", DealsResponse.class);
    }

    public static AnmfAccountServiceResponse generateAnmfLoanPartsResponseTodayProductEndDate() throws IOException {
        return FixtureReader.get("anmf/account-info-multi-loans-deals-end-date-today.json", AnmfAccountServiceResponse.class);
    }

    public static PaymentsInternalTransferRequest buildPaymentsInternalTransferRequest() {
        PaymentsInternalTransferRequest paymentsInternalTransferRequest = new PaymentsInternalTransferRequest();
        paymentsInternalTransferRequest.setPaymentReference("ANMF 1234");
        return paymentsInternalTransferRequest;
    }
}

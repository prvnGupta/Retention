package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.LoanBlockers;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.OutsideDealWindow;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class OutsideDealWindowTest extends RuleTest {

    OutsideDealWindow rule;

    @BeforeEach
    public void setUp() {
        rule = new OutsideDealWindow();
    }

    @Test
    public void testWhenAllLoansAreOutsideTermWindow() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));
        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");


        LoanBlockers outsideDealWindowBlocker = new LoanBlockers();
        outsideDealWindowBlocker.setOutsideDealWindow(true);

        Loan loan1 = new Loan();
        loan1.setBlockers(outsideDealWindowBlocker);

        Loan loan2 = new Loan();
        loan2.setBlockers(outsideDealWindowBlocker);

        eligibilityResponse.setLoans(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isOutsideDealWindow(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isOutsideDealWindow(), equalTo(true));


    }

    @Test
    public void testWhenAllLoansAreInsideTermWindow() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));
        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");

        LoanBlockers insideDealWindowBlocker = new LoanBlockers();
        insideDealWindowBlocker.setOutsideDealWindow(false);

        Loan loan1 = new Loan();
        loan1.setBlockers(insideDealWindowBlocker);

        Loan loan2 = new Loan();
        loan2.setBlockers(insideDealWindowBlocker);

        eligibilityResponse.setLoans(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isOutsideDealWindow(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isOutsideDealWindow(), equalTo(false));


    }

    @Test
    public void testWhenSomeLoansAreOutsideTermWindow() {

        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(new Loan()));
        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");

        LoanBlockers outsideDealWindowBlocker = new LoanBlockers();
        outsideDealWindowBlocker.setOutsideDealWindow(true);

        LoanBlockers insideDealWindowBlocker = new LoanBlockers();
        insideDealWindowBlocker.setOutsideDealWindow(false);

        Loan loan1 = new Loan();
        loan1.setBlockers(outsideDealWindowBlocker);

        Loan loan2 = new Loan();
        loan2.setBlockers(insideDealWindowBlocker);

        eligibilityResponse.setLoans(Arrays.asList(loan1, loan2));

        assertThat(eligibilityResponse.getBlockers().isOutsideDealWindow(), equalTo(false));

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isOutsideDealWindow(), equalTo(false));


    }

}

package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorBasic;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class UpdateOfferInfoServiceTest {

    @Mock
    private OperativeSecurityService operativeSecurityService;

    @Mock
    private CacheableOperations cacheableOperations;

    @Mock
    private ProductSwitchClient productSwitchClient;

    @Mock
    private OfferInfoValidatorBasic offerInfoValidatorBasic;

    private UpdateOfferInfoService updateOfferInfoService;

    private static final int ACCOUNT = 123456;
    private static final String ESIS_REF_ID = "esis-ref-id";
    private static final String JWT_TOKEN = "token";


    @BeforeEach
    public void setUp() {
        updateOfferInfoService = new UpdateOfferInfoService(operativeSecurityService, cacheableOperations, productSwitchClient, offerInfoValidatorBasic);
    }

    @Test
    public void testWeCallAnmfRegionOperationsForRegion() throws MaintenanceException, ConnectionException, OperativeSecurityException {

        updateOfferInfoService.updateOfferInfo(ACCOUNT, ESIS_REF_ID, JWT_TOKEN);

        verify(cacheableOperations, times(1)).getAnmfActiveRegion();
    }

    @Test
    public void testWeValidateCustomerBelongsToAccount() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        updateOfferInfoService.updateOfferInfo(ACCOUNT, ESIS_REF_ID, JWT_TOKEN);

        verify(operativeSecurityService, times(1)).checkAnmfAccountBelongToCustomerInJwt(anyInt(), anyString(), any());
    }

    @Test
    public void testWeCallProductSwitchClient() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        updateOfferInfoService.updateOfferInfo(ACCOUNT, ESIS_REF_ID, JWT_TOKEN);

        verify(productSwitchClient, times(1)).sendUpdateRequest(anyInt(), anyString());
    }

    @Test
    public void testWeCallProductSwitchClientForOfferInfo() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        updateOfferInfoService.updateOfferInfo(ACCOUNT, ESIS_REF_ID, JWT_TOKEN);

        verify(productSwitchClient, times(1)).retrieveOfferInfo(anyString());
    }

    @Test
    public void testWeCallValidateAccountIsAbleToAccess() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        updateOfferInfoService.updateOfferInfo(ACCOUNT, ESIS_REF_ID, JWT_TOKEN);

        verify(offerInfoValidatorBasic, times(1)).validateOffer(any(), anyString(), anyInt());
    }
}

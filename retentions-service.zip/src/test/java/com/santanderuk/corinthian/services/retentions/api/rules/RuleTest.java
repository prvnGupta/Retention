package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.AccountBlockers;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.LoanBlockers;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.AccountResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;

import java.util.List;

public abstract class RuleTest {

    protected EligibilityResponse buildEligibilityResponse(List<Loan> loans) {

        AccountBlockers accountBlockers = new AccountBlockers();
        accountBlockers.setNotOnline(false);

        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        eligibilityResponse.setBlockers(accountBlockers);

        eligibilityResponse.setLoans(loans);

        return eligibilityResponse;
    }

    protected OdmEligibilityResponse buildODMEligibilityResponse(String bandId) {

        AccountResponse accountResponse = new AccountResponse();
        accountResponse.setAccountBand(bandId);

        OdmEligibilityResponse odmEligibilityResponse = new OdmEligibilityResponse();
        odmEligibilityResponse.setAccountResponse(accountResponse);

        return odmEligibilityResponse;
    }

    protected OdmEligibilityResponse buildODMEligibilityResponseInArrears(String bandId) {

        AccountResponse accountResponse = new AccountResponse();
        accountResponse.setAccountBand(bandId);


        OdmEligibilityResponse odmEligibilityResponse = new OdmEligibilityResponse();
        odmEligibilityResponse.setAccountResponse(accountResponse);


        return odmEligibilityResponse;
    }

    protected Loan buildLoanPartsResponse(String productDescription) {
        Loan loanPart = new Loan();
        loanPart.setBlockers(new LoanBlockers());
        loanPart.setProductDescription(productDescription);


        return loanPart;
    }
}

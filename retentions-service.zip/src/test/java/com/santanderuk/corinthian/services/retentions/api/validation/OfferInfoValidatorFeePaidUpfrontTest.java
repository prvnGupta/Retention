package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.retentions.api.exceptions.ForbiddenException;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

class OfferInfoValidatorFeePaidUpfrontTest {

    private OfferInfoValidatorFeePaidUpfront offerInfoValidatorFeePaidUpfront;

    @BeforeEach
    public void setUp() {
        offerInfoValidatorFeePaidUpfront = new OfferInfoValidatorFeePaidUpfront();
    }

    @Test
    public void testWeThrowExceptionWhenEsisRefIdDoesntMatch() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setEsisRefId("anotherReference");
        data.setAnmfAccountNumber("ANMF1234");
        data.setFeePaidUpfront(true);
        offerInfoResponse.setData(data);

        assertThrows(ForbiddenException.class, () -> offerInfoValidatorFeePaidUpfront.validateOffer(offerInfoResponse, "reference", 1234));
    }

    @Test
    public void testWeThrowExceptionWhenAccountDoesntMatch() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setAnmfAccountNumber("ANMF2345");
        data.setEsisRefId("reference");
        data.setFeePaidUpfront(true);
        offerInfoResponse.setData(data);

        assertThrows(ForbiddenException.class, () -> offerInfoValidatorFeePaidUpfront.validateOffer(offerInfoResponse, "reference", 1234));
    }

    @Test
    public void testWeThrowExceptionWhenRequestIsForInternalTransfer() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setAnmfAccountNumber("ANMF1234");
        data.setEsisRefId("reference");
        data.setFeePaidUpfront(false);
        offerInfoResponse.setData(data);

        assertThrows(ForbiddenException.class, () -> offerInfoValidatorFeePaidUpfront.validateOffer(offerInfoResponse, "reference", 1234));
    }
}

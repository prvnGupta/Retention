package com.santanderuk.corinthian.services.retentions.api.service.generateoffer;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.retentions.api.clients.CoreRetentionsClient;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionMapper;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionMapperTestBase;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionGenerateResponse;
import com.santanderuk.corinthian.services.retentions.api.model.createCase.CreateCaseRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class GenerateOfferServiceTest extends CoreRetentionMapperTestBase {

    @Mock
    private CoreRetentionsRequestBuilder requestBuilder;

    @Mock
    private CoreRetentionMapper coreRetentionMapper;

    @Mock
    private CoreRetentionsClient coreRetentionsClient;

    @Mock
    private ProductSwitchClient productSwitchClient;

    private GenerateOfferService generateOfferService;

    private CreateCaseRequest offerRequest;

    private static final int ACCOUNT_NUMBER = 12345;
    private static final String TOKEN = "token";

    @BeforeEach
    public void setUp() throws GeneralException {

        generateOfferService = new GenerateOfferService(requestBuilder, coreRetentionMapper, coreRetentionsClient, productSwitchClient);

        offerRequest = genericOfferRequest();
        CoreRetentionGenerateResponse offerResponse = genericOfferResponse();
        Mockito.when(coreRetentionsClient.generateOfferInSession(any())).thenReturn(offerResponse);
    }

    @Test
    public void testWeCallCoreRetentionMapper() throws GeneralException {

        generateOfferService.generateOfferInSession(ACCOUNT_NUMBER, offerRequest, TOKEN);

        verify(coreRetentionMapper, times(1)).buildCoreRetentionsRequest(any());
    }

    @Test
    public void testWeCallCoreRetentionsClient() throws GeneralException {

        generateOfferService.generateOfferInSession(ACCOUNT_NUMBER, offerRequest, TOKEN);

        verify(coreRetentionsClient, times(1)).generateOfferInSession(any());
    }

    private CoreRetentionGenerateResponse genericOfferResponse() {
        CoreRetentionGenerateResponse offerResponse = new CoreRetentionGenerateResponse();
        offerResponse.setKfiOfferId("1E1B708E51B2414F818BC845CACF71C7");
        return offerResponse;
    }
}

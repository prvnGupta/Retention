package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class EligibilityLoanPartFunctionalTest extends FunctionalTest {

    private String eligibilityEndpoint;
    Header authorizationHeader;
    Header contentType;
    Header accept;

    @BeforeEach
    public void setUp() {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
    }


    @Test
    public void checkSingleLoanWithLessThan30MonthsRemainingTermReturnBlocker() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/odm-single-loan-not-eligible-less-than-30-months.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.blockers.termRemaining", equalTo(true)
                );
    }

    @Test
    public void testWeReturnTheLoanPartEligibilityIfOutsideDealWindow() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-q-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].eligibleToTransfer", equalTo(false),
                        "response.loans[0].blockers.outsideDealWindow", equalTo(true)
                );
    }

    @Test
    public void testWhenALoanPartIsNotEligibleOnlyForTheBalanceIsMarkedAsEligible() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/loans-part-not-eligible-balance-only.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].eligibleToTransfer", equalTo(true)
                );
    }

    @Test
    public void testWhenALoanPartIsNotEligibleForTheBalanceAndOtherReasonIsMarkedAsNotEligible() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/loans-part-not-eligible-balance-and-other.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].eligibleToTransfer", equalTo(false)
                );
    }

    @Test
    public void mortgageShouldReturnBodyViewAsTrackingNotFixedBecasueIsAFlexi() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success-loan-parts-flexible.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/odm-single-loan-not-eligible-less-than-30-months.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].view.headerView", equalTo("NOT_FIXED"),
                        "response.loans[0].view.bodyView", equalTo("TRACKING")
                );
    }

    @Test
    public void mortgageShouldReturnBodyViewAsTrackingdBecasueIsAFixed() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-success.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/odm-single-loan-not-eligible-less-than-30-months.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].view.bodyView", equalTo("NOT_TRACKING")
                );
    }


    @Test
    public void test1stAnd2ndLoansAreEligibleBut3rdIsNot() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/2421/mortgage-account-service-response.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/2421/risk.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/2421/odm.json");
        stubAnmfCustomerInfo("/2421/mortgage-customer-details-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].eligibleToTransfer", equalTo(true),
                        "response.loans[1].eligibleToTransfer", equalTo(true),
                        "response.loans[2].eligibleToTransfer", equalTo(false)
                );

    }


    @Test
    public void testTelephonyOnlyForLoansLessThanFiveAndHalfYears() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-multi-loans.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-a-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[0].telephonyOnly", equalTo(true),
                        "response.loans[1].telephonyOnly", equalTo(false),
                        "response.loans[2].telephonyOnly", equalTo(false),
                        "response.loans[3].telephonyOnly", equalTo(false)
                );
    }
    @Test
    public void testLoansWithIdZeroAreFiltered() {

        int accountNumber = 123456;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubANMFAccountInfo(accountNumber, "/anmf/account-info-multi-loans-zeros.json");
        stubANMFPropertyInfoV2(accountNumber, "/anmf/property/anmf-property.json");
        stubRiskValuation(accountNumber, "/risk-valuation/response.json");
        stubProductDirectoryResponse("/productdirectory/product-directory-response.json");
        stubODMCoreEligibility("/odm/band-a-eligible-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        given().
                header(authorizationHeader).
                header(contentType).
                header(accept).
                when().
                get(eligibilityEndpoint).
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "response.loans[3]", equalTo(null)
                );
    }
}


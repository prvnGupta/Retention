package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.retentions.api.clients.EsisClient;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.mapper.OfferResponseMapper;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.retrieve.RetrieveOfferResponse;
import com.santanderuk.corinthian.services.retentions.api.model.esis.RetrieveEsisResponse;
import com.santanderuk.corinthian.services.retentions.api.validation.OfferInfoValidatorBasic;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class RetrieveOfferServiceTest {

    @Mock
    private OperativeSecurityService operativeSecurityService;

    @Mock
    private CacheableOperations cacheableOperations;

    @Mock
    private ProductSwitchClient productSwitchClient;

    @Mock
    private EsisClient esisClient;

    @Mock
    private OfferInfoValidatorBasic offerInfoValidatorBasic;

    @Mock
    private OfferResponseMapper responseMapper;

    private RetrieveOfferService retrieveOfferService;

    public static final int ACCOUNT_NUMBER = 123456;
    public static final String JWT = "Bearer jwt-token";
    public static final String ESIS_REF_ID = "esis-ref-id";

    @BeforeEach
    public void setUp() {

        retrieveOfferService = new RetrieveOfferService(operativeSecurityService, cacheableOperations, productSwitchClient, esisClient, responseMapper, offerInfoValidatorBasic);
    }

    @Test
    public void testWeReturnARetrieveOfferResponse() throws MaintenanceException, ConnectionException, OperativeSecurityException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        Mockito.when(esisClient.retrieveOffer(ESIS_REF_ID)).thenReturn(buildEsisResponse());
        Mockito.when(responseMapper.mapToResponse(any(), any())).thenReturn(buildRetrieveOfferResponse());

        RetrieveOfferResponse offerResponse = retrieveOfferService.retrieveOffer(ACCOUNT_NUMBER, JWT, ESIS_REF_ID);

        assertThat(offerResponse.getPdfString(), equalTo("pdfEncodedString"));
        assertThat(offerResponse.isDownloaded(), equalTo(true));
    }

    @Test
    public void testWeCallCacheableOperationsForRegion() throws MaintenanceException, ConnectionException, OperativeSecurityException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        Mockito.when(esisClient.retrieveOffer(ESIS_REF_ID)).thenReturn(buildEsisResponse());

        retrieveOfferService.retrieveOffer(ACCOUNT_NUMBER, JWT, ESIS_REF_ID);

        verify(cacheableOperations, times(1)).getAnmfActiveRegion();
    }

    @Test
    public void testWeCallOperativeSecurityToValidateJwt() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        Mockito.when(esisClient.retrieveOffer(ESIS_REF_ID)).thenReturn(buildEsisResponse());

        retrieveOfferService.retrieveOffer(ACCOUNT_NUMBER, JWT, ESIS_REF_ID);

        verify(operativeSecurityService, times(1)).checkAnmfAccountBelongToCustomerInJwt(anyInt(), anyString(), any());
    }

    @Test
    public void testWeCallProductSwitchClientForOfferInfo() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        Mockito.when(esisClient.retrieveOffer(ESIS_REF_ID)).thenReturn(buildEsisResponse());

        retrieveOfferService.retrieveOffer(ACCOUNT_NUMBER, JWT, ESIS_REF_ID);

        verify(productSwitchClient, times(1)).retrieveOfferInfo(anyString());
    }

    @Test
    public void testWeCallOfferInfoValidator() throws OperativeSecurityException, MaintenanceException, ConnectionException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        Mockito.when(esisClient.retrieveOffer(ESIS_REF_ID)).thenReturn(buildEsisResponse());

        retrieveOfferService.retrieveOffer(ACCOUNT_NUMBER, JWT, ESIS_REF_ID);

        verify(offerInfoValidatorBasic, times(1)).validateOffer(any(), anyString(), anyInt());
    }

    @Test
    public void testWeCallEsisClientForPdfEncoded() throws OperativeSecurityException, MaintenanceException, ConnectionException, ValidationsException {

        String anmfAccountNumber = String.format("ANMF%s", ACCOUNT_NUMBER);
        Mockito.when(productSwitchClient.retrieveOfferInfo(ESIS_REF_ID)).thenReturn(buildRetrieveOfferInfoResponse(ESIS_REF_ID, anmfAccountNumber));
        Mockito.when(esisClient.retrieveOffer(ESIS_REF_ID)).thenReturn(buildEsisResponse());

        retrieveOfferService.retrieveOffer(ACCOUNT_NUMBER, JWT, ESIS_REF_ID);

        verify(esisClient, times(1)).retrieveOffer(anyString());
    }

    private OfferInfoResponse buildRetrieveOfferInfoResponse(String esisRefId, String anmfAccountNumber) {
        OfferInfoResponse response = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setEsisRefId(esisRefId);
        data.setAnmfAccountNumber(anmfAccountNumber);
        response.setData(data);
        return response;
    }

    private RetrieveOfferResponse buildRetrieveOfferResponse() {
        RetrieveOfferResponse retrieveOfferResponse = new RetrieveOfferResponse();
        retrieveOfferResponse.setPdfString("pdfEncodedString");
        retrieveOfferResponse.setDownloaded(true);
        return retrieveOfferResponse;
    }

    private RetrieveEsisResponse buildEsisResponse() {
        RetrieveEsisResponse retrieveEsisResponse = new RetrieveEsisResponse();
        RetrieveEsisResponse.Output output = new RetrieveEsisResponse.Output();
        output.setValue("pdfEncodedString");
        retrieveEsisResponse.setOutput(output);
        return retrieveEsisResponse;
    }
}

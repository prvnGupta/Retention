package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.AccountResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.CanNotChangeOnline;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class CanNotChangeOnlineTest extends RuleTest {

    CanNotChangeOnline rule;
    EligibilityResponse eligibilityResponse;

    @BeforeEach
    public void setUp() {
        rule = new CanNotChangeOnline();
        Loan loan = new Loan();
        eligibilityResponse = buildEligibilityResponse(Arrays.asList(loan));
    }

    @Test
    public void testShouldNotBlockWhenODMReturnsBandEligibilityAsY() {

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponseWithBandEligibility("Y", "A");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isNotOnline(), equalTo(false));

    }


    @Test
    public void testShouldBlockWhenODMReturnsBandEligibilityAsN() {

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponseWithBandEligibility("N", "B");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isNotOnline(), equalTo(true));

    }

    @Test
    public void testShouldNotBlockWhenODMReturnsBandEligibilityAsNAndBandW() {

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponseWithBandEligibility("N", "W");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isNotOnline(), equalTo(false));

    }

    @Test
    public void testShouldNotBlockWhenODMReturnsBandEligibilityAsYAndBandW() {

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponseWithBandEligibility("Y", "W");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertThat(eligibilityResponse.getBlockers().isNotOnline(), equalTo(false));

    }

    private OdmEligibilityResponse buildODMEligibilityResponseWithBandEligibility(String bandEligibility, String accountBand) {
        OdmEligibilityResponse respone = new OdmEligibilityResponse();
        AccountResponse accountResponse = new AccountResponse();
        accountResponse.setBandEligibility(bandEligibility);
        accountResponse.setAccountBand(accountBand);
        respone.setAccountResponse(accountResponse);

        return respone;
    }

}

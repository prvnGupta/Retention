package com.santanderuk.corinthian.services.retentions.api.service.deals.functionalvalidation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapperTestData.createEmptyAnmfAccountServiceResponse;
import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.request.MortgageDealsClientRequestMapperTestData.createEmptyDealsRequest;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
class DealsFunctionalValidationTest {

    DealsFunctionalValidation validation;

    @BeforeEach
    void setUp() {
        validation = new DealsFunctionalValidation();
    }

    @Test
    void nullLoansInRequest() {

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(new DealsRequest(), new AnmfAccountServiceResponse())
        );

        assertEquals("EXC_DEALS_NO_LOANS_IN_REQUEST", ex.getCode());
        assertEquals("There are not loans in the request", ex.getMessage());
    }

    @Test
    void emptyListLoansInRequest() {

        var dealRequest = createEmptyDealsRequest();

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(new DealsRequest(), new AnmfAccountServiceResponse())
        );

        assertEquals("EXC_DEALS_NO_LOANS_IN_REQUEST", ex.getCode());
        assertEquals("There are not loans in the request", ex.getMessage());
    }

    @Test
    void oneInRequest_oneInAccount_same_OK() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 1);

        assertDoesNotThrow(() -> validation.run(dealRequest, emptyAnmfAccountServiceResponse));

    }

    @Test
    void oneInRequest_oneInAccount_different_KO() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 2);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }

    @Test
    void oneInRequest_twoInAccount_same_OK() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 1);
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 2);

        assertDoesNotThrow(
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );
    }

    @Test
    void oneInRequest_twoInAccount_different_KO() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 2);
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 3);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }

    @Test
    void twoInRequest_oneInAccount_same_KO() {
        // Not all the laons in the request are in the account so KO
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 1);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }

    @Test
    void twoInRequest_oneInAccount_different_KO() {
        // Not all the laons in the request are in the account so KO
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 3);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }

    @Test
    void twoInRequest_twoInAccount_same_OK() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 1);
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 2);

        assertDoesNotThrow(
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );
    }

    @Test
    void twoInRequest_twoInAccount_one_different_KO() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 3);
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 2);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }

    @Test
    void twoInRequest_twoInAccount_two_different_KO() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 3);
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 4);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }


    @Test
    void twoloansInRequestButOnlyOneExistsInAccountResponse() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 1);

        var ex = assertThrows(
                DealsFunctionalValidationException.class,
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );

        assertEquals("EXC_DEALS_LOAN_DOES_NOT_BELONG_TO_ACCOUNT", ex.getCode());
        assertEquals("One or more of the loans does not belong to the account", ex.getMessage());
    }

    @Test
    void twoInRequestTwoInAccountAllTheSame() {
        var dealRequest = createEmptyDealsRequest();
        addLoanInDealsRequest(dealRequest, "3A", 1);
        addLoanInDealsRequest(dealRequest, "3A", 2);

        var emptyAnmfAccountServiceResponse = createEmptyAnmfAccountServiceResponse();
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 1);
        addActiveLoanInAccountResponse(emptyAnmfAccountServiceResponse, "3A", 2);

        assertDoesNotThrow(
                () -> validation.run(dealRequest, emptyAnmfAccountServiceResponse)
        );
    }


    private void addActiveLoanInAccountResponse(AnmfAccountServiceResponse accountServiceResponse, String loanScheme, int sequenceNumber) {
        var activeLoanDetail = new OActiveLoanDetail();
        activeLoanDetail.setOLoanScheme(loanScheme);
        activeLoanDetail.setOApplSeqNo(sequenceNumber);
        accountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(activeLoanDetail);
    }

    private void addLoanInDealsRequest(DealsRequest dealsRequest, String loanScheme, int sequenceNumber) {
        var loanSelected = new LoanIdentifier();
        loanSelected.setLoanScheme(loanScheme);
        loanSelected.setSequenceNumber(sequenceNumber);
        dealsRequest.getLoansSelected().add(loanSelected);
    }
}

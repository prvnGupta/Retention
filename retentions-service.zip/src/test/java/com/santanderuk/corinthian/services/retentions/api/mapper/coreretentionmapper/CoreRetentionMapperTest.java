package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.ClientChannel;
import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CoreRetentionMapperTest extends CoreRetentionMapperTestBase {

    @Test
    public void mapClientChannelToCoreRetentionsRequest() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals(ClientChannel.CORINTHIAN, coreRetentionRequest.getChannel());

    }

    @Test
    public void mapGovernanceType() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertEquals("1", coreRetentionRequest.getGovernanceType());

    }

    @Test
    public void mapAnmfToAnmf() {

        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertTrue(coreRetentionRequest.isAnmfToAnmfSwitch());

    }
}

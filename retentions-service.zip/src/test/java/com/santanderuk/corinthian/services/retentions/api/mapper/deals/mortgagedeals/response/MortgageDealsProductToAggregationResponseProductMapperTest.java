package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.input.MortgageDealsClientRequest;
import com.santanderuk.corinthian.services.retentions.api.clients.mortgagedeals.io.output.ErcStep;
import com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.LongestTermFinder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response.MortgageDealsClientResponseMapperTest.loanMortgageDealsFixture;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class MortgageDealsProductToAggregationResponseProductMapperTest {

    @Mock
    LongestTermFinder longestTermFinder;

    MortgageDealsProductToAggregationResponseProductMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new MortgageDealsProductToAggregationResponseProductMapper(longestTermFinder);
    }

    @Test
    void test_product() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");
        when(longestTermFinder.get(any())).thenReturn(46);
        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertEquals(new BigDecimal("999"), returnProduct.getProductFee());
        assertEquals("2 Yr Tracker BBR plus 1.29% then FoR", returnProduct.getDescription());
        assertEquals("B070S", returnProduct.getProductCode());
        assertEquals("01/02/2025", returnProduct.getChargeEndDate());
        assertEquals("Tracker", returnProduct.getType());
        assertEquals(new BigDecimal("1.39"), returnProduct.getRate());
        assertEquals("2 Year", returnProduct.getTerm());
        assertEquals(24, returnProduct.getTermInMonths());
        assertEquals(22, returnProduct.getMortgageTermInMonthsAfterProduct());
        assertEquals(new BigDecimal("0.1"), returnProduct.getBankOfEnglandRate());
        assertEquals(new BigDecimal("1.2"), returnProduct.getBankOfEnglandRateDifference());
        assertEquals(new BigDecimal("3.00"), returnProduct.getErcPercentage());
        assertEquals(new BigDecimal("1.81"), returnProduct.getAnnualOverpaymentAllowancePercentage());
        assertEquals(new BigDecimal("3.75"), returnProduct.getSantanderRevisionaryRate());
        assertEquals("06/08/2021", returnProduct.getProductCompletionDate());
    }


    @Test
    void productRevertingToFoR() throws IOException {
        var clientResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        when(longestTermFinder.get(any())).thenReturn(46);
        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertEquals("c 5 Yr Fixed til 02 Jan 2029 then FoR", returnProduct.getDescription());
        assertEquals("FoR", returnProduct.getReversionProduct());
    }

    @Test
    void productRevertingToSVR() throws IOException {
        var clientResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        when(longestTermFinder.get(any())).thenReturn(46);
        var returnProduct = mapper.map(clientResponse.getProducts().get(4), new MortgageDealsClientRequest());

        assertEquals("2 Yr Tracker BBR plus 0.34% then SVR", returnProduct.getDescription());
        assertEquals("SVR", returnProduct.getReversionProduct());
    }

    @Test
    void productRevertingToNA() throws IOException {
        var clientResponse = loanMortgageDealsFixture("11169738/mortgage-deals.json");
        when(longestTermFinder.get(any())).thenReturn(46);
        var returnProduct = mapper.map(clientResponse.getProducts().get(10), new MortgageDealsClientRequest());

        assertEquals("Lifetime Tracker BBR plus 0.54%", returnProduct.getDescription());
        assertEquals("N/A", returnProduct.getReversionProduct());
    }



    @Test
    void test_product_steppedErc() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");

        clientResponse.getProducts().get(0).setChargeEndDate("");
        List<ErcStep> steps = clientResponse.getProducts().get(0).getErc().getSteps();
        ErcStep newStep =  new ErcStep();
        newStep.setRate(new BigDecimal("4.00"));
        newStep.setStepMaturityDate("2025-01-02T00:00:00");
        steps.add(newStep);
        clientResponse.getProducts().get(0).getErc().setSteps(steps);

        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertTrue(returnProduct.isStepErc());
    }

    @Test
    void test_product_NonSteppedErc() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");

        clientResponse.getProducts().get(0).setChargeEndDate("");
        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertFalse(returnProduct.isStepErc());
    }

    @Test
    void test_product_no_erc() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");

        clientResponse.getProducts().get(0).setChargeEndDate("");
        clientResponse.getProducts().get(0).getErc().setApplicable(false);

        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertFalse(returnProduct.isStepErc());
    }

    @Test
    void test_product_SteppedErc_NullPointerExceptionStepsErc() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");

        clientResponse.getProducts().get(0).setChargeEndDate("");
        clientResponse.getProducts().get(0).getErc().setSteps(null);

        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertFalse(returnProduct.isStepErc());
    }

    @Test
    void test_product_chargeEndDateIsNotADate() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");

        clientResponse.getProducts().get(0).setChargeEndDate("");

        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertEquals("", returnProduct.getChargeEndDate());
    }

    @Test
    void test_SteppedErcGetHigherValueOfAllSteps() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-SteppedERC.json");
        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertEquals(new BigDecimal("3.00"), returnProduct.getErcPercentage());

    }
    @Test
    void test_NoErcApplicable() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-ERC-not-applicable.json");
        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertEquals(new BigDecimal("0.00"), returnProduct.getErcPercentage());

    }

    @Test
    void test_BOEBaseRateForLifetimeTrackerProduct() throws IOException {
        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-lifetime.json");
        var returnProduct = mapper.map(clientResponse.getProducts().get(0), new MortgageDealsClientRequest());

        assertEquals(new BigDecimal("0.1"), returnProduct.getBankOfEnglandRate());

    }
}

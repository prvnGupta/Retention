package com.santanderuk.corinthian.services.retentions.api.rules.loan;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.LoanBlockers;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.RuleTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class LoanOutsideDealWindowTest extends RuleTest {

    LoanOutsideDealWindow rule;

    @BeforeEach
    public void setUp() throws Exception {
        rule = new LoanOutsideDealWindow();
    }

    @Test
    public void testWeSetTheBlockerWhenTheLoanIsOutsideDealWindow() {

        Loan loan = buildLoanPartsResponse("");
        loan.getBlockers().setOutsideDealWindow(true);

        ODMLoanResponse odmLoanResponse = new ODMLoanResponse();
        odmLoanResponse.setTermEligibility("N");
        odmLoanResponse.setLoanID("1");

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(odmLoanResponse));

        Loan loan1 = new Loan();
        loan1.setBlockers(new LoanBlockers());
        loan1.setLoanId(1);
        EligibilityResponse response = buildEligibilityResponse(Arrays.asList(loan1));

        assertThat(response.getLoans().get(0).getBlockers().isOutsideDealWindow(), equalTo(false));

        rule.isEligible(response, odmEligibilityResponse);

        assertThat(response.getLoans().get(0).getBlockers().isOutsideDealWindow(), equalTo(true));
        assertThat(response.getLoans().get(0).isEligibleToTransfer(), equalTo(false));
    }

    @Test
    public void testWeDontSetTheBlockerWhenTheLoanIsNotOutsideDealWindow() {

        Loan loan = buildLoanPartsResponse("");
        loan.getBlockers().setOutsideDealWindow(true);

        ODMLoanResponse odmLoanResponse = new ODMLoanResponse();
        odmLoanResponse.setTermEligibility("Y");
        odmLoanResponse.setLoanID("1");

        OdmEligibilityResponse odmEligibilityResponse = buildODMEligibilityResponse("A");
        odmEligibilityResponse.getAccountResponse().setLoanResponse(Arrays.asList(odmLoanResponse));

        Loan loan1 = new Loan();
        loan1.setBlockers(new LoanBlockers());
        loan1.setLoanId(1);
        EligibilityResponse response = buildEligibilityResponse(Arrays.asList(loan1));

        assertThat(response.getLoans().get(0).getBlockers().isOutsideDealWindow(), equalTo(false));

        rule.isEligible(response, odmEligibilityResponse);

        assertThat(response.getLoans().get(0).getBlockers().isOutsideDealWindow(), equalTo(false));
        assertThat(response.getLoans().get(0).isEligibleToTransfer(), equalTo(true));
    }
}

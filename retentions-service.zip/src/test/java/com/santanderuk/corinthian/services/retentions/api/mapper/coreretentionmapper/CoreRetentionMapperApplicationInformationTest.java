package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CoreRetentionMapperApplicationInformationTest extends CoreRetentionMapperTestBase {

    @Test
    public void test() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getApplicationInformation());

        assertEquals("", coreRetentionRequest.getApplicationInformation().getOmrtReference());
        assertEquals("", coreRetentionRequest.getApplicationInformation().getBrokerReferenceCode());
        assertEquals("", coreRetentionRequest.getApplicationInformation().getBrokerEmail());
        assertEquals("", coreRetentionRequest.getApplicationInformation().getSwitchEarlyReference());
        assertEquals("CORINTHIAN", coreRetentionRequest.getApplicationInformation().getRetentionUserId());
        assertEquals("CORINTHIAN", coreRetentionRequest.getApplicationInformation().getRetentionUserName());
        assertEquals("2", coreRetentionRequest.getApplicationInformation().getSaleTypeID());
        assertEquals(false, coreRetentionRequest.getApplicationInformation().isCommunicationOptOut());
        assertEquals("1", coreRetentionRequest.getApplicationInformation().getOfferCreationSource());
    }
}

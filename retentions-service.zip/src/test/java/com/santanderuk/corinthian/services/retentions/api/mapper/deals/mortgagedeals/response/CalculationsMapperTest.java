package com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.math.BigDecimal;

import static com.santanderuk.corinthian.services.retentions.api.mapper.deals.mortgagedeals.response.MortgageDealsClientResponseMapperTest.loanMortgageDealsFixture;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(SpringExtension.class)
class CalculationsMapperTest {

    CalculationsMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new CalculationsMapper();
    }

    @Test
    void calculations() throws IOException {

        var clientResponse = loanMortgageDealsFixture("mortgage-deals/mortgage-deals-one-deal-ok.json");

        var calculations = mapper.map(clientResponse.getProducts().get(0));

        assertEquals(BigDecimal.valueOf(9999.99), calculations.getRemainingBalanceWithoutFee());
        assertEquals(BigDecimal.valueOf(4444.44), calculations.getRemainingBalanceWithFee());
        assertEquals(BigDecimal.valueOf(1111.11), calculations.getMonthlyPaymentWithFee());
        assertEquals(BigDecimal.valueOf(6666.66), calculations.getMonthlyPaymentWithoutFee());
        assertEquals(BigDecimal.valueOf(3333.33), calculations.getNewMortgageOutstandingBalanceWithFee());
        assertEquals(BigDecimal.valueOf(8888.88), calculations.getNewMortgageOutstandingBalanceWithoutFee());
    }

    @Test
    void WithFeeValueIsSameAsWithoutFeeWhenProductHasNoFee() throws IOException {

        var clientResponse = loanMortgageDealsFixture("mortgage-deals/breakdownSummary-withFee-is-null.json");

        var calculations = mapper.map(clientResponse.getProducts().get(0));

        assertEquals(BigDecimal.valueOf(9999.99), calculations.getRemainingBalanceWithFee());
        assertEquals(BigDecimal.valueOf(9999.99), calculations.getRemainingBalanceWithoutFee());
        assertEquals(BigDecimal.valueOf(6666.66), calculations.getMonthlyPaymentWithFee());
        assertEquals(BigDecimal.valueOf(6666.66), calculations.getMonthlyPaymentWithoutFee());
        assertEquals(BigDecimal.valueOf(8888.88), calculations.getNewMortgageOutstandingBalanceWithFee());
        assertEquals(BigDecimal.valueOf(8888.88), calculations.getNewMortgageOutstandingBalanceWithoutFee());
    }
}

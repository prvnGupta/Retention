package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.retentions.TestDataCreator;
import com.santanderuk.corinthian.services.retentions.api.clients.InternalTransferClient;
import com.santanderuk.corinthian.services.retentions.api.exceptions.PaymentsException;
import com.santanderuk.corinthian.services.retentions.api.mapper.InternalTransferMapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.InternalTransferResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.PaymentsInternalTransferRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class PaymentsServiceTest extends TestDataCreator {

    @Mock
    PaymentsService paymentsService;

    @Mock
    private InternalTransferClient mockInternalTransferClient;

    @Mock
    private InternalTransferMapper mockInternalTransferMapper;

    PaymentsInternalTransferRequest paymentsInternalTransferRequest;

    @BeforeEach
    void setUp() {

        paymentsService = new PaymentsService(mockInternalTransferClient, mockInternalTransferMapper);
        paymentsInternalTransferRequest = buildPaymentsInternalTransferRequest();
    }

    @Test
    void payAcceptInSession_OK() throws PaymentsException {
        when(mockInternalTransferClient.makeInternalTransfer(any())).thenReturn(buildResponseWrapper());

        paymentsService.makeInternalTransfer(12345, "jwt-token", new AcceptAndPayInSessionRequest(), new OnlineOfferEntity());
        verify(mockInternalTransferMapper, times(1)).mapData(any(), anyString(), any(), anyInt());
        verify(mockInternalTransferClient, times(1)).makeInternalTransfer(any());
    }

    private AcceptAndPayInSessionResponseWrapper buildResponseWrapper() {
        AcceptAndPayInSessionResponseWrapper responseWrapper = new AcceptAndPayInSessionResponseWrapper();
        InternalTransferResponse transferResponse = new InternalTransferResponse();
        transferResponse.setPaymentId("1234");
        responseWrapper.setResponse(transferResponse);
        return responseWrapper;
    }

    @Test
    void payAcceptInSession_KO() throws PaymentsException {

        Mockito.when(mockInternalTransferClient.makeInternalTransfer(any())).thenThrow(PaymentsException.class);
        assertThrows(PaymentsException.class, () -> paymentsService.makeInternalTransfer(12345, "jwt", new AcceptAndPayInSessionRequest(), new OnlineOfferEntity()));
    }
}

package com.santanderuk.corinthian.services.retentions.api.validation;

import com.santanderuk.corinthian.services.retentions.api.exceptions.ForbiddenException;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class OfferInfoValidatorFeeRolledIntoMortgageTest {

    private OfferInfoValidatorFeeRolledIntoMortgage offerInfoValidatorFeeRolledIntoMortgage;

    @BeforeEach
    public void setUp() {
        offerInfoValidatorFeeRolledIntoMortgage = new OfferInfoValidatorFeeRolledIntoMortgage();
    }

    @Test
    public void testWeThrowExceptionWhenEsisRefIdDoesntMatch() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setEsisRefId("anotherReference");
        data.setAnmfAccountNumber("ANMF1234");
        offerInfoResponse.setData(data);

        assertThrows(ForbiddenException.class, () -> offerInfoValidatorFeeRolledIntoMortgage.validateOffer(offerInfoResponse, "reference", 1234));
    }

    @Test
    public void testWeThrowExceptionWhenAccountDoesntMatch() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setAnmfAccountNumber("ANMF2345");
        data.setEsisRefId("reference");
        offerInfoResponse.setData(data);

        assertThrows(ForbiddenException.class, () -> offerInfoValidatorFeeRolledIntoMortgage.validateOffer(offerInfoResponse, "reference", 1234));
    }

    @Test
    public void testWeThrowExceptionWhenRequestIsForInternalTransfer() {
        OfferInfoResponse offerInfoResponse = new OfferInfoResponse();
        OnlineOfferEntity data = new OnlineOfferEntity();
        data.setAnmfAccountNumber("ANMF1234");
        data.setEsisRefId("reference");
        data.setFeePaidUpfront(true);
        offerInfoResponse.setData(data);

        assertThrows(ForbiddenException.class, () -> offerInfoValidatorFeeRolledIntoMortgage.validateOffer(offerInfoResponse, "reference", 1234));
    }
}

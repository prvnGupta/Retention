package com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper;

import com.santanderuk.corinthian.services.retentions.api.model.core.coreretentions.CoreRetentionRequest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CoreRetentionMapperAdvisorInformationTest extends CoreRetentionMapperTestBase {

    @Test
    public void test() {
        CoreRetentionsData input = generateDefaultMapperInput();
        CoreRetentionRequest coreRetentionRequest = mapper.buildCoreRetentionsRequest(input);

        assertNotNull(coreRetentionRequest.getAdvisorInformation());

        assertEquals("00000001", coreRetentionRequest.getAdvisorInformation().getAdvisorEmployeeNumber());
        assertEquals("Corinthian", coreRetentionRequest.getAdvisorInformation().getAdvisorSurname());

    }


}

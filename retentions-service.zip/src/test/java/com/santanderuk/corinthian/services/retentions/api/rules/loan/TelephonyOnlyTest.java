package com.santanderuk.corinthian.services.retentions.api.rules.loan;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class TelephonyOnlyTest {

    private TelephonyOnly rule;

    @BeforeEach
    public void setUp() {
        rule = new TelephonyOnly();
    }

    @Test
    public void testTelephonyOnlyWhen5Years6MonthsLeft() {

        Loan loan = new Loan();
        loan.setRemainingTerm(66);

        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        eligibilityResponse.setLoans(Arrays.asList(loan));

        assertThat(eligibilityResponse.getLoans().get(0).isTelephonyOnly(), equalTo(false));

        rule.isEligible(eligibilityResponse, new OdmEligibilityResponse());

        assertThat(eligibilityResponse.getLoans().get(0).isTelephonyOnly(), equalTo(false));
    }

    @Test
    public void testTelephonyOnlyWhen5Years5MonthsLeft() {

        Loan loan = new Loan();
        loan.setRemainingTerm(65);

        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        eligibilityResponse.setLoans(Arrays.asList(loan));

        assertThat(eligibilityResponse.getLoans().get(0).isTelephonyOnly(), equalTo(false));

        rule.isEligible(eligibilityResponse, new OdmEligibilityResponse());

        assertThat(eligibilityResponse.getLoans().get(0).isTelephonyOnly(), equalTo(true));
    }

    @Test
    public void testTelephonyOnlyWhen5Years7MonthsLeft() {

        Loan loan = new Loan();
        loan.setRemainingTerm(66);

        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        eligibilityResponse.setLoans(Arrays.asList(loan));

        assertThat(eligibilityResponse.getLoans().get(0).isTelephonyOnly(), equalTo(false));

        rule.isEligible(eligibilityResponse, new OdmEligibilityResponse());

        assertThat(eligibilityResponse.getLoans().get(0).isTelephonyOnly(), equalTo(false));
    }

}

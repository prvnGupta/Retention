package com.santanderuk.corinthian.services.retentions.api.service;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.clients.PafClient;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafAddress;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafDetailResponse;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafIdResponse;
import com.santanderuk.corinthian.services.retentions.api.model.paf.PafItem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class PafServiceTest {

    @Mock
    PafClient pafClient;

    PafService pafService;

    @BeforeEach
    void setUp() {
        pafService = new PafService(pafClient);
    }

    @Test
    public void testWeGetEmptyStringWhenPAFDown() throws ConnectionException, InterruptedException {

        String postcode = "MK1 1AB";
        Mockito.when(pafClient.fetchPafIdResponse(postcode)).thenThrow(ConnectionException.class);

        String country = pafService.fetchCountry(postcode);
        assertThat(country, equalTo(""));
    }

    @Test
    public void testWeGetEmptyStringWhenPafDetailsDown() throws ConnectionException, InterruptedException {
        String postcode = "MK1 1AB";
        String id = "GB|SOME|ID";
        PafIdResponse pafIdResponse = generateDefaultPafResponse(id);
        Mockito.when(pafClient.fetchPafIdResponse(postcode)).thenReturn(pafIdResponse);
        Mockito.when(pafClient.fetchPafIdAndPostcodeResponse(postcode, id)).thenReturn(id);
        Mockito.when(pafClient.fetchPafDetailResponse(id)).thenThrow(ConnectionException.class);

        String country = pafService.fetchCountry(postcode);
        assertThat(country, equalTo(""));

    }

    private PafIdResponse generateDefaultPafResponse(String id) {
        PafIdResponse pafIdResponse = new PafIdResponse();
        List<PafItem> items = new ArrayList<>(1);

        PafItem item1 = new PafItem();
        item1.setType("Postcode");
        item1.setId(id);
        items.add(item1);
        pafIdResponse.setItems(items);
        return pafIdResponse;
    }


    @Test
    public void testWeGetCountryBackWhenAllGood3PafCalls() throws ConnectionException, InterruptedException {
        String postcode = "MK1 1AB";
        String id = "GB|SOME|ID";
        String countryName = "UNITED REPUBLIC OF YOUR MUM";

        PafAddress pafAddress = new PafAddress();
        pafAddress.setHomeCountry(countryName);

        PafDetailResponse pafDeatils = new PafDetailResponse();
        pafDeatils.setAddress(pafAddress);

        PafIdResponse pafIdResponse = generateDefaultPafResponse(id);

        Mockito.when(pafClient.fetchPafIdResponse(postcode)).thenReturn(pafIdResponse);
        Mockito.when(pafClient.fetchPafIdAndPostcodeResponse(postcode, id)).thenReturn(id);
        Mockito.when(pafClient.fetchPafDetailResponse(id)).thenReturn(pafDeatils);

        String country = pafService.fetchCountry(postcode);
        assertThat(country, equalTo(countryName));

    }

    @Test
    public void testWeGetCountryBackWhenAllGood2PafCalls() throws ConnectionException, InterruptedException {
        String postcode = "MK1 1AB";
        String id = "GB|SOME|ID";
        String countryName = "ENGLAND";

        PafAddress pafAddress = new PafAddress();
        pafAddress.setHomeCountry(countryName);

        PafDetailResponse pafDeatils = new PafDetailResponse();
        pafDeatils.setAddress(pafAddress);

        PafIdResponse pafIdResponse = generateDefaultPafResponse(id);
        pafIdResponse.getItems().get(0).setType("Address");

        Mockito.when(pafClient.fetchPafIdResponse(postcode)).thenReturn(pafIdResponse);
        Mockito.when(pafClient.fetchPafDetailResponse(id)).thenReturn(pafDeatils);

        String country = pafService.fetchCountry(postcode);
        verify(pafClient,Mockito.times(1)).fetchPafIdResponse(postcode);
        verify(pafClient,Mockito.times(1)).fetchPafDetailResponse(id);
        verify(pafClient,Mockito.times(0)).fetchPafIdAndPostcodeResponse(postcode,id);
        assertThat(country, equalTo(countryName));

    }

    @Test
    public void testWeGetCountryWhentypeIsNotAddress() throws ConnectionException, InterruptedException {
        String postcode = "MK1 1AB";
        String id = "GB|SOME|ID";
        String countryName = "England";

        PafAddress pafAddress = new PafAddress();
        pafAddress.setHomeCountry(countryName);

        PafDetailResponse pafDetails = new PafDetailResponse();
        pafDetails.setAddress(pafAddress);

        PafIdResponse pafIdResponse = generateDefaultPafResponse(id);
        pafIdResponse.getItems().get(0).setType("BuildingName");

        Mockito.when(pafClient.fetchPafIdResponse(postcode)).thenReturn(pafIdResponse);
        Mockito.when(pafClient.fetchPafIdAndPostcodeResponse(postcode,id)).thenReturn(id);
        Mockito.when(pafClient.fetchPafDetailResponse(id)).thenReturn(pafDetails);

        String country = pafService.fetchCountry(postcode);
        verify(pafClient,Mockito.times(1)).fetchPafIdResponse(postcode);
        verify(pafClient,Mockito.times(1)).fetchPafDetailResponse(id);
        verify(pafClient,Mockito.times(1)).fetchPafIdAndPostcodeResponse(postcode,id);
        assertThat(country, equalTo("England"));

    }

}

package com.santanderuk.corinthian.services.retentions.functional.dealspdf;

import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.retentions.functional.FunctionalTest;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import static com.jayway.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
public class PDFFunctionalTest extends FunctionalTest {
    private Header authorizationHeader;
    private Header contentType;
    private Header accept;

    @BeforeEach
    public void setUp() {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/pdf");
    }

    @Test
    public void testWeGetCorrectPDFBack() throws IOException {

        DateTime secondFebTwentyNineteen = new DateTime(2019, 2, 2, 9, 15);

        DateTimeUtils.setCurrentMillisFixed(secondFebTwentyNineteen.getMillis());

        int accountNumber = 123456;
        String dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals-pdf", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/one-product.json");

        ExtractableResponse result =
                given().
                        header(authorizationHeader).
                        header(contentType).
                        header(accept).
                        body("{\"loansSelected\":[" +
                                "{\"loanScheme\":\"3R\"," +
                                "\"sequenceNumber\":2}" +
                                "]}").
                        when().
                        post(dealsEndpoint).
                        then().
                        statusCode(201).
                        and().
                        contentType("application/pdf")
                        .extract();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(result.body().asByteArray());
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("2 Year Tracker"));
        assertTrue(text.contains("1.09%"));
        assertTrue(text.contains("BoE BR* + 0.99%"));
        assertTrue(text.contains("£999.99"));
        assertTrue(text.contains("£724.79"));
        assertTrue(text.contains("£739.12"));
        assertTrue(text.contains("23.56%"));
        assertTrue(text.contains("12.12%"));


        // As is a single loan this text should not appear
        assertFalse(text.contains("Current mortgage"));
        assertTrue(text.contains("After the initial rate period they move onto the Santander's Follow-on Rate"));
        assertFalse(text.contains("After the deal ends, your mortgage will move to the Standard Variable Rate (SVR). This doesn't apply to Lifetime Tracker or SVR \nmortgages. The SVR is a variable rate that we can change."));

        File testPdf = new File(filename);
        testPdf.delete();
    }

    @Test
    public void testWeGetCorrectPDFWithSVR() throws IOException {

        DateTime secondFebTwentyNineteen = new DateTime(2019, 2, 2, 9, 15);

        DateTimeUtils.setCurrentMillisFixed(secondFebTwentyNineteen.getMillis());

        int accountNumber = 123456;
        String dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals-pdf", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/11169738/anmf-customer-info.json");

        stubANMFAccountInfo(accountNumber, "/11169738/anmf-account-details.json");
        stubANMFPropertyInfoV2(accountNumber, "/11169738/anmf-property-info.json");

        stubMortgageDealsProduct("/11169738/mortgage-deals.json");

        ExtractableResponse result =
                given().
                        header(authorizationHeader).
                        header(contentType).
                        header(accept).
                        body("{\"loansSelected\":[" +
                                "{\"loanScheme\":\"3I\"," +
                                "\"sequenceNumber\":2}" +
                                "]}").
                        when().
                        post(dealsEndpoint).
                        then().
                        statusCode(201).
                        and().
                        contentType("application/pdf")
                        .extract();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(result.body().asByteArray());
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Standard Variable Rate"));
        assertTrue(text.contains("After the deal ends, your mortgage will move to the Standard Variable Rate (SVR). This doesn't apply to Lifetime Tracker or SVR \nmortgages. The SVR is a variable rate that we can change."));
        assertFalse(text.contains("After the initial rate period they move onto the Santander's Follow-on Rate"));
        File testPdf = new File(filename);
        testPdf.delete();
    }

    @Test
    public void testStepErcText() throws IOException {

        DateTime secondFebTwentyNineteen = new DateTime(2019, 2, 2, 9, 15);

        DateTimeUtils.setCurrentMillisFixed(secondFebTwentyNineteen.getMillis());

        int accountNumber = 123456;
        String dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals-pdf", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/two-loans.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/two-products-one-stepErc.json");

        ExtractableResponse result =
                given().
                        header(authorizationHeader).
                        header(contentType).
                        header(accept).
                        body("{\"loansSelected\":[" +
                                "{\"loanScheme\":\"3R\"," +
                                "\"sequenceNumber\":2}" +
                                "]}").
                        when().
                        post(dealsEndpoint).
                        then().
                        statusCode(201).
                        and().
                        contentType("application/pdf")
                        .extract();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(result.body().asByteArray());
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        // When there is two products, we cannot realistically see the table but we will check that
        // the values are there
        assertTrue(text.contains("2 Year Tracker"));
        assertTrue(text.contains("1.09%"));
        assertTrue(text.contains("BoE BR* + 0.99%"));
        assertTrue(text.contains("£999.99"));
        assertTrue(text.contains("£724.79"));
        assertTrue(text.contains("£739.12"));
        assertTrue(text.contains("23.56%"));
        assertTrue(text.contains("12.12%"));


        assertTrue(text.contains("3 Year Fixed"));
        assertTrue(text.contains("2.09%"));
        assertTrue(text.contains("£1099.99"));
        assertTrue(text.contains("£824.79"));
        assertTrue(text.contains("£839.12"));
        assertTrue(text.contains("33.56%"));
        assertTrue(text.contains("3.00%"));

        // Same for loans. We cannot really check the rows so we will check all the data is there
        assertTrue(text.contains("STANDARD VARIABLE RATE"));
        assertTrue(text.contains("Yes"));
        assertTrue(text.contains("4.34%"));
        assertTrue(text.contains("50,500.77"));
        assertTrue(text.contains("£797.94"));

        assertTrue(text.contains("STANDARD FIXED RATE"));
        assertTrue(text.contains("No"));
        assertTrue(text.contains("7.34%"));
        assertTrue(text.contains("£67,890.90"));
        assertTrue(text.contains("£976.23"));

        assertTrue(text.contains("Early Repayment Charges apply on deals where the ERC is indicated as a percentage amount, in the table above. This is the "));
        assertTrue(text.contains("percentage charge to repay this mortgage deal early, or if you transferred to a new deal while the charge still applied. It's also the "));
        assertTrue(text.contains("percentage charge on overpayments greater than your annual overpayment allowance. The charge is stepped which means it reduces "));
        assertTrue(text.contains("over the term of the deal. Full details can be found in the mortgage offer document, which is provided as part of any transfer. Where "));
        assertTrue(text.contains("indicated, products that have 'No charge', can pay off as much as you like, without an Early Repayment Charge."));

        File testPdf = new File(filename);
        testPdf.delete();
    }


    @Test
    public void testWeGetCorrectPDFBackTwoLoansTwoProductsSelectedOnlyFirstOne() throws IOException {

        DateTime secondFebTwentyNineteen = new DateTime(2019, 2, 2, 9, 15);

        DateTimeUtils.setCurrentMillisFixed(secondFebTwentyNineteen.getMillis());

        int accountNumber = 123456;
        String dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals-pdf", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/two-loans.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/two-products.json");

        ExtractableResponse result =
                given().
                        header(authorizationHeader).
                        header(contentType).
                        header(accept).
                        body("{\"loansSelected\":[" +
                                "{\"loanScheme\":\"3R\"," +
                                "\"sequenceNumber\":2}" +
                                "]}").
                        when().
                        post(dealsEndpoint).
                        then().
                        statusCode(201).
                        and().
                        contentType("application/pdf")
                        .extract();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(result.body().asByteArray());
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        // When there is two products, we cannot realistically see the table but we will check that
        // the values are there
        assertTrue(text.contains("2 Year Tracker"));
        assertTrue(text.contains("1.09%"));
        assertTrue(text.contains("BoE BR* + 0.99%"));
        assertTrue(text.contains("£999.99"));
        assertTrue(text.contains("£724.79"));
        assertTrue(text.contains("£739.12"));
        assertTrue(text.contains("23.56%"));
        assertTrue(text.contains("12.12%"));


        assertTrue(text.contains("3 Year Fixed"));
        assertTrue(text.contains("2.09%"));
        assertTrue(text.contains("£1099.99"));
        assertTrue(text.contains("£824.79"));
        assertTrue(text.contains("£839.12"));
        assertTrue(text.contains("33.56%"));
        assertTrue(text.contains("22.12%"));

        // Same for loans. We cannot really check the rows so we will check all the data is there
        assertTrue(text.contains("STANDARD VARIABLE RATE"));
        assertTrue(text.contains("Yes"));
        assertTrue(text.contains("4.34%"));
        assertTrue(text.contains("50,500.77"));
        assertTrue(text.contains("£797.94"));

        assertTrue(text.contains("STANDARD FIXED RATE"));
        assertTrue(text.contains("No"));
        assertTrue(text.contains("7.34%"));
        assertTrue(text.contains("£67,890.90"));
        assertTrue(text.contains("£976.23"));

        assertTrue(text.contains("Early Repayment Charges apply on deals where the ERC is indicated as a percentage amount, in the table above. This is the "));
        assertTrue(text.contains("percentage charge to repay this mortgage deal early, or if you transferred to a new deal while the charge still applied. It's also the "));
        assertTrue(text.contains("percentage charge on overpayments greater than your annual overpayment allowance. Where indicated, products that have 'No "));
        assertTrue(text.contains("charge', can pay off as much as you like, without an Early Repayment Charge."));


        File testPdf = new File(filename);
        testPdf.delete();
    }

    @Test
    public void thereIsAProductButIsNotEligible() throws IOException {

        DateTime secondFebTwentyNineteen = new DateTime(2019, 2, 2, 9, 15);

        DateTimeUtils.setCurrentMillisFixed(secondFebTwentyNineteen.getMillis());

        int accountNumber = 123456;
        String dealsEndpoint = String.format("http://localhost:%s/retentions-service/%s/deals-pdf", serverPort, accountNumber);

        stubHeartBeat("/heartbeat/heartbeat-response.json");
        stubAnmfCustomerInfo("/anmf/anmf-borrower/mortgage-customer-details-default-response.json");

        stubANMFAccountInfo(accountNumber, "/new-deals/anmf-account-service/one-loan.json");
        stubANMFPropertyInfoV2(accountNumber, "/new-deals/anmf-property-info/anmf-property-info.json");

        stubMortgageDealsProduct("/new-deals/mortgage-deals-products/no-eligible-products.json");

        ExtractableResponse result =
                given().
                        header(authorizationHeader).
                        header(contentType).
                        header(accept).
                        body("{\"loansSelected\":[" +
                                "{\"loanScheme\":\"3R\"," +
                                "\"sequenceNumber\":2}" +
                                "]}").
                        when().
                        post(dealsEndpoint).
                        then().
                        statusCode(201).
                        and().
                        contentType("application/pdf")
                        .extract();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(result.body().asByteArray());
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        // There is no much that we can test I'm afraid. Just we have the pdf and didn't crash
        // due to lack of deals data

        // As is a single loan this text should not appear
        assertFalse(text.contains("Current mortgage"));

        File testPdf = new File(filename);
        testPdf.delete();
    }
}

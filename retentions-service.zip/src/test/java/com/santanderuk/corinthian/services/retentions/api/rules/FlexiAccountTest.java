package com.santanderuk.corinthian.services.retentions.api.rules;

import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.AccountResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.rules.account.FlexiODMEligibility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FlexiAccountTest extends RuleTest {

    FlexiODMEligibility rule;

    @BeforeEach
    public void setUp() {
        rule = new FlexiODMEligibility();
    }


    @Test
    public void testWeSetBlockerWhenFlexiEligibilyIsN() {

        Loan loan = buildLoanPartsResponse("FLEXIBLE");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(loan));

        OdmEligibilityResponse odmEligibilityResponse = createOdmEligibilityResponseWithFlexiEligibility("N");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertTrue(eligibilityResponse.getBlockers().isFlexi());
    }

    @Test
    public void testWeSetBlockerWhenFlexiEligibilyIsY() {

        Loan loan = buildLoanPartsResponse("FLEXIBLE");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(loan));

        OdmEligibilityResponse odmEligibilityResponse = createOdmEligibilityResponseWithFlexiEligibility("Y");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertFalse(eligibilityResponse.getBlockers().isFlexi());
    }

    @Test
    public void testWeSetBlockerWhenSVRFlexiEligibilyIsN() {

        Loan loan = buildLoanPartsResponse("SVR");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(loan));

        OdmEligibilityResponse odmEligibilityResponse = createOdmEligibilityResponseWithFlexiEligibility("N");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertTrue(eligibilityResponse.getBlockers().isFlexi());
    }

    @Test
    public void testWeSetBlockerWhenSVRFlexiEligibilyIsY() {

        Loan loan = buildLoanPartsResponse("SVR");
        EligibilityResponse eligibilityResponse = buildEligibilityResponse(Arrays.asList(loan));

        OdmEligibilityResponse odmEligibilityResponse = createOdmEligibilityResponseWithFlexiEligibility("Y");

        rule.isEligible(eligibilityResponse, odmEligibilityResponse);

        assertFalse(eligibilityResponse.getBlockers().isFlexi());
    }

    private OdmEligibilityResponse createOdmEligibilityResponseWithFlexiEligibility(String flexiEligibility) {
        OdmEligibilityResponse odmEligibilityResponse = new OdmEligibilityResponse();
        AccountResponse account = new AccountResponse();
        account.setFlexiEligibility(flexiEligibility);
        odmEligibilityResponse.setAccountResponse(account);
        return odmEligibilityResponse;
    }

}

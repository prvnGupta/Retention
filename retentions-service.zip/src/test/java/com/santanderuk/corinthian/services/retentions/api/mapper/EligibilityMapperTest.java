package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.AccountResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.ODMLoanResponse;
import com.santanderuk.corinthian.services.retentions.api.model.eligibilitycore.response.OdmEligibilityResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class EligibilityMapperTest {

    EligibilityMapper mapper;

    @BeforeEach
    public void setUp() {
        mapper = new EligibilityMapper();
    }

    @Test
    public void testWeMapCorrectlyWhenIsEligible() {
        AccountResponse accountResponse = new AccountResponse();
        accountResponse.setAccountEligibility("Y");
        accountResponse.setAccountBalanceEligibility("Y");
        accountResponse.setAccountBand("0");

        OdmEligibilityResponse coreResponse = new OdmEligibilityResponse();
        accountResponse.setMinimumBalance(new BigDecimal("1000"));
        accountResponse.setLoanResponse(buildEligibleLoanParts());
        coreResponse.setAccountResponse(accountResponse);

        EligibilityResponse response = mapper.toEligibilityResponse(coreResponse);

        assertThat(response.getBlockers().isAccountIneligible(), equalTo(false));
        assertThat(response.getBlockers().isAccountBalanceBelowThreshold(), equalTo(false));
        assertThat(response.getBlockers().isAllLoansIneligible(), equalTo(false));
        assertThat(response.getBlockers().isAllLoansERC(), equalTo(false));
    }

    private ArrayList<ODMLoanResponse> buildEligibleLoanParts() {
        ArrayList<ODMLoanResponse> loanListResponse = new ArrayList<>();
        ODMLoanResponse l1 = new ODMLoanResponse();
        l1.setLoanID("1");
        l1.setLoanEligibility("Y");
        l1.setErcEligibility("Y");
        loanListResponse.add(l1);
        ODMLoanResponse l2 = new ODMLoanResponse();
        l2.setLoanID("2");
        l2.setLoanEligibility("N");
        l2.setErcEligibility("N");
        loanListResponse.add(l2);
        return loanListResponse;
    }

}

package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.ProductTransferFeePayment;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ProductTransferUpdateFeePaymentMapperTest {

    UpdateFeePaymentMapper updateFeePaymentMapper;

    @Mock
    private InternalTransferConfig mockConfig;

    @Spy
    private ObjectMapper objectMapper;

    protected String jwtWithCustomer554;

    @BeforeEach
    void setUp() {
        Clock fixedClock = Clock.fixed(Instant.parse("2019-10-03T10:15:30.00Z"), ZoneId.systemDefault());
        jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
        updateFeePaymentMapper = new UpdateFeePaymentMapper(mockConfig, objectMapper, fixedClock);
        Mockito.when(mockConfig.getAgentId()).thenReturn("CORINTHIAN");
        Mockito.when(mockConfig.getPaymentsDestinationAccNo()).thenReturn("090127 25319954");
    }

    @Test
    void map() throws IOException {
        ProductTransferFeePayment productTransferFeePayment = updateFeePaymentMapper.generateRequest(createRequest(), createOffer(), "payment-id", jwtWithCustomer554);

        assertEquals("CORINTHIAN", productTransferFeePayment.getAgentId());
        assertEquals("090127 25319954", productTransferFeePayment.getAnmfAccountNumber());
        assertEquals("090128 12312323", productTransferFeePayment.getOriginatingDetails());
        assertEquals("MR UFER CARY LISA", productTransferFeePayment.getOriginatorName());
        assertEquals("payment-id", productTransferFeePayment.getPaymentId());
        assertEquals("ANMF12345678", productTransferFeePayment.getReference());
        assertEquals(new BigDecimal("999"), productTransferFeePayment.getAmount());
        assertEquals("2019-10-03 11:15:30", productTransferFeePayment.getPaymentDateTime());
    }

    @Test
    void shouldMapForSavingAccountCorrectly() throws IOException {
        ProductTransferFeePayment productTransferFeePayment = updateFeePaymentMapper.generateRequest(createSavingAccountRequest(), createOffer(), "payment-id", jwtWithCustomer554);

        assertEquals("X12345678", productTransferFeePayment.getOriginatorName());
        assertEquals("090127 25319954", productTransferFeePayment.getAnmfAccountNumber());
        assertEquals("SAVING - X12345678", productTransferFeePayment.getOriginatingDetails());
    }

    private OnlineOfferEntity createOffer() {
        OnlineOfferEntity onlineOfferEntity = new OnlineOfferEntity();
        onlineOfferEntity.setOfferAcceptedBy("Sponge Bob");
        onlineOfferEntity.setAnmfAccountNumber("ANMF12345678");
        onlineOfferEntity.setCoreRetentionsData("{\n" +
                "\"selectedDeal\": {\n" +
                "  \"product\": {\n" +
                "    \"productFee\": 999\n" +
                "  }\n" +
                "},\n" +
                "\"customerDetailsResponse\": {\n" +
                "  \"CustomerServiceResponse\": {\n" +
                "    \"o_struc\": {\n" +
                "      \"o_account_title\": \"MR C L UFER\",\n" +
                "      \"o_customer_list\": [\n" +
                "        {\n" +
                "          \"osurname\": \"UFER\",\n" +
                "          \"o_surname\": \"UFER\",\n" +
                "          \"ofaxNumber\": \"\",\n" +
                "          \"oforename1\": \"CARY\",\n" +
                "          \"oforename2\": \"LISA\",\n" +
                "          \"oforename3\": \"\",\n" +
                "          \"ohomePhone\": \"\",\n" +
                "          \"o_forename1\": \"CARY\",\n" +
                "          \"o_forename2\": \"LISA\",\n" +
                "          \"o_forename3\": \"\",\n" +
                "          \"o_customer_id\": 554,\n" +
                "          \"ocustomerTitle\": \"MR\",\n" +
                "          \"o_customer_title\": \"MR\"\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  }\n" +
                "}\n" +
                "}");
        return onlineOfferEntity;
    }

    private AcceptAndPayInSessionRequest createRequest() {
        AcceptAndPayInSessionRequest request = new AcceptAndPayInSessionRequest();
        request.setAccountFrom("09012812312323");
        return request;
    }

    private AcceptAndPayInSessionRequest createSavingAccountRequest() {
        AcceptAndPayInSessionRequest request = new AcceptAndPayInSessionRequest();
        request.setAccountFrom("SAVINGX12345678ABC");
        return request;
    }
}

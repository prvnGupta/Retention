package com.santanderuk.corinthian.services.retentions.api.clients;

import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.retentions.api.exceptions.UpdateFeeException;
import com.santanderuk.corinthian.services.retentions.api.mapper.coreretentionmapper.CoreRetentionsData;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.gass.OfferInfoResponseWrapper;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.UpdateOfferInfoResponse;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.ProductTransferFeePayment;
import com.santanderuk.corinthian.services.retentions.config.Config;
import com.santanderuk.corinthian.services.retentions.config.InternalTransferConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ProductSwitchClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private RestTemplate retrieveOfferInfoRestTemplate;

    @Mock
    private Config config;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    @Mock
    private InternalTransferConfig mockInternalTransferConfig;

    private ProductSwitchClient productSwitchClient;

    private static final int ACCOUNT_NUMBER = 123456;
    private static final String ESIS_REF_ID = "esis-ref-id";
    private static final String CASE_ID = "case-id-1234";

    @BeforeEach
    public void setUp() {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}");
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(config.getAcceptInSessionUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session");
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        productSwitchClient = new ProductSwitchClient(restTemplate, retrieveOfferInfoRestTemplate, config, apiManagerConfig, mockInternalTransferConfig);
    }

    @Test
    public void testGenerateHeaders() {
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");

        MultiValueMap<String, String> headers = productSwitchClient.generateRequestHeaders();

        assertEquals("client-id", headers.get("x-ibm-client-id").get(0));
        assertEquals("client-secret", headers.get("x-ibm-client-secret").get(0));
        assertEquals("application/json", headers.get("Accept").get(0));
        assertEquals("application/json", headers.get("Content-Type").get(0));
    }

    @Test
    public void testWeBuildRequestCorrectly() throws ConnectionException {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}");
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(config.getAcceptInSessionUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session");
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        ResponseEntity<UpdateOfferInfoResponse> mockResponse = generateDefaultUpdateOfferInfoResponse();

        when(restTemplate.exchange(anyString(), any(), any(), eq(UpdateOfferInfoResponse.class))).thenReturn(mockResponse);

        UpdateOfferInfoResponse response = productSwitchClient.sendUpdateRequest(ACCOUNT_NUMBER, ESIS_REF_ID);

        assertThat(response.getInfo().getStatus(), equalTo("ok"));
        assertThat(response.getInfo().getMessage(), equalTo("Data found"));
    }

    @Test
    public void testWeReturnCorrectResponseForAcceptLater() throws ConnectionException {
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        ResponseEntity<ServiceInfo> mockResponse = generateDefaultAcceptResponse();

        when(restTemplate.exchange(anyString(), any(), any(), eq(ServiceInfo.class))).thenReturn(mockResponse);

        ServiceInfo response = productSwitchClient.acceptLater(CASE_ID);

        assertThat(response.getStatus(), equalTo("ok"));
        assertThat(response.getMessage(), equalTo("Data found"));
    }

    @Test
    public void testWeReturnCorrectResponseForAcceptInSession() throws ConnectionException {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}");
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(config.getAcceptInSessionUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session");
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        ResponseEntity<ServiceInfo> mockResponse = generateDefaultAcceptResponse();

        when(restTemplate.exchange(anyString(), any(), any(), eq(ServiceInfo.class))).thenReturn(mockResponse);

        ServiceInfo response = productSwitchClient.acceptInSession(CASE_ID);

        assertThat(response.getStatus(), equalTo("ok"));
        assertThat(response.getMessage(), equalTo("Data found"));
    }

    private ResponseEntity<ServiceInfo> generateDefaultAcceptResponse() {
        ServiceInfo info = ServiceInfoCreator.ok();
        return new ResponseEntity<>(info, HttpStatus.OK);
    }
    private ResponseEntity<OfferInfoResponseWrapper> generateDefaultSaveCoreRetentionDataToDBResponse() {
        OfferInfoResponseWrapper offerInfoResponseWrapper = new OfferInfoResponseWrapper();
        offerInfoResponseWrapper.setInfo(ServiceInfoCreator.ok());

        return new ResponseEntity<>(offerInfoResponseWrapper, HttpStatus.OK);
    }

    @Test
    public void testWeReturnResponseFromRestTemplate() throws ConnectionException {
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/mortgage-offer-fulfilment/offer-info/esis-ref-id/{esisRefId}");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        ResponseEntity<OfferInfoResponse> mockResponse = generateDefaultOfferInfoResponse();

        when(retrieveOfferInfoRestTemplate.exchange(anyString(), any(), any(), eq(OfferInfoResponse.class))).thenReturn(mockResponse);

        OfferInfoResponse response = productSwitchClient.retrieveOfferInfo(ESIS_REF_ID);

        OnlineOfferEntity tableData = response.getData();

        assertThat(tableData.getCaseId(), equalTo("case-id"));
        assertThat(tableData.getAnmfAccountNumber(), equalTo("anmf-account-number"));
        assertThat(tableData.getEsisRefId(), equalTo("esis-ref-id"));
        assertThat(tableData.getOfferAcceptedBy(), equalTo("your-mum"));
        assertThat(tableData.getOfferGeneratedBy(), equalTo("your-mum"));
        assertNotNull(tableData.getCreatedDateTime());
        assertNotNull(tableData.getOfferAcceptedDateTime());
        assertNotNull(tableData.getOfferDownloadedDateTime());
        assertNotNull(tableData.getUpdatedDateTime());
    }

    @Test
    public void testWeHandleRestClientException() {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        when(restTemplate.exchange(anyString(), any(), any(), eq(UpdateOfferInfoResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> productSwitchClient.sendUpdateRequest(ACCOUNT_NUMBER, ESIS_REF_ID));
    }

    @Test
    public void testWeHandleRestClientExceptionOnRetrieve() {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}");
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(config.getAcceptInSessionUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session");
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        when(retrieveOfferInfoRestTemplate.exchange(anyString(), any(), any(), eq(OfferInfoResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> productSwitchClient.retrieveOfferInfo(ESIS_REF_ID));
    }

    @Test
    public void testWeHandleRestClientExceptionOnAcceptLater() {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}");
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(config.getAcceptInSessionUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session");
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        when(restTemplate.exchange(anyString(), any(), any(), eq(ServiceInfo.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> productSwitchClient.acceptLater(CASE_ID));
    }

    @Test
    public void testWeHandleRestClientExceptionOnAcceptInSession() {
        when(config.getUpdateOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/download");
        when(config.getRetrieveOfferInfoUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}");
        when(config.getAcceptLaterUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/bridge-transmission");
        when(config.getAcceptInSessionUrl()).thenReturn("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer/{caseId}/accept-in-session");
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        when(restTemplate.exchange(anyString(), any(), any(), eq(ServiceInfo.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> productSwitchClient.acceptInSession(CASE_ID));
    }

    @Test
    public void testWeHandleRestClientExceptionOnSavingCoreRetentionsData() {
        assertThrows(Exception.class, () -> productSwitchClient.saveCoreRetentionsDataInDB(any(), any()));
    }

    @Test
    public void testWeHandleRestClientOnSavingCoreRetentionsData() throws ConnectionException {
        when(config.getSaveRetentionDataUrl()).thenReturn("https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/product-switch-service/offer-info/esis-ref-id/{esisRefId}/gass");
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        ResponseEntity<OfferInfoResponseWrapper> mockResponse = generateDefaultSaveCoreRetentionDataToDBResponse();
        when(restTemplate.exchange(anyString(), any(), any(), eq(OfferInfoResponseWrapper.class))).thenReturn(mockResponse);
        productSwitchClient.saveCoreRetentionsDataInDB(new CoreRetentionsData(), ESIS_REF_ID);
        verify(restTemplate, times(1)).exchange(anyString(), any(), any(), eq(OfferInfoResponseWrapper.class));
    }

    @Test
    void callUpdateFee_Ok() throws UpdateFeeException {
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        when(mockInternalTransferConfig.getFeePaymentEndpoint()).thenReturn("url");
        productSwitchClient.callUpdateFee("case-id", new ProductTransferFeePayment());
        verify(restTemplate, times(1)).postForEntity(anyString(), any(), any());
    }

    @Test
    void callUpdateFee_Ko() {
        when(restTemplate.postForEntity(anyString(), any(), eq(Void.class)))
                .thenThrow(RestClientException.class);

        UpdateFeeException updateFeeException = assertThrows(UpdateFeeException.class, () -> productSwitchClient.callUpdateFee("case-id", new ProductTransferFeePayment()));
        Assertions.assertEquals("Exception while calling product-switch-service for update-fee", updateFeeException.getMessage());
    }

    private ResponseEntity<UpdateOfferInfoResponse> generateDefaultUpdateOfferInfoResponse() {
        UpdateOfferInfoResponse response = new UpdateOfferInfoResponse();
        ServiceInfo info = ServiceInfoCreator.ok();
        response.setInfo(info);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private ResponseEntity<OfferInfoResponse> generateDefaultOfferInfoResponse() {
        OfferInfoResponse response = new OfferInfoResponse();
        OnlineOfferEntity entity = generateDefaultEntity();
        ServiceInfo info = ServiceInfoCreator.ok();
        response.setInfo(info);
        response.setData(entity);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private OnlineOfferEntity generateDefaultEntity() {
        OnlineOfferEntity entity = new OnlineOfferEntity();
        entity.setCaseId("case-id");
        entity.setAnmfAccountNumber("anmf-account-number");
        entity.setEsisRefId("esis-ref-id");
        entity.setCreatedDateTime("2020-04-20 00:00:00.000");
        entity.setOfferAcceptedBy("your-mum");
        entity.setOfferGeneratedBy("your-mum");
        entity.setOfferAcceptedDateTime("2020-04-20 00:00:00.000");
        entity.setOfferDownloadedDateTime("2020-04-20 00:00:00.000");
        entity.setUpdatedDateTime("2020-04-20 00:00:00.000");
        return entity;
    }

}

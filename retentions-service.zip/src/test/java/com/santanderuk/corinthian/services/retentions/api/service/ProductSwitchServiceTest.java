package com.santanderuk.corinthian.services.retentions.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.retentions.api.clients.ProductSwitchClient;
import com.santanderuk.corinthian.services.retentions.api.exceptions.AcceptInSessionException;
import com.santanderuk.corinthian.services.retentions.api.exceptions.UpdateFeeException;
import com.santanderuk.corinthian.services.retentions.api.mapper.UpdateFeePaymentMapper;
import com.santanderuk.corinthian.services.retentions.api.model.acceptandpay.AcceptAndPayInSessionRequest;
import com.santanderuk.corinthian.services.retentions.api.model.core.productswitch.info.OnlineOfferEntity;
import com.santanderuk.corinthian.services.retentions.api.model.internalTransfer.ProductTransferFeePayment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductSwitchServiceTest {

    ProductSwitchService productSwitchService;

    @Mock
    private UpdateFeePaymentMapper mockUpdateFeePaymentMapper;

    @Mock
    private ProductSwitchClient mockProductSwitchClient;

    @BeforeEach
    void setUp() {
        productSwitchService = new ProductSwitchService(mockUpdateFeePaymentMapper, mockProductSwitchClient);
    }

    @Test
    void callUpdateFee_Ok() throws JsonProcessingException, UpdateFeeException {

        productSwitchService.callUpdateFee("case-id", new AcceptAndPayInSessionRequest(), new OnlineOfferEntity(), "payment-id", "jwtToken");

        verify(mockUpdateFeePaymentMapper, times(1)).generateRequest(any(), any(), anyString(), anyString());
        verify(mockProductSwitchClient, times(1)).callUpdateFee(anyString(), any());
    }

    @Test
    void callUpdateFee_Ko() throws JsonProcessingException, UpdateFeeException {
        when(mockUpdateFeePaymentMapper.generateRequest(any(AcceptAndPayInSessionRequest.class), any(), anyString(), anyString())).thenReturn(new ProductTransferFeePayment());
        doThrow(new UpdateFeeException("Exception while calling product switch service")).when(mockProductSwitchClient).callUpdateFee(anyString(), any(ProductTransferFeePayment.class));

        UpdateFeeException updateFeeException = assertThrows(UpdateFeeException.class, () -> productSwitchService.callUpdateFee("case-id", new AcceptAndPayInSessionRequest(), new OnlineOfferEntity(), "payment-id", "jwtToken"));
        assertEquals("Exception while calling product switch service", updateFeeException.getMessage());

        verify(mockUpdateFeePaymentMapper, times(1)).generateRequest(any(AcceptAndPayInSessionRequest.class), any(), anyString(), anyString());
        verify(mockProductSwitchClient, times(1)).callUpdateFee(anyString(), any(ProductTransferFeePayment.class));
    }

    @Test
    void callAcceptInSession_Ok() throws ConnectionException {
        productSwitchService.callAcceptInSession("case-id");
        verify(mockProductSwitchClient, times(1)).acceptInSession(anyString());
    }

    @Test
    void callAcceptInSession_Ko() throws ConnectionException {
        doThrow(ConnectionException.class).when(mockProductSwitchClient).acceptInSession(anyString());

        AcceptInSessionException acceptInSessionException = assertThrows(AcceptInSessionException.class, () -> productSwitchService.callAcceptInSession("case-id"));
        assertEquals("Error calling product-switch-service accept-in-session", acceptInSessionException.getMessage());
        verify(mockProductSwitchClient, times(1)).acceptInSession(anyString());
    }
}

package com.santanderuk.corinthian.services.retentions.cache;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.retentions.commons.CacheableOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("testCache")
@SpringBootTest
public class CatchableOperationsTests {

    @MockBean
    private HeartBeatClient heartBeatClient;

    @Autowired
    private CacheableOperations cacheableOperations;

    @Test
    public void getAnmfRegionIsCachedForSpecifiedSeconds() throws Exception {

        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        AnmfRegion anmfActiveRegion = cacheableOperations.getAnmfActiveRegion();
        assertEquals(AnmfRegion.A, anmfActiveRegion);
        verify(heartBeatClient, times(1)).fetchCurrentRegion();
        assertEquals(AnmfRegion.A, cacheableOperations.getAnmfActiveRegion());
        assertEquals(AnmfRegion.A, cacheableOperations.getAnmfActiveRegion());
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.W);
        assertEquals(AnmfRegion.A, cacheableOperations.getAnmfActiveRegion());
        cacheableOperations.getAnmfActiveRegion();
        cacheableOperations.getAnmfActiveRegion();
        cacheableOperations.getAnmfActiveRegion();
        cacheableOperations.getAnmfActiveRegion();
        cacheableOperations.getAnmfActiveRegion();
        verify(heartBeatClient, times(1)).fetchCurrentRegion();
        TimeUnit.SECONDS.sleep(3);
        anmfActiveRegion = cacheableOperations.getAnmfActiveRegion();
        assertEquals(AnmfRegion.W, anmfActiveRegion);
        verify(heartBeatClient, times(2)).fetchCurrentRegion();
    }
}

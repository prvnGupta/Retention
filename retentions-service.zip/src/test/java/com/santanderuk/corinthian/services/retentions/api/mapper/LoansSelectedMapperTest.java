package com.santanderuk.corinthian.services.retentions.api.mapper;

import com.santanderuk.corinthian.services.retentions.api.exceptions.NoDealsFoundException;
import com.santanderuk.corinthian.services.retentions.api.model.anmf.Loan;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.DealsRequest;
import com.santanderuk.corinthian.services.retentions.api.model.deals.request.LoanIdentifier;
import com.santanderuk.corinthian.services.retentions.api.model.eligibility.EligibilityResponse;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class LoansSelectedMapperTest {

    @Test
    public void testWeBuildMatchedLoansCorrectly() {

        LoansSelectedMapper loansSelectedMapper = new LoansSelectedMapper(buildDealsSelectedLoans(), buildDummyEligibilityResponse());

        List<Loan> selectedLoansList = loansSelectedMapper.getSelectedLoans();

        assertThat(selectedLoansList.size(), equalTo(3));
        assertThat(selectedLoansList.get(0).getScheme(), equalTo("3R"));
        assertThat(selectedLoansList.get(0).getSequenceNumber(), equalTo(1));
        assertThat(selectedLoansList.get(1).getScheme(), equalTo("3R"));
        assertThat(selectedLoansList.get(1).getSequenceNumber(), equalTo(2));
        assertThat(selectedLoansList.get(2).getScheme(), equalTo("3R"));
        assertThat(selectedLoansList.get(2).getSequenceNumber(), equalTo(4));

    }

    @Test
    public void balanceIsAggregated() {

        LoansSelectedMapper loansSelectedMapper = new LoansSelectedMapper(buildDealsSelectedLoans(), buildDummyEligibilityResponse());

        BigDecimal balance = loansSelectedMapper.totalMonthlyPaymentOfNotSelectedLoans();
        assertThat(balance, equalTo(new BigDecimal(2000)));
    }

    @Test
    public void shouldReturnShortestTermOfLoans() {

        LoansSelectedMapper loansSelectedMapper = new LoansSelectedMapper(buildDealsSelectedLoans(), buildDummyEligibilityResponse());

        int shortestTerm = loansSelectedMapper.getShortestTermOfMatchedLoans();

        assertThat(shortestTerm, equalTo(36));
    }

    @Test
    public void testWeThrowException() {
        EligibilityResponse eligibltyResponse = buildDummyEligibilityResponse();
        eligibltyResponse.setLoans(Collections.emptyList());
        assertThrows(NoDealsFoundException.class, () -> new LoansSelectedMapper(buildDealsSelectedLoans(), eligibltyResponse));
    }

    private DealsRequest buildDealsSelectedLoans() {
        DealsRequest selectedLoans = new DealsRequest();
        ArrayList<LoanIdentifier> loansSelected = new ArrayList<>();
        loansSelected.add(buildLoanId("3R", 1));
        loansSelected.add(buildLoanId("3R", 2));
        loansSelected.add(buildLoanId("3R", 4));
        selectedLoans.setLoansSelected(loansSelected);
        return selectedLoans;
    }

    private EligibilityResponse buildDummyEligibilityResponse() {
        EligibilityResponse eligibilityResponse = new EligibilityResponse();
        ArrayList<Loan> loans = new ArrayList<>();
        loans.add(buildDummyLoan("3R", 1, new BigDecimal("1000"), 36));
        loans.add(buildDummyLoan("3R", 2, new BigDecimal("1000"), 48));
        loans.add(buildDummyLoan("3R", 3, new BigDecimal("1000"), 60));
        loans.add(buildDummyLoan("3R", 4, new BigDecimal("1000"), 72));
        loans.add(buildDummyLoan("3R", 5, new BigDecimal("1000"), 24));
        eligibilityResponse.setLoans(loans);
        return eligibilityResponse;
    }

    private Loan buildDummyLoan(String scheme, int sequence, BigDecimal monthlyPayment, int remainingTerm) {
        Loan loan = new Loan();
        loan.setScheme(scheme);
        loan.setSequenceNumber(sequence);
        loan.setMonthlyPayment(monthlyPayment);
        loan.setRemainingTerm(remainingTerm);
        return loan;
    }

    private LoanIdentifier buildLoanId(String scheme, int sequence) {
        LoanIdentifier loanId1 = new LoanIdentifier();
        loanId1.setLoanScheme(scheme);
        loanId1.setSequenceNumber(sequence);
        return loanId1;
    }
}

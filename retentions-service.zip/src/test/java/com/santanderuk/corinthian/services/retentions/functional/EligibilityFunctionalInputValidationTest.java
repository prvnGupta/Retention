package com.santanderuk.corinthian.services.retentions.functional;

import com.jayway.restassured.response.Header;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class EligibilityFunctionalInputValidationTest extends FunctionalTest {

    private String eligibilityEndpoint;
    private Header authorizationHeader;
    private Header contentType;
    private Header accept;

    @BeforeEach
    public void setUp() {

        authorizationHeader = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        accept = new Header("Accept", "application/json");
    }

    @Test
    public void ShouldThrowValidationExceptionWhenAccountIsNotValid() throws IOException {

        DateTime secondFebTwentyNineteen = new DateTime(2019, 2, 2, 9, 15);

        DateTimeUtils.setCurrentMillisFixed(secondFebTwentyNineteen.getMillis());

        int accountNumber = -1;
        eligibilityEndpoint = String.format("http://localhost:%s/retentions-service/%s/account-eligibility", serverPort, accountNumber);


        given().
                header(authorizationHeader).
                header(contentType).
                when().
                get(eligibilityEndpoint)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT"),
                        "info.message", equalTo("The input account format is not valid")
                );
    }
}

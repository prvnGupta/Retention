package com.santanderuk.corinthian.services.retentions.api.utils;

import org.junit.jupiter.api.Test;

import java.time.*;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;

public class DateUtilsTest {

    private final DateUtils dateUtils = new DateUtils(Clock.fixed(Instant.parse("2021-01-05T10:00:00Z"), ZoneOffset.UTC));


    @Test
    public void subtractOneDayFromDateTest() {
        assertEquals("18/05/2018", dateUtils.subtractOneDay("19/05/2018"));
        assertEquals("30/04/2018", dateUtils.subtractOneDay("01/05/2018"));
        assertEquals("31/12/2018", dateUtils.subtractOneDay("01/01/2019"));
        assertEquals("28/02/2019", dateUtils.subtractOneDay("01/03/2019"));
        assertEquals("29/02/2020", dateUtils.subtractOneDay("01/03/2020"));
        assertEquals("28/02/2021", dateUtils.subtractOneDay("01/03/2021"));
        assertEquals("28/02/2022", dateUtils.subtractOneDay("01/03/2022"));
    }

    @Test
    public void testWeGetTodaysDateAsString() {

        Clock clock = Clock.fixed(Instant.parse("2018-12-22T10:15:30.00Z"), ZoneId.of("UTC"));

        String result = dateUtils.returnDateAsString(LocalDate.now(clock));

        assertThat(result, equalTo("22/12/2018"));
    }

    @Test
    public void testDate1BeforeDate2() {
        assertTrue(dateUtils.date1SoonerThanDate2("19/05/2018", "20/05/2018"));
        assertTrue(dateUtils.date1SoonerThanDate2("19/05/2018", "19/05/3018"));
        assertFalse(dateUtils.date1SoonerThanDate2("19/05/2018", "19/05/2018"));
        assertFalse(dateUtils.date1SoonerThanDate2("20/05/2018", "19/05/2018"));
    }

}
